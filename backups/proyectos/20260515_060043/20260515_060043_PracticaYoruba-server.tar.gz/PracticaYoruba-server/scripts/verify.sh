#!/bin/bash
# =============================================================================
# scripts/verify.sh
# Verificación completa del entorno de PracticaYoruba-server
# =============================================================================
# Comprueba en orden (13 checks):
#
#   1.  Variables requeridas en .env
#   2.  Apache instalado y versión 2.4.x
#   3.  Módulos Apache requeridos cargados (ssl, wsgi, headers, rewrite)
#   4.  Apache activo en puerto 80
#   5.  SSL activo en puerto 443
#   6.  Certificado SSL — días restantes (WARN/ERR según umbrales de .env)
#   7.  Django API responde (DRF retorna 4xx para GET en /api/v1/auth/login/)
#   8.  Redirect HTTP → HTTPS (301 con Location: https://)
#   9.  SPA catch-all activo (/test-spa-catch-all-practicayoruba retorna 200)
#   10. Firewall UFW activo con puertos SSH, 80 y 443 permitidos
#   11. Privilegio mínimo: clave SSL protegida, Apache no corre como root
#   12. fail2ban activo con jails sshd y apache-auth
#   13. SSH hardening efectivo — PermitRootLogin no, PasswordAuthentication no,
#       puerto SSH no estándar
#
# Muestra resumen final con contadores OK / WARN / ERR.
# Retorna exit code 0 si ERR=0, 1 si hay algún error.
#
# Uso:
#   bash scripts/verify.sh
#
# Variables del .env:
#   DOMAIN, SSL_CERT_DIR, SSL_CERT_DAYS_WARN, SSL_CERT_DAYS_ERR
#   SSH_PORT (default: 22), F2B_* (defaults seguros)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"

source "${PROJECT_ROOT}/utils/logging.sh"
source "${PROJECT_ROOT}/utils/core.sh"
source "${PROJECT_ROOT}/utils/network.sh"
source "${PROJECT_ROOT}/utils/validation.sh"

# =============================================================================
# Cargar .env
# =============================================================================
ENV_FILE="${PROJECT_ROOT}/.env"
if [[ ! -f "$ENV_FILE" ]]; then
    echo ""
    echo "  ERROR: Archivo .env no encontrado en ${PROJECT_ROOT}"
    echo "  Crea tu configuración: cp .env.example .env"
    echo ""
    exit 1
fi
set -a; source "$ENV_FILE"; set +a

# Defaults para variables de umbral
SSL_CERT_DAYS_WARN="${SSL_CERT_DAYS_WARN:-30}"
SSL_CERT_DAYS_ERR="${SSL_CERT_DAYS_ERR:-7}"

# Defaults para SSH y fail2ban — usados en checks 12 y 13
SSH_PORT="${SSH_PORT:-22}"

# =============================================================================
# Contadores OK / WARN / ERR
# =============================================================================
_OK=0; _WARN=0; _ERR=0

ok()   { log_success "  [OK]   $1"; _OK=$(( _OK + 1 ));   }
warn() { log_warn    "  [WARN] $1"; _WARN=$(( _WARN + 1 )); }
fail() { log_error   "  [ERR]  $1"; _ERR=$(( _ERR + 1 ));  }

# =============================================================================
# Check 1: Variables de entorno requeridas
# =============================================================================
check_env_vars() {
    log_header "PASO: Variables de entorno (.env)"

    local required=(
        "DOMAIN"
        "API_ROOT"
        "STATIC_ROOT"
        "MEDIA_ROOT"
        "VENV_PATH"
        "WSGI_USER"
        "WSGI_GROUP"
        "WSGI_PROCESSES"
        "WSGI_THREADS"
        "SSL_EMAIL"
        "SSL_CERT_DIR"
        "SSL_CERT_DAYS_WARN"
        "SSL_CERT_DAYS_ERR"
    )

    for var in "${required[@]}"; do
        if [[ -n "${!var:-}" ]]; then
            ok "${var}=${!var}"
        else
            fail "${var} no definido o vacío en .env"
        fi
    done
}

# =============================================================================
# Check 2: Apache instalado y versión 2.4.x
# =============================================================================
check_apache_version() {
    log_header "PASO: Apache instalado y versión"

    if ! command_exists apache2; then
        fail "apache2 no encontrado — Apache no está instalado"
        log_error "  Instala con: sudo bash provisioners/apache/install.sh"
        return
    fi

    if validate_apache_version 2 4; then
        local version_str
        version_str=$(apache2 -v 2>/dev/null \
            | grep -oE 'Apache/[0-9]+\.[0-9]+\.[0-9]+' | head -1 \
            | cut -d/ -f2)
        ok "Apache ${version_str} instalado (serie 2.4.x)"
    else
        fail "Versión de Apache incorrecta"
        log_error "  Migra con: sudo bash provisioners/apache/install.sh"
    fi
}

# =============================================================================
# Check 3: Módulos Apache requeridos cargados
# =============================================================================
check_apache_modules() {
    log_header "PASO: Módulos Apache requeridos"

    if ! command_exists apache2ctl; then
        warn "apache2ctl no encontrado — check omitido"
        return
    fi

    local modules_output
    # Suprimir stderr: apache2ctl emite un warning de ulimit en contenedores
    # que no afecta la lista de módulos pero confunde la salida del check
    modules_output=$(apache2ctl -M 2>/dev/null || echo "")

    if [[ -z "$modules_output" ]]; then
        warn "No se pudo obtener la lista de módulos — ¿está Apache activo?"
        return
    fi

    local required_modules=("ssl" "wsgi" "headers" "rewrite")
    for mod in "${required_modules[@]}"; do
        if echo "$modules_output" | grep -q "${mod}_module"; then
            ok "Módulo ${mod} activo"
        else
            fail "Módulo ${mod} no activo"
            log_error "  Activa con: sudo a2enmod ${mod} && sudo systemctl reload apache2"
        fi
    done
}

# =============================================================================
# Check 4: Apache activo en puerto 80
# =============================================================================
check_apache_port_80() {
    log_header "PASO: Apache activo en puerto 80"

    if tcp_is_reachable "127.0.0.1" 80 3; then
        ok "Apache responde en :80"
    else
        fail "Apache no responde en :80"
        log_error "  Arranca con: sudo systemctl start apache2"
        log_error "  Estado: sudo systemctl status apache2"
    fi
}

# =============================================================================
# Check 5: SSL activo en puerto 443
# =============================================================================
check_ssl_port_443() {
    log_header "PASO: SSL activo en puerto 443"

    if tcp_is_reachable "127.0.0.1" 443 3; then
        ok "SSL responde en :443"
    else
        fail "SSL no responde en :443"
        log_error "  Verifica el certificado: sudo bash provisioners/ssl/setup_ssl.sh"
        log_error "  Verifica el virtualhost: sudo bash provisioners/apache/setup_vhost.sh"
    fi
}

# =============================================================================
# Check 6: Certificado SSL — días restantes
# =============================================================================
check_ssl_cert() {
    log_header "PASO: Certificado SSL — días restantes"

    local cert_file="${SSL_CERT_DIR}/cert.pem"

    # validate_ssl_cert retorna siempre 0 y exporta SSL_CERT_STATUS
    validate_ssl_cert "$cert_file" "$SSL_CERT_DAYS_WARN" "$SSL_CERT_DAYS_ERR"

    case "$SSL_CERT_STATUS" in
        OK)
            ok "Certificado SSL válido"
            ;;
        WARN)
            warn "Certificado próximo a vencer"
            log_warn "  Renueva con: bash scripts/renew_ssl.sh"
            ;;
        ERR)
            fail "Certificado vencido o no encontrado"
            log_error "  Renueva con: bash scripts/renew_ssl.sh"
            log_error "  O emite nuevo: sudo bash provisioners/ssl/setup_ssl.sh"
            ;;
    esac
}

# =============================================================================
# Check 7: Django API responde
# GET /api/v1/auth/login/ → DRF retorna 405 (POST-only endpoint)
# Cualquier 4xx es aceptable (DRF + autenticación)
# 5xx o 000 indica error del servidor
# =============================================================================
check_django_api() {
    log_header "PASO: Django API responde"

    if ! command_exists curl; then
        warn "curl no disponible — check omitido"
        return
    fi

    local http_code
    http_code=$(curl \
        --silent \
        --max-time 10 \
        --insecure \
        --output /dev/null \
        --write-out "%{http_code}" \
        "https://${DOMAIN}/api/v1/auth/login/" 2>/dev/null \
        || true)
    [[ -z "$http_code" ]] && http_code="000"

    # 000 = conexión rechazada o timeout
    if [[ "$http_code" == "000" ]]; then
        fail "Django API no responde (timeout o conexión rechazada)"
        log_error "  Verifica que Apache y mod_wsgi están activos"
        log_error "  Logs: sudo tail -f /var/log/apache2/practicayoruba-https-error.log"
        return
    fi

    # 5xx = error del servidor Django o mod_wsgi
    if [[ "${http_code:0:1}" == "5" ]]; then
        fail "Django API error de servidor: HTTP ${http_code}"
        log_error "  Logs: sudo tail -f /var/log/apache2/practicayoruba-https-error.log"
        return
    fi

    # 4xx = DRF respondió correctamente (autenticación requerida, método no permitido, etc.)
    # 2xx = también es válido (si el endpoint permite GET sin auth)
    ok "Django API responde: HTTP ${http_code}"
}

# =============================================================================
# Check 8: Redirect HTTP → HTTPS
# curl a http://DOMAIN/ debe retornar 301 con Location: https://
# =============================================================================
check_http_redirect() {
    log_header "PASO: Redirect HTTP → HTTPS"

    if ! command_exists curl; then
        warn "curl no disponible — check omitido"
        return
    fi

    local http_code location_header
    http_code=$(curl \
        --silent \
        --max-time 10 \
        --output /dev/null \
        --write-out "%{http_code}" \
        "http://${DOMAIN}/" 2>/dev/null \
        || true)
    [[ -z "$http_code" ]] && http_code="000"

    location_header=$(curl \
        --silent \
        --max-time 10 \
        --head \
        "http://${DOMAIN}/" 2>/dev/null \
        | grep -i "^location:" | head -1 \
        || echo "")

    if [[ "$http_code" == "000" ]]; then
        fail "No hay respuesta en http://${DOMAIN}/ (puerto 80)"
        log_error "  ¿Apache activo? sudo systemctl status apache2"
        return
    fi

    if [[ "$http_code" != "301" ]]; then
        fail "Redirect HTTP → HTTPS no es 301 (obtenido: HTTP ${http_code})"
        log_error "  Verifica el virtualhost HTTP: config/apache/practicayoruba-http.conf"
        return
    fi

    if echo "$location_header" | grep -qi "https://"; then
        ok "Redirect HTTP → HTTPS: 301 → ${location_header#*: }"
    else
        fail "Redirect 301 pero Location no apunta a HTTPS: ${location_header}"
        log_error "  Verifica: config/apache/practicayoruba-http.conf"
    fi
}

# =============================================================================
# Check 9: SPA catch-all activo
# Una ruta inexistente debe retornar HTTP 200 (index.html del UI)
# Si retorna 404: la vista serve_spa no está activa (UI_DIST no configurado)
# =============================================================================
check_spa_catchall() {
    log_header "PASO: SPA catch-all activo"

    if ! command_exists curl; then
        warn "curl no disponible — check omitido"
        return
    fi

    # Ruta claramente inexistente — no debe coincidir con ningún endpoint del API
    local test_path="/test-spa-catch-all-practicayoruba"
    local http_code
    http_code=$(curl \
        --silent \
        --max-time 10 \
        --insecure \
        --output /dev/null \
        --write-out "%{http_code}" \
        "https://${DOMAIN}${test_path}" 2>/dev/null \
        || true)
    [[ -z "$http_code" ]] && http_code="000"

    if [[ "$http_code" == "000" ]]; then
        fail "Sin respuesta en https://${DOMAIN}${test_path}"
        return
    fi

    if [[ "$http_code" == "200" ]]; then
        ok "SPA catch-all activo — HTTP ${http_code} (serve_spa sirviendo index.html)"
    elif [[ "$http_code" == "404" ]]; then
        fail "SPA catch-all inactivo — HTTP 404"
        log_error "  UI_DIST no está configurado en el .env de PracticaYoruba-api"
        log_error "  O la vista serve_spa no está en config/urls.py"
        log_error "  Ver: PracticaYoruba-api commit 8ee87c6 (Fase 0, T-PC)"
    else
        fail "SPA catch-all: respuesta inesperada — HTTP ${http_code}"
        log_error "  Se esperaba HTTP 200 (catch-all) o HTTP 404 (sin catch-all)"
    fi
}

# =============================================================================
# Check 10: Firewall UFW activo con puertos correctos
# =============================================================================
check_firewall() {
    log_header "PASO: Firewall UFW — puertos permitidos"

    if ! command_exists ufw; then
        warn "ufw no encontrado — firewall no verificado"
        log_warn "  Instala con: sudo apt-get install ufw"
        log_warn "  Configura con: sudo bash provisioners/firewall/setup_firewall.sh"
        return
    fi

    local ufw_status_line
    ufw_status_line=$(ufw status 2>/dev/null | head -1)

    if ! echo "$ufw_status_line" | grep -q "Status: active"; then
        fail "UFW inactivo — el servidor está expuesto sin firewall"
        log_error "  Configura con: sudo bash provisioners/firewall/setup_firewall.sh"
        return
    fi
    ok "UFW activo"

    local ufw_rules
    ufw_rules=$(ufw status 2>/dev/null)

    # SSH_PORT configurable — default 22
    local ssh_port="${SSH_PORT:-22}"
    local required_ports=("$ssh_port" "80" "443")
    local port_names=("SSH(${ssh_port})" "HTTP(80)" "HTTPS(443)")

    local i=0
    for port in "${required_ports[@]}"; do
        if echo "$ufw_rules" | grep -qE "^${port}[[:space:]]|^${port}/tcp[[:space:]]"; then
            ok "Puerto ${port_names[$i]} permitido en UFW"
        else
            fail "Puerto ${port_names[$i]} NO permitido en UFW"
            log_error "  Corrige con: sudo ufw allow ${port}/tcp"
        fi
        i=$(( i + 1 ))
    done
}

# =============================================================================
# Check 11: Privilegio mínimo — clave SSL y proceso Apache
# =============================================================================
check_min_privilege() {
    log_header "PASO: Privilegio mínimo"

    # 11a. Permisos de la clave SSL privada — debe ser 600 (solo root puede leer)
    local key_file="${SSL_CERT_DIR:-/etc/ssl/practicayoruba}/key.pem"

    if [[ ! -f "$key_file" ]]; then
        warn "Clave SSL no encontrada (${key_file}) — check de permisos omitido"
    else
        local key_perms
        key_perms=$(stat -c "%a" "$key_file" 2>/dev/null || echo "000")
        if [[ "$key_perms" == "600" || "$key_perms" == "640" ]]; then
            ok "Clave SSL: permisos ${key_perms} — solo propietario puede leer"
        else
            fail "Clave SSL: permisos ${key_perms} — deben ser 600"
            log_error "  Corrige con: sudo chmod 600 ${key_file}"
            log_error "  Una clave con permisos abiertos expone el certificado SSL"
        fi
    fi

    # 11b. Proceso Apache no corre como root (solo el proceso master necesita root)
    # Los workers de mod_wsgi deben correr como WSGI_USER (www-data por defecto)
    local apache_workers
    apache_workers=$(ps -eo user,comm 2>/dev/null \
        | grep apache2 \
        | grep -v "^root" \
        | awk '{print $1}' \
        | sort -u \
        | head -3 \
        || echo "")

    if [[ -z "$apache_workers" ]]; then
        # Puede ser que Apache no esté corriendo o ps no muestre workers aún
        warn "No se pudo verificar el usuario de los workers Apache"
        log_warn "  Verifica manualmente: ps -eo user,comm | grep apache2"
    else
        local worker_user
        worker_user=$(echo "$apache_workers" | head -1)
        if [[ "$worker_user" == "root" ]]; then
            fail "Workers Apache corriendo como root — riesgo de seguridad"
            log_error "  Verifica WSGIDaemonProcess user= en el virtualhost HTTPS"
        else
            ok "Workers Apache corriendo como ${worker_user} (no root)"
        fi
    fi
}

# =============================================================================
# Check 12: fail2ban activo con jails sshd y apache-auth
# =============================================================================
check_fail2ban() {
    log_header "PASO: fail2ban — jails activas"

    # fail2ban no instalado → warn, no fail
    # Es una capa de seguridad adicional, no crítica para la aplicación
    if ! command_exists fail2ban-client; then
        warn "fail2ban no instalado"
        log_warn "  Instala con: sudo bash provisioners/security/setup_fail2ban.sh"
        return
    fi

    # Verificar que el servicio está activo
    # svc_is_active usa systemctl si hay systemd, o 'service' si no
    if ! svc_is_active fail2ban; then
        fail "fail2ban instalado pero inactivo"
        log_error "  Arranca con: sudo systemctl start fail2ban"
        log_error "  O reconfigura: sudo bash provisioners/security/setup_fail2ban.sh"
        return
    fi
    ok "fail2ban activo"

    # Verificar jails — fail2ban-client status requiere root (socket /run/fail2ban/)
    # Si no hay acceso, emitir warn en lugar de fail para no penalizar ejecución sin sudo
    local socket_accessible=false
    if fail2ban-client status &>/dev/null; then
        socket_accessible=true
    fi

    if [[ "$socket_accessible" == "false" ]]; then
        warn "fail2ban corriendo — jails no verificadas (ejecuta con sudo para detalles)"
        log_warn "  sudo fail2ban-client status sshd"
        log_warn "  sudo fail2ban-client status apache-auth"
        return
    fi

    # Con acceso al socket, verificar cada jail
    for jail in sshd apache-auth; do
        if fail2ban-client status "$jail" &>/dev/null; then
            ok "Jail '${jail}' activa"
        else
            fail "Jail '${jail}' no activa"
            log_error "  Reconfigura: sudo bash provisioners/security/setup_fail2ban.sh"
        fi
    done
}

# =============================================================================
# Check 13: SSH hardening efectivo
# Usa sshd -T que vuelca la configuración efectiva incluyendo overrides
# (funciona sin root — lee archivos de configuración, no el socket del servicio)
# =============================================================================
check_ssh_hardening() {
    log_header "PASO: SSH hardening — configuración efectiva"

    if ! command_exists sshd; then
        warn "sshd no encontrado — check omitido"
        return
    fi

    # sshd -T vuelca la configuración efectiva incluyendo sshd_config.d/*.conf
    local sshd_config
    sshd_config=$(sshd -T 2>/dev/null)

    if [[ -z "$sshd_config" ]]; then
        warn "sshd -T no retornó configuración — check omitido"
        return
    fi

    # 13a. Puerto SSH no estándar
    local effective_port
    effective_port=$(echo "$sshd_config" | grep "^port " | awk '{print $2}')

    if [[ "$effective_port" == "$SSH_PORT" && "$SSH_PORT" != "22" ]]; then
        ok "SSH Puerto: ${effective_port} (no estándar)"
    elif [[ "$effective_port" == "22" ]]; then
        warn "SSH Puerto: 22 (estándar — recomendado cambiarlo)"
        log_warn "  Configura SSH_PORT en .env y ejecuta:"
        log_warn "    sudo bash provisioners/security/setup_ssh_hardening.sh"
        log_warn "    sudo bash provisioners/firewall/setup_firewall.sh"
    else
        ok "SSH Puerto: ${effective_port}"
    fi

    # 13b. PermitRootLogin
    local effective_rootlogin
    effective_rootlogin=$(echo "$sshd_config" | grep "^permitrootlogin " | awk '{print $2}')

    if [[ "$effective_rootlogin" == "no" ]]; then
        ok "PermitRootLogin: no"
    else
        fail "PermitRootLogin: ${effective_rootlogin:-<no configurado>} (debe ser 'no')"
        log_error "  Aplica: sudo bash provisioners/security/setup_ssh_hardening.sh"
    fi

    # 13c. PasswordAuthentication
    local effective_passauth
    effective_passauth=$(echo "$sshd_config" | grep "^passwordauthentication " | awk '{print $2}')

    if [[ "$effective_passauth" == "no" ]]; then
        ok "PasswordAuthentication: no"
    else
        fail "PasswordAuthentication: ${effective_passauth:-<no configurado>} (debe ser 'no')"
        log_error "  Aplica: sudo bash provisioners/security/setup_ssh_hardening.sh"
        log_error "  ANTES verifica que tienes clave SSH autorizada en ~/.ssh/authorized_keys"
    fi
}

# =============================================================================
# MAIN
# =============================================================================
log_header "PracticaYoruba-server — Verificación completa"
log_info "  Dominio: ${DOMAIN:-<no definido>}"
echo ""

check_env_vars;        echo ""
check_apache_version;  echo ""
check_apache_modules;  echo ""
check_apache_port_80;  echo ""
check_ssl_port_443;    echo ""
check_ssl_cert;        echo ""
check_django_api;      echo ""
check_http_redirect;   echo ""
check_spa_catchall;    echo ""
check_firewall;        echo ""
check_min_privilege;   echo ""
check_fail2ban;        echo ""
check_ssh_hardening;   echo ""

# =============================================================================
# Resumen
# =============================================================================
log_separator 60 "="
echo ""
log_success  "OK:           ${_OK}"
[[ $_WARN -gt 0 ]] && log_warn "Advertencias: ${_WARN}" \
                   || log_success "Advertencias: ${_WARN}"
[[ $_ERR  -gt 0 ]] && log_error  "Errores:      ${_ERR}" \
                   || log_success "Errores:      ${_ERR}"
echo ""

if [[ $_ERR -eq 0 && $_WARN -eq 0 ]]; then
    log_success "Entorno listo para producción."
elif [[ $_ERR -eq 0 ]]; then
    log_warn "Entorno funcional con advertencias — revisa los items marcados WARN."
else
    log_error "Entorno incompleto — corrige los errores antes de usar en producción."
fi

exit $(( _ERR > 0 ? 1 : 0 ))

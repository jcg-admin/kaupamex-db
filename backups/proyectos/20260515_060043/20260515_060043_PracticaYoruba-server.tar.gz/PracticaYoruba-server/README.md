# PracticaYoruba-server

Repositorio de infraestructura de servidor web para PracticaYoruba.
Provisiona Apache 2.4 con mod_wsgi para el API Django, servicio
de archivos estáticos del UI React, terminación SSL con Let's Encrypt
via acme.sh, seguridad SSH con fail2ban y hardening de OpenSSH,
y verificación continua del estado del servidor.

---

## Prerequisitos obligatorios en PracticaYoruba-api y PracticaYoruba-ui

Tres correcciones de arquitectura son necesarias para que el servidor
funcione correctamente. **Ya están aplicadas** en los repositorios:

| Configuración | Repo | Cambio aplicado | Commit |
|---|---|---|---|
| STATIC_ROOT | PracticaYoruba-api | `STATIC_ROOT` en `settings/production.py` | `8ee87c6` |
| SECURE_PROXY_SSL_HEADER + UI_DIST | PracticaYoruba-api | `SECURE_PROXY_SSL_HEADER` + `UI_DIST` en `settings/production.py` | `8ee87c6` |
| serve_spa + webpack API_URL | PracticaYoruba-api / ui | Vista `serve_spa` en `urls.py` + `.env.production.example` + fix `webpack.config.js` | `8ee87c6` / `53b46e0` |

Ver detalles en `docs/operaciones.md`.

---

## Prerequisitos del sistema

- **OS**: Ubuntu 24.04 LTS
- **Apache**: 2.4.x — instalado por `provisioners/apache/install.sh`
- **mod_wsgi**: `libapache2-mod-wsgi-py3` — instalado por `provisioners/apache/install.sh`
- **acme.sh**: instalado por `provisioners/ssl/setup_ssl.sh`
- **fail2ban**: instalado por `provisioners/security/setup_fail2ban.sh`
- **OpenSSH**: ya incluido en Ubuntu — endurecido por `provisioners/security/setup_ssh_hardening.sh`
- **UFW**: ya incluido en Ubuntu — configurado por `provisioners/firewall/setup_firewall.sh`

---

## Estructura

```
PracticaYoruba-server/
├── .env.example                              # Plantilla de variables
│
├── config/
│   └── apache/
│       ├── practicayoruba-http.conf          # VirtualHost :80 (solo redirect)
│       └── practicayoruba-https.conf         # VirtualHost :443 (routing completo)
│
├── utils/                                    # Librerías de shell compartidas
│   ├── logging.sh
│   ├── core.sh
│   ├── network.sh
│   └── validation.sh                         # Incluye validate_apache_version,
│                                             # validate_ssl_cert
│
├── provisioners/
│   ├── apache/
│   │   ├── install.sh                        # Instala Apache + mod_wsgi (idempotente)
│   │   └── setup_vhost.sh                    # Copia templates, sustituye %%VAR%%,
│   │                                         # activa con a2ensite
│   ├── firewall/
│   │   └── setup_firewall.sh                 # UFW: permite SSH_PORT/80/443,
│   │                                         # deniega el resto
│   ├── security/
│   │   ├── setup_fail2ban.sh                 # fail2ban: jails sshd + apache-auth
│   │   └── setup_ssh_hardening.sh            # OpenSSH: Port/PermitRootLogin/
│   │                                         # PasswordAuthentication/MaxAuthTries
│   └── ssl/
│       └── setup_ssl.sh                      # Let's Encrypt (producción) o
│                                             # self-signed (--dev)
│
├── scripts/
│   ├── renew_ssl.sh                          # Renueva certificado (idempotente)
│   └── verify.sh                             # 13 checks del entorno
│
├── docs/
│   └── operaciones.md                        # Runbook completo
│
└── backups/                                  # Backups de configuración Apache
```

---

## Configuración inicial

```bash
# 1. Clonar y configurar
git clone <repo> PracticaYoruba-server
cd PracticaYoruba-server
cp .env.example .env
# Editar .env con las rutas, dominio, SSH_PORT y parámetros F2B_*

# 2. Instalar Apache y mod_wsgi
sudo bash provisioners/apache/install.sh

# 3. Configurar firewall (solo puertos SSH_PORT, 80 y 443)
#    ADVERTENCIA: el script permite SSH antes de activar UFW — sin riesgo de lockout.
#    Si usas un puerto SSH no estándar: SSH_PORT=2222 sudo bash ...
sudo bash provisioners/firewall/setup_firewall.sh

# 3a. Configurar fail2ban (jails sshd + apache-auth)
sudo bash provisioners/security/setup_fail2ban.sh

# 3b. Aplicar hardening de SSH
#     ADVERTENCIA: verifica que tienes clave SSH en ~/.ssh/authorized_keys
#     antes de ejecutar — el script desactiva autenticación por contraseña.
sudo bash provisioners/security/setup_ssh_hardening.sh

# 4. Obtener certificado SSL
sudo bash provisioners/ssl/setup_ssl.sh          # producción
sudo bash provisioners/ssl/setup_ssl.sh --dev    # desarrollo (self-signed)

# 5. Activar virtualhosts
sudo bash provisioners/apache/setup_vhost.sh

# 6. Verificar el entorno (13 checks)
bash scripts/verify.sh
```

---

## Diseño de routing

```
Petición HTTPS → Apache
│
├── /static/*    → Archivos físicos de collectstatic (sin pasar por Python)
├── /media/*     → Archivos media (uploads de usuarios)
└── /* (resto)   → mod_wsgi → Django
                   ├── /api/*         → DRF endpoints
                   ├── /admin/*       → Django Admin
                   ├── /api/schema/*  → OpenAPI / Swagger / Redoc
                   └── /* (catch-all) → sirve UI_DIST/index.html (React Router)
```

---

## Operaciones comunes

```bash
# Verificar estado del entorno (13 checks)
bash scripts/verify.sh

# Renovar certificado SSL (solo actúa si < 30 días restantes)
bash scripts/renew_ssl.sh

# Recargar Django sin reiniciar Apache
touch <API_ROOT>/practicayoruba/config/wsgi.py

# Ver logs de errores
sudo tail -f /var/log/apache2/practicayoruba-https-error.log

# Estado de fail2ban
sudo fail2ban-client status
sudo fail2ban-client status sshd

# Desbanear una IP bloqueada por error
sudo fail2ban-client set sshd unbanip <IP>
```

---

## Relación con otros repositorios

| Repositorio | Responsabilidad |
|---|---|
| `PracticaYoruba-api` | Aplicación backend Django |
| `PracticaYoruba-ui` | Aplicación frontend React |
| `PracticaYoruba-db` | Infraestructura de base de datos (MariaDB) |
| `PracticaYoruba-server` | Infraestructura de servidor web (este repo) |

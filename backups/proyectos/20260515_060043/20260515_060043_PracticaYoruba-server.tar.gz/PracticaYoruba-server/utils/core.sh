#!/bin/bash
# =============================================================================
# utils/core.sh — Funciones utilitarias core — PracticaYoruba-server
# =============================================================================
# Portado desde PracticaYoruba-db/utils/core.sh sin cambios funcionales.
#
# Nota: provisioning.sh (apt_update, install_apt_packages, setup_venv)
# no se porta porque PracticaYoruba-server gestiona sus dependencias apt
# directamente en los provisioners con funciones privadas. Centralizar
# operaciones apt en utils/ crearía acoplamiento innecesario.
#
# Depende de: logging.sh
#
# Provee:
#   command_exists <cmd>
#   require_command <cmd>
#   exists_file <path>
#   exists_dir  <path>
#
# Uso:
#   source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/core.sh"
# =============================================================================

# -----------------------------------------------------------------------------
# command_exists <cmd>
#   Retorna 0 si el comando existe en PATH, 1 si no.
# -----------------------------------------------------------------------------
command_exists() {
    command -v "$1" &>/dev/null
}

# -----------------------------------------------------------------------------
# require_command <cmd>
#   Igual que command_exists pero emite log_warn si el comando no existe.
# -----------------------------------------------------------------------------
require_command() {
    local cmd="$1"
    if ! command_exists "$cmd"; then
        log_warn "Comando no encontrado: ${cmd}"
        return 1
    fi
    return 0
}

exists_file() { [[ -f "$1" ]]; }
exists_dir()  { [[ -d "$1" ]]; }

# =============================================================================
# Detección de systemd
# =============================================================================

# is_systemd
#   Retorna 0 si el sistema corre con systemd como init (PID 1).
#   Retorna 1 en contenedores, entornos CI, o sistemas con otro init.
#
#   Se verifica /run/systemd/system — es el indicador canónico de que
#   systemd está activo como gestor de servicios. No basta con que el
#   binario systemctl exista: en contenedores existe pero no conecta.
# =============================================================================
is_systemd() {
    [[ -d /run/systemd/system ]]
}

# =============================================================================
# Wrappers de gestión de servicios — systemd o fallback directo
#
# Todos los provisioners usan estas funciones en lugar de llamar
# systemctl directamente. Esto garantiza que los scripts funcionen
# correctamente en:
#   - VPS Ubuntu 24.04 con systemd (entorno objetivo de producción)
#   - Contenedores Docker/LXC sin systemd (desarrollo, CI, pruebas)
#   - Entornos cloud-init donde systemd puede no estar completamente activo
#
# Convención de nombres: svc_<acción> <nombre_servicio>
# Todos los wrappers propagan el código de salida de la herramienta usada.
# =============================================================================

# svc_is_active <nombre>
#   Retorna 0 si el servicio está corriendo, 1 si no.
svc_is_active() {
    local name="$1"
    if is_systemd; then
        systemctl is-active --quiet "$name" 2>/dev/null
    else
        service "$name" status &>/dev/null
    fi
}

# svc_start <nombre>
#   Arranca el servicio. En modo sin-systemd usa la herramienta nativa
#   de cada servicio cuando 'service' no es suficiente.
svc_start() {
    local name="$1"
    if is_systemd; then
        systemctl start "$name" 2>/dev/null
    else
        case "$name" in
            apache2)
                # apache2ctl suprime el warning de ulimit de contenedores
                apache2ctl start 2>/dev/null
                ;;
            fail2ban)
                # fail2ban-server -b arranca en background sin systemd
                fail2ban-server -b 2>/dev/null
                ;;
            sshd|ssh)
                service ssh start 2>/dev/null || service sshd start 2>/dev/null
                ;;
            *)
                service "$name" start 2>/dev/null
                ;;
        esac
    fi
}

# svc_stop <nombre>
svc_stop() {
    local name="$1"
    if is_systemd; then
        systemctl stop "$name" 2>/dev/null
    else
        case "$name" in
            apache2)
                apache2ctl stop 2>/dev/null
                ;;
            fail2ban)
                fail2ban-client stop 2>/dev/null
                ;;
            *)
                service "$name" stop 2>/dev/null
                ;;
        esac
    fi
}

# svc_reload <nombre>
#   Recarga la configuración sin cortar conexiones activas (graceful).
svc_reload() {
    local name="$1"
    if is_systemd; then
        systemctl reload "$name" 2>/dev/null
    else
        case "$name" in
            apache2)
                # graceful — recarga sin cortar conexiones activas
                apache2ctl graceful 2>/dev/null
                ;;
            fail2ban)
                fail2ban-client reload 2>/dev/null
                ;;
            sshd|ssh)
                # SIGHUP recarga sshd sin cerrar sesiones activas
                local pid_file="/run/sshd.pid"
                if [[ -f "$pid_file" ]]; then
                    kill -HUP "$(cat "$pid_file")" 2>/dev/null
                else
                    service ssh reload 2>/dev/null || service sshd reload 2>/dev/null
                fi
                ;;
            *)
                service "$name" reload 2>/dev/null
                ;;
        esac
    fi
}

# svc_restart <nombre>
#   Para y vuelve a arrancar el servicio.
svc_restart() {
    local name="$1"
    if is_systemd; then
        systemctl restart "$name" 2>/dev/null
    else
        case "$name" in
            apache2)
                apache2ctl restart 2>/dev/null
                ;;
            fail2ban)
                # Para correctamente y espera antes de rearrancar
                fail2ban-client stop 2>/dev/null || true
                sleep 1
                fail2ban-server -b 2>/dev/null
                ;;
            *)
                service "$name" restart 2>/dev/null
                ;;
        esac
    fi
}

# svc_enable <nombre>
#   Habilita el inicio automático del servicio al arrancar el sistema.
#   En entornos sin systemd esta operación no aplica — se documenta.
svc_enable() {
    local name="$1"
    if is_systemd; then
        systemctl enable "$name" 2>/dev/null || true
    else
        # Sin systemd (contenedor, CI) el inicio automático no aplica.
        # En un VPS con systemd real esto se gestionará correctamente.
        log_info "  (sin systemd — inicio automático de '${name}' no configurado)"
        log_info "  En el servidor de producción con systemd se habilitará automáticamente."
    fi
}

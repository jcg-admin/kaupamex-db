#!/bin/bash
# =============================================================================
# utils/validation.sh — Funciones de validación — PracticaYoruba-server
# =============================================================================
# Portado desde PracticaYoruba-db/utils/validation.sh y extendido con
# funciones específicas del servidor web.
#
# Depende de: logging.sh, core.sh
#
# Funciones portadas desde PracticaYoruba-db (sin cambios funcionales):
#   validate_root
#   validate_ubuntu [version_prefix]
#   validate_python_version [major] [minor]
#
# Funciones NO portadas desde PracticaYoruba-db:
#   validate_mariadb_version — específica del dominio de base de datos.
#     Requiere el CLI mysql que no está instalado en el servidor web.
#     Incluirla sería código muerto en este contexto.
#
# Funciones nuevas específicas de PracticaYoruba-server:
#   validate_apache_version [required_major] [required_minor]
#   validate_ssl_cert <cert_path> [warn_days] [err_days]
#
# Uso:
#   source "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/validation.sh"
# =============================================================================

# -----------------------------------------------------------------------------
# validate_root
#   Retorna 0 si el proceso corre como root (EUID=0), 1 si no.
#   Los provisioners (install.sh, setup_vhost.sh, setup_ssl.sh) requieren
#   root para instalar paquetes y escribir en /etc/apache2/.
# -----------------------------------------------------------------------------
validate_root() {
    if [[ $EUID -ne 0 ]]; then
        log_error "Este script debe ejecutarse como root (usa sudo)"
        return 1
    fi
    return 0
}

# -----------------------------------------------------------------------------
# validate_ubuntu [version_prefix]
#   Verifica que el SO es Ubuntu y que la versión comienza con version_prefix.
#   Default: "24.04"
# -----------------------------------------------------------------------------
validate_ubuntu() {
    local required_prefix="${1:-24.04}"
    local os_release="/etc/os-release"

    [[ -f "$os_release" ]] || { log_error "No se encontro ${os_release}"; return 1; }

    local os_id os_version_id
    os_id=$(. "$os_release" && echo "${ID:-}")
    os_version_id=$(. "$os_release" && echo "${VERSION_ID:-}")

    [[ "${os_id,,}" == "ubuntu" ]] || { log_error "SO incompatible: ${os_id}"; return 1; }
    [[ "${os_version_id}" == "${required_prefix}"* ]] || {
        log_error "Version incompatible: Ubuntu ${os_version_id} (se requiere ${required_prefix}.x)"
        return 1
    }
    return 0
}

# -----------------------------------------------------------------------------
# validate_python_version [major] [minor]
#   Verifica que python3 existe y cumple la versión mínima requerida.
#   Default: 3.11
# -----------------------------------------------------------------------------
validate_python_version() {
    local required_major="${1:-3}" required_minor="${2:-11}"

    require_command python3 || return 1

    local major minor
    major=$(python3 -c "import sys; print(sys.version_info.major)")
    minor=$(python3 -c "import sys; print(sys.version_info.minor)")

    if (( major < required_major )) || (( major == required_major && minor < required_minor )); then
        log_error "Python ${major}.${minor} no cumple el minimo: ${required_major}.${required_minor}+"
        return 1
    fi
    return 0
}

# -----------------------------------------------------------------------------
# validate_apache_version [required_major] [required_minor]
#   Verifica que Apache está instalado y cumple la serie major.minor.x.
#   Default: 2.4
#
#   Lee la versión del binario apache2 -v (no requiere servidor activo).
#   Mismo patrón que validate_mariadb_version en PracticaYoruba-db:
#   retorna 0 si la versión es correcta, 1 si no está instalado o la
#   serie no coincide.
#
#   Ejemplo de salida de apache2 -v:
#     Server version: Apache/2.4.57 (Ubuntu)
#     Server built:   2023-10-26T13:11:10
# -----------------------------------------------------------------------------
validate_apache_version() {
    local required_major="${1:-2}" required_minor="${2:-4}"

    require_command apache2 || {
        log_error "apache2 no encontrado — Apache no está instalado"
        log_error "  Instala con: sudo bash provisioners/apache/install.sh"
        return 1
    }

    # Extraer "Apache/major.minor.patch" de la salida de apache2 -v
    local version_full
    version_full=$(apache2 -v 2>/dev/null \
        | grep -oE 'Apache/[0-9]+\.[0-9]+\.[0-9]+' \
        | head -1)

    if [[ -z "$version_full" ]]; then
        local raw
        raw=$(apache2 -v 2>/dev/null || echo "")
        log_error "No se pudo leer la versión de Apache"
        log_error "  Salida: ${raw}"
        log_error "  Se requiere: Apache ${required_major}.${required_minor}.x"
        return 1
    fi

    # Extraer major y minor del string "Apache/2.4.57"
    local version_str installed_major installed_minor
    version_str=$(echo "$version_full" | cut -d/ -f2)
    installed_major=$(echo "$version_str" | cut -d. -f1)
    installed_minor=$(echo "$version_str" | cut -d. -f2)

    if [[ "${installed_major}" != "${required_major}" ]] || \
       [[ "${installed_minor}" != "${required_minor}" ]]; then
        log_error "Version instalada: Apache ${version_str}"
        log_error "Se requiere: Apache ${required_major}.${required_minor}.x"
        log_error "  Migra con: sudo bash provisioners/apache/install.sh"
        return 1
    fi

    return 0
}

# -----------------------------------------------------------------------------
# validate_ssl_cert <cert_path> [warn_days] [err_days]
#   Verifica la vigencia de un certificado SSL instalado.
#   Defaults: warn_days=30, err_days=7
#
#   No requiere conexión de red — lee la fecha del archivo cert.pem.
#
#   CONVENCIÓN DE RETORNO compatible con set -euo pipefail:
#   Retorna siempre 0. Exporta SSL_CERT_STATUS con valor OK, WARN o ERR.
#   Los callers consultan la variable en lugar del código de retorno.
#   Retornar 1 o 2 con set -e activo mata el script si el caller no usa
#   || true — patrón frágil que esta convención evita.
#
#   Ejemplo de uso:
#     validate_ssl_cert "/etc/ssl/practicayoruba/cert.pem" 30 7
#     if [[ "$SSL_CERT_STATUS" == "ERR" ]]; then
#         log_error "Certificado vencido o próximo a vencer"
#     fi
# -----------------------------------------------------------------------------
validate_ssl_cert() {
    local cert_path="${1:-}"
    local warn_days="${2:-30}"
    local err_days="${3:-7}"

    # Exportar siempre — el caller necesita poder leer la variable
    # incluso si la función sale antes por error
    export SSL_CERT_STATUS="ERR"

    # Verificar que el certificado existe
    if [[ -z "$cert_path" ]]; then
        log_error "validate_ssl_cert: se requiere la ruta del certificado"
        return 0
    fi

    if [[ ! -f "$cert_path" ]]; then
        log_error "Certificado no encontrado: ${cert_path}"
        log_error "  Obtén el certificado con: sudo bash provisioners/ssl/setup_ssl.sh"
        return 0
    fi

    # Verificar que openssl está disponible
    if ! require_command openssl; then
        log_error "openssl no disponible — no se puede verificar el certificado"
        return 0
    fi

    # Leer la fecha de expiración
    local expiry_str
    expiry_str=$(openssl x509 -enddate -noout -in "$cert_path" 2>/dev/null \
        | cut -d= -f2)

    if [[ -z "$expiry_str" ]]; then
        log_error "No se pudo leer la fecha de expiración de: ${cert_path}"
        log_error "  El archivo puede estar corrupto o no ser un certificado válido"
        return 0
    fi

    # Convertir la fecha de expiración a epoch (GNU date — Ubuntu)
    local expiry_epoch
    expiry_epoch=$(date -d "$expiry_str" +%s 2>/dev/null)

    if [[ -z "$expiry_epoch" ]]; then
        log_error "No se pudo parsear la fecha de expiración: ${expiry_str}"
        return 0
    fi

    # Calcular días restantes
    local now_epoch days_remaining
    now_epoch=$(date +%s)
    days_remaining=$(( (expiry_epoch - now_epoch) / 86400 ))

    # Determinar estado y emitir mensaje apropiado
    if (( days_remaining <= 0 )); then
        export SSL_CERT_STATUS="ERR"
        log_error "Certificado VENCIDO hace $(( -days_remaining )) días"
        log_error "  Renueva con: bash scripts/renew_ssl.sh"
    elif (( days_remaining < err_days )); then
        export SSL_CERT_STATUS="ERR"
        log_error "Certificado vence en ${days_remaining} días — URGENTE"
        log_error "  Renueva con: bash scripts/renew_ssl.sh"
    elif (( days_remaining < warn_days )); then
        export SSL_CERT_STATUS="WARN"
        log_warn "Certificado vence en ${days_remaining} días"
        log_warn "  Renueva con: bash scripts/renew_ssl.sh"
    else
        export SSL_CERT_STATUS="OK"
        log_success "Certificado válido — vence en ${days_remaining} días"
    fi

    return 0
}

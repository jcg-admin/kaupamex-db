# docs/operaciones.md

Runbook de operaciones para PracticaYoruba-server.

---

## Arquitectura de la API y el UI relevante para el servidor

Esta sección describe las configuraciones en PracticaYoruba-api y
PracticaYoruba-ui que hacen posible el funcionamiento de este servidor.

### Archivos estáticos — STATIC_ROOT y collectstatic

`settings/production.py` define `STATIC_ROOT = BASE_DIR / 'staticfiles'`.
Apache sirve `/static/` directamente desde ese directorio sin pasar por Python.
Ejecutar tras cada deploy que modifique plantillas o CSS del Django Admin:

```bash
cd <PracticaYoruba-api>/practicayoruba
python manage.py collectstatic --noinput
```

### Proxy SSL — SECURE_PROXY_SSL_HEADER

`settings/production.py` define:

```python
SECURE_PROXY_SSL_HEADER = ('HTTP_X_FORWARDED_PROTO', 'https')
```

Apache termina el SSL y reenvía las peticiones a Django via HTTP interno.
Esta configuración le indica a Django que la conexión original era HTTPS,
evitando el bucle de redirects que produce `SECURE_SSL_REDIRECT = True`
cuando el servidor web actúa como terminador SSL.
El virtualhost HTTPS inyecta el header con `RequestHeader set X-Forwarded-Proto "https"`.

### React Router — vista catch-all serve_spa

Django está montado en raíz (`/`) via `WSGIScriptAlias`. La función
`serve_spa` en `config/urls.py` sirve `index.html` para rutas del UI
como `/cart`, `/checkout` o `/profile` que no están en los `urlpatterns`
del API. El catch-all se activa solo cuando `UI_DIST` está configurado
en el `.env` de la API — permanece inactivo en desarrollo y tests.

`UI_DIST` se lee del `.env` de PracticaYoruba-api, no del `.env`
de PracticaYoruba-server.

### API_URL en el build del UI

`webpack.config.js` inyecta `API_URL` en el bundle con esta prioridad:

1. Variable de entorno de shell `API_URL`
2. Archivo `.env.production` en PracticaYoruba-ui
3. Fallback `http://localhost:8000`

Para configurar el build de producción, ver la sección
[Despliegue de una nueva versión del UI](#despliegue-de-una-nueva-versión-del-ui).

---

## Configuración inicial (una vez por servidor)

```bash
# 1. Clonar el repositorio
git clone <repo> PracticaYoruba-server
cd PracticaYoruba-server

# 2. Crear .env desde la plantilla
cp .env.example .env
# Editar .env con las rutas, dominio, SSH_PORT y parámetros F2B_*

# 3. Instalar Apache y mod_wsgi
sudo bash provisioners/apache/install.sh

# 4. Configurar firewall (privilegio mínimo — puertos SSH_PORT, 80, 443)
#    ADVERTENCIA: el script permite SSH antes de activar UFW para evitar lockout.
#    Si usas un puerto SSH no estándar: SSH_PORT=2222 sudo bash ...
sudo bash provisioners/firewall/setup_firewall.sh

# 4a. Configurar fail2ban (protección contra fuerza bruta SSH y HTTP)
sudo bash provisioners/security/setup_fail2ban.sh

# 4b. Aplicar hardening de SSH
#     ADVERTENCIA: verifica que tienes clave SSH en ~/.ssh/authorized_keys
#     antes de ejecutar — el script desactiva la autenticación por contraseña.
sudo bash provisioners/security/setup_ssh_hardening.sh

# 5. Obtener certificado SSL
#    Producción (requiere dominio público):
sudo bash provisioners/ssl/setup_ssl.sh
#    Desarrollo (self-signed, sin dominio real):
sudo bash provisioners/ssl/setup_ssl.sh --dev

# 6. Activar los virtualhosts
sudo bash provisioners/apache/setup_vhost.sh

# 7. Verificar el entorno (13 checks)
bash scripts/verify.sh
```

---

## Despliegue de una nueva versión del API

```bash
cd <PracticaYoruba-api>

# 1. Activar el virtualenv
source venv/bin/activate

# 2. Instalar dependencias nuevas (si las hay)
pip install -r requirements/base.txt

# 3. Aplicar migraciones
python practicayoruba/manage.py migrate

# 4. Recolectar archivos estáticos
python practicayoruba/manage.py collectstatic --noinput

# 5. Recargar el proceso mod_wsgi sin downtime
# mod_wsgi recarga el proceso WSGI cuando se modifica wsgi.py
touch practicayoruba/config/wsgi.py
# o recargar Apache directamente:
sudo systemctl reload apache2
```

---

## Despliegue de una nueva versión del UI

```bash
cd <PracticaYoruba-ui>

# Primera vez: crear .env.production desde la plantilla
cp .env.production.example .env.production
# Editar .env.production con la URL real del API:
#   API_URL=https://practicayoruba.mx

# Build de producción (webpack lee .env.production automáticamente)
npm run build
# Genera dist/ con API_URL hardcodeada en el bundle

# No es necesario recargar Apache — los archivos son servidos por
# la vista serve_spa de Django, que lee del disco en cada petición
```

**Nota:** `API_URL` en `.env.production` es efectiva porque
`webpack.config.js` usa la cadena de prioridad:
`process.env.API_URL || resolvedEnv.API_URL || 'http://localhost:8000'`
(corregido en commit `53b46e0`).

---

## Renovación de certificado SSL

### Renovación automática (via cron de acme.sh)
acme.sh instala un cron semanal automáticamente al emitir el certificado.
Para verificar que está activo:

```bash
crontab -l | grep acme
```

### Cron manual para renew_ssl.sh (alternativa o complemento)
Para usar el script de renovación del repositorio con control de logs:

```bash
# Agregar al crontab de root (sudo crontab -e):
0 2 * * 1 /bin/bash /opt/practicayoruba-server/scripts/renew_ssl.sh
```

El script registra el resultado en `logs/renew_ssl.log` y sale con
código 1 si la renovación falla, lo que activa la notificación por
email de cron si el MTA está configurado.

### Renovación manual
```bash
bash scripts/renew_ssl.sh
```

El script verifica si quedan menos de 30 días (umbral configurable en .env);
si hay suficiente vida útil, acme.sh reporta código 2 y el script termina
sin renovar (idempotente).

### Forzar renovación (independiente de la fecha)
```bash
~/.acme.sh/acme.sh --renew -d ${DOMAIN} --force
sudo systemctl reload apache2
```

---

## Verificación del entorno

```bash
bash scripts/verify.sh
```

Checks incluidos:
1.  Variables requeridas en .env
2.  Apache 2.4.x instalado
3.  mod_wsgi cargado
4.  Apache activo en puerto 80
5.  SSL activo en puerto 443
6.  Días restantes del certificado
7.  Django API responde (DRF retorna 4xx, no 5xx)
8.  Redirect HTTP → HTTPS funciona
9.  SPA catch-all activo (`/test-spa-catch-all-practicayoruba` retorna 200)
10. Firewall UFW activo con puertos SSH, 80 y 443
11. Clave SSL con permisos 600, workers Apache sin root
12. fail2ban activo con jails sshd y apache-auth
13. SSH hardening — PermitRootLogin no, PasswordAuthentication no, puerto no estándar

`verify.sh` retorna exit code 0 si todo está bien, 1 si hay errores.

---

## Firewall y privilegio mínimo

### Configurar UFW

```bash
sudo bash provisioners/firewall/setup_firewall.sh
```

Abre solo los puertos necesarios (22 SSH, 80 HTTP, 443 HTTPS) y
deniega todo el tráfico entrante no listado. El script es idempotente:
si UFW ya tiene las reglas correctas, termina sin cambios.

Si usas un puerto SSH no estándar:

```bash
SSH_PORT=2222 sudo bash provisioners/firewall/setup_firewall.sh
```

### Verificar reglas activas

```bash
sudo ufw status verbose
```

### Privilegio mínimo de Apache

Apache está configurado para correr con el usuario mínimo necesario:

- **Proceso master**: corre como root temporalmente (necesario para
  abrir puertos < 1024), luego cede privilegios.
- **Workers mod_wsgi**: corren como ``WSGI_USER`` (default: ``www-data``),
  configurado en ``WSGIDaemonProcess`` dentro del virtualhost HTTPS.
  El código Django nunca tiene acceso root.

La clave SSL privada (``key.pem``) tiene permisos 600 — solo el
propietario (root) puede leerla. Apache la lee durante el arranque
del proceso master antes de ceder privilegios.

---

## Seguridad de acceso — SSH y fail2ban

### Configurar fail2ban y SSH hardening

```bash
# Instalar y configurar fail2ban (jails sshd y apache-auth)
sudo bash provisioners/security/setup_fail2ban.sh

# Aplicar hardening de OpenSSH
# ADVERTENCIA: verifica primero que tienes clave SSH en ~/.ssh/authorized_keys
sudo bash provisioners/security/setup_ssh_hardening.sh
```

### Estado de fail2ban

```bash
# Estado general y lista de jails activas
sudo fail2ban-client status

# Estado detallado de una jail específica
sudo fail2ban-client status sshd
sudo fail2ban-client status apache-auth
```

### IPs baneadas

```bash
# Ver IPs baneadas en la jail SSH
sudo fail2ban-client status sshd | grep "Banned IP"

# Ver IPs baneadas en la jail Apache
sudo fail2ban-client status apache-auth | grep "Banned IP"
```

### Desbanear una IP bloqueada por error

```bash
# Desbanear de la jail SSH
sudo fail2ban-client set sshd unbanip <IP>

# Desbanear de la jail apache-auth
sudo fail2ban-client set apache-auth unbanip <IP>

# Desbanear de todas las jails a la vez
sudo fail2ban-client unban <IP>
```

### Logs de fail2ban

```bash
# Ver logs en tiempo real
sudo journalctl -u fail2ban -f

# Ver los últimos bans
sudo journalctl -u fail2ban --no-pager | grep "Ban " | tail -20
```

### SSH hardening activo

```bash
# Verificar la configuración efectiva de sshd (sin root)
sshd -T | grep -E "^port|^permitrootlogin|^passwordauthentication|^maxauthtries"

# El resultado esperado con el hardening aplicado:
#   port 2222
#   permitrootlogin no
#   passwordauthentication no
#   maxauthtries 3
```

### Referencia de email (PracticaYoruba-api)

El servidor envía emails para verificación de cuenta (UC-AUTH-10) y
recuperación de contraseña (UC-AUTH-09). Las variables de configuración
van en el `.env` de **PracticaYoruba-api**, no en este repositorio.

Puerto saliente requerido: `587/tcp` (SMTP STARTTLS). Ya permitido
por UFW (`default allow outgoing`) — sin regla adicional en UFW.

Variables a configurar en `PracticaYoruba-api/.env`:

```bash
EMAIL_HOST=smtp.sendgrid.net   # o el proveedor elegido
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=apikey
EMAIL_HOST_PASSWORD=<api_key>
FRONTEND_URL=https://practicayoruba.mx
```

---

## Diagnóstico

```bash
# Estado de Apache
sudo systemctl status apache2

# Verificar configuración de Apache (antes de activar cambios)
sudo apachectl configtest

# Recargar Apache sin downtime
sudo systemctl reload apache2

# Ver logs en tiempo real
sudo tail -f /var/log/apache2/practicayoruba-https-error.log
sudo tail -f /var/log/apache2/practicayoruba-https-access.log

# Verificar que mod_wsgi está cargado
apache2ctl -M | grep wsgi

# Verificar módulos activos
apache2ctl -M | sort

# Verificar el certificado SSL instalado
openssl x509 -in /etc/ssl/practicayoruba/cert.pem -noout -dates

# Probar que Django responde (sin pasar por Apache)
cd <PracticaYoruba-api>/practicayoruba
DJANGO_SETTINGS_MODULE=config.settings.production \
python manage.py check --deploy
```

---

## Reiniciar el proceso WSGI sin downtime

mod_wsgi daemon mode permite recargar el proceso Python sin reiniciar
Apache. Dos métodos:

```bash
# Método 1: tocar wsgi.py (mod_wsgi lo detecta y recarga)
touch <API_ROOT>/practicayoruba/config/wsgi.py

# Método 2: recargar Apache (más agresivo pero sin downtime en conexiones activas)
sudo systemctl reload apache2
```

---

## Referencias

- `ADR-009`: MariaDB 11.8 como motor
- `PracticaYoruba-db/docs/operaciones.md`: operaciones de base de datos
- `config/apache/practicayoruba-https.conf`: virtualhost con el routing completo

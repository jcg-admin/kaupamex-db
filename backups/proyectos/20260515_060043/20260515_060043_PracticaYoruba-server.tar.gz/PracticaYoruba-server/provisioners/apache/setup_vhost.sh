#!/bin/bash
# =============================================================================
# provisioners/apache/setup_vhost.sh
# Activa los virtualhosts de PracticaYoruba en Apache
# =============================================================================
# Lee las variables del .env, las sustituye en los templates de configuración
# y activa los virtualhosts via a2ensite.
#
# Proceso: COPIAR → SUSTITUIR → VERIFICAR → a2ensite → apachectl configtest
#
# Por qué se copia en lugar de crear un symlink al template:
#   Los archivos template contienen placeholders %%VARIABLE%% que Apache
#   no puede parsear. Apache necesita archivos con valores reales en
#   /etc/apache2/sites-available/. Un symlink al template provocaría
#   un error 500 en todas las peticiones.
#
# Verificación previa a la activación:
#   'apachectl configtest' valida la sintaxis antes de recargar Apache.
#   Si falla, el script revierte los cambios (a2dissite + restaura 000-default)
#   y sale con código 1 sin tocar el servidor en producción.
#
# Uso:
#   sudo bash provisioners/apache/setup_vhost.sh
#
# Variables requeridas en .env:
#   DOMAIN, API_ROOT, VENV_PATH, WSGI_USER, WSGI_GROUP,
#   WSGI_PROCESSES, WSGI_THREADS, STATIC_ROOT, MEDIA_ROOT, SSL_CERT_DIR
#
# Requiere: root, Apache instalado (provisioners/apache/install.sh)
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

source "${PROJECT_ROOT}/utils/logging.sh"
source "${PROJECT_ROOT}/utils/core.sh"
source "${PROJECT_ROOT}/utils/validation.sh"

# =============================================================================
# Cargar .env — requerido (a diferencia de install.sh donde es opcional)
# =============================================================================
ENV_FILE="${PROJECT_ROOT}/.env"
if [[ ! -f "$ENV_FILE" ]]; then
    log_error "Archivo .env no encontrado en ${PROJECT_ROOT}"
    log_error "  Crea tu configuración: cp .env.example .env"
    exit 1
fi
set -a; source "$ENV_FILE"; set +a

# =============================================================================
# Validar variables requeridas
# =============================================================================
_check_required_vars() {
    log_header "PASO: Verificando prerequisitos"

    validate_root || {
        log_error "  Ejecuta con: sudo bash provisioners/apache/setup_vhost.sh"
        exit 1
    }
    log_success "Corriendo como root"

    command_exists apachectl || {
        log_error "apachectl no encontrado — instala Apache primero:"
        log_error "  sudo bash provisioners/apache/install.sh"
        exit 1
    }
    log_success "Apache instalado"

    local missing=()
    for var in DOMAIN API_ROOT VENV_PATH WSGI_USER WSGI_GROUP \
               WSGI_PROCESSES WSGI_THREADS STATIC_ROOT MEDIA_ROOT SSL_CERT_DIR; do
        [[ -z "${!var:-}" ]] && missing+=("$var")
    done

    if (( ${#missing[@]} > 0 )); then
        log_error "Variables no definidas en .env:"
        for v in "${missing[@]}"; do
            log_error "  ${v}"
        done
        exit 1
    fi
    log_success "Variables requeridas presentes"
}

# =============================================================================
# Sustituir placeholders %%VARIABLE%% en un archivo copiado
# Usa | como delimitador para soportar rutas con /
# Limitación: los valores de las variables no deben contener |
# =============================================================================
_substitute_vars() {
    local file="$1"

    sed -i \
        -e "s|%%DOMAIN%%|${DOMAIN}|g" \
        -e "s|%%API_ROOT%%|${API_ROOT}|g" \
        -e "s|%%VENV_PATH%%|${VENV_PATH}|g" \
        -e "s|%%WSGI_USER%%|${WSGI_USER}|g" \
        -e "s|%%WSGI_GROUP%%|${WSGI_GROUP}|g" \
        -e "s|%%WSGI_PROCESSES%%|${WSGI_PROCESSES}|g" \
        -e "s|%%WSGI_THREADS%%|${WSGI_THREADS}|g" \
        -e "s|%%STATIC_ROOT%%|${STATIC_ROOT}|g" \
        -e "s|%%MEDIA_ROOT%%|${MEDIA_ROOT}|g" \
        -e "s|%%SSL_CERT_DIR%%|${SSL_CERT_DIR}|g" \
        "$file"

    # Verificar que no queden placeholders sin sustituir
    # Indica un bug: una variable nueva en el template no está en este script
    local remaining
    remaining=$(grep -oE '%%[A-Z_]+%%' "$file" 2>/dev/null || echo "")
    if [[ -n "$remaining" ]]; then
        log_error "Placeholders sin sustituir en ${file}:"
        echo "$remaining" | sort -u | while IFS= read -r ph; do
            log_error "  ${ph}"
        done
        log_error "  Agrega la variable a _substitute_vars() en este script"
        exit 1
    fi
}

# =============================================================================
# PASO: Copiar template y sustituir variables
# =============================================================================
_setup_conf() {
    local conf_name="$1"
    local src="${PROJECT_ROOT}/config/apache/${conf_name}"
    local dst="/etc/apache2/sites-available/${conf_name}"

    log_info "  ${conf_name}"

    [[ -f "$src" ]] || {
        log_error "Template no encontrado: ${src}"
        exit 1
    }

    cp "$src" "$dst"
    _substitute_vars "$dst"
    log_success "  Configurado: ${dst}"
}

# =============================================================================
# PASO: Revertir cambios si configtest falla
# =============================================================================
_revert() {
    local default_was_active="${1:-false}"

    log_warn "Revirtiendo cambios..."
    a2dissite practicayoruba-http.conf practicayoruba-https.conf \
        2>/dev/null || true
    rm -f \
        /etc/apache2/sites-available/practicayoruba-http.conf \
        /etc/apache2/sites-available/practicayoruba-https.conf \
        2>/dev/null || true

    if [[ "$default_was_active" == "true" ]]; then
        a2ensite 000-default.conf 2>/dev/null || true
        log_info "  000-default.conf restaurado"
    fi

    log_error "Setup revertido. Corrige los errores y vuelve a ejecutar."
}

# =============================================================================
# MAIN
# =============================================================================
log_header "Setup de virtualhosts — PracticaYoruba-server"
log_info "  Dominio: ${DOMAIN:-<no definido>}"
echo ""

_check_required_vars; echo ""

# Registrar si 000-default estaba activo antes de desactivarlo
default_was_active=false
if [[ -f /etc/apache2/sites-enabled/000-default.conf ]]; then
    default_was_active=true
fi

# ── PASO: Copiar y sustituir ─────────────────────────────────────────────────
log_header "PASO: Copiando y sustituyendo variables"
_setup_conf "practicayoruba-http.conf"
_setup_conf "practicayoruba-https.conf"
echo ""

# ── PASO: Desactivar 000-default ─────────────────────────────────────────────
log_header "PASO: Desactivando virtualhost 000-default"
a2dissite 000-default.conf 2>/dev/null && \
    log_success "000-default.conf desactivado" || \
    log_info "000-default.conf no estaba activo"
echo ""

# ── PASO: Activar virtualhosts de PracticaYoruba ─────────────────────────────
log_header "PASO: Activando virtualhosts"
a2ensite practicayoruba-http.conf  && log_success "practicayoruba-http.conf activado"
a2ensite practicayoruba-https.conf && log_success "practicayoruba-https.conf activado"
echo ""

# ── PASO: Verificar configuración ────────────────────────────────────────────
log_header "PASO: Verificando configuración (apachectl configtest)"
if ! apachectl configtest 2>/dev/null; then
    log_error "apachectl configtest falló"
    _revert "$default_was_active"
    exit 1
fi
log_success "Configuración válida"
echo ""

# ── PASO: Recargar Apache ─────────────────────────────────────────────────────
log_header "PASO: Recargando Apache"
if systemctl is-active --quiet apache2 2>/dev/null; then
    systemctl reload apache2 && log_success "Apache recargado"
else
    log_info "Apache no está activo — arrancando..."
    systemctl start apache2 && log_success "Apache arrancado"
fi
echo ""

log_separator 60 "="
log_success "Virtualhosts activados para ${DOMAIN}"
echo ""
log_info "Siguiente paso si aún no tienes certificado SSL:"
log_info "  sudo bash provisioners/ssl/setup_ssl.sh"
log_info "  sudo bash provisioners/ssl/setup_ssl.sh --dev   # desarrollo"

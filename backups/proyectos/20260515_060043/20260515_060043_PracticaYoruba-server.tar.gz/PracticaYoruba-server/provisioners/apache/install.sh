#!/bin/bash
# =============================================================================
# provisioners/apache/install.sh
# Instala Apache 2.4 + mod_wsgi o migra desde una versión incorrecta
# =============================================================================
# IDEMPOTENTE: si Apache 2.4.x ya está instalado con los módulos correctos,
# no hace nada.
#
# Escenarios:
#   A) Apache no instalado      → instala Apache 2.4 y libapache2-mod-wsgi-py3
#   B) Apache 2.4.x instalado   → verifica módulos → activa los faltantes → OK
#   C) Versión incorrecta       → backup /etc/apache2/ → purga → instala 2.4
#
# A diferencia de MariaDB, Apache no almacena datos del negocio en su
# directorio de instalación. Purgar e instalar la versión correcta no
# implica pérdida de datos del proyecto — no requiere flag --migrate.
# El backup de /etc/apache2/ antes de purgar preserva las configuraciones
# manuales previas del operador.
#
# Módulos activados tras la instalación:
#   ssl      — soporte HTTPS
#   wsgi     — interfaz Python para Django (libapache2-mod-wsgi-py3)
#   headers  — directiva RequestHeader (X-Forwarded-Proto)
#   rewrite  — redirect HTTP → HTTPS
#
# Uso:
#   sudo bash provisioners/apache/install.sh
#
# Requiere: root, Ubuntu 24.04, apt
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

source "${PROJECT_ROOT}/utils/logging.sh"
source "${PROJECT_ROOT}/utils/core.sh"
source "${PROJECT_ROOT}/utils/network.sh"
source "${PROJECT_ROOT}/utils/validation.sh"

readonly APACHE_TARGET_MAJOR="2"
readonly APACHE_TARGET_MINOR="4"
readonly APACHE_TARGET_SERIES="${APACHE_TARGET_MAJOR}.${APACHE_TARGET_MINOR}"

# Módulos requeridos por PracticaYoruba-server
readonly APACHE_REQUIRED_MODULES=("ssl" "wsgi" "headers" "rewrite")

# =============================================================================
# Helpers de apt — privados, solo para este script
# =============================================================================
_apt_install() {
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends "$@"
}

_apt_purge() {
    DEBIAN_FRONTEND=noninteractive apt-get purge -y "$@" 2>/dev/null || true
}

# =============================================================================
# Detectar la serie de Apache instalada
# Retorna "major.minor" (ej: "2.4") o cadena vacía si no está instalado
# =============================================================================
_detect_installed_series() {
    local version_str
    version_str=$(apache2 -v 2>/dev/null \
        | grep -oE 'Apache/[0-9]+\.[0-9]+' \
        | head -1)
    [[ -z "$version_str" ]] && echo "" && return
    echo "$version_str" | cut -d/ -f2
}

# =============================================================================
# PASO: Verificar requisitos
# =============================================================================
_check_requisites() {
    log_header "PASO: Verificando requisitos"

    validate_root || {
        log_error "  Ejecuta con: sudo bash provisioners/apache/install.sh"
        exit 1
    }
    log_success "Corriendo como root"

    command_exists apt-get || {
        log_error "apt-get no encontrado — se requiere Ubuntu/Debian"
        exit 1
    }
    log_success "apt disponible"

    # Acceso a internet — necesario para descargar paquetes
    if ! tcp_is_reachable "archive.ubuntu.com" 80 5; then
        log_warn "Sin acceso a archive.ubuntu.com:80"
        log_warn "  Si los paquetes están en caché local puede continuar"
    else
        log_success "Acceso a archive.ubuntu.com"
    fi
}

# =============================================================================
# PASO: Detectar versión instalada y decidir escenario
# Retorna 0 siempre; el estado se comunica via exit 0 (Escenario B)
# o continuando el flujo del MAIN (Escenarios A y C)
# =============================================================================
_check_current_version() {
    log_header "PASO: Detectando versión instalada"

    local installed_series
    installed_series=$(_detect_installed_series)

    if [[ -z "$installed_series" ]]; then
        log_info "Apache no instalado — instalación desde cero (Escenario A)"
        return 0
    fi

    log_info "Instalado: Apache ${installed_series}.x"

    if [[ "$installed_series" == "$APACHE_TARGET_SERIES" ]]; then
        log_success "Apache ${installed_series}.x — serie correcta"
        log_info "  Verificando módulos requeridos... (Escenario B)"
        _ensure_modules_active
        echo ""
        log_separator 60 "="
        log_success "Apache ${APACHE_TARGET_SERIES}.x ya instalado. Sin cambios."
        exit 0
    fi

    # Versión incorrecta — Escenario C
    log_warn "Serie instalada: ${installed_series} — se requiere ${APACHE_TARGET_SERIES}"
    log_warn "  Apache no almacena datos del negocio — se purgará e instalará 2.4"
}

# =============================================================================
# PASO: Verificar y activar módulos requeridos
# Activa los módulos faltantes sin reiniciar Apache
# =============================================================================
_ensure_modules_active() {
    log_header "PASO: Verificando módulos requeridos"

    local all_active=true

    for mod in "${APACHE_REQUIRED_MODULES[@]}"; do
        if apache2ctl -M 2>/dev/null | grep -q "${mod}_module"; then
            log_success "  Módulo activo: ${mod}"
        else
            log_info "  Activando módulo: ${mod}"
            a2enmod "$mod" >/dev/null 2>&1 || {
                log_error "  No se pudo activar el módulo: ${mod}"
                all_active=false
            }
            log_success "  Módulo activado: ${mod}"
        fi
    done

    # Recargar Apache si está corriendo para aplicar módulos nuevos
    if svc_is_active apache2; then
        log_info "  Recargando Apache para aplicar cambios..."
        svc_reload apache2 \
            || log_warn "  No se pudo recargar Apache — reinicia manualmente"
    fi

    [[ "$all_active" == "true" ]] || {
        log_error "Uno o más módulos no se pudieron activar"
        exit 1
    }
}

# =============================================================================
# PASO: Backup de configuración antes de purgar
# Guarda en backups/ del repositorio (no en /tmp/ — se pierde al reiniciar)
# =============================================================================
_backup_apache_config() {
    log_header "PASO: Backup de configuración Apache"

    local backup_dir="${PROJECT_ROOT}/backups"
    local backup_file="${backup_dir}/apache2-config-$(date +%Y%m%d_%H%M%S).tar.gz"

    if [[ ! -d /etc/apache2 ]]; then
        log_info "  /etc/apache2 no existe — no hay configuración que respaldar"
        return 0
    fi

    mkdir -p "$backup_dir"
    if tar -czf "$backup_file" /etc/apache2/ 2>/dev/null; then
        log_success "Backup creado: ${backup_file}"
    else
        log_warn "No se pudo crear el backup de /etc/apache2/"
        log_warn "  Continuando sin backup — la instalación es segura"
    fi
}

# =============================================================================
# PASO: Purgar versión incorrecta (Escenario C)
# =============================================================================
_purge_wrong_version() {
    log_header "PASO: Purgando versión incorrecta de Apache"

    # Detener el servicio si está corriendo
    if svc_is_active apache2; then
        log_info "  Deteniendo Apache..."
        svc_stop apache2 || true
    fi

    # Purgar todos los paquetes apache2 relacionados
    _apt_purge apache2 apache2-utils libapache2-mod-wsgi-py3 \
        apache2-bin apache2-data > /dev/null
    DEBIAN_FRONTEND=noninteractive apt-get autoremove -y > /dev/null 2>&1 || true

    log_success "Versión incorrecta purgada"
}

# =============================================================================
# PASO: Instalar Apache 2.4 y libapache2-mod-wsgi-py3
# =============================================================================
_install_apache() {
    log_header "PASO: Instalando Apache ${APACHE_TARGET_SERIES} y mod_wsgi"

    log_info "  Actualizando índice de paquetes..."
    DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>/dev/null || \
        log_warn "  apt-get update retornó error — continuando"

    log_info "  Instalando apache2 y libapache2-mod-wsgi-py3..."
    if ! _apt_install apache2 libapache2-mod-wsgi-py3 > /dev/null; then
        log_error "No se pudo instalar apache2"
        exit 1
    fi

    log_success "Apache ${APACHE_TARGET_SERIES} instalado"

    # Activar los módulos requeridos
    _ensure_modules_active

    # Arrancar el servicio
    if ! svc_is_active apache2; then
        log_info "  Arrancando Apache..."
        svc_enable apache2
        svc_start apache2 || {
            log_error "No se pudo arrancar Apache"
            exit 1
        }
    fi

    log_success "Servicio apache2 activo"
}

# =============================================================================
# PASO: Verificar versión instalada
# =============================================================================
_verify_installation() {
    log_header "PASO: Verificando versión instalada"

    if validate_apache_version "$APACHE_TARGET_MAJOR" "$APACHE_TARGET_MINOR"; then
        local version_str
        version_str=$(_detect_installed_series)
        log_success "Apache ${version_str}.x — serie ${APACHE_TARGET_SERIES} confirmada"
    else
        log_error "La verificación de versión falló tras la instalación"
        exit 1
    fi
}

# =============================================================================
# MAIN
# =============================================================================
log_header "Instalación Apache ${APACHE_TARGET_SERIES} — PracticaYoruba-server"
log_info "  Objetivo: Apache ${APACHE_TARGET_SERIES}.x con mod_wsgi"
echo ""

_check_requisites;      echo ""
_check_current_version; echo ""

# Si llegamos aquí: Escenario A (no instalado) o C (versión incorrecta)
installed_series=$(_detect_installed_series)
if [[ -n "$installed_series" && "$installed_series" != "$APACHE_TARGET_SERIES" ]]; then
    _backup_apache_config; echo ""
    _purge_wrong_version;  echo ""
fi

_install_apache;      echo ""
_verify_installation; echo ""

log_separator 60 "="
log_success "Apache ${APACHE_TARGET_SERIES} instalado y configurado."
echo ""
log_info "Siguientes pasos:"
log_info "  Obtener certificado SSL:"
log_info "    sudo bash provisioners/ssl/setup_ssl.sh          # produccion"
log_info "    sudo bash provisioners/ssl/setup_ssl.sh --dev    # desarrollo"
log_info "  Activar virtualhosts:"
log_info "    sudo bash provisioners/apache/setup_vhost.sh"
log_info "  Verificar entorno:"
log_info "    bash scripts/verify.sh"

#!/bin/bash
# =============================================================================
# provisioners/security/setup_fail2ban.sh
# Instala y configura fail2ban para PracticaYoruba-server
# =============================================================================
# IDEMPOTENTE: si fail2ban ya está activo con la configuración correcta
# y las jails corriendo, no hace nada.
#
# Jails configuradas:
#
#   sshd:         Monitorea /var/log/auth.log.
#                 Banea IPs con intentos fallidos de autenticación SSH.
#                 Variables: F2B_SSH_MAXRETRY, F2B_SSH_FINDTIME, F2B_SSH_BANTIME
#                 Defaults:  5 intentos / 600 s / 3600 s (1 hora)
#
#   apache-auth:  Monitorea el log de acceso HTTPS de PracticaYoruba.
#                 Banea IPs con respuestas 401/403 repetidas — protege
#                 /admin/ y /api/v1/auth/ contra fuerza bruta.
#                 Variables: F2B_APACHE_MAXRETRY, F2B_APACHE_FINDTIME,
#                            F2B_APACHE_BANTIME
#                 Defaults:  10 intentos / 600 s / 1800 s (30 min)
#
# El banaction usa UFW — consistente con el firewall del servidor.
# Las IPs baneadas se añaden como reglas de denegación en UFW
# y se eliminan automáticamente al expirar el ban.
#
# Uso:
#   sudo bash provisioners/security/setup_fail2ban.sh
#
# Variables opcionales en .env (con defaults seguros):
#   SSH_PORT, F2B_SSH_MAXRETRY, F2B_SSH_FINDTIME, F2B_SSH_BANTIME,
#   F2B_APACHE_MAXRETRY, F2B_APACHE_FINDTIME, F2B_APACHE_BANTIME
#
# Requiere: root, Ubuntu 24.04, apt
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

source "${PROJECT_ROOT}/utils/logging.sh"
source "${PROJECT_ROOT}/utils/core.sh"
source "${PROJECT_ROOT}/utils/validation.sh"

# =============================================================================
# Cargar .env (opcional — las variables tienen defaults seguros)
# =============================================================================
ENV_FILE="${PROJECT_ROOT}/.env"
[[ -f "$ENV_FILE" ]] && { set -a; source "$ENV_FILE"; set +a; }

# Valores con defaults seguros
SSH_PORT="${SSH_PORT:-22}"
F2B_SSH_MAXRETRY="${F2B_SSH_MAXRETRY:-5}"
F2B_SSH_FINDTIME="${F2B_SSH_FINDTIME:-600}"
F2B_SSH_BANTIME="${F2B_SSH_BANTIME:-3600}"
F2B_APACHE_MAXRETRY="${F2B_APACHE_MAXRETRY:-10}"
F2B_APACHE_FINDTIME="${F2B_APACHE_FINDTIME:-600}"
F2B_APACHE_BANTIME="${F2B_APACHE_BANTIME:-1800}"

# Ruta del archivo de configuración de jails
readonly JAIL_CONF="/etc/fail2ban/jail.d/practicayoruba.conf"

# Log de Apache HTTPS configurado en practicayoruba-https.conf
readonly APACHE_LOG="/var/log/apache2/practicayoruba-https-access.log"

# =============================================================================
# Genera el contenido esperado del archivo de jails
# La salida se usa tanto para escribir como para comparar (idempotencia)
# =============================================================================
_generate_jail_conf() {
    cat << JAILEOF
# /etc/fail2ban/jail.d/practicayoruba.conf
# Generado por provisioners/security/setup_fail2ban.sh
# No editar manualmente — ejecutar setup_fail2ban.sh para aplicar cambios.

[DEFAULT]
# banaction = ufw: las IPs baneadas se agregan como reglas de denegación
# en UFW. Consistente con el firewall del servidor (setup_firewall.sh).
banaction = ufw

[sshd]
enabled  = true
port     = ${SSH_PORT}
filter   = sshd
logpath  = /var/log/auth.log
maxretry = ${F2B_SSH_MAXRETRY}
findtime = ${F2B_SSH_FINDTIME}
bantime  = ${F2B_SSH_BANTIME}

[apache-auth]
enabled  = true
port     = http,https
filter   = apache-auth
logpath  = ${APACHE_LOG}
maxretry = ${F2B_APACHE_MAXRETRY}
findtime = ${F2B_APACHE_FINDTIME}
bantime  = ${F2B_APACHE_BANTIME}
JAILEOF
}

# =============================================================================
# PASO: Verificar requisitos
# =============================================================================
_check_requisites() {
    log_header "PASO: Verificando requisitos"

    validate_root || {
        log_error "  Ejecuta con: sudo bash provisioners/security/setup_fail2ban.sh"
        exit 1
    }
    log_success "Corriendo como root"

    command_exists apt-get || {
        log_error "apt-get no encontrado — se requiere Ubuntu/Debian"
        exit 1
    }
    log_success "apt disponible"
}

# =============================================================================
# PASO: Verificar estado actual (idempotencia)
# Compara la configuración esperada con la actual y verifica que fail2ban
# esté activo con las jails correctas. Si todo coincide, sale con éxito.
# =============================================================================
_check_current_state() {
    log_header "PASO: Estado actual de fail2ban"

    # Si fail2ban no está instalado, continuar con la instalación
    if ! command_exists fail2ban-client; then
        log_info "fail2ban no instalado — se instalará"
        return 0
    fi

    # Si el archivo de configuración no existe, continuar
    if [[ ! -f "$JAIL_CONF" ]]; then
        log_info "Configuración no encontrada — se creará"
        return 0
    fi

    # Comparar configuración esperada con la actual
    local expected
    expected=$(_generate_jail_conf)
    local current
    current=$(cat "$JAIL_CONF")

    if [[ "$expected" != "$current" ]]; then
        log_info "Configuración desactualizada — se aplicará"
        return 0
    fi

    # Configuración correcta — verificar que el servicio esté activo
    if ! svc_is_active fail2ban; then
        log_info "Configuración correcta pero servicio inactivo — se activará"
        return 0
    fi

    # Verificar que las jails estén corriendo
    local jails_ok=true
    for jail in sshd apache-auth; do
        if ! fail2ban-client status "$jail" &>/dev/null; then
            log_info "Jail '${jail}' no activa — se activará"
            jails_ok=false
            break
        fi
    done

    if [[ "$jails_ok" == "true" ]]; then
        log_success "fail2ban activo con configuración y jails correctas — sin cambios"
        log_success "  Jail sshd:        activa"
        log_success "  Jail apache-auth: activa"
        exit 0
    fi
}

# =============================================================================
# PASO: Instalar fail2ban
# =============================================================================
_install_fail2ban() {
    log_header "PASO: Instalando fail2ban"

    if command_exists fail2ban-client; then
        log_success "fail2ban ya instalado: $(fail2ban-client --version 2>/dev/null | head -1)"
        return 0
    fi

    log_info "  Actualizando índice de paquetes..."
    DEBIAN_FRONTEND=noninteractive apt-get update -qq 2>/dev/null || \
        log_warn "  apt-get update retornó error — continuando"

    log_info "  Instalando fail2ban..."
    DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends \
        fail2ban > /dev/null || {
        log_error "No se pudo instalar fail2ban"
        exit 1
    }

    log_success "fail2ban instalado: $(fail2ban-client --version 2>/dev/null | head -1)"
}

# =============================================================================
# PASO: Escribir configuración de jails
# =============================================================================
_write_jail_conf() {
    log_header "PASO: Escribiendo configuración de jails"

    # Crear el directorio si no existe
    mkdir -p /etc/fail2ban/jail.d

    # Generar y escribir la configuración
    _generate_jail_conf > "$JAIL_CONF"
    log_success "Configuración escrita: ${JAIL_CONF}"

    log_info "  Jail sshd:"
    log_info "    Puerto:    ${SSH_PORT}/tcp"
    log_info "    Log:       /var/log/auth.log"
    log_info "    Max retry: ${F2B_SSH_MAXRETRY} intentos en ${F2B_SSH_FINDTIME}s"
    log_info "    Ban:       ${F2B_SSH_BANTIME}s"

    log_info "  Jail apache-auth:"
    log_info "    Log:       ${APACHE_LOG}"
    log_info "    Max retry: ${F2B_APACHE_MAXRETRY} intentos en ${F2B_APACHE_FINDTIME}s"
    log_info "    Ban:       ${F2B_APACHE_BANTIME}s"
}

# =============================================================================
# PASO: Habilitar y arrancar fail2ban
# =============================================================================
_enable_fail2ban() {
    log_header "PASO: Activando fail2ban"

    # Habilitar inicio automático (solo aplica con systemd)
    svc_enable fail2ban

    # Arrancar o reiniciar según el estado actual
    if svc_is_active fail2ban; then
        log_info "  Reiniciando fail2ban para aplicar nueva configuración..."
        svc_restart fail2ban || {
            log_error "No se pudo reiniciar fail2ban"
            log_error "  Revisa la configuración: fail2ban-client -d"
            exit 1
        }
        log_success "fail2ban reiniciado"
    else
        log_info "  Arrancando fail2ban..."
        svc_start fail2ban || {
            log_error "No se pudo arrancar fail2ban"
            log_error "  Revisa la configuración: fail2ban-client -d"
            exit 1
        }
        log_success "fail2ban arrancado"
    fi
}

# =============================================================================
# PASO: Verificar que las jails están activas
# =============================================================================
_verify_jails() {
    log_header "PASO: Verificando jails"

    # fail2ban puede tardar unos segundos en inicializar las jails
    local retries=5
    local i=0

    while (( i < retries )); do
        if fail2ban-client status &>/dev/null; then
            break
        fi
        i=$(( i + 1 ))
        log_info "  Esperando que fail2ban inicialice... (${i}/${retries})"
        sleep 2
    done

    local all_ok=true

    for jail in sshd apache-auth; do
        if fail2ban-client status "$jail" &>/dev/null; then
            log_success "  Jail '${jail}': activa"
        else
            log_error "  Jail '${jail}': NO activa"
            all_ok=false
        fi
    done

    if [[ "$all_ok" == "false" ]]; then
        log_error "Una o más jails no están activas"
        log_error "  Diagnóstico: fail2ban-client -d"
        log_error "  Logs: journalctl -u fail2ban --no-pager | tail -20"
        exit 1
    fi
}

# =============================================================================
# MAIN
# =============================================================================
log_header "Configuración de fail2ban — PracticaYoruba-server"
log_info "  SSH_PORT:          ${SSH_PORT}"
log_info "  SSH  maxretry:     ${F2B_SSH_MAXRETRY} en ${F2B_SSH_FINDTIME}s"
log_info "  SSH  bantime:      ${F2B_SSH_BANTIME}s"
log_info "  Apache maxretry:   ${F2B_APACHE_MAXRETRY} en ${F2B_APACHE_FINDTIME}s"
log_info "  Apache bantime:    ${F2B_APACHE_BANTIME}s"
echo ""

_check_requisites;    echo ""
_check_current_state; echo ""
_install_fail2ban;    echo ""
_write_jail_conf;     echo ""
_enable_fail2ban;     echo ""
_verify_jails;        echo ""

log_separator 60 "="
log_success "fail2ban configurado. Jails activas: sshd, apache-auth"
echo ""
log_info "Operaciones comunes:"
log_info "  Estado:          sudo fail2ban-client status"
log_info "  Estado jail SSH: sudo fail2ban-client status sshd"
log_info "  Desbanear IP:    sudo fail2ban-client set sshd unbanip <IP>"
log_info "  Logs:            sudo journalctl -u fail2ban"
log_info "  Verificar:       bash scripts/verify.sh"

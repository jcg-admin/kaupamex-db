#!/bin/bash
# =============================================================================
# provisioners/ssl/setup_ssl.sh
# Obtiene y configura el certificado SSL para PracticaYoruba
# =============================================================================
# IDEMPOTENTE: si el certificado existe y está vigente (SSL_CERT_STATUS=OK),
# no hace nada.
#
# Escenarios:
#   A) Certificado válido instalado (SSL_CERT_STATUS=OK):
#      No-op. Informa la fecha de expiración y los días restantes.
#
#   B) Sin certificado o expirado (SSL_CERT_STATUS=ERR):
#      --dev: genera self-signed con OpenSSL (desarrollo local)
#      sin flag: emite certificado de Let's Encrypt via acme.sh (producción)
#
#   C) Certificado próximo a vencer (SSL_CERT_STATUS=WARN):
#      Delega a scripts/renew_ssl.sh (operación continua, no setup).
#      El provisioner de setup no renueva — esa es responsabilidad de
#      renew_ssl.sh que corre vía cron.
#
# Uso:
#   sudo bash provisioners/ssl/setup_ssl.sh           # producción
#   sudo bash provisioners/ssl/setup_ssl.sh --dev     # desarrollo (self-signed)
#
# Variables requeridas en .env:
#   DOMAIN, SSL_CERT_DIR, SSL_EMAIL (solo producción),
#   SSL_CERT_DAYS_WARN, SSL_CERT_DAYS_ERR
#
# Prerequisitos para producción:
#   - Apache activo en puerto 80 (para HTTP-01 challenge de Let's Encrypt)
#   - El directorio /.well-known/ servido en HTTP sin redirect
#     (ya configurado en practicayoruba-http.conf)
#   - Acceso a internet (acme.sh descarga el certificado de Let's Encrypt)
#
# Requiere: root, Ubuntu 24.04
# =============================================================================
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "${SCRIPT_DIR}/../.." && pwd)"

source "${PROJECT_ROOT}/utils/logging.sh"
source "${PROJECT_ROOT}/utils/core.sh"
source "${PROJECT_ROOT}/utils/network.sh"
source "${PROJECT_ROOT}/utils/validation.sh"

# Detectar flag --dev
DEV_MODE=false
for arg in "$@"; do
    [[ "$arg" == "--dev" ]] && DEV_MODE=true
done

# =============================================================================
# Cargar .env — requerido
# =============================================================================
ENV_FILE="${PROJECT_ROOT}/.env"
if [[ ! -f "$ENV_FILE" ]]; then
    log_error "Archivo .env no encontrado en ${PROJECT_ROOT}"
    log_error "  Crea tu configuración: cp .env.example .env"
    exit 1
fi
set -a; source "$ENV_FILE"; set +a

# Defaults para variables de umbral si no están en .env
SSL_CERT_DAYS_WARN="${SSL_CERT_DAYS_WARN:-30}"
SSL_CERT_DAYS_ERR="${SSL_CERT_DAYS_ERR:-7}"

# =============================================================================
# PASO: Verificar requisitos
# =============================================================================
_check_requisites() {
    log_header "PASO: Verificando requisitos"

    validate_root || {
        log_error "  Ejecuta con: sudo bash provisioners/ssl/setup_ssl.sh"
        exit 1
    }
    log_success "Corriendo como root"

    [[ -n "${DOMAIN:-}" ]] || {
        log_error "DOMAIN no definido en .env"
        exit 1
    }
    log_success "DOMAIN: ${DOMAIN}"

    [[ -n "${SSL_CERT_DIR:-}" ]] || {
        log_error "SSL_CERT_DIR no definido en .env"
        exit 1
    }
    log_success "SSL_CERT_DIR: ${SSL_CERT_DIR}"

    if [[ "$DEV_MODE" == "true" ]]; then
        log_info "Modo: --dev (self-signed con OpenSSL)"
        command_exists openssl || {
            log_error "openssl no encontrado"
            log_error "  Instala con: sudo apt-get install openssl"
            exit 1
        }
        log_success "openssl disponible"
        return 0
    fi

    # Producción — verificar requisitos adicionales
    log_info "Modo: producción (Let's Encrypt via acme.sh)"

    [[ -n "${SSL_EMAIL:-}" ]] || {
        log_error "SSL_EMAIL no definido en .env"
        log_error "  Let's Encrypt requiere un email para notificaciones"
        exit 1
    }
    log_success "SSL_EMAIL: ${SSL_EMAIL}"

    # Apache debe estar activo en :80 para el HTTP-01 challenge
    if ! tcp_is_reachable "127.0.0.1" 80 3; then
        log_error "Apache no responde en el puerto 80"
        log_error "  Let's Encrypt necesita servir el challenge en HTTP"
        log_error "  Asegúrate de que Apache esté activo y el virtualhost HTTP configurado:"
        log_error "    sudo bash provisioners/apache/install.sh"
        log_error "    sudo bash provisioners/apache/setup_vhost.sh"
        exit 1
    fi
    log_success "Apache activo en puerto 80"

    # Acceso a Let's Encrypt
    if ! tcp_is_reachable "acme-v02.api.letsencrypt.org" 443 5; then
        log_error "Sin acceso a acme-v02.api.letsencrypt.org:443"
        log_error "  Se requiere conexión a internet para emitir el certificado"
        exit 1
    fi
    log_success "Acceso a Let's Encrypt"
}

# =============================================================================
# PASO: Verificar certificado existente
# Determina el escenario (A, B o C) y actúa en consecuencia
# =============================================================================
_check_existing_cert() {
    log_header "PASO: Verificando certificado existente"

    local cert_file="${SSL_CERT_DIR}/cert.pem"

    validate_ssl_cert "$cert_file" "$SSL_CERT_DAYS_WARN" "$SSL_CERT_DAYS_ERR"

    case "$SSL_CERT_STATUS" in
        OK)
            # Escenario A — certificado válido, no hacer nada
            log_success "Certificado vigente — sin acción requerida (Escenario A)"
            echo ""
            log_separator 60 "="
            log_success "Certificado SSL en orden. Sin cambios."
            exit 0
            ;;
        WARN)
            # Escenario C — próximo a vencer, delegar a renew_ssl.sh
            log_warn "Certificado próximo a vencer (Escenario C)"
            log_warn "  La renovación es responsabilidad del script de operación continua"
            local renew_script="${PROJECT_ROOT}/scripts/renew_ssl.sh"
            if [[ -f "$renew_script" ]]; then
                log_info "  Ejecutando scripts/renew_ssl.sh..."
                bash "$renew_script"
            else
                log_warn "  scripts/renew_ssl.sh no encontrado — renueva manualmente:"
                log_warn "    ~/.acme.sh/acme.sh --renew -d ${DOMAIN}"
                log_warn "    sudo systemctl reload apache2"
            fi
            exit 0
            ;;
        ERR)
            # Escenario B — sin certificado o expirado, continuar con emisión
            log_info "Procediendo con la emisión del certificado (Escenario B)"
            ;;
    esac
}

# =============================================================================
# PASO: Crear directorio de certificados
# =============================================================================
_create_cert_dir() {
    log_header "PASO: Preparando directorio de certificados"

    mkdir -p "$SSL_CERT_DIR"
    chmod 700 "$SSL_CERT_DIR"
    log_success "Directorio: ${SSL_CERT_DIR}"
}

# =============================================================================
# PASO: Generar certificado self-signed (--dev)
# =============================================================================
_generate_self_signed() {
    log_header "PASO: Generando certificado self-signed (desarrollo)"

    local cert_file="${SSL_CERT_DIR}/cert.pem"
    local key_file="${SSL_CERT_DIR}/key.pem"
    local chain_file="${SSL_CERT_DIR}/fullchain.pem"

    log_info "  Dominio: ${DOMAIN}"
    log_info "  Validez: 365 días"
    log_info "  Nota: los navegadores mostrarán una advertencia de seguridad"

    openssl req -x509 -nodes -days 365 -newkey rsa:2048 \
        -keyout "$key_file" \
        -out    "$cert_file" \
        -subj   "/CN=${DOMAIN}/O=PracticaYoruba Dev/C=MX" \
        2>/dev/null

    # Para self-signed, fullchain es igual al certificado (sin cadena intermedia)
    cp "$cert_file" "$chain_file"

    chmod 600 "$key_file"
    chmod 644 "$cert_file" "$chain_file"

    log_success "Certificado self-signed generado en ${SSL_CERT_DIR}"
    log_warn "  Válido para: ${DOMAIN}"
    log_warn "  Expiración: en 365 días"
    log_warn "  Los navegadores mostrarán advertencia — es esperado en desarrollo"
}

# =============================================================================
# PASO: Instalar acme.sh si no existe (producción)
# =============================================================================
_install_acme_sh() {
    log_header "PASO: Verificando acme.sh"

    local acme_home="${HOME}/.acme.sh"
    local acme_cmd="${acme_home}/acme.sh"

    if [[ -f "$acme_cmd" ]]; then
        log_success "acme.sh ya instalado: ${acme_cmd}"
        return 0
    fi

    log_info "  Instalando acme.sh..."

    command_exists curl || {
        log_info "  Instalando curl..."
        DEBIAN_FRONTEND=noninteractive apt-get install -y --no-install-recommends curl > /dev/null
    }

    if ! curl -fsSL https://get.acme.sh | sh -s email="${SSL_EMAIL}" > /dev/null 2>&1; then
        log_error "No se pudo instalar acme.sh"
        log_error "  Instala manualmente: curl https://get.acme.sh | sh -s email=${SSL_EMAIL}"
        exit 1
    fi

    # Recargar el PATH para encontrar acme.sh
    # shellcheck source=/dev/null
    [[ -f "${acme_home}/acme.sh.env" ]] && source "${acme_home}/acme.sh.env"

    log_success "acme.sh instalado: ${acme_cmd}"
}

# =============================================================================
# PASO: Emitir certificado Let's Encrypt (producción)
# Usa HTTP-01 webroot challenge — Apache debe estar activo en :80
# =============================================================================
_issue_certificate() {
    log_header "PASO: Emitiendo certificado para ${DOMAIN}"

    local acme_cmd="${HOME}/.acme.sh/acme.sh"
    local webroot="/var/www/html"

    # Crear el directorio del webroot challenge si no existe
    mkdir -p "${webroot}/.well-known/acme-challenge"

    log_info "  Dominio: ${DOMAIN}"
    log_info "  Método: HTTP-01 webroot (${webroot})"
    log_info "  CA: Let's Encrypt"

    if ! "$acme_cmd" --issue -d "${DOMAIN}" \
            --webroot "$webroot" \
            --accountemail "${SSL_EMAIL}" \
            2>/dev/null; then
        log_error "No se pudo emitir el certificado"
        log_error "  Verifica que:"
        log_error "    - El dominio ${DOMAIN} resuelve a este servidor"
        log_error "    - Apache sirve ${webroot}/.well-known/ en http://${DOMAIN}/"
        log_error "    - No hay firewall bloqueando el puerto 80"
        exit 1
    fi

    log_success "Certificado emitido para ${DOMAIN}"
}

# =============================================================================
# PASO: Instalar certificado en SSL_CERT_DIR (producción)
# =============================================================================
_install_certificate() {
    log_header "PASO: Instalando certificado en ${SSL_CERT_DIR}"

    local acme_cmd="${HOME}/.acme.sh/acme.sh"

    if ! "$acme_cmd" --install-cert -d "${DOMAIN}" \
            --cert-file      "${SSL_CERT_DIR}/cert.pem" \
            --key-file       "${SSL_CERT_DIR}/key.pem" \
            --fullchain-file "${SSL_CERT_DIR}/fullchain.pem" \
            --reloadcmd      "apache2ctl graceful" \
            2>/dev/null; then
        log_error "No se pudo instalar el certificado en ${SSL_CERT_DIR}"
        exit 1
    fi

    chmod 600 "${SSL_CERT_DIR}/key.pem"
    chmod 644 "${SSL_CERT_DIR}/cert.pem" "${SSL_CERT_DIR}/fullchain.pem"

    log_success "Certificado instalado en ${SSL_CERT_DIR}"
}

# =============================================================================
# PASO: Configurar renovación automática via cron (producción)
# =============================================================================
_configure_renewal() {
    log_header "PASO: Configurando renovación automática"

    local acme_cmd="${HOME}/.acme.sh/acme.sh"

    "$acme_cmd" --install-cronjob 2>/dev/null && \
        log_success "Cron de renovación automática configurado" || \
        log_warn "  No se pudo instalar el cron — configura manualmente:"
        log_warn "    0 2 * * 1 ${acme_cmd} --cron --home ${HOME}/.acme.sh"
}

# =============================================================================
# PASO: Verificar certificado instalado
# =============================================================================
_verify_certificate() {
    log_header "PASO: Verificando certificado instalado"

    validate_ssl_cert "${SSL_CERT_DIR}/cert.pem" \
        "$SSL_CERT_DAYS_WARN" "$SSL_CERT_DAYS_ERR"

    if [[ "$SSL_CERT_STATUS" == "OK" ]]; then
        log_success "Certificado verificado correctamente"
    else
        log_error "La verificación del certificado falló (SSL_CERT_STATUS=${SSL_CERT_STATUS})"
        exit 1
    fi
}

# =============================================================================
# MAIN
# =============================================================================
log_header "Configuración SSL — PracticaYoruba-server"
[[ "$DEV_MODE" == "true" ]] && \
    log_info "  Modo: self-signed (--dev)" || \
    log_info "  Modo: Let's Encrypt (producción)"
echo ""

_check_requisites;     echo ""
_check_existing_cert;  echo ""
_create_cert_dir;      echo ""

if [[ "$DEV_MODE" == "true" ]]; then
    _generate_self_signed; echo ""
else
    _install_acme_sh;     echo ""
    _issue_certificate;   echo ""
    _install_certificate; echo ""
    _configure_renewal;   echo ""
fi

_verify_certificate; echo ""

log_separator 60 "="
log_success "Certificado SSL configurado para ${DOMAIN}"
echo ""
log_info "Siguiente paso — activar los virtualhosts (si no está hecho):"
log_info "  sudo bash provisioners/apache/setup_vhost.sh"
log_info "Verificar entorno completo:"
log_info "  bash scripts/verify.sh"

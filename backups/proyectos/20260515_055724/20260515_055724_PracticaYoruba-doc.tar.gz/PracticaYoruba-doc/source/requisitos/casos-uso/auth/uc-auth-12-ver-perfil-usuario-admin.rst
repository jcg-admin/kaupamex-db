.. meta::
   :artefacto: UC-AUTH-12
   :tipo: Caso de Uso
   :subdominio: accounts
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-auth-12:

====================================================
UC-AUTH-12: Ver Perfil de Usuario (Admin)
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-12
   * - **Nombre**
     - Ver Perfil de Usuario (Admin)
   * - **Modulo**
     - ACCOUNTS (MOD-001)
   * - **BReq**
     - BReq-014
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador consultar el perfil completo de
cualquier usuario del sistema, incluyendo su estado de cuenta,
datos de contacto, actividad reciente y acciones disponibles
sobre esa cuenta. A diferencia de UC-AUTH-05 — donde el
usuario ve su propio perfil — aquí el administrador ve el
perfil de un tercero para operar sobre él.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Visualización completa del registro ``User`` del usuario
  seleccionado: datos personales, estado, tipo y actividad.
- Acceso directo a las acciones sobre la cuenta:
  suspender (UC-AUTH-13) o reactivar (UC-AUTH-14).

**Excluido de este UC:**

- Ver el propio perfil del administrador — UC-AUTH-05.
- Suspender la cuenta — UC-AUTH-13.
- Reactivar la cuenta — UC-AUTH-14.
- Editar datos del usuario — fuera del alcance del MVP.
- Los campos ``User.password``, ``User.is_superuser``
  nunca se exponen.

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Accede al backoffice con ``User.is_staff = True``.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Servicio de Cuentas** (``apps.users``)

Recupera el registro ``User`` completo del usuario
identificado por su ``User.id``.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene sesión activa con
       ``User.is_staff = True``
   * - PRE-02
     - El ``User.id`` del usuario a consultar existe en el
       sistema

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El administrador ve el perfil completo del usuario
       con su estado actual y las acciones disponibles
   * - POST-02
     - El administrador puede iniciar UC-AUTH-13 o UC-AUTH-14
       directamente desde esta vista

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Administrador
     - Selecciona un usuario del listado de UC-AUTH-11
   * - 2
     - Sistema
     - Recupera el registro ``User`` completo por ``User.id``
   * - 3
     - Sistema
     - Presenta el perfil con los datos del usuario:
       ``User.username``, ``User.email``, ``get_full_name()``,
       ``User.phone``, ``User.is_active``, ``User.is_staff``,
       ``User.date_joined``, ``User.last_login``
   * - 4
     - Sistema
     - Muestra las acciones disponibles según el estado actual:
       si ``User.is_active = True`` muestra la opción de
       suspender (UC-AUTH-13); si ``User.is_active = False``
       muestra la opción de reactivar (UC-AUTH-14)
   * - 5
     - Administrador
     - Consulta la información y decide qué acción tomar

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Usuario suspendido — contexto de suspensión
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el sistema detecta que
``User.is_active = False``.

- A1: El sistema indica de forma destacada que la cuenta
  está suspendida.
- A2: La única acción disponible en el paso 4 es reactivar
  (UC-AUTH-14). La opción de suspender no aparece.

**Retorno:** Paso 5.

4.2 Alternativa B: Usuario es administrador
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, ``User.is_staff = True``.

- B1: El sistema indica que el usuario tiene rol de
  administrador.
- B2: Las acciones de suspender y reactivar están disponibles
  igualmente — un administrador puede suspender la cuenta de
  otro administrador.

**Retorno:** Paso 5.

4.3 Alternativa C: Acceder a suspender o reactivar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 5, el administrador selecciona
la acción de suspender o reactivar.

- C1: Acción suspender → redirige a UC-AUTH-13 con
  ``User.id`` preseleccionado.
- C2: Acción reactivar → redirige a UC-AUTH-14 con
  ``User.id`` preseleccionado.

**Retorno:** UC-AUTH-13 o UC-AUTH-14 según corresponda.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Usuario no encontrado
     - El ``User.id`` no existe en el repositorio. El sistema
       informa al administrador que el usuario no fue
       encontrado y lo devuelve al listado de UC-AUTH-11.
   * - EX-02
     - Error al recuperar el perfil
     - El Servicio de Cuentas no puede consultar el
       repositorio. El sistema informa del error temporal.
       El administrador puede reintentar.

----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 300ms para cargar el perfil completo

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo usuarios con ``User.is_staff = True``
   * - Datos excluidos
     - ``User.password`` y ``User.is_superuser`` nunca
       se exponen en ninguna circunstancia

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Req
     - Descripcion
   * - ``User.id``
     - ``BigAutoField``
     - SI
     - Identificador del usuario cuyo perfil se quiere ver

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - ``User.username``
     - Nombre de usuario
   * - ``User.email``
     - Correo electrónico
   * - ``get_full_name()``
     - Nombre completo
   * - ``User.phone``
     - Teléfono de contacto (puede estar vacío)
   * - ``User.is_active``
     - Estado de la cuenta
   * - ``User.is_staff``
     - Tipo de usuario: administrador o comprador
   * - ``User.date_joined``
     - Fecha de registro
   * - ``User.last_login``
     - Último acceso (nulo si nunca accedió)
   * - Acciones disponibles
     - Suspender o Reactivar según ``User.is_active``

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Usuario no encontrado
     - 404
     - ``codigo_error = USUARIO_NO_ENCONTRADO``
   * - Error de repositorio
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-014
   * - **Depende de**
     - UC-AUTH-11 (punto de entrada al perfil)
   * - **Habilita**
     - UC-AUTH-13 (suspender), UC-AUTH-14 (reactivar)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador ve el perfil completo de
un usuario y las acciones disponibles según su estado actual.
No conoce cómo se consulta el repositorio ni cómo se determina
qué acciones están habilitadas.

**Nivel Desarrollo:** Panel Admin → Servicio de Cuentas
(``apps.users``) → Repositorio ``User`` por ``id``.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Datos del usuario, estado de cuenta, tipo
       y acciones disponibles según el estado.
     - Consulta al repositorio por ``User.id``.
       Lógica de qué acciones mostrar según
       ``User.is_active``. Exclusión de ``password``
       e ``is_superuser``.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Administrador (``User.is_staff = True``)
- **Prerequisito:** UC-AUTH-11 (el usuario debe localizarse
  en el listado)
- **Prerequisito de:** UC-AUTH-13 y UC-AUTH-14

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- ``User.is_active = True`` → muestra acción Suspender
- ``User.is_active = False`` → muestra acción Reactivar
- ``User.is_staff = True`` → indica rol de administrador
  (las acciones se mantienen disponibles)

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-12 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-12

   participant AdminPanel
   participant AccountService
   participant Repositorio

   AdminPanel -> AccountService : solicita perfil (User.id)
   AccountService -> Repositorio : busca User por id
   Repositorio --> AccountService : registro User completo
   AccountService -> AccountService : excluye password e is_superuser,\ndetermina acciones según is_active
   AccountService --> AdminPanel : perfil con datos y acciones disponibles
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-12 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-AUTH-11 Ver Listado Usuarios"
   usecase "UC-AUTH-12 Ver Perfil Usuario"
   usecase "UC-AUTH-13 Suspender Usuario"
   usecase "UC-AUTH-14 Reactivar Usuario"

   Administrador --> "UC-AUTH-12 Ver Perfil Usuario"
   "UC-AUTH-11 Ver Listado Usuarios" ..> "UC-AUTH-12 Ver Perfil Usuario"  : origen
   "UC-AUTH-12 Ver Perfil Usuario"  ..> "UC-AUTH-13 Suspender Usuario"   : acción disponible si is_active=True
   "UC-AUTH-12 Ver Perfil Usuario"  ..> "UC-AUTH-14 Reactivar Usuario"   : acción disponible si is_active=False
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 1.0.0
     - 2026-05-05
     - Version inicial. Gap identificado en analisis-cobertura-backoffice.rst.

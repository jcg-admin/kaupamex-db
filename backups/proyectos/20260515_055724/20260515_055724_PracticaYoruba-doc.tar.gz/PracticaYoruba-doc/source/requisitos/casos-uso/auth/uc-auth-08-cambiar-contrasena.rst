.. meta::
   :artefacto: UC-AUTH-08
   :tipo: Caso de Uso
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-auth-08:

========================================
UC-AUTH-08: Cambiar Contrasena
========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-08
   * - **Nombre**
     - Cambiar Contrasena
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Depende de**
     - UC-AUTH-02 (debe tener sesion activa y conocer la contrasena actual)
   * - **BReq**
     - BReq-009
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al usuario autenticado cambiar su contrasena de forma segura,
verificando primero que conoce la contrasena actual antes de aceptar
la nueva. A diferencia de UC-AUTH-09 (recuperar contrasena), este
UC requiere que el usuario recuerde su contrasena actual.

1.3 Alcance
-----------

**Incluido en este UC:**

- Verificacion de la contrasena actual del usuario
- Validacion y establecimiento de la nueva contrasena
- Invalidacion de todas las sesiones activas (excepto la actual, opcional)
- Registro en auditoria

**Excluido de este UC:**

- Recuperar contrasena sin conocer la actual — UC-AUTH-09

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Autenticado**

Persona que conoce su contrasena actual y quiere cambiarla,
ya sea por motivos de seguridad o preferencia personal.

2.2 Actores Secundarios
-----------------------

**Sistema de Autenticacion**

Verifica la contrasena actual, valida la nueva y actualiza
las credenciales del usuario de forma segura.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario esta autenticado
   * - PRE-02
     - El usuario conoce su contrasena actual

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La contrasena del usuario queda actualizada con la nueva
   * - POST-02
     - Las sesiones activas en otros dispositivos quedan invalidadas
   * - POST-03
     - El evento queda registrado en auditoria

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Desde el perfil, accede a la opcion de cambiar contrasena
   * - 2
     - Sistema
     - Presenta el formulario con tres campos: contrasena actual,
       nueva contrasena, confirmacion de nueva contrasena
   * - 3
     - Usuario
     - Ingresa su contrasena actual
   * - 4
     - Usuario
     - Ingresa la nueva contrasena
   * - 5
     - Sistema
     - Valida que la nueva contrasena cumple los requisitos de seguridad.
       Muestra indicador de fortaleza en tiempo real
   * - 6
     - Usuario
     - Confirma la nueva contrasena
   * - 7
     - Sistema
     - Verifica que nueva contrasena y confirmacion son identicas
   * - 8
     - Usuario
     - Solicita guardar el cambio
   * - 9
     - Sistema
     - Verifica la contrasena actual ingresada contra la almacenada
       (comparacion en tiempo constante)
   * - 10
     - Sistema
     - Verifica que la nueva contrasena es diferente a la actual
   * - 11
     - Sistema
     - Almacena la nueva contrasena de forma segura
   * - 12
     - Sistema
     - Invalida las sesiones activas del usuario en otros dispositivos
   * - 13
     - Sistema
     - Registra el cambio en auditoria
   * - 14
     - Sistema
     - Confirma al usuario que la contrasena fue cambiada exitosamente
   * - 15
     - Sistema
     - Informa que las sesiones en otros dispositivos han sido cerradas

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Contrasena actual incorrecta
------------------------------------------------

**Activador:** En el paso 9, la contrasena actual no coincide.

- A1: El sistema informa que la contrasena actual es incorrecta
- A2: Incrementa el contador de intentos fallidos de cambio
- A3: Los campos de nueva contrasena y confirmacion se limpian por seguridad
- A4: Si se alcanzan demasiados intentos: bloquea temporalmente

**Retorno:** Paso 3.

4.2 Alternativa B: Nueva contrasena igual a la actual
------------------------------------------------------

**Activador:** En el paso 10, la nueva contrasena es identica a la actual.

- B1: El sistema informa que la nueva contrasena debe ser diferente a la actual
- B2: El campo de nueva contrasena se limpia

**Retorno:** Paso 4.

4.3 Alternativa C: Nueva contrasena no cumple requisitos
---------------------------------------------------------

**Activador:** En el paso 5, la nueva contrasena no cumple los criterios.

- C1: El indicador de fortaleza muestra los requisitos no cumplidos
- C2: El boton de guardar permanece deshabilitado

**Retorno:** Paso 4.

4.4 Alternativa D: Confirmacion no coincide
--------------------------------------------

**Activador:** En el paso 7, las dos entradas de nueva contrasena no coinciden.

- D1: El sistema informa que las contrasenas no coinciden
- D2: El campo de confirmacion se limpia

**Retorno:** Paso 6.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - El repositorio falla al actualizar la contrasena.
       La contrasena no cambia. Se informa al usuario.
   * - EX-02
     - Error al invalidar sesiones
     - Si la invalidacion de sesiones falla despues de cambiar la contrasena,
       el cambio de contrasena persiste. Las sesiones expiraran por tiempo.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de cambio (P95)
     - Menor a 800ms (incluye verificacion y actualizacion)

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Verificacion de actual
     - La contrasena actual se verifica en tiempo constante
   * - Nueva contrasena
     - Se almacena de forma segura irreversible
   * - Nueva diferente a actual
     - El sistema impide reutilizar la misma contrasena
   * - Invalidacion de sesiones
     - Cambiar la contrasena invalida sesiones en otros dispositivos
   * - Datos en logs
     - Ninguna contrasena (actual ni nueva) aparece en ningun log

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Atomicidad
     - El cambio de contrasena y la invalidacion de sesiones ocurren de forma atomica

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Campos separados
     - Los tres campos (actual, nueva, confirmacion) son claramente diferenciados
   * - Indicador de fortaleza
     - La nueva contrasena muestra fortaleza en tiempo real
   * - Aviso de cierre de sesiones
     - El usuario es informado de que sus otras sesiones seran cerradas

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Contrasena actual
     - Texto
     - SI
     - La contrasena vigente. NUNCA se registra en logs.
   * - Nueva contrasena
     - Texto
     - SI
     - Debe cumplir requisitos de seguridad y ser diferente a la actual.
   * - Confirmacion
     - Texto
     - SI
     - Debe ser identica a la nueva contrasena.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Mensaje de cambio exitoso e informacion sobre el cierre de otras sesiones

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Contrasena actual incorrecta
     - 401
     - ``codigo_error = CONTRASENA_ACTUAL_INCORRECTA``
   * - Nueva igual a actual
     - 400
     - ``codigo_error = CONTRASENA_SIN_CAMBIO``
   * - Nueva invalida
     - 400
     - ``codigo_error = CONTRASENA_INVALIDA``
   * - No autenticado
     - 401
     - ``codigo_error = AUTENTICACION_REQUERIDA``
   * - Error del sistema
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-009
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~6 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~12 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario autenticado actualiza su contrasena verificando la actual, sin conocer el proceso de hashing.

**Nivel Desarrollo:** Interfaz de Seguridad → Servicio de Autenticacion → Repositorio de Usuarios.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario de contrasena actual y nueva (con confirmacion). Mensaje de exito y solicitud de nuevo login.
     - Verificacion del hash de la contrasena actual. Generacion del nuevo hash. Invalidacion de todas las sesiones activas excepto la actual.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Comprador autenticado
- **Diferente de:** UC-AUTH-09 (recuperar sin contrasena actual)
- **Postcondicion:** todas las sesiones en otros dispositivos quedan invalidadas

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Contrasena actual correcta** → se actualiza y se invalidan otras sesiones
- **Contrasena actual incorrecta** → error sin revelar el hash
- **Nueva contrasena debil** → rechazada con indicacion de requisitos

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-08: Cambiar Contrasena — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-08: Cambiar Contrasena

   participant SecurityInterface
   participant AuthService
   participant Repositorio

   SecurityInterface -> AuthService : envia contrasena actual y nueva
   AuthService -> Repositorio : recupera hash actual del usuario
   Repositorio --> AuthService : hash almacenado
   AuthService -> AuthService : verifica que la actual coincide con el hash
   AuthService -> AuthService : genera nuevo hash de la nueva contrasena
   AuthService -> Repositorio : actualiza el hash
   AuthService -> AuthService : invalida otras sesiones activas del usuario
   AuthService --> SecurityInterface  : contrasena actualizada
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-08: Cambiar Contrasena — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      actor AuthUser
      usecase "UC-AUTH-08 Cambiar Contrasena"
      usecase "UC-AUTH-09 Recuperar Contrasena"
      usecase "UC-AUTH-02 Login"
      AuthUser --> "UC-AUTH-08 Cambiar Contrasena"
      "UC-AUTH-08 Cambiar Contrasena" ..> "UC-AUTH-02 Login" : requiere (usuario autenticado)
      "UC-AUTH-09 Recuperar Contrasena" ..> "UC-AUTH-08 Cambiar Contrasena" : alternativa (sin contrasena actual)
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.

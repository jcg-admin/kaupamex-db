.. meta::
   :artefacto: UC-AUTH-01
   :tipo: Caso de Uso
   :dominio: requisitos
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: UC_ACC_02 TiendaMax v2.0.0

.. _uc-auth-01:

=========================================
UC-AUTH-01: Registrar Cuenta de Usuario
=========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-01
   * - **Nombre**
     - Registrar Cuenta de Usuario
   * - **Version**
     - 2.0.0
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Precedente**
     - Ninguno (punto de entrada publico)
   * - **Siguiente**
     - UC-AUTH-10 (verificar email), UC-AUTH-02 (iniciar sesion)
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir a cualquier visitante crear una cuenta en el sistema
proporcionando su informacion basica. Al completar el registro,
el sistema inicia el proceso de verificacion de identidad antes
de que el usuario pueda iniciar sesion.

1.3 Alcance
-----------

**Incluido en este UC:**

- Formulario de registro con campos requeridos
- Validacion de formato y reglas de cada campo
- Verificacion de que el identificador no este en uso
- Almacenamiento seguro de credenciales
- Generacion y envio del mensaje de verificacion de identidad
- Informacion al usuario sobre los pasos siguientes

**Excluido de este UC:**

- Registro mediante proveedores externos (OAuth, SSO) — UC futuro
- Proceso de verificacion de identidad — UC-AUTH-10
- Inicio de sesion despues del registro — UC-AUTH-02

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Visitante**

Persona que accede al sistema sin cuenta previa y desea registrarse.

Caracteristicas:

- No tiene cuenta en el sistema
- Tiene acceso a un correo electronico valido
- Desea realizar compras o acceder a funciones protegidas

Objetivos del actor:

- Crear una cuenta para poder comprar y gestionar sus ordenes

2.2 Actores Secundarios
-----------------------

**Sistema de Validacion**

Verifica que los datos ingresados cumplan las reglas del sistema:
formato de email, fortaleza de contrasena, campos obligatorios.

**Servicio de Notificacion**

Envia el mensaje de verificacion de identidad al email registrado.
Su disponibilidad no bloquea la creacion de la cuenta.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El visitante no tiene una cuenta existente con el mismo email
   * - PRE-02
     - El sistema esta disponible y operando correctamente
   * - PRE-03
     - El canal de comunicacion es seguro y cifrado

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La cuenta queda creada en estado pendiente de verificacion
   * - POST-02
     - El sistema envia un mensaje de verificacion al email registrado
   * - POST-03
     - El visitante no puede iniciar sesion hasta completar UC-AUTH-10
   * - POST-04
     - El evento de registro queda registrado en el log de auditoria

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - No se crea ninguna cuenta en el sistema
   * - POST-F02
     - El visitante recibe informacion sobre el motivo del fallo

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

Secuencia normal: el visitante crea su cuenta exitosamente.

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Visitante
     - Accede a la pagina de registro del sistema
   * - 2
     - Sistema
     - Presenta el formulario de registro con los campos requeridos:
       nombre, apellido, email y contrasena (con confirmacion).
       Incluye enlace a la politica de privacidad y terminos de uso.
       Incluye enlace a iniciar sesion si ya tiene cuenta
   * - 3
     - Visitante
     - Ingresa su nombre
   * - 4
     - Sistema
     - Valida que el nombre no este vacio y cumpla la longitud minima
   * - 5
     - Visitante
     - Ingresa su apellido
   * - 6
     - Sistema
     - Valida que el apellido no este vacio y cumpla la longitud minima
   * - 7
     - Visitante
     - Ingresa su email
   * - 8
     - Sistema
     - Valida el formato del email en tiempo real con retroalimentacion visual.
       Verifica que el email no este ya registrado en el sistema
   * - 9
     - Visitante
     - Ingresa su contrasena
   * - 10
     - Sistema
     - Valida que la contrasena cumpla los requisitos de seguridad definidos.
       Muestra indicador de fortaleza en tiempo real
   * - 11
     - Visitante
     - Confirma la contrasena (la escribe nuevamente)
   * - 12
     - Sistema
     - Verifica que ambas contrasenas sean identicas
   * - 13
     - Visitante
     - Acepta los terminos de uso y politica de privacidad
   * - 14
     - Visitante
     - Solicita crear la cuenta
   * - 15
     - Sistema
     - Realiza validacion final de todos los campos de forma conjunta
   * - 16
     - Sistema
     - Verifica una vez mas que el email no esta ya registrado
       (para cubrir el caso de registro concurrente)
   * - 17
     - Sistema
     - Crea la cuenta en estado pendiente de verificacion.
       La contrasena se almacena de forma segura, nunca en texto plano
   * - 18
     - Sistema
     - Genera un token de verificacion de un solo uso con tiempo de expiracion
   * - 19
     - Sistema
     - Envia el mensaje de verificacion al email registrado
       con el enlace para confirmar la identidad
   * - 20
     - Sistema
     - Registra el evento de registro en el log de auditoria
   * - 21
     - Sistema
     - Informa al visitante que la cuenta fue creada y que debe
       revisar su email para completar el proceso

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Email ya registrado
---------------------------------------

**Activador:** En el paso 8 o 16, el email ya existe en el sistema.

- A1: El sistema detecta que el email ya esta asociado a una cuenta
- A2: Informa al visitante que el email ya esta registrado
- A3: Ofrece la opcion de iniciar sesion (UC-AUTH-02)
  o recuperar contrasena (UC-AUTH-09) si olvido sus datos
- A4: No crea un registro duplicado

**Retorno:** Paso 7 o cierre del flujo.

4.2 Alternativa B: Contrasena no cumple requisitos
---------------------------------------------------

**Activador:** En el paso 10, la contrasena no cumple los criterios de seguridad.

- B1: El sistema muestra los requisitos no cumplidos de forma clara
- B2: El indicador de fortaleza refleja el nivel actual
- B3: El visitante puede corregir y reintentar sin perder los otros campos

**Retorno:** Paso 9.

4.3 Alternativa C: Contrasenas no coinciden
--------------------------------------------

**Activador:** En el paso 12, las dos contrasenas ingresadas no son iguales.

- C1: El sistema indica que las contrasenas no coinciden
- C2: El campo de confirmacion se limpia
- C3: El visitante puede reintentar sin perder los otros campos

**Retorno:** Paso 11.

4.4 Alternativa D: Email del servicio de notificacion no disponible
-------------------------------------------------------------------

**Activador:** En el paso 19, el servicio de notificacion no puede enviar el mensaje.

- D1: La cuenta queda creada en estado pendiente de verificacion
- D2: El sistema informa al visitante que hubo un problema enviando el email
- D3: Ofrece la opcion de solicitar el reenvio del mensaje (UC-AUTH-10)
- D4: El visitante puede intentar mas tarde desde la pagina de verificacion pendiente

**Retorno:** El visitante va a UC-AUTH-10.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Repositorio no disponible
     - El repositorio de usuarios no responde durante el intento de creacion.
       El sistema informa de un error temporal. No se crea ninguna cuenta.
   * - EX-02
     - Conflicto de registro concurrente
     - Dos visitantes intentan registrar el mismo email simultaneamente.
       El sistema garantiza que solo uno prospera y el otro recibe el mensaje
       de email ya registrado.
   * - EX-03
     - Solicitud invalida
     - Campos faltantes, tipos incorrectos o formato invalido.
       El sistema retorna error de validacion con descripcion de los campos.
   * - EX-04
     - Canal no seguro
     - La solicitud llega por canal no cifrado.
       El sistema rechaza la solicitud. Las credenciales nunca viajan en claro.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta del registro (P95)
     - Menor a 800ms (incluye creacion de cuenta y generacion de token)
   * - Tiempo de envio del mensaje de verificacion
     - El envio ocurre de forma asincrona y no bloquea la respuesta al usuario
   * - Disponibilidad
     - Segun SLO de BReq-007

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Almacenamiento de contrasenas
     - NUNCA en texto plano. Solo se almacena la representacion segura irreversible
   * - Token de verificacion
     - De un solo uso con tiempo de expiracion definido.
       No puede reutilizarse despues de ser usado o de expirar
   * - Canal de comunicacion
     - Toda la informacion viaja por canal seguro cifrado
   * - Datos en logs
     - Las contrasenas NUNCA aparecen en ningun registro del sistema
   * - Registro de auditoria
     - Todo intento de registro queda registrado con timestamp y origen

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Unicidad del identificador
     - El sistema garantiza que no existan dos cuentas con el mismo email,
       incluso bajo registro concurrente
   * - Consistencia de estado
     - Una cuenta creada siempre queda en estado consistente
       independientemente de si el envio del mensaje fallo
   * - Recuperabilidad
     - Si el mensaje de verificacion no llego, el usuario puede solicitarlo
       de nuevo sin tener que volver a registrarse

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Indicador de fortaleza
     - La contrasena muestra un indicador visual de fortaleza en tiempo real
   * - Retroalimentacion inmediata
     - Cada campo valida al perder el foco sin esperar al envio del formulario
   * - Claridad de requisitos
     - Los requisitos de contrasena son visibles antes de que el usuario comience a escribir
   * - Mensajes de error
     - Especificos por campo, claros y orientados a la accion correctiva
   * - Accesibilidad
     - WCAG 2.1 nivel AA
   * - Adaptabilidad
     - Funciona en dispositivos moviles y de escritorio

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 18 12 12 58
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion y reglas
   * - Nombre
     - Texto
     - SI
     - Nombre del usuario. Longitud: 2 a 50 caracteres.
       Solo letras, espacios y caracteres especiales del idioma.
   * - Apellido
     - Texto
     - SI
     - Apellido del usuario. Longitud: 2 a 50 caracteres.
   * - Email
     - Texto
     - SI
     - Formato RFC 5322. Longitud: 5 a 254 caracteres.
       Se normaliza a minusculas. Debe ser unico en el sistema.
   * - Contrasena
     - Texto
     - SI
     - Debe cumplir los criterios de seguridad definidos (longitud minima,
       complejidad). Se almacena de forma segura irreversible.
       NUNCA se registra en logs.
   * - Confirmacion
     - Texto
     - SI
     - Debe ser identica a la contrasena. Solo se usa para validacion en cliente.
   * - Aceptacion de terminos
     - Booleano
     - SI
     - El usuario debe aceptar los terminos de uso y politica de privacidad.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion de registro
     - Mensaje informando que la cuenta fue creada exitosamente
       y que el usuario debe revisar su email para completar la verificacion
   * - Instrucciones de verificacion
     - Pasos claros sobre como completar el proceso (revisar email, hacer clic en enlace)

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Email ya registrado
     - 409
     - Indica que el email ya esta asociado a una cuenta.
       Ofrece opciones de inicio de sesion o recuperacion.
       ``codigo_error = EMAIL_YA_REGISTRADO``
   * - Datos invalidos
     - 400
     - Describe los campos con errores de formato o reglas incumplidas.
       ``codigo_error = DATOS_INVALIDOS``
   * - Error del sistema
     - 500
     - Mensaje generico temporal sin detalles internos.
       ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001 (plataforma)
   * - **BR**
     - BR-013 (auditabilidad)
   * - **Habilita**
     - UC-AUTH-10, UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~8 FR estimados)
   * - **Pseudocode**
     - Pendiente - Capa 4
   * - **Tests**
     - Pendiente - Capa 5 (~16 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El visitante proporciona su email y contrasena y obtiene una cuenta activa, sin conocer el proceso de hashing ni el envio del email de verificacion.

**Nivel Desarrollo:** Interfaz de Registro → Servicio de Autenticacion → Repositorio de Usuarios → Servicio de Notificaciones.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario de email y contrasena. Mensaje de confirmacion con instruccion de verificar email.
     - Hash de contrasena. Generacion del token de verificacion. Envio del email de verificacion (UC-AUTH-10). Registro en auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** N/A (crea al Visitante que luego puede ser Comprador)
- **Este UC habilita:** UC-AUTH-10 (verificar email)
- **Este UC habilita:** UC-AUTH-02 (login una vez verificado)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Email ya registrado** → error EMAIL_DUPLICADO, se ofrece login o recuperacion
- **Registro como invitado** → el sistema no requiere verificacion inmediata para completar la compra (BR-011)

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-01: Registrar Cuenta — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-01: Registrar Cuenta

   participant RegistrationInterface
   participant AuthService
   participant Repositorio
   participant NotificationService

   RegistrationInterface -> AuthService : envia email y contrasena
   AuthService -> Repositorio : verifica que el email no existe
   Repositorio --> AuthService : email disponible
   AuthService -> AuthService : genera hash de contrasena
   AuthService -> Repositorio : crea el usuario (inactivo hasta verificar)
   AuthService ->> NotificationService : envia email de verificacion (UC-AUTH-10, asincrono)
   AuthService --> RegistrationInterface  : cuenta creada, revisa tu email
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-01: Registrar Cuenta — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      actor Visitante
   
      usecase "UC-AUTH-01 Registrar"
      usecase "UC-AUTH-10 Verificar Email"
      usecase "UC-AUTH-02 Login"
   
      Visitante --> "UC-AUTH-01 Registrar"
      "UC-AUTH-01 Registrar" ->> "UC-AUTH-10 Verificar Email" : dispara (asincrono)
      "UC-AUTH-01 Registrar"  ..> "UC-AUTH-02 Login" : habilita (tras verificar)
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa con las 7 partes requeridas.
       Adaptado de UC_ACC_02 TiendaMax v2.0.0.
       Sin referencias tecnologicas. Diagramas en PlantUML.

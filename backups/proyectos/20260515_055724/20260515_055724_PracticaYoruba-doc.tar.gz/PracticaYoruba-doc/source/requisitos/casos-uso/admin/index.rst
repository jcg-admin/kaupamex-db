.. meta::
   :tipo: Indice
   :estado: Vigente

=================================
Administracion del Sistema (ADM)
=================================

UCs del panel de administracion. Actores: Administrador con permisos staff.

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-adm-01-gestionar-usuarios
   uc-adm-02-gestionar-permisos
   uc-adm-03-auditoria
   uc-adm-04-configuracion-sistema
   uc-adm-05-backup-automatico

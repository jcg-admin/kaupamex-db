.. meta::
   :artefacto: UC-CFG-03
   :tipo: Caso de Uso
   :subdominio: settings
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-cfg-03:

==========================================================
UC-CFG-03: Configurar SiteSettings (IVA, Moneda, Nombre)
==========================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CFG-03
   * - **Nombre**
     - Configurar SiteSettings (IVA, Moneda, Nombre)
   * - **Modulo**
     - SETTINGS
   * - **Criticidad**
     - CRITICA
   * - **Complejidad**
     - BAJA
   * - **BReq**
     - BReq-015
   * - **BR aplicadas**
     - BR-001, BR-002, BR-013

1.2 Proposito
-------------

Permitir al administrador configurar los parametros globales del sitio: nombre del negocio, moneda, tasa de IVA y otros valores que afectan el comportamiento general del sistema como el calculo de precios.

1.3 Alcance
-----------

**Incluido en este UC:**

- Configurar SiteSettings (IVA, Moneda, Nombre)
- Validacion de los datos ingresados
- Aplicacion inmediata de los cambios

**Excluido de este UC:**

- Gestion de contenido estatico — UC-CFG-04
- Datos de contacto — UC-CFG-05

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
-------------------

**Administrador**

Usuario con rol administrativo responsable de la configuracion del sistema.

2.2 Actores Secundarios
-----------------------

**Sistema de Configuracion**

Valida y persiste los parametros del sistema.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene rol de administrador del sistema
   * - PRE-02
     - El sistema esta disponible

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La configuracion de configurar sitesettings (iva, moneda, nombre) queda actualizada
   * - POST-02
     - El cambio tiene efecto inmediato en el sistema

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La configuracion anterior permanece sin cambios


----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la configuracion general del sitio
   * - 2
     - Sistema
     - Muestra los valores actuales de cada parametro
   * - 3
     - Admin
     - Modifica los parametros deseados: nombre, moneda, tasa de IVA
   * - 4
     - Sistema
     - Valida que los valores son correctos
   * - 5
     - Sistema
     - Aplica los cambios al sistema
   * - 6
     - Sistema
     - Confirma los nuevos valores activos

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Error de formato en un campo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** Un valor ingresado no cumple el formato esperado.

- El sistema indica el campo y el formato esperado.
- El administrador puede corregir sin perder los otros cambios.



4.2 Alternativa B: Cambio de tasa de IVA con ordenes pendientes
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** El administrador modifica la tasa de IVA cuando hay ordenes
en estado PENDIENTE_PAGO.

- B1: El sistema advierte que el cambio de IVA no afecta las ordenes ya creadas
  (sus valores son snapshots inmutables — BR-005)
- B2: El nuevo IVA se aplica unicamente a las nuevas ordenes que se creen a partir
  del momento del cambio
- B3: El administrador confirma entendiendo el alcance del cambio

4.3 Alternativa C: Cambio de moneda del negocio
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El administrador cambia la moneda base del sistema.

- C1: El sistema advierte que el cambio de moneda afectara todos los precios mostrados.
- C2: Las ordenes historicas conservan la moneda con la que fueron creadas (BR-005).
- C3: Los precios del catalogo se mantienen en el valor numerico pero en la nueva moneda.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - La configuracion no se persiste. Se informa al administrador.

   * - EX-02
     - Tasa de IVA fuera del rango valido
     - El valor ingresado para la tasa de IVA esta fuera del rango permitido (0% a 100%). El sistema rechaza el cambio e informa el rango valido.
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Aplicacion de cambios (P95)
     - Menor a 500ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Solo administradores
     - Solo usuarios con rol de administrador pueden cambiar la configuracion
   * - Credenciales enmascaradas
     - Las credenciales sensibles se muestran enmascaradas en la interfaz

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Cambio inmediato
     - La configuracion tiene efecto inmediato sin necesidad de reiniciar el sistema

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Valores actuales visibles
     - El administrador ve los valores actuales antes de modificar
   * - Confirmacion del cambio
     - El administrador recibe confirmacion de que el cambio fue aplicado

----

PARTE 7: Datos Involucrados
------------------------------

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Parametros a configurar
     - Varios
     - SI
     - Dependiendo del UC especifico

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Los nuevos valores activos en el sistema

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Valor invalido
     - 400
     - ``codigo_error = CONFIGURACION_INVALIDA``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``

----

Trazabilidad
-------------

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-015
   * - **BR**
     - BR-001, BR-002, BR-013
   * - **Depende de**
     - —
   * - **Habilita**
     - UC-CAT-01 (precios), UC-ORD-01 (calculo de IVA)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`


8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario (Admin):** el administrador ajusta los parametros globales sin conocer
como se propagan a los calculos de precio en tiempo real.

**Nivel Desarrollo:** Panel Admin → Servicio de Configuracion → SiteSettings → Todos los servicios que usan IVA.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el Admin)
     - Logica privada (invisible para el Admin)
   * - Formulario de parametros globales: nombre del negocio, moneda, tasa de IVA. Confirmacion de valores activos en el sistema.
     - Propagacion del nuevo IVA a calculos de precio. IVA en ordenes existentes NO cambia (BR-005). Registro de auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante
- **Depende de:** —
- **Habilita:** UC-CAT-01, UC-CAT-02 (precios), UC-ORD-01 (calculo de IVA)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

Este UC tiene comportamiento uniforme para el administrador.
El polimorfismo se expresa en los UCs que consumen esta configuracion
(UC-ORD-01 usa el metodo de envio; UC-CAT-01 usa el IVA configurado).

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: uc-cfg-03-configurar-sitesettings--iva- — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title Configurar SiteSettings (Admin)

   participant AdminPanel
   participant ConfigService
   participant Repositorio

   AdminPanel -> ConfigService : envia nuevos parametros
   ConfigService -> ConfigService : valida formato y consistencia
   ConfigService -> Repositorio : persiste la configuracion
   Repositorio --> ConfigService : confirmacion
   ConfigService -> Repositorio : registra cambio en auditoria
   ConfigService --> AdminPanel  : nuevos valores activos en el sistema
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: uc-cfg-03-configurar-sitesettings--iva- — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor Administrador

   usecase "UC-CFG-03-CONFIGURAR Configurar SiteSettings"
   usecase "UC-ORD-01 Crear Orden"

   Administrador --> "UC-CFG-03-CONFIGURAR Configurar SiteSettings"
   "UC-CFG-03-CONFIGURAR Configurar SiteSettings" ..> "UC-ORD-01 Crear Orden" : habilita (configuracion activa)
   @enduml

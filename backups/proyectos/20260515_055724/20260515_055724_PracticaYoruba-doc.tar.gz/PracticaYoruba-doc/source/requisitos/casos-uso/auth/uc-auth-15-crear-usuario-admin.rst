.. meta::
   :artefacto: UC-AUTH-15
   :tipo: Caso de Uso
   :subdominio: accounts
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-auth-15:

====================================================
UC-AUTH-15: Crear Usuario Administrador
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-15
   * - **Nombre**
     - Crear Usuario Administrador
   * - **Modulo**
     - ACCOUNTS (MOD-001)
   * - **BReq**
     - BReq-014
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador crear una nueva cuenta con acceso
al backoffice, estableciendo ``User.is_staff = True``. A
diferencia de UC-AUTH-01 — donde un visitante se registra
como comprador — aquí el administrador provisiona una cuenta
para otro miembro del equipo de operaciones.

La cuenta se crea directamente activa con una contraseña
temporal. El nuevo administrador debe cambiarla en su
primer acceso mediante UC-AUTH-08.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Creación de un ``User`` con ``is_staff = True``
  e ``is_active = True``.
- Establecimiento de una contraseña temporal definida por
  el administrador que crea la cuenta.

**Excluido de este UC:**

- Crear cuentas de comprador — UC-AUTH-01.
- Crear cuentas con ``User.is_superuser = True`` — solo
  posible desde la consola del servidor con
  ``createsuperuser``.
- Verificación de email — no aplica para cuentas
  administrativas creadas internamente.
- Cambio de contraseña temporal — responsabilidad del nuevo
  administrador mediante UC-AUTH-08.

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Accede al backoffice con ``User.is_staff = True``.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Servicio de Cuentas** (``apps.users``)

Valida la unicidad de ``username`` y ``email``, almacena
el hash de la contraseña y persiste el nuevo ``User``.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene sesión activa con
       ``User.is_staff = True``

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - Existe un nuevo ``User`` con ``is_staff = True``,
       ``is_active = True`` e ``is_superuser = False``
   * - POST-02
     - ``User.password`` almacena el hash de la contraseña
       temporal — nunca en texto plano
   * - POST-03
     - El nuevo administrador puede iniciar sesión mediante
       UC-AUTH-02 con la contraseña temporal

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - No se crea ningún ``User``
   * - POST-F02
     - El ``username`` y el ``email`` indicados siguen
       disponibles en el sistema

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Administrador
     - Accede al formulario de nuevo administrador en el
       backoffice
   * - 2
     - Administrador
     - Ingresa ``User.username``, ``User.email``,
       ``User.first_name``, ``User.last_name`` y una
       contraseña temporal
   * - 3
     - Sistema
     - Valida que ``User.username`` no existe en el
       repositorio (campo ``unique``)
   * - 4
     - Sistema
     - Valida que ``User.email`` no existe en el
       repositorio (campo ``unique``)
   * - 5
     - Sistema
     - Valida que la contraseña temporal cumple las reglas
       mínimas de seguridad definidas en ``SiteSettings``
   * - 6
     - Administrador
     - Confirma la creación
   * - 7
     - Sistema
     - Crea el ``User`` con ``is_staff = True``,
       ``is_active = True``, ``is_superuser = False`` y
       almacena el hash de la contraseña temporal
   * - 8
     - Sistema
     - Confirma la creación, muestra las credenciales de
       acceso (``username`` y contraseña temporal en texto
       claro, por única vez) para que el administrador las
       entregue al nuevo miembro del equipo

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Username ya existe
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el Servicio de Cuentas detecta
que ``User.username`` ya está registrado.

- A1: El sistema informa al administrador que el nombre de
  usuario ya está en uso.
- A2: El formulario señala el campo ``username`` con el error.
- A3: El administrador ingresa un ``username`` diferente.

**Retorno:** Paso 3.

4.2 Alternativa B: Email ya existe
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4, el Servicio de Cuentas detecta
que ``User.email`` ya está registrado en otra cuenta.

- B1: El sistema informa al administrador que el email ya
  está asociado a otra cuenta.
- B2: El formulario señala el campo ``email`` con el error.
- B3: El administrador ingresa un ``email`` diferente.

**Retorno:** Paso 4.

4.3 Alternativa C: El nuevo admin cambia su contraseña en el primer acceso
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 5, el administrador creador elige la opción
de notificar al nuevo usuario de sus credenciales temporales.

- C1: El nuevo administrador inicia sesión con UC-AUTH-02
  usando las credenciales temporales.
- C2: El sistema recomienda cambiar la contraseña temporal
  en el perfil mediante UC-AUTH-08.
- C3: La contraseña temporal deja de ser válida tras el cambio.

**Retorno:** no aplica — flujo posterior a este UC.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Contraseña temporal no cumple requisitos mínimos
     - La contraseña ingresada no cumple las reglas de
       seguridad mínimas. El sistema indica los requisitos
       incumplidos. No se crea ningún ``User``. El
       administrador debe corregirla antes de continuar.
   * - EX-02
     - Error al persistir el nuevo usuario
     - El Servicio de Cuentas no puede escribir el registro.
       No se crea ningún ``User``. El sistema informa del
       error temporal y ofrece reintentar.

----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 500ms para creación y confirmación

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo usuarios con ``User.is_staff = True``
   * - Hash de contraseña
     - ``User.password`` almacena únicamente el hash —
       nunca la contraseña en texto plano
   * - Exposición única
     - La contraseña temporal se muestra en texto claro
       solo en el paso 8 de confirmación, por única vez.
       No se almacena en texto claro en ningún momento
   * - is_superuser bloqueado
     - El sistema establece ``is_superuser = False``
       siempre. No existe campo de formulario para elevarlo

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Req
     - Descripcion
   * - ``User.username``
     - ``CharField(150)``
     - SI
     - Nombre de usuario único en el sistema
   * - ``User.email``
     - ``EmailField``
     - SI
     - Correo electrónico único en el sistema
   * - ``User.first_name``
     - ``CharField(150)``
     - NO
     - Nombre del nuevo administrador
   * - ``User.last_name``
     - ``CharField(150)``
     - NO
     - Apellido del nuevo administrador
   * - Contraseña temporal
     - ``CharField``
     - SI
     - Contraseña para el primer acceso. Debe cumplir las
       reglas mínimas de seguridad de ``SiteSettings``

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - ``User.id``
     - Identificador del nuevo administrador creado
   * - ``User.username``
     - Nombre de usuario para entregar al nuevo miembro
   * - Contraseña temporal
     - Mostrada en texto claro por única vez para entrega
       al nuevo miembro del equipo

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Username ya existe
     - 409
     - ``codigo_error = USERNAME_EN_USO``
   * - Email ya existe
     - 409
     - ``codigo_error = EMAIL_EN_USO``
   * - Contraseña no cumple requisitos
     - 422
     - ``codigo_error = CONTRASENA_INVALIDA``
   * - Error de persistencia
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-014
   * - **Habilita**
     - UC-AUTH-02 (el nuevo admin puede iniciar sesión),
       UC-AUTH-08 (debe cambiar la contraseña temporal)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador rellena el formulario y
recibe las credenciales del nuevo miembro del equipo. No
conoce cómo se hashea la contraseña ni los detalles de la
persistencia.

**Nivel Desarrollo:** Panel Admin → Servicio de Cuentas
(``apps.users``) → Repositorio ``User``.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario con username, email, nombre y
       contraseña temporal. Credenciales mostradas
       en el paso de confirmación.
     - Validación de unicidad de ``username`` y ``email``.
       Hash de contraseña. Establecimiento de
       ``is_staff = True``, ``is_superuser = False``.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Administrador (``User.is_staff = True``)
- **Habilita:** UC-AUTH-02 (acceso del nuevo administrador),
  UC-AUTH-08 (cambio de contraseña temporal)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- ``is_staff = True`` → acceso al backoffice habilitado
- ``is_superuser = False`` siempre → no hay elevación
  de privilegios desde el backoffice
- Contraseña temporal → válida hasta que el nuevo admin
  la cambie mediante UC-AUTH-08

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-15 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-15

   participant AdminPanel
   participant AccountService
   participant Repositorio

   AdminPanel -> AccountService : envía datos del nuevo admin
   AccountService -> Repositorio : verifica unicidad de username
   Repositorio --> AccountService : username disponible
   AccountService -> Repositorio : verifica unicidad de email
   Repositorio --> AccountService : email disponible
   AccountService -> AccountService : hashea contraseña temporal
   AccountService -> Repositorio : crea User (is_staff=True, is_superuser=False)
   Repositorio --> AccountService : User.id confirmado
   AccountService --> AdminPanel : credenciales del nuevo admin (una sola vez)
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-15 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-AUTH-15 Crear Usuario Admin"
   usecase "UC-AUTH-02 Iniciar Sesion"
   usecase "UC-AUTH-08 Cambiar Contrasena"
   usecase "UC-AUTH-11 Ver Listado Usuarios"

   Administrador --> "UC-AUTH-15 Crear Usuario Admin"
   "UC-AUTH-15 Crear Usuario Admin" ..> "UC-AUTH-02 Iniciar Sesion"         : habilita primer acceso
   "UC-AUTH-15 Crear Usuario Admin" ..> "UC-AUTH-08 Cambiar Contrasena"  : el nuevo admin debe cambiar contraseña temporal
   "UC-AUTH-15 Crear Usuario Admin" ..> "UC-AUTH-11 Ver Listado Usuarios"   : el nuevo admin aparece en el listado
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 1.0.0
     - 2026-05-05
     - Version inicial. Gap identificado en analisis-cobertura-backoffice.rst.

.. meta::
   :tipo: Indice
   :estado: Vigente

=============
Configuracion
=============

UCs de configuracion del sistema. Actor: Administrador.

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Nombre
   * - UC-CFG-01
     - Configurar Gateways de Pago
   * - UC-CFG-02
     - Configurar Metodos y Costos de Envio
   * - UC-CFG-03
     - Configurar SiteSettings (IVA, Moneda, Nombre)
   * - UC-CFG-04
     - Gestionar Contenido Estatico
   * - UC-CFG-05
     - Gestionar Datos de Contacto

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-cfg-01-configurar-gateways-de-pago
   uc-cfg-02-configurar-metodos-y-costos-de
   uc-cfg-03-configurar-sitesettings--iva-
   uc-cfg-04-gestionar-contenido-estatico
   uc-cfg-05-gestionar-datos-contacto

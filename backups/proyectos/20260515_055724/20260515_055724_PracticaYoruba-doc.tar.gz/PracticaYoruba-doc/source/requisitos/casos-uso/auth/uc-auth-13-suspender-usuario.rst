.. meta::
   :artefacto: UC-AUTH-13
   :tipo: Caso de Uso
   :subdominio: accounts
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-auth-13:

====================================================
UC-AUTH-13: Suspender Cuenta de Usuario (Admin)
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-13
   * - **Nombre**
     - Suspender Cuenta de Usuario (Admin)
   * - **Modulo**
     - ACCOUNTS (MOD-001)
   * - **BReq**
     - BReq-014
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador desactivar la cuenta de un usuario
estableciendo ``User.is_active = False``. A partir de ese
momento el usuario no puede iniciar sesión ni renovar su
sesión activa. La cuenta se conserva con todo su historial
— la suspensión no elimina datos.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Establecer ``User.is_active = False`` en la cuenta del
  usuario seleccionado.

**Excluido de este UC:**

- Eliminar la cuenta — operación no soportada en el MVP.
- Reactivar la cuenta — UC-AUTH-14.
- Suspender la propia cuenta del administrador — protegido
  por este UC (ver EX-02).
- Suspender una cuenta con ``User.is_superuser = True`` —
  protegido (ver EX-03).

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Accede al backoffice con ``User.is_staff = True``.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Servicio de Cuentas** (``apps.users``)

Aplica el cambio de estado y lo persiste.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene sesión activa con
       ``User.is_staff = True``
   * - PRE-02
     - El usuario a suspender existe con
       ``User.is_active = True``
   * - PRE-03
     - El usuario a suspender no es el propio administrador
       que ejecuta la acción
   * - PRE-04
     - El usuario a suspender tiene
       ``User.is_superuser = False``

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - ``User.is_active = False`` en la cuenta del usuario
       seleccionado
   * - POST-02
     - El usuario suspendido no puede iniciar sesión
       (UC-AUTH-02 rechaza con ``CUENTA_INACTIVA``)
   * - POST-03
     - Los refresh tokens del usuario son rechazados
       inmediatamente (UC-AUTH-04 paso 5 verifica
       ``User.is_active``)
   * - POST-04
     - Los access tokens vigentes expiran de forma natural
       en un máximo de 15 minutos — ventana residual conocida
       y aceptada del diseño JWT stateless

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - ``User.is_active`` conserva el valor ``True``
   * - POST-F02
     - El usuario puede seguir accediendo normalmente

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Administrador
     - Accede al perfil del usuario desde UC-AUTH-12 y
       selecciona la opción de suspender
   * - 2
     - Sistema
     - Verifica que el usuario no es el propio administrador
       y que no tiene ``User.is_superuser = True``
   * - 3
     - Sistema
     - Muestra el resumen de la cuenta a suspender:
       ``User.username``, ``User.email`` y aviso del impacto:
       el usuario no podrá iniciar sesión hasta que la cuenta
       sea reactivada en UC-AUTH-14
   * - 4
     - Administrador
     - Confirma la suspensión
   * - 5
     - Sistema
     - Establece ``User.is_active = False`` y registra
       ``updated_at`` con el timestamp de la operación
   * - 6
     - Sistema
     - Confirma la suspensión y retorna a UC-AUTH-12 con
       el estado actualizado de la cuenta

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Cancelación antes de confirmar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4, el administrador decide no
proceder con la suspensión.

- A1: El sistema cancela la operación sin modificar ningún dato.
- A2: ``User.is_active`` permanece ``True``.
- A3: El sistema retorna al perfil del usuario en UC-AUTH-12.

**Retorno:** UC-AUTH-12.

4.2 Alternativa B: El usuario tiene sesión activa en el momento de la suspensión
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 5, el usuario suspendido tiene un
access token vigente emitido antes de la suspensión.

- B1: El sistema establece ``User.is_active = False`` igualmente.
- B2: El access token vigente expira de forma natural en un
  máximo de 15 minutos (límite de vida del access token).
- B3: Cuando el usuario intente renovar su sesión, UC-AUTH-04
  rechaza la solicitud en el paso 5 con ``CUENTA_INACTIVA``.
- B4: El sistema informa al administrador de esta ventana
  residual en la confirmación del paso 6.

**Retorno:** Paso 6.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Usuario ya suspendido o no encontrado
     - El ``User.is_active`` ya es ``False`` o el
       ``User.id`` no existe. El sistema informa al
       administrador y lo devuelve al listado de UC-AUTH-11.
   * - EX-02
     - Intento de suspender la propia cuenta
     - El ``User.id`` del usuario a suspender coincide con
       el ``User.id`` del administrador autenticado. El
       sistema rechaza la operación con el mensaje «No puedes
       suspender tu propia cuenta» y no modifica ningún dato.
   * - EX-03
     - Intento de suspender una cuenta de superusuario
     - El usuario a suspender tiene
       ``User.is_superuser = True``. El sistema rechaza la
       operación. Las cuentas de superusuario solo pueden
       gestionarse desde la consola del servidor.
   * - EX-04
     - Error al persistir la suspensión
     - El Servicio de Cuentas no puede escribir el cambio.
       ``User.is_active`` conserva el valor ``True``. El
       sistema informa del error temporal y ofrece reintentar.

----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 400ms para aplicar y confirmar la suspensión

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo usuarios con ``User.is_staff = True``
   * - Autoprotección
     - El sistema nunca permite que un administrador
       suspenda su propia cuenta
   * - Protección de superusuario
     - Las cuentas con ``User.is_superuser = True`` no
       pueden suspenderse desde el backoffice

6.3 Confiabilidad
^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Confirmación obligatoria
     - El sistema siempre muestra el resumen del impacto
       antes de ejecutar la suspensión
   * - Ventana residual documentada
     - Los access tokens vigentes expiran en máximo 15
       minutos — limitación conocida del diseño JWT

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Req
     - Descripcion
   * - ``User.id``
     - ``BigAutoField``
     - SI
     - Identificador del usuario a suspender
   * - Confirmación del admin
     - Booleano
     - SI
     - El administrador debe confirmar explícitamente

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - ``User.is_active``
     - ``False``
   * - ``User.updated_at``
     - Timestamp de la suspensión
   * - Aviso de ventana residual
     - Confirmación de que los access tokens vigentes
       expirarán en máximo 15 minutos

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Ya suspendido o no encontrado
     - 404
     - ``codigo_error = USUARIO_NO_DISPONIBLE``
   * - Intento de suspender propia cuenta
     - 403
     - ``codigo_error = AUTOPROTECCION_CUENTA``
   * - Intento de suspender superusuario
     - 403
     - ``codigo_error = CUENTA_PROTEGIDA``
   * - Error de persistencia
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-014
   * - **Depende de**
     - UC-AUTH-12 (punto de entrada a la suspensión)
   * - **Relacionado con**
     - UC-AUTH-04 paso 5 (verifica ``User.is_active``
       al renovar sesión — rechaza tras la suspensión)
   * - **Revertido por**
     - UC-AUTH-14 (reactivar usuario)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador confirma la suspensión y
ve el estado actualizado de la cuenta. No necesita conocer
cómo se invalidan los tokens ni los detalles del diseño JWT.

**Nivel Desarrollo:** Panel Admin → Servicio de Cuentas
(``apps.users``) → Repositorio ``User``.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Resumen de la cuenta. Aviso del impacto.
       Confirmación obligatoria. Estado actualizado.
     - Verificación de autoprotección y superusuario.
       Cambio de ``is_active`` a ``False``. Registro
       de ``updated_at``. La invalidación de tokens
       ocurre de forma natural en UC-AUTH-04.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Administrador (``User.is_staff = True``)
- **Prerequisito:** UC-AUTH-12 (perfil del usuario visible)
- **Revertido por:** UC-AUTH-14

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- Usuario con sesión activa → access token expira en 15 min,
  refresh token rechazado en el siguiente intento de renovación
- Usuario sin sesión activa → suspensión efectiva inmediata
- Intento sobre propia cuenta → rechazado (EX-02)
- Intento sobre superusuario → rechazado (EX-03)

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-13 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-13

   participant AdminPanel
   participant AccountService
   participant Repositorio

   AdminPanel -> AccountService : solicita suspender (User.id)
   AccountService -> AccountService : verifica que no es propia cuenta\nni superusuario
   AccountService -> Repositorio : busca User (is_active=True)
   Repositorio --> AccountService : datos del usuario
   AccountService --> AdminPanel : resumen con impacto en acceso

   AdminPanel -> AccountService : confirma suspensión
   AccountService -> Repositorio : establece is_active=False, registra updated_at
   Repositorio --> AccountService : confirmado
   AccountService --> AdminPanel : cuenta suspendida, aviso ventana residual 15 min
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-13 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-AUTH-12 Ver Perfil Usuario"
   usecase "UC-AUTH-13 Suspender Usuario"
   usecase "UC-AUTH-14 Reactivar Usuario"
   usecase "UC-AUTH-04 Renovar Sesion"

   Administrador --> "UC-AUTH-13 Suspender Usuario"
   "UC-AUTH-12 Ver Perfil Usuario"     ..> "UC-AUTH-13 Suspender Usuario"      : origen
   "UC-AUTH-13 Suspender Usuario"      ..> "UC-AUTH-14 Reactivar Usuario"      : revertir suspensión
   "UC-AUTH-13 Suspender Usuario"      ..> "UC-AUTH-04 Renovar Sesion" : rechaza is_active=False en paso 5
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 1.0.0
     - 2026-05-05
     - Version inicial. Gap identificado en analisis-cobertura-backoffice.rst.

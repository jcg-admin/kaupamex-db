.. meta::
   :tipo: Indice
   :estado: Vigente

=============
Autenticacion
=============

Registro, login, sesion, perfil y seguridad de cuenta. Actor: Comprador.

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Nombre
   * - UC-AUTH-01
     - Registrar Cuenta
   * - UC-AUTH-02
     - Iniciar Sesion
   * - UC-AUTH-03
     - Cerrar Sesion
   * - UC-AUTH-04
     - Renovar Sesion
   * - UC-AUTH-05
     - Ver Perfil
   * - UC-AUTH-06
     - Editar Perfil
   * - UC-AUTH-07
     - Gestionar Direcciones
   * - UC-AUTH-08
     - Cambiar Contrasena
   * - UC-AUTH-09
     - Recuperar Contrasena
   * - UC-AUTH-10
     - Verificar Email

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-auth-01-registrar
   uc-auth-02-login
   uc-auth-03-logout
   uc-auth-04-renovar-sesion
   uc-auth-05-ver-perfil
   uc-auth-06-editar-perfil
   uc-auth-07-gestionar-direcciones
   uc-auth-08-cambiar-contrasena
   uc-auth-09-recuperar-contrasena
   uc-auth-10-verificar-email
   uc-auth-11-ver-usuarios-admin
   uc-auth-12-ver-perfil-usuario-admin
   uc-auth-13-suspender-usuario
   uc-auth-14-reactivar-usuario
   uc-auth-15-crear-usuario-admin

.. meta::
   :artefacto: UC-AUTH-04
   :tipo: Caso de Uso
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-auth-04:

=================================================
UC-AUTH-04: Renovar Credenciales de Sesion
=================================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-04
   * - **Nombre**
     - Renovar Credenciales de Sesion
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Precedente**
     - UC-AUTH-02 (el usuario tiene credenciales de sesion activas)
   * - **Siguiente**
     - Cualquier UC que requiera autenticacion
   * - **BReq**
     - BReq-009
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al sistema obtener nuevas credenciales de acceso de corta
duracion usando la credencial de renovacion de larga duracion, sin
obligar al usuario a volver a ingresar su contrasena. Este proceso
es transparente para el usuario.

1.3 Alcance
-----------

**Incluido en este UC:**

- Validacion de la credencial de renovacion
- Emision de nueva credencial de acceso
- Rotacion de la credencial de renovacion (la usada queda invalidada)
- Registro del evento en auditoria

**Excluido de este UC:**

- Inicio de sesion con contrasena — UC-AUTH-02
- Cierre de sesion — UC-AUTH-03

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Sistema del Cliente**

La renovacion la inicia el sistema del cliente de forma automatica
cuando detecta que la credencial de acceso esta proxima a expirar
o ya expiro. El usuario no lo inicia de forma consciente.

2.2 Actores Secundarios
-----------------------

**Sistema de Autenticacion**

Valida la credencial de renovacion, emite las nuevas credenciales
y revoca la credencial usada para garantizar la rotacion.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario tiene una credencial de renovacion valida y vigente
   * - PRE-02
     - La credencial de renovacion no ha sido revocada (por logout u otro medio)

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El cliente dispone de una nueva credencial de acceso valida
   * - POST-02
     - La credencial de renovacion usada queda invalidada
   * - POST-03
     - Se emite una nueva credencial de renovacion (rotacion automatica)
   * - POST-04
     - El evento queda registrado en auditoria

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Sistema cliente
     - Detecta que la credencial de acceso esta expirada o proxima a expirar
   * - 2
     - Sistema cliente
     - Envia la credencial de renovacion al servicio de autenticacion
   * - 3
     - Sistema
     - Verifica que la credencial de renovacion existe y no ha sido revocada
   * - 4
     - Sistema
     - Verifica que la credencial de renovacion no ha expirado
   * - 5
     - Sistema
     - Verifica que la cuenta del usuario sigue activa
   * - 6
     - Sistema
     - Emite una nueva credencial de acceso (vida corta)
   * - 7
     - Sistema
     - Invalida la credencial de renovacion usada
   * - 8
     - Sistema
     - Emite una nueva credencial de renovacion (rotacion)
   * - 9
     - Sistema
     - Registra el evento de renovacion en auditoria
   * - 10
     - Sistema cliente
     - Almacena las nuevas credenciales y reanuda las operaciones del usuario


Diagrama de Secuencia
---------------------

.. uml::
   :caption: Flujo de secuencia — UC-AUTH-04 Renovar Credenciales

      @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-04: Renovar Credenciales de Sesion

   actor SystemClient
   participant AccessControl
   participant VerificadorDeCredenciales
   participant Repositorio
   participant UserRepository

   SystemClient -> AccessControl: solicita recurso con credencial de acceso expirada
   AccessControl -> VerificadorDeCredenciales: presenta credencial de renovacion
   VerificadorDeCredenciales -> Repositorio: verifica vigencia de la credencial de renovacion
   Repositorio --> VerificadorDeCredenciales: credencial valida

   VerificadorDeCredenciales -> UserRepository: verifica cuenta activa
   UserRepository --> VerificadorDeCredenciales: cuenta activa

   VerificadorDeCredenciales -> VerificadorDeCredenciales: emite nueva credencial de acceso
   VerificadorDeCredenciales -> Repositorio: invalida credencial de renovacion usada (rotacion)
   VerificadorDeCredenciales -> Repositorio: registra nueva credencial de renovacion

   VerificadorDeCredenciales --> AccessControl: nuevas credenciales
   AccessControl --> SystemClient: acceso concedido

   @enduml

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Credencial de renovacion expirada
-----------------------------------------------------

**Activador:** En el paso 4, la credencial de renovacion ha expirado.

- A1: El sistema rechaza la renovacion
- A2: Notifica al cliente que la sesion ha expirado
- A3: El usuario debe iniciar sesion nuevamente (UC-AUTH-02)

**Retorno:** El usuario va a UC-AUTH-02.

4.2 Alternativa B: Credencial de renovacion revocada
-----------------------------------------------------

**Activador:** En el paso 3, la credencial fue revocada (por logout previo).

- B1: El sistema rechaza la renovacion
- B2: El usuario debe iniciar sesion nuevamente

**Retorno:** El usuario va a UC-AUTH-02.

4.3 Alternativa C: Cuenta del usuario inactivada
-------------------------------------------------

**Activador:** En el paso 5, la cuenta fue suspendida desde el ultimo acceso.

- C1: El sistema rechaza la renovacion
- C2: No emite ninguna credencial nueva
- C3: Informa al cliente del estado de la cuenta

**Retorno:** El sistema cliente informa al usuario.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Repositorio no disponible
     - No se puede verificar la credencial. Se rechaza la renovacion
       de forma segura. El usuario debe reautenticarse.
   * - EX-02
     - Error al emitir nuevas credenciales
     - El proceso de emision falla. La credencial usada no se invalida.
       El cliente puede reintentar la renovacion.
   * - EX-03
     - Rotacion de claves de firma
     - La clave de firma del token fue rotada por seguridad. Los tokens antiguos ya no son validos. El sistema invalida la sesion y el usuario debe autenticarse de nuevo.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de renovacion (P95)
     - Menor a 200ms (proceso interno, sin interaccion del usuario)

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Rotacion obligatoria
     - Cada credencial de renovacion solo puede usarse una vez.
       Al usarse, se emite una nueva (rotacion automatica)
   * - Revocacion de usada
     - La credencial de renovacion usada queda invalidada de forma atomica
       con la emision de las nuevas
   * - Canal seguro
     - La credencial de renovacion viaja siempre por canal cifrado

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Atomicidad
     - La invalidacion de la credencial usada y la emision de las nuevas
       ocurren de forma atomica
   * - Sin interrupcion para el usuario
     - La renovacion debe ser transparente y no interrumpir la experiencia

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Transparencia
     - El usuario no debe percibir la renovacion en condiciones normales
   * - Sesion expirada
     - Si la renovacion falla por credencial expirada, el sistema
       redirige al login con mensaje claro de sesion expirada

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Credencial de renovacion
     - Texto
     - SI
     - La credencial de renovacion vigente del usuario

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Nueva credencial de acceso
     - Credencial de vida corta para el acceso a recursos protegidos
   * - Nueva credencial de renovacion
     - Credencial de vida larga para la siguiente renovacion

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Credencial expirada
     - 401
     - ``codigo_error = SESION_EXPIRADA``
   * - Credencial revocada
     - 401
     - ``codigo_error = SESION_REVOCADA``
   * - Cuenta inactiva
     - 401
     - ``codigo_error = CUENTA_INACTIVA``
   * - Error del sistema
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-009
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~4 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~8 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El sistema renueva automaticamente la sesion del usuario activo sin que este lo note, evitando que sea desconectado durante el uso normal.

**Nivel Desarrollo:** Cliente (navegador) → Servicio de Autenticacion → Servicio de Sesion.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Ninguna (proceso transparente). El usuario no percibe nada — su sesion simplemente no expira.
     - Verificacion de la validez del token actual. Generacion del nuevo token. Reemplazo atomico del token anterior.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Sistema (proceso automatico del cliente)
- **Este UC esta incluido por:** UC-AUTH-02 (login lo inicia) — ``<<include>>``
- **Inverso de cierre por inactividad:** UC-SYS-01 equivalente para sesiones

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Token valido y proximo a expirar** → se renueva de forma transparente
- **Token ya expirado** → no se puede renovar, el usuario es redirigido a UC-AUTH-02

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-04: Renovar Sesion — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-04: Renovar Sesion

   participant AutomaticClient
   participant AuthService
   participant SessionStore

   AutomaticClient -> AuthService : envia token actual (automatico, previo a expiracion)
   AuthService -> SessionStore : verifica validez del token
   SessionStore --> AuthService : token valido
   AuthService -> SessionStore : genera y almacena nuevo token
   AuthService --> AutomaticClient : nuevo token activo
   note over AutomaticClient : El usuario no percibe la renovacion
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-04: Renovar Sesion — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      usecase "UC-AUTH-02 Login"
      usecase "UC-AUTH-04 Renovar Sesion"
      "UC-AUTH-02 Login" ..> "UC-AUTH-04 Renovar Sesion" : <<include>>
      note bottom of "UC-AUTH-04 Renovar Sesion" : Proceso automatico y transparente
para el usuario
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.

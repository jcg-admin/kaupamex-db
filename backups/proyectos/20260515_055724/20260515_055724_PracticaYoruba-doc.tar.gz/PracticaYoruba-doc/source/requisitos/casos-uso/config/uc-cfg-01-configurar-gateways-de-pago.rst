.. meta::
   :artefacto: UC-CFG-01
   :tipo: Caso de Uso
   :subdominio: settings
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-cfg-01:

========================================
UC-CFG-01: Configurar Gateways de Pago
========================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CFG-01
   * - **Nombre**
     - Configurar Gateways de Pago
   * - **Modulo**
     - SETTINGS
   * - **Criticidad**
     - CRITICA
   * - **Complejidad**
     - BAJA
   * - **BReq**
     - BReq-002
   * - **BR aplicadas**
     - BR-006, BR-007, BR-013

1.2 Proposito
-------------

Permitir al administrador activar, desactivar y configurar los gateways de pago del sistema (Mercado Pago como primario y PayPal como secundario). Sin esta configuracion correcta el sistema no puede procesar pagos.

1.3 Alcance
-----------

**Incluido en este UC:**

- Configurar Gateways de Pago
- Validacion de los datos ingresados
- Aplicacion inmediata de los cambios

**Excluido de este UC:**

- Gestion de contenido estatico — UC-CFG-04
- Datos de contacto — UC-CFG-05

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
-------------------

**Administrador**

Usuario con rol administrativo responsable de la configuracion del sistema.

2.2 Actores Secundarios
-----------------------

**Sistema de Configuracion**

Valida y persiste los parametros del sistema.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene rol de administrador del sistema
   * - PRE-02
     - El sistema esta disponible

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La configuracion de configurar gateways de pago queda actualizada
   * - POST-02
     - El cambio tiene efecto inmediato en el sistema

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La configuracion anterior permanece sin cambios


----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la seccion de configuracion de gateways de pago
   * - 2
     - Sistema
     - Muestra el estado actual de cada gateway con sus credenciales (enmascaradas)
   * - 3
     - Admin
     - Selecciona el gateway a configurar (MP o PayPal)
   * - 4
     - Admin
     - Ingresa o actualiza las credenciales del gateway
   * - 5
     - Sistema
     - Valida el formato de las credenciales
   * - 6
     - Sistema
     - Verifica la conectividad con el gateway usando las credenciales
   * - 7
     - Sistema
     - Guarda la configuracion de forma segura
   * - 8
     - Sistema
     - Confirma que el gateway esta activo y operativo

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Error de formato en un campo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** Un valor ingresado no cumple el formato esperado.

- El sistema indica el campo y el formato esperado.
- El administrador puede corregir sin perder los otros cambios.



4.2 Alternativa B: Credenciales invalidas o gateway rechaza la conexion
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 6, el gateway rechaza las credenciales durante la verificacion.

- B1: El sistema informa claramente que las credenciales no son validas
- B2: La configuracion anterior del gateway permanece sin cambios
- B3: El administrador puede corregir las credenciales y volver a intentar
- B4: El gateway permanece en el estado que tenia antes del intento

4.3 Alternativa C: Rotacion periodica de credenciales
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El administrador actualiza las credenciales del gateway por politica de seguridad.

- C1: El admin ingresa las nuevas credenciales.
- C2: El sistema verifica la conexion con las nuevas credenciales.
- C3: Al validar exitosamente reemplaza las anteriores — no hay periodo de inactividad en el gateway.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - La configuracion no se persiste. Se informa al administrador.

   * - EX-02
     - Gateway en mantenimiento
     - El gateway responde pero indica que esta en mantenimiento. El sistema almacena las credenciales y marca el gateway como pendiente de verificacion para reintentar automaticamente.
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Aplicacion de cambios (P95)
     - Menor a 500ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Solo administradores
     - Solo usuarios con rol de administrador pueden cambiar la configuracion
   * - Credenciales enmascaradas
     - Las credenciales sensibles se muestran enmascaradas en la interfaz

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Cambio inmediato
     - La configuracion tiene efecto inmediato sin necesidad de reiniciar el sistema

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Valores actuales visibles
     - El administrador ve los valores actuales antes de modificar
   * - Confirmacion del cambio
     - El administrador recibe confirmacion de que el cambio fue aplicado

----

PARTE 7: Datos Involucrados
------------------------------

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Parametros a configurar
     - Varios
     - SI
     - Dependiendo del UC especifico

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Los nuevos valores activos en el sistema

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Valor invalido
     - 400
     - ``codigo_error = CONFIGURACION_INVALIDA``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``

----

Trazabilidad
-------------

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-002
   * - **BR**
     - BR-006, BR-007, BR-013
   * - **Depende de**
     - —
   * - **Habilita**
     - UC-PAY-01 (MP), UC-PAY-02 (PayPal)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`


8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario (Admin):** El administrador ingresa las credenciales del gateway
y el sistema verifica la conexion, sin conocer el protocolo de autenticacion
ni el almacenamiento seguro de las credenciales.

**Nivel Desarrollo:** Panel Admin → Servicio de Configuracion →
Gateway de Pago (verificacion) → Repositorio de Configuracion.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el Admin)
     - Logica privada (invisible para el Admin)
   * - Formulario con campos enmascarados.
       Estado del gateway (activo/inactivo).
       Resultado de la verificacion de conexion.
     - Almacenamiento cifrado de credenciales.
       Protocolo de verificacion con el gateway.
       Nunca se exponen las credenciales en texto plano.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante
- **Polimorfismo de gateways:** UC-CFG-01 configura MP (BR-006) y PayPal (BR-007)
- **Habilita:** UC-PAY-01 (MP) y UC-PAY-02 (PayPal) solo si esta correctamente configurado

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El comportamiento varia segun el gateway configurado:

- **Mercado Pago** → flujo de autenticacion via Client ID y Client Secret (BR-006)
- **PayPal** → flujo de autenticacion via Client ID y Secret (BR-007)
- **Credenciales invalidas** → el gateway rechaza la verificacion sin revelar el motivo exacto

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-01 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-CFG-01: Configurar Gateway de Pago

   participant AdminPanel
   participant ConfigService
   participant PaymentGateway
   participant Repositorio

   AdminPanel -> ConfigService : envia credenciales del gateway (enmascaradas en trayecto)
   ConfigService -> ConfigService : valida formato de las credenciales
   ConfigService -> PaymentGateway  : verifica conexion con las credenciales
   PaymentGateway --> ConfigService : conexion exitosa o credenciales invalidas

   alt Conexion exitosa
   ConfigService -> Repositorio : almacena credenciales de forma cifrada
   ConfigService --> AdminPanel  : gateway activo y operativo
   else Credenciales invalidas
   ConfigService --> AdminPanel  : error de credenciales (sin revelar la razon exacta)
   end
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-01 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor Administrador
   actor PaymentGateway

   usecase "UC-CFG-01 Configurar Gateways"
   usecase "UC-PAY-01 Pago MP"
   usecase "UC-PAY-02 Pago PayPal"

   Administrador --> "UC-CFG-01 Configurar Gateways"
   "UC-CFG-01 Configurar Gateways" ..> "UC-PAY-01 Pago MP" : habilita (MP configurado)
   "UC-CFG-01 Configurar Gateways" ..> "UC-PAY-02 Pago PayPal" : habilita (PayPal configurado)
   PaymentGateway ..> "UC-CFG-01 Configurar Gateways" : verifica (durante configuracion)
   @enduml

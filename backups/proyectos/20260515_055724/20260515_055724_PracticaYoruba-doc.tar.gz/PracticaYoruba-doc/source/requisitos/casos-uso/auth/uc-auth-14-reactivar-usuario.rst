.. meta::
   :artefacto: UC-AUTH-14
   :tipo: Caso de Uso
   :subdominio: accounts
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-auth-14:

====================================================
UC-AUTH-14: Reactivar Cuenta de Usuario (Admin)
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-14
   * - **Nombre**
     - Reactivar Cuenta de Usuario (Admin)
   * - **Modulo**
     - ACCOUNTS (MOD-001)
   * - **BReq**
     - BReq-014
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador restaurar el acceso de un usuario
suspendido estableciendo ``User.is_active = True``. A partir
de ese momento el usuario puede volver a iniciar sesión
mediante UC-AUTH-02. Es la operación inversa de UC-AUTH-13.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Establecer ``User.is_active = True`` en la cuenta del
  usuario suspendido.

**Excluido de este UC:**

- Suspender la cuenta — UC-AUTH-13.
- Ver el perfil del usuario — UC-AUTH-12.
- Reactivar la propia cuenta del administrador — el
  administrador, al ejecutar este UC, ya tiene su cuenta
  activa (de lo contrario no tendría sesión).

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Accede al backoffice con ``User.is_staff = True``.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Servicio de Cuentas** (``apps.users``)

Aplica el cambio de estado y lo persiste.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene sesión activa con
       ``User.is_staff = True``
   * - PRE-02
     - El usuario a reactivar existe con
       ``User.is_active = False``

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - ``User.is_active = True`` en la cuenta del usuario
   * - POST-02
     - El usuario puede iniciar sesión con sus credenciales
       mediante UC-AUTH-02
   * - POST-03
     - ``User.updated_at`` registra el timestamp de la
       reactivación

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - ``User.is_active`` conserva el valor ``False``
   * - POST-F02
     - El usuario sigue sin poder acceder al sistema

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Administrador
     - Accede al perfil del usuario suspendido desde
       UC-AUTH-12 y selecciona la opción de reactivar
   * - 2
     - Sistema
     - Muestra el resumen de la cuenta a reactivar:
       ``User.username``, ``User.email`` y confirmación
       de que el usuario podrá iniciar sesión nuevamente
   * - 3
     - Administrador
     - Confirma la reactivación
   * - 4
     - Sistema
     - Establece ``User.is_active = True`` y registra
       ``updated_at`` con el timestamp de la operación
   * - 5
     - Sistema
     - Confirma la reactivación y retorna a UC-AUTH-12
       con el estado actualizado de la cuenta

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Cancelación antes de confirmar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el administrador decide no
proceder con la reactivación.

- A1: El sistema cancela la operación sin modificar ningún dato.
- A2: ``User.is_active`` permanece ``False``.
- A3: El sistema retorna al perfil del usuario en UC-AUTH-12.

**Retorno:** UC-AUTH-12.

4.2 Alternativa B: Reactivar usuario que nunca había iniciado sesión
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 2, ``User.last_login`` es nulo —
el usuario fue creado y suspendido antes de su primer acceso.

- B1: El flujo sigue el camino normal.
- B2: La confirmación del paso 5 indica que el usuario podrá
  iniciar sesión por primera vez.

**Retorno:** Paso 3.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Usuario ya activo o no encontrado
     - El ``User.is_active`` ya es ``True`` o el ``User.id``
       no existe. El sistema informa al administrador y lo
       devuelve al listado de UC-AUTH-11.
   * - EX-02
     - Error al persistir la reactivación
     - El Servicio de Cuentas no puede escribir el cambio.
       ``User.is_active`` conserva el valor ``False``. El
       sistema informa del error temporal y ofrece reintentar.

----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 400ms para aplicar y confirmar la reactivación

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo usuarios con ``User.is_staff = True``
   * - Confirmacion obligatoria
     - El sistema siempre muestra el resumen antes de ejecutar

6.3 Confiabilidad
^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Trazabilidad
     - ``User.updated_at`` registra el timestamp de la
       reactivación

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Req
     - Descripcion
   * - ``User.id``
     - ``BigAutoField``
     - SI
     - Identificador del usuario a reactivar
   * - Confirmación del admin
     - Booleano
     - SI
     - El administrador debe confirmar explícitamente

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - ``User.is_active``
     - ``True``
   * - ``User.updated_at``
     - Timestamp de la reactivación

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Ya activo o no encontrado
     - 404
     - ``codigo_error = USUARIO_NO_DISPONIBLE``
   * - Error de persistencia
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-014
   * - **Depende de**
     - UC-AUTH-12 (punto de entrada a la reactivación),
       UC-AUTH-13 (la cuenta fue suspendida previamente)
   * - **Habilita**
     - UC-AUTH-02 (el usuario puede iniciar sesión nuevamente)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador confirma la reactivación
y ve el estado actualizado. No necesita conocer los detalles
del repositorio ni del ciclo de vida de los tokens.

**Nivel Desarrollo:** Panel Admin → Servicio de Cuentas
(``apps.users``) → Repositorio ``User``.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Resumen de la cuenta. Confirmación obligatoria.
       Estado de cuenta actualizado.
     - Cambio de ``is_active`` a ``True``. Registro
       de ``updated_at``.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Administrador (``User.is_staff = True``)
- **Prerequisito:** UC-AUTH-13 (la cuenta debe estar suspendida)
- **Habilita:** UC-AUTH-02 (acceso del usuario restaurado)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- Usuario con ``last_login`` nulo → primer acceso posible
  tras la reactivación
- Usuario con ``last_login`` previo → acceso restaurado al
  estado anterior a la suspensión

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-14 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-14

   participant AdminPanel
   participant AccountService
   participant Repositorio

   AdminPanel -> AccountService : solicita reactivar (User.id)
   AccountService -> Repositorio : busca User (is_active=False)
   Repositorio --> AccountService : datos del usuario suspendido
   AccountService --> AdminPanel : resumen con confirmación

   AdminPanel -> AccountService : confirma reactivación
   AccountService -> Repositorio : establece is_active=True, registra updated_at
   Repositorio --> AccountService : confirmado
   AccountService --> AdminPanel : cuenta reactivada
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-14 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-AUTH-12 Ver Perfil Usuario"
   usecase "UC-AUTH-13 Suspender Usuario"
   usecase "UC-AUTH-14 Reactivar Usuario"
   usecase "UC-AUTH-02 Iniciar Sesion"

   Administrador --> "UC-AUTH-14 Reactivar Usuario"
   "UC-AUTH-12 Ver Perfil Usuario" ..> "UC-AUTH-14 Reactivar Usuario" : origen
   "UC-AUTH-13 Suspender Usuario"  ..> "UC-AUTH-14 Reactivar Usuario" : operación inversa
   "UC-AUTH-14 Reactivar Usuario"  ..> "UC-AUTH-02 Iniciar Sesion"     : habilita el acceso del usuario
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 1.0.0
     - 2026-05-05
     - Version inicial. Gap identificado en analisis-cobertura-backoffice.rst.

.. meta::
   :artefacto: UC-AUTH-07
   :tipo: Caso de Uso
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-auth-07:

============================================
UC-AUTH-07: Gestionar Direcciones de Envio
============================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-07
   * - **Nombre**
     - Gestionar Direcciones de Envio
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Depende de**
     - UC-AUTH-02
   * - **Siguiente**
     - UC-ORD-02 (seleccionar direccion en checkout)
   * - **BReq**
     - BReq-001, BReq-004
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al usuario autenticado administrar su libreta de direcciones
de envio: agregar nuevas direcciones, editar las existentes, eliminar
las que ya no usa y designar una direccion como favorita o predeterminada.
Las direcciones guardadas agilizan el proceso de checkout.

1.3 Alcance
-----------

**Incluido en este UC:**

- Ver la lista de direcciones guardadas
- Agregar nueva direccion
- Editar direccion existente
- Eliminar direccion
- Designar direccion predeterminada

**Excluido de este UC:**

- Usar la direccion durante el checkout — UC-ORD-02
- Ingresar una nueva direccion directamente en el checkout sin guardarla

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Autenticado**

Persona que quiere mantener una libreta de direcciones para agilizar
futuras compras.

2.2 Actores Secundarios
-----------------------

**Servicio de Validacion de Direcciones**

Verifica que la direccion ingresada es valida y esta dentro de la
zona de envio soportada por el sistema (actualmente Mexico — BReq-015).

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario esta autenticado

2.4 Postcondiciones
-------------------

**Caso exitoso (agregar):**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La nueva direccion figura en la libreta del usuario
   * - POST-02
     - Si es la primera direccion, queda como predeterminada automaticamente

----

PARTE 3: Flujo Principal (Happy Path) — Agregar direccion
===========================================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Accede a la gestion de direcciones desde su perfil
   * - 2
     - Sistema
     - Presenta la lista de direcciones guardadas con opcion de agregar nueva
   * - 3
     - Usuario
     - Solicita agregar una nueva direccion
   * - 4
     - Sistema
     - Presenta el formulario de nueva direccion
   * - 5
     - Usuario
     - Completa los campos: destinatario, calle, numero exterior,
       numero interior (opcional), colonia, ciudad, estado, codigo postal,
       pais (Mexico por defecto), telefono de contacto para entrega
   * - 6
     - Sistema
     - Valida el formato de todos los campos
   * - 7
     - Sistema
     - Verifica que la direccion esta dentro de la zona de envio soportada
   * - 8
     - Usuario
     - Opcionalmente marca la direccion como predeterminada
   * - 9
     - Usuario
     - Solicita guardar la direccion
   * - 10
     - Sistema
     - Almacena la nueva direccion asociada al usuario
   * - 11
     - Sistema
     - Si fue marcada como predeterminada: desmarca la anterior predeterminada
   * - 12
     - Sistema
     - Si es la primera direccion: la marca como predeterminada automaticamente
   * - 13
     - Sistema
     - Confirma al usuario y presenta la lista actualizada de direcciones

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Editar direccion existente
----------------------------------------------

**Activador:** El usuario selecciona editar una direccion de la lista.

- A1: El sistema presenta el formulario con los datos actuales de la direccion
- A2: El usuario modifica los campos deseados
- A3: El sistema valida y guarda los cambios
- A4: La direccion actualizada queda en la lista

4.2 Alternativa B: Eliminar direccion
--------------------------------------

**Activador:** El usuario selecciona eliminar una direccion.

- B1: El sistema solicita confirmacion de eliminacion
- B2: El usuario confirma
- B3: El sistema elimina la direccion
- B4: Si era la predeterminada y habia otras: designa la mas reciente como predeterminada
- B5: La lista se actualiza

4.3 Alternativa C: Cambiar direccion predeterminada
----------------------------------------------------

**Activador:** El usuario designa una direccion diferente como predeterminada.

- C1: El usuario selecciona la opcion de establecer como predeterminada
- C2: El sistema desmarca la anterior y marca la nueva
- C3: La lista refleja el cambio

4.4 Alternativa D: Direccion fuera de zona de envio
----------------------------------------------------

**Activador:** En el paso 7, la direccion no esta dentro de la zona soportada.

- D1: El sistema informa que esa zona no esta disponible para envio
- D2: Indica las zonas cubiertas
- D3: La direccion no se guarda

**Retorno:** Paso 5.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - El repositorio falla. La direccion no se almacena. Se informa al usuario.
   * - EX-02
     - Limite de direcciones alcanzado
     - El usuario alcanzo el numero maximo de direcciones permitidas.
       Se informa del limite y se ofrece eliminar una existente.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Carga de lista y guardado (P95)
     - Menor a 400ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Aislamiento
     - Un usuario solo puede ver y gestionar sus propias direcciones
   * - Autenticacion obligatoria
     - Solo usuarios autenticados pueden gestionar la libreta de direcciones

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Una sola predeterminada
     - El sistema garantiza que en todo momento solo existe una direccion
       marcada como predeterminada por usuario

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Direccion predeterminada visible
     - La direccion predeterminada se identifica claramente en la lista
   * - Formulario completo
     - El formulario incluye todos los campos necesarios para un envio en Mexico

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Destinatario
     - Texto
     - SI
     - Nombre de quien recibe el paquete
   * - Calle y numero exterior
     - Texto
     - SI
     - Calle con numero exterior
   * - Numero interior
     - Texto
     - NO
     - Departamento, piso u otra referencia interior
   * - Colonia
     - Texto
     - SI
     - Colonia o barrio
   * - Ciudad
     - Texto
     - SI
     - Ciudad o municipio
   * - Estado
     - Texto
     - SI
     - Estado de la Republica Mexicana
   * - Codigo postal
     - Texto
     - SI
     - Codigo postal valido dentro de Mexico
   * - Telefono de contacto
     - Texto
     - SI
     - Telefono para coordinacion de entrega
   * - Predeterminada
     - Booleano
     - NO
     - Si es la direccion por defecto para nuevas ordenes

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Lista actualizada
     - Todas las direcciones del usuario con indicador de predeterminada

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Datos invalidos
     - 400
     - ``codigo_error = DATOS_INVALIDOS``
   * - Zona no soportada
     - 422
     - ``codigo_error = ZONA_NO_SOPORTADA``
   * - Limite alcanzado
     - 409
     - ``codigo_error = LIMITE_DIRECCIONES``
   * - No autenticado
     - 401
     - ``codigo_error = AUTENTICACION_REQUERIDA``
   * - Error del sistema
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001, BReq-004
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-02
   * - **Habilita**
     - UC-ORD-02 (seleccion rapida de direccion en checkout)
   * - **FR derivados**
     - Pendiente - Capa 3 (~8 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~16 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El comprador agrega, edita o elimina direcciones de envio sin conocer como se validan ni almacenan.

**Nivel Desarrollo:** Interfaz de Perfil → Servicio de Autenticacion → Repositorio de Direcciones.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Lista de direcciones guardadas. Formulario de nueva direccion o edicion. Indicador de direccion predeterminada.
     - Validacion del formato de la direccion. Logica de direccion predeterminada (solo una por usuario). Persistencia y auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Comprador autenticado
- **Este UC es prerequisito de:** UC-ORD-01 (el checkout necesita una direccion)
- **Polimorfismo CRUD:** crear, editar, eliminar, marcar como predeterminada

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Crear nueva direccion** → se valida y persiste; si es la primera, queda como predeterminada
- **Editar existente** → se actualizan los campos seleccionados
- **Eliminar** → no se puede eliminar la predeterminada si es la unica
- **Marcar predeterminada** → la anterior deja de serlo automaticamente

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-07: Gestionar Direcciones — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-07: Gestionar Direcciones

   participant ProfileInterface
   participant AuthService
   participant Repositorio

   ProfileInterface -> AuthService : solicita accion (crear/editar/eliminar/predeterminar)
   AuthService -> AuthService : valida la accion y los datos
   AuthService -> Repositorio : ejecuta la operacion sobre la direccion
   Repositorio --> AuthService : confirmacion
   AuthService -> AuthService : ajusta la predeterminada si corresponde
   AuthService --> ProfileInterface  : lista actualizada de direcciones
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-07: Gestionar Direcciones — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Comprador
   usecase "UC-AUTH-07 Gestionar Direcciones"
   usecase "UC-ORD-01 Crear Orden"
   Comprador  --> "UC-AUTH-07 Gestionar Direcciones"
   "UC-AUTH-07 Gestionar Direcciones"  ..> "UC-ORD-01 Crear Orden" : prerequisito (direccion debe existir)
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.

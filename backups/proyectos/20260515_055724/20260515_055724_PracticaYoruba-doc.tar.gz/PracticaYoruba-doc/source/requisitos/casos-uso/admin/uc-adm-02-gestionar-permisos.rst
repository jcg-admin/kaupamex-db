.. meta::
   :artefacto: UC-ADM-02
   :tipo: Caso de Uso
   :subdominio: admin
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-adm-02:

=========================================
UC-ADM-02: Gestionar Permisos (Roles)
=========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-ADM-02
   * - **Nombre**
     - Gestionar Permisos y Roles de Administradores
   * - **Modulo**
     - Django admin (``apps.users`` + ``django.contrib.auth``)
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Actores**
     - Superadministrador (``User.is_superuser = True``)
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al superadministrador asignar y revocar permisos de Django
a cuentas de staff. En PracticaYoruba se usan dos niveles de acceso:
``is_staff`` (acceso al panel admin de Django) e ``is_superuser``
(acceso completo sin restricciones).

1.3 Alcance
-----------

**Incluido:** asignar/revocar ``is_staff``, ``is_superuser``, y grupos
de permisos de Django. **Excluido:** gestionar cuentas de compradores
(UC-ADM-01), crear usuarios (UC-AUTH-15).

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actores
-----------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Actor
     - Rol
   * - Superadministrador
     - Actor primario. ``User.is_superuser = True``.

2.2 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El actor tiene ``User.is_superuser = True``

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Superadmin
     - Localiza el ``User`` staff desde UC-ADM-01
   * - 2
     - Sistema
     - Presenta la seccion de permisos: ``is_staff``,
       ``is_superuser``, grupos de permisos de Django
   * - 3
     - Superadmin
     - Activa o desactiva los permisos deseados
   * - 4
     - Sistema
     - Guarda los cambios y registra la accion en ``AccessAuditLog``
       con el superadmin responsable
   * - 5
     - Sistema
     - Confirma los cambios. El usuario afectado tendra los nuevos
       permisos en su proxima sesion.

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Revocar acceso staff
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el superadmin desactiva ``User.is_staff``.

- A1: El usuario pierde acceso al panel de admin en su proxima sesion.
- A2: Se invalidan sus sesiones activas de admin.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Intento de quitar permisos al propio superadmin
     - El sistema rechaza la operacion con
       ``NO_PUEDE_MODIFICAR_PROPIO_USUARIO`` para evitar que el
       superadmin se bloquee accidentalmente.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Guardado de permisos (P95)
     - Menor a 400ms (incluye escritura en BD + registro en AccessAuditLog)
   * - Carga del formulario de permisos (P95)
     - Menor a 200ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Verificacion de is_superuser
     - Se verifica en cada peticion (RNF-SEC-001)
   * - Autorreferencia bloqueada
     - El sistema rechaza la operacion si superadmin == usuario objetivo
   * - Auditoria obligatoria
     - Todo cambio de permisos queda registrado en AccessAuditLog
       con el superadmin responsable — sin excepciones


----

PARTE 7: Datos Involucrados
============================

7.1 Entrada
-----------

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - ID del usuario objetivo
     - Entero (PK)
     - SI
     - ``User.pk`` del usuario al que se modifican los permisos.
       Obtenido desde UC-ADM-01.
   * - is_staff
     - Booleano
     - SI
     - Nuevo valor de ``User.is_staff``. True = acceso al panel admin.
   * - is_superuser
     - Booleano
     - SI
     - Nuevo valor de ``User.is_superuser``. True = acceso total.
   * - Grupos de permisos
     - Lista de IDs
     - NO
     - IDs de ``Group`` de Django a asignar. Lista vacía = sin grupos.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Permisos actualizados correctamente. Los nuevos permisos
       son efectivos en la próxima sesión del usuario afectado.
   * - Registro de auditoria
     - ``AccessAuditLog`` creado con el superadmin responsable,
       el usuario afectado y los cambios aplicados.

7.3 Salida (Casos de error)
-----------------------------

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Intento de modificar propio usuario
     - Rechazado
     - ``NO_PUEDE_MODIFICAR_PROPIO_USUARIO``. Sin codigo HTTP — validacion en formulario.
   * - Sin permiso de superadmin
     - HTTP 403
     - ``is_superuser = False``. No se aplican cambios.

----

Diagrama de Secuencia
-----------------------

.. uml::
   :caption: UC-ADM-02 — Gestionar Permisos y Roles

   @startuml
   !include ../../../_static/plantuml-styles.puml

   actor Superadmin
   participant PermissionsInterface
   participant UserRepository
   participant AuditLog

   Superadmin -> PermissionsInterface : accede al formulario de permisos del usuario
   PermissionsInterface -> UserRepository : User.get(pk)
   UserRepository --> PermissionsInterface : User con is_staff, is_superuser, groups
   PermissionsInterface --> Superadmin : formulario con permisos actuales

   Superadmin -> PermissionsInterface : modifica permisos y guarda
   PermissionsInterface -> PermissionsInterface : verificar superadmin != usuario_objetivo
   PermissionsInterface -> UserRepository : User.save(is_staff, is_superuser, groups)
   UserRepository --> PermissionsInterface : OK
   PermissionsInterface -> AuditLog : registrar(superadmin, usuario, cambios_permisos)
   PermissionsInterface --> Superadmin : permisos actualizados

   note over PermissionsInterface
     EX-01: si superadmin == usuario_objetivo
     retornar NO_PUEDE_MODIFICAR_PROPIO_USUARIO
   end note
   @enduml

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El superadmin activa o desactiva checkboxes de
``is_staff`` e ``is_superuser`` y selecciona grupos de permisos de
Django, sin conocer la estructura de la tabla de permisos.

**Nivel Desarrollo:** Panel Admin → ``User.save()`` →
``AccessAuditLog.create()`` → tabla ``auth_user_groups`` y ``auth_user``
en MySQL.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 45 55
   :header-rows: 1

   * - Interfaz publica (visible al superadmin)
     - Logica privada (invisible al superadmin)
   * - Checkboxes de is_staff / is_superuser,
       selector de grupos de permisos Django.
     - Verificacion de autorreferencia (no modificar propio usuario).
       Registro automatico en AccessAuditLog.
       Invalidacion de sesiones activas del usuario afectado.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Administrador generico. Solo ``is_superuser``
  puede ejecutar este UC (mas restrictivo que UC-ADM-01).
- **Este UC precede a:** Los cambios de permiso son el prerrequisito
  para que el usuario afectado pueda ejecutar UCs de administracion.

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El resultado varia segun el tipo de cambio:

- **Otorgar is_staff** → el usuario gana acceso al panel admin
- **Revocar is_staff** → el usuario pierde acceso; sus sesiones admin
  se invalidan
- **Otorgar is_superuser** → acceso completo sin restricciones


Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-05
     - Version inicial. UC especificado desde cero.

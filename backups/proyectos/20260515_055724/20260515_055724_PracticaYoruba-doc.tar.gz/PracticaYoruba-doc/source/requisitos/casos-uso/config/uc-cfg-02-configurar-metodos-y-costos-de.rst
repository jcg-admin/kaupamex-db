.. meta::
   :artefacto: UC-CFG-02
   :tipo: Caso de Uso
   :subdominio: settings
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-cfg-02:

=================================================
UC-CFG-02: Configurar Metodos y Costos de Envio
=================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CFG-02
   * - **Nombre**
     - Configurar Metodos y Costos de Envio
   * - **Modulo**
     - SETTINGS
   * - **Criticidad**
     - CRITICA
   * - **Complejidad**
     - BAJA
   * - **BReq**
     - BReq-015
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al administrador definir los metodos de envio disponibles, sus costos, tiempos estimados y zonas geograficas cubiertas para que los compradores puedan seleccionarlos durante el checkout.

1.3 Alcance
-----------

**Incluido en este UC:**

- Configurar Metodos y Costos de Envio
- Validacion de los datos ingresados
- Aplicacion inmediata de los cambios

**Excluido de este UC:**

- Gestion de contenido estatico — UC-CFG-04
- Datos de contacto — UC-CFG-05

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
-------------------

**Administrador**

Usuario con rol administrativo responsable de la configuracion del sistema.

2.2 Actores Secundarios
-----------------------

**Sistema de Configuracion**

Valida y persiste los parametros del sistema.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene rol de administrador del sistema
   * - PRE-02
     - El sistema esta disponible

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La configuracion de configurar metodos y costos de envio queda actualizada
   * - POST-02
     - El cambio tiene efecto inmediato en el sistema

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La configuracion anterior permanece sin cambios


----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la configuracion de envio
   * - 2
     - Sistema
     - Muestra los metodos de envio configurados actualmente
   * - 3
     - Admin
     - Agrega, edita o desactiva un metodo de envio
   * - 4
     - Admin
     - Define: nombre, descripcion, costo, tiempo estimado, zonas cubiertas
   * - 5
     - Sistema
     - Valida que los datos son correctos y consistentes
   * - 6
     - Sistema
     - Guarda la configuracion
   * - 7
     - Sistema
     - El nuevo metodo ya esta disponible en el checkout

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Error de formato en un campo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** Un valor ingresado no cumple el formato esperado.

- El sistema indica el campo y el formato esperado.
- El administrador puede corregir sin perder los otros cambios.



4.2 Alternativa B: Desactivar un metodo de envio existente
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** El administrador desactiva un metodo de envio que tenia ordenes activas.

- B1: El sistema verifica si el metodo tiene ordenes en proceso que dependen de el
- B2: Si tiene ordenes activas: advierte al administrador e informa cuantas ordenes se veran afectadas
- B3: El administrador confirma o cancela la desactivacion
- B4: Si confirma: el metodo queda desactivado para nuevas ordenes pero las ordenes existentes
  no se ven afectadas

4.3 Alternativa C: Configurar zona de envio gratuito
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El administrador define un monto minimo de orden para envio gratis.

- C1: El admin activa el envio gratuito y define el monto minimo.
- C2: UC-ORD-01 aplica envio gratuito automaticamente cuando el subtotal supera el minimo.
- C3: El comprador ve el indicador de cuanto le falta para obtener envio gratuito.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - La configuracion no se persiste. Se informa al administrador.

   * - EX-02
     - Metodo de envio en uso activo
     - El metodo a eliminar tiene ordenes activas asociadas. El sistema no permite eliminarlo — solo puede desactivarse para que no acepte nuevas ordenes.
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Aplicacion de cambios (P95)
     - Menor a 500ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Solo administradores
     - Solo usuarios con rol de administrador pueden cambiar la configuracion
   * - Credenciales enmascaradas
     - Las credenciales sensibles se muestran enmascaradas en la interfaz

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Cambio inmediato
     - La configuracion tiene efecto inmediato sin necesidad de reiniciar el sistema

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Valores actuales visibles
     - El administrador ve los valores actuales antes de modificar
   * - Confirmacion del cambio
     - El administrador recibe confirmacion de que el cambio fue aplicado

----

PARTE 7: Datos Involucrados
------------------------------

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Parametros a configurar
     - Varios
     - SI
     - Dependiendo del UC especifico

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Los nuevos valores activos en el sistema

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Valor invalido
     - 400
     - ``codigo_error = CONFIGURACION_INVALIDA``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``

----

Trazabilidad
-------------

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-015
   * - **BR**
     - BR-013
   * - **Depende de**
     - —
   * - **Habilita**
     - UC-ORD-01 (checkout), UC-LOG-09 (calculo de costo)
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`


8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario (Admin):** el administrador define los metodos de envio sin conocer
como se calculan ni como se presentan al comprador.

**Nivel Desarrollo:** Panel Admin → Servicio de Configuracion → Repositorio de Metodos de Envio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el Admin)
     - Logica privada (invisible para el Admin)
   * - Formulario de metodo de envio: nombre, costo, tiempo estimado y zonas. Confirmacion de valores guardados.
     - Validacion de consistencia de zonas. Actualizacion en el selector de checkout (UC-ORD-01). Registro de auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante
- **Depende de:** —
- **Habilita:** UC-ORD-01 (selector de envio), UC-ORD-06 (cambio de metodo)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

Este UC tiene comportamiento uniforme para el administrador.
El polimorfismo se expresa en los UCs que consumen esta configuracion
(UC-ORD-01 usa el metodo de envio; UC-CAT-01 usa el IVA configurado).

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: uc-cfg-02-configurar-metodos-y-costos-de — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title Configurar Metodos y Costos de Envio (Admin)

   participant AdminPanel
   participant ConfigService
   participant Repositorio

   AdminPanel -> ConfigService : envia nuevos parametros
   ConfigService -> ConfigService : valida formato y consistencia
   ConfigService -> Repositorio : persiste la configuracion
   Repositorio --> ConfigService : confirmacion
   ConfigService -> Repositorio : registra cambio en auditoria
   ConfigService --> AdminPanel  : nuevos valores activos en el sistema
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: uc-cfg-02-configurar-metodos-y-costos-de — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor Administrador

   usecase "UC-CFG-02-CONFIGURAR Configurar Metodos y Cost"
   usecase "UC-ORD-01 Crear Orden"

   Administrador --> "UC-CFG-02-CONFIGURAR Configurar Metodos y Cost"
   "UC-CFG-02-CONFIGURAR Configurar Metodos y Cost" ..> "UC-ORD-01 Crear Orden" : habilita (configuracion activa)
   @enduml

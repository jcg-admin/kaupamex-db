.. meta::
   :artefacto: UC-AUTH-10
   :tipo: Caso de Uso
   :dominio: requisitos
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: UC_ACC_03 TiendaMax v2.0.1

.. _uc-auth-10:

=================================================
UC-AUTH-10: Verificar Email (Confirmar Cuenta)
=================================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-10
   * - **Nombre**
     - Verificar Email (Confirmar Cuenta)
   * - **Version**
     - 2.0.0
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Precedente**
     - UC-AUTH-01 (la cuenta debe existir en estado pendiente)
   * - **Siguiente**
     - UC-AUTH-02 (el usuario puede iniciar sesion)
   * - **BReq**
     - BReq-001, BReq-009
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Confirmar que el usuario tiene control sobre el email que registro,
mediante un token de un solo uso enviado a ese correo. Solo tras
completar este paso el usuario puede iniciar sesion.

1.3 Alcance
-----------

**Incluido en este UC:**

- Validacion del token de verificacion
- Activacion de la cuenta en el sistema
- Invalidacion del token para que no pueda reutilizarse
- Registro del evento de verificacion en auditoria
- Opcion de reenviar el mensaje de verificacion si no llego

**Excluido de este UC:**

- Cambio de email despues de verificado — UC futuro
- Verificacion de numero de telefono — UC futuro

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Recien Registrado**

Persona que acaba de crear su cuenta y necesita confirmar
su identidad para poder acceder al sistema.

Caracteristicas:

- Tiene cuenta en estado pendiente de verificacion (UC-AUTH-01 completado)
- Tiene acceso al email que registro
- Recibio el mensaje de verificacion con el enlace

Objetivos del actor:

- Activar su cuenta para poder iniciar sesion y realizar compras

2.2 Actores Secundarios
-----------------------

**Sistema de Validacion de Tokens**

Verifica la existencia, vigencia y estado de uso del token.
Garantiza que cada token solo pueda usarse una vez.

**Servicio de Notificacion**

Reenvio el mensaje de verificacion cuando el usuario lo solicita.
Solo actua en los flujos alternativos.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario ha completado el registro (UC-AUTH-01) y su cuenta
       esta en estado pendiente de verificacion
   * - PRE-02
     - El sistema genero y envio un token de verificacion al email registrado
   * - PRE-03
     - El token no ha expirado ni ha sido usado anteriormente
   * - PRE-04
     - El usuario tiene acceso al enlace de verificacion recibido en su email

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La cuenta pasa de estado pendiente a estado activo y verificado
   * - POST-02
     - El token de verificacion queda marcado como usado y no puede reutilizarse
   * - POST-03
     - El usuario puede iniciar sesion (UC-AUTH-02)
   * - POST-04
     - El evento de verificacion queda registrado en el log de auditoria

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La cuenta permanece en estado pendiente de verificacion
   * - POST-F02
     - El usuario recibe informacion sobre el motivo y como resolverlo

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Abre el email de verificacion recibido tras el registro
   * - 2
     - Usuario
     - Hace clic en el enlace de verificacion contenido en el mensaje
   * - 3
     - Sistema
     - Recibe la solicitud de verificacion con el token incluido en el enlace
   * - 4
     - Sistema
     - Extrae el token del enlace
   * - 5
     - Sistema
     - Verifica que el token existe en el sistema
   * - 6
     - Sistema
     - Verifica que el token no ha expirado (el tiempo de vida es limitado)
   * - 7
     - Sistema
     - Verifica que el token no ha sido usado anteriormente
   * - 8
     - Sistema
     - Identifica la cuenta asociada al token
   * - 9
     - Sistema
     - Verifica que la cuenta esta en estado pendiente de verificacion
       (no ya activa, no eliminada)
   * - 10
     - Sistema
     - Actualiza el estado de la cuenta de pendiente a activo y verificado
   * - 11
     - Sistema
     - Marca el token como usado e invalidado para cualquier uso posterior
   * - 12
     - Sistema
     - Registra el evento en el log de auditoria:
       identificador de cuenta, token, resultado=VERIFICACION_EXITOSA, timestamp
   * - 13
     - Sistema
     - Informa al usuario que su cuenta esta activa y lista para usar.
       Ofrece acceso directo al inicio de sesion (UC-AUTH-02)

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Token expirado
-----------------------------------

**Activador:** En el paso 6, el token ha superado su tiempo de vida.

- A1: El sistema detecta que el token ha expirado
- A2: Informa al usuario que el enlace ya no es valido con explicacion clara
- A3: Ofrece la opcion de solicitar un nuevo enlace de verificacion
- A4: La cuenta permanece en estado pendiente

**Retorno:** El usuario solicita reenvio (ver 4.3).

4.2 Alternativa B: Token ya utilizado
---------------------------------------

**Activador:** En el paso 7, el token ya fue usado anteriormente.

- B1: El sistema detecta que el token ya fue consumido
- B2: Verifica si la cuenta ya esta activa como consecuencia de ese uso
- B3: Si la cuenta ya esta activa: informa al usuario que ya puede iniciar sesion
- B4: Si la cuenta no esta activa por alguna inconsistencia: solicita nuevo enlace

**Retorno:** El usuario va a UC-AUTH-02 o solicita reenvio.

4.3 Alternativa C: El usuario solicita reenvio del mensaje
------------------------------------------------------------

**Activador:** El usuario no recibio el mensaje o el enlace expiro.

- C1: El usuario accede a la opcion de reenvio de verificacion
- C2: El sistema solicita el email registrado para identificar la cuenta
- C3: El sistema verifica que el email corresponde a una cuenta pendiente de verificacion
- C4: Si corresponde: genera un nuevo token e invalida los anteriores
- C5: Envia el nuevo mensaje de verificacion
- C6: Confirma al usuario que el mensaje fue enviado

**Nota de seguridad:** El sistema siempre responde con el mismo mensaje
independientemente de si el email existe o no (proteccion contra enumeracion).

**Retorno:** El usuario vuelve al paso 1.

4.4 Alternativa D: Cuenta ya verificada
-----------------------------------------

**Activador:** En el paso 9, la cuenta ya estaba en estado activo
(el usuario uso el enlace dos veces o por error).

- D1: El sistema detecta que la cuenta ya esta activa
- D2: Informa al usuario que su cuenta ya estaba verificada
- D3: Ofrece acceso directo al inicio de sesion

**Retorno:** El usuario va a UC-AUTH-02.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Token no encontrado
     - El token del enlace no existe en el sistema (puede haber sido
       manipulado o ser de otro sistema). El sistema informa que el
       enlace no es valido y ofrece solicitar uno nuevo.
   * - EX-02
     - Repositorio no disponible
     - El repositorio no responde durante la verificacion.
       El sistema informa de un error temporal. La cuenta no se modifica.
   * - EX-03
     - Error al actualizar estado
     - La actualizacion del estado de la cuenta falla despues de verificar
       el token. El sistema reintenta y si persiste informa al usuario.
       El token queda en estado intermedio hasta que el proceso se complete.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 500ms
   * - Tiempo de vida del token
     - Configurable. Debe ser suficiente para que el usuario acceda
       al email y realice la verificacion (minimo 24 horas recomendado)

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Token de un solo uso
     - El token NUNCA puede usarse mas de una vez aunque no haya expirado
   * - Token no predecible
     - Los tokens deben ser generados de forma que no sean predecibles
       o inferibles por terceros
   * - Expiracion obligatoria
     - Todo token tiene un tiempo de vida maximo. Tokens sin expiracion
       son un riesgo de seguridad inaceptable
   * - Reenvio seguro
     - Al solicitar reenvio, los tokens anteriores quedan invalidados
   * - Proteccion contra enumeracion
     - La opcion de reenvio siempre responde igual
       independientemente de si el email existe

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Atomicidad
     - La activacion de la cuenta y la invalidacion del token ocurren
       de forma atomica. No puede quedar una sin la otra
   * - Recuperabilidad
     - El usuario siempre puede solicitar un nuevo enlace si el anterior
       expiro o no llego, sin tener que volver a registrarse

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Enlace de un clic
     - La verificacion debe completarse con un solo clic en el enlace.
       No debe requerir ingresar el token manualmente
   * - Mensaje de verificacion claro
     - El email de verificacion debe tener asunto y contenido claros,
       con el enlace visible y prominente
   * - Opcion de reenvio visible
     - Si el usuario llega a la pagina de verificacion pendiente,
       la opcion de reenvio debe ser facil de encontrar
   * - Compatibilidad de email
     - El mensaje debe mostrarse correctamente en los clientes de email
       mas usados (HTML y texto plano)

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Token de verificacion
     - Texto (parte de la URL)
     - SI
     - Identificador unico de un solo uso generado al registrarse.
       Se transmite como parametro del enlace en el email.
       Tiene tiempo de expiracion definido.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion de activacion
     - Mensaje claro indicando que la cuenta quedo activa y verificada
   * - Acceso a inicio de sesion
     - Enlace o boton directo para ir a UC-AUTH-02

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Token expirado
     - 400
     - El enlace ya no es valido por haber superado su tiempo de vida.
       ``codigo_error = TOKEN_EXPIRADO``
   * - Token ya utilizado
     - 400
     - El enlace ya fue usado anteriormente.
       ``codigo_error = TOKEN_YA_UTILIZADO``
   * - Token invalido
     - 400
     - El token no existe o fue manipulado.
       ``codigo_error = TOKEN_INVALIDO``
   * - Error del sistema
     - 500
     - Error temporal. La cuenta no fue modificada.
       ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001, BReq-009
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-01
   * - **Habilita**
     - UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~6 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~12 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario recien registrado activa su cuenta haciendo clic en el enlace recibido, sin conocer el proceso de validacion del token.

**Nivel Desarrollo:** Email del usuario → Interfaz → Servicio de Autenticacion → Repositorio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Enlace de verificacion en el email. Mensaje de cuenta activada.
     - Validacion del token (existencia, expiracion, ya usado). Activacion del estado de la cuenta. Invalidacion del token tras uso.

8.3 Herencia
^^^^^^^^^^^^

- **Disparado por:** UC-AUTH-01 (el registro genera el email de verificacion)
- **Este UC habilita:** UC-AUTH-02 (login completo con cuenta activa)
- **Token de un solo uso** — el mismo enlace no puede usarse dos veces

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Token valido** → cuenta activada, se puede hacer login
- **Token expirado** → se informa y se puede solicitar reenvio
- **Token ya usado** → se informa que la cuenta ya esta activa

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-10: Verificar Email — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-10: Verificar Email

   participant AuthInterface
   participant AuthService
   participant Repositorio

   AuthInterface -> AuthService : envia token del enlace de verificacion
   AuthService -> Repositorio : busca el token y verifica validez y expiracion
   Repositorio --> AuthService : token valido y no usado
   AuthService -> Repositorio : activa la cuenta del usuario
   AuthService -> Repositorio : invalida el token (un solo uso)
   AuthService --> AuthInterface  : cuenta verificada, puede iniciar sesion
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-10: Verificar Email — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      usecase "UC-AUTH-01 Registrar"
      usecase "UC-AUTH-10 Verificar Email"
      usecase "UC-AUTH-02 Login"
      "UC-AUTH-01 Registrar" ->> "UC-AUTH-10 Verificar Email" : dispara (asincrono)
      "UC-AUTH-10 Verificar Email" ..> "UC-AUTH-02 Login" : habilita
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Adaptado de UC_ACC_03 TiendaMax v2.0.1.
       Sin referencias tecnologicas.

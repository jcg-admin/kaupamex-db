.. meta::
   :artefacto: UC-AUTH-09
   :tipo: Caso de Uso
   :dominio: requisitos
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: UC_ACC_04 TiendaMax v2.0.1

.. _uc-auth-09:

===========================================
UC-AUTH-09: Recuperar Contrasena
===========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-09
   * - **Nombre**
     - Recuperar Contrasena
   * - **Version**
     - 2.0.0
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Precedente**
     - UC-AUTH-02 (el usuario intento iniciar sesion y fallo)
   * - **Siguiente**
     - UC-AUTH-02 (el usuario puede volver a iniciar sesion)
   * - **Depende de**
     - UC-AUTH-01 (la cuenta debe existir)
   * - **BReq**
     - BReq-001, BReq-009
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir a un usuario que no puede acceder a su cuenta recuperar
el control de la misma mediante la verificacion de su identidad
por email y el establecimiento de una nueva contrasena.

1.3 Alcance
-----------

**Incluido en este UC:**

- Solicitud de recuperacion por identificador (email)
- Envio de enlace de restablecimiento de un solo uso
- Validacion del enlace y establecimiento de nueva contrasena
- Invalidacion de todas las sesiones activas del usuario
- Registro del evento en auditoria

**Excluido de este UC:**

- Recuperacion por numero de telefono — UC futuro
- Recuperacion por preguntas de seguridad — UC futuro
- Restablecimiento forzado por el administrador — UC-ADM-01

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Registrado sin Acceso**

Persona que tiene cuenta en el sistema pero no puede iniciar sesion
porque olvido su contrasena o no la recuerda.

Objetivos del actor:

- Recuperar el acceso a su cuenta de forma segura
- Establecer una nueva contrasena que recuerde

2.2 Actores Secundarios
-----------------------

**Sistema de Autenticacion**

Genera el token de restablecimiento, valida el proceso y actualiza
la contrasena de forma segura. Invalida todas las sesiones activas
al completar el restablecimiento.

**Servicio de Notificacion**

Envia el mensaje con el enlace de restablecimiento al email del usuario.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El sistema esta disponible y el canal de comunicacion es seguro
   * - PRE-02
     - El usuario tiene acceso al email registrado en el sistema

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - La contrasena del usuario queda actualizada con la nueva que establecio
   * - POST-02
     - Todas las sesiones activas previas del usuario quedan invalidadas
   * - POST-03
     - El token de restablecimiento queda consumido y no puede reutilizarse
   * - POST-04
     - El usuario puede iniciar sesion con la nueva contrasena
   * - POST-05
     - El evento queda registrado en el log de auditoria

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La contrasena del usuario no cambia
   * - POST-F02
     - Las sesiones activas no se ven afectadas

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

El proceso tiene dos fases: solicitud del enlace y uso del enlace.

**Fase 1 — Solicitud del enlace:**

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Accede a la pagina de inicio de sesion y selecciona
       la opcion de recuperar contrasena
   * - 2
     - Sistema
     - Presenta el formulario de recuperacion con un unico campo: email
   * - 3
     - Usuario
     - Ingresa el email con el que registro su cuenta
   * - 4
     - Sistema
     - Valida el formato del email
   * - 5
     - Sistema
     - Busca el email en el sistema de forma interna
       (sin revelar si existe o no)
   * - 6
     - Sistema
     - Si el email existe y la cuenta esta activa:
       genera un token de restablecimiento de un solo uso con tiempo
       de expiracion limitado e invalida los tokens previos de restablecimiento
   * - 7
     - Sistema
     - Envia el mensaje de restablecimiento al email (si existe)
   * - 8
     - Sistema
     - Informa al usuario con mensaje identico sin importar si el email
       existe o no: *"Si el email esta registrado, recibiras un mensaje
       con instrucciones"*

**Fase 2 — Uso del enlace:**

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 9
     - Usuario
     - Abre el mensaje de restablecimiento y hace clic en el enlace
   * - 10
     - Sistema
     - Extrae y valida el token del enlace
   * - 11
     - Sistema
     - Verifica que el token no ha expirado
   * - 12
     - Sistema
     - Verifica que el token no ha sido usado anteriormente
   * - 13
     - Sistema
     - Presenta el formulario para establecer la nueva contrasena
       (campo de nueva contrasena y campo de confirmacion)
   * - 14
     - Usuario
     - Ingresa la nueva contrasena
   * - 15
     - Sistema
     - Valida que la nueva contrasena cumple los requisitos de seguridad.
       Muestra indicador de fortaleza en tiempo real
   * - 16
     - Usuario
     - Confirma la nueva contrasena
   * - 17
     - Sistema
     - Verifica que ambas entradas son identicas
   * - 18
     - Usuario
     - Solicita guardar la nueva contrasena
   * - 19
     - Sistema
     - Almacena la nueva contrasena de forma segura (nunca en texto plano)
   * - 20
     - Sistema
     - Invalida el token de restablecimiento
   * - 21
     - Sistema
     - Invalida todas las sesiones activas previas del usuario
       (fuerza inicio de sesion con la nueva contrasena)
   * - 22
     - Sistema
     - Registra el evento en el log de auditoria
   * - 23
     - Sistema
     - Informa al usuario que la contrasena fue restablecida exitosamente.
       Ofrece acceso directo al inicio de sesion (UC-AUTH-02)

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Email no registrado
---------------------------------------

**Activador:** En el paso 5, el email no existe en el sistema.

- A1: El sistema no encuentra el email
- A2: No genera ningun token ni envia ningun mensaje
- A3: Retorna el mismo mensaje que si el email existiera
  (proteccion contra enumeracion de usuarios)

**Retorno:** El usuario no recibe mensaje pero ve la misma pantalla.

4.2 Alternativa B: Token de restablecimiento expirado
-------------------------------------------------------

**Activador:** En el paso 11, el token supero su tiempo de vida.

- B1: El sistema detecta que el token ha expirado
- B2: Informa al usuario que el enlace ya no es valido
- B3: Ofrece la opcion de solicitar un nuevo enlace (vuelve al paso 1)

**Retorno:** Paso 1.

4.3 Alternativa C: Nueva contrasena no cumple requisitos
---------------------------------------------------------

**Activador:** En el paso 15, la contrasena no cumple los criterios.

- C1: El sistema muestra los requisitos no cumplidos de forma clara
- C2: El usuario puede corregir sin perder el contexto del token
  (el token sigue vigente mientras no expire)

**Retorno:** Paso 14.

4.4 Alternativa D: Contrasenas no coinciden
--------------------------------------------

**Activador:** En el paso 17, las dos entradas no son iguales.

- D1: El sistema indica que las contrasenas no coinciden
- D2: El campo de confirmacion se limpia
- D3: El usuario puede reintentar

**Retorno:** Paso 16.

4.5 Alternativa E: Cuenta inactiva o suspendida
-------------------------------------------------

**Activador:** En el paso 5, el email existe pero la cuenta no esta activa.

- E1: El sistema no genera token ni envia mensaje
- E2: Retorna el mismo mensaje generico (proteccion contra enumeracion)

**Retorno:** El usuario debe contactar soporte.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Fallo al enviar mensaje
     - El servicio de notificacion no puede enviar el email.
       El token queda generado. El usuario puede solicitar reenvio
       desde la pagina de recuperacion.
   * - EX-02
     - Token no encontrado
     - El token del enlace no existe (puede haber sido manipulado).
       El sistema informa que el enlace no es valido.
   * - EX-03
     - Error al actualizar contrasena
     - El repositorio falla al guardar la nueva contrasena.
       La contrasena anterior no cambia. El token queda vigente
       para que el usuario pueda reintentar.
   * - EX-04
     - Repositorio no disponible
     - El repositorio no responde. Se informa de error temporal.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta fase 1 (P95)
     - Menor a 500ms (incluye busqueda y generacion del token)
   * - Tiempo de envio del mensaje
     - Asincrono, no bloquea la respuesta al usuario
   * - Tiempo de respuesta fase 2 (P95)
     - Menor a 800ms (incluye actualizacion de contrasena e invalidacion)
   * - Tiempo de vida del token
     - Configurable. Recomendado: 1 hora maxima para minimizar ventana de ataque

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Proteccion contra enumeracion
     - La respuesta es identica si el email existe o no
   * - Token de un solo uso
     - El token de restablecimiento no puede usarse mas de una vez
   * - Token no predecible
     - Los tokens deben ser generados de forma que no sean predecibles
   * - Invalidacion de sesiones
     - Todas las sesiones activas deben invalidarse al restablecer la contrasena
   * - Invalidacion de tokens previos
     - Al solicitar nuevo enlace, los tokens anteriores quedan invalidados
   * - Almacenamiento seguro
     - La nueva contrasena NUNCA se almacena en texto plano
   * - Datos en logs
     - La nueva contrasena NUNCA aparece en ningun registro del sistema

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Atomicidad del restablecimiento
     - La actualizacion de la contrasena, la invalidacion del token y
       la invalidacion de sesiones ocurren de forma atomica
   * - Recuperabilidad ante fallo de envio
     - Si el mensaje no llego, el usuario puede solicitar uno nuevo
       sin tener que reiniciar el proceso
   * - Consistencia de estado
     - Ante cualquier fallo, la contrasena anterior sigue siendo valida

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Formulario minimalista
     - La fase 1 solo requiere el email. Sin preguntas innecesarias
   * - Indicador de fortaleza
     - La nueva contrasena muestra fortaleza en tiempo real
   * - Requisitos visibles
     - Los criterios de contrasena se muestran antes de que el usuario escriba
   * - Mensaje claro al expirar
     - Si el enlace expiro, el mensaje explica claramente que hacer
   * - Compatibilidad de email
     - El mensaje de restablecimiento es compatible con los principales
       clientes de correo (HTML y texto plano)

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

**Fase 1 — Solicitud:**

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Email
     - Texto
     - SI
     - Email registrado en el sistema.
       Formato RFC 5322. Se normaliza a minusculas.

**Fase 2 — Restablecimiento:**

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Token
     - Texto (URL)
     - SI
     - Token de restablecimiento de un solo uso incluido en el enlace.
   * - Nueva contrasena
     - Texto
     - SI
     - Debe cumplir los requisitos de seguridad. NUNCA en logs.
   * - Confirmacion
     - Texto
     - SI
     - Debe ser identica a la nueva contrasena.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Mensaje fase 1
     - Texto identico independientemente de si el email existe o no.
       Indica que si el email estaba registrado el usuario recibira un mensaje.
   * - Confirmacion fase 2
     - Indica que la contrasena fue restablecida exitosamente.
       Ofrece acceso directo al inicio de sesion.

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Token expirado
     - 400
     - El enlace supero su tiempo de vida.
       ``codigo_error = TOKEN_EXPIRADO``
   * - Token ya utilizado
     - 400
     - El enlace ya fue usado.
       ``codigo_error = TOKEN_YA_UTILIZADO``
   * - Token invalido
     - 400
     - El token no existe o fue manipulado.
       ``codigo_error = TOKEN_INVALIDO``
   * - Contrasena invalida
     - 400
     - La nueva contrasena no cumple los requisitos.
       ``codigo_error = CONTRASENA_INVALIDA``
   * - Error del sistema
     - 500
     - Error temporal. La contrasena no fue modificada.
       ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001, BReq-009
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-01
   * - **Habilita**
     - UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~10 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~20 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario sin acceso recibe un enlace temporal para restablecer su contrasena sin conocer el token de recuperacion.

**Nivel Desarrollo:** Interfaz de Recuperacion → Servicio de Autenticacion → Servicio de Notificaciones → Repositorio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario de email. Mensaje de instruccion enviada. Formulario de nueva contrasena (desde el enlace).
     - Generacion del token de recuperacion con expiracion. Envio del email con enlace unico. Verificacion del token. Invalidacion del token tras uso.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Usuario registrado sin acceso (sesion expirada o contrasena olvidada)
- **Diferente de:** UC-AUTH-08 (cambiar contrasena con la actual conocida)
- **Este UC habilita:** UC-AUTH-02 (login con la nueva contrasena)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- **Email registrado** → se envia el enlace de recuperacion
- **Email no registrado** → el sistema responde de forma identica para no revelar si el email existe
- **Token expirado** → se informa y se puede solicitar uno nuevo

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-09: Recuperar Contrasena — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-09: Recuperar Contrasena

   participant RecoveryInterface
   participant AuthService
   participant NotificationService
   participant Repositorio

   RecoveryInterface -> AuthService : solicita recuperacion con email
   AuthService -> Repositorio : busca el email (respuesta identica si no existe)
   AuthService -> AuthService : genera token temporal con expiracion
   AuthService -> Repositorio : almacena el token
   AuthService ->> NotificationService : envia email con enlace de recuperacion (asincrono)
   AuthService --> RecoveryInterface  : instrucciones enviadas al email
   note over RecoveryInterface : El usuario hace clic en el enlace del email
   RecoveryInterface -> AuthService : envia token + nueva contrasena
   AuthService -> Repositorio : verifica que el token es valido y no expiro
   AuthService -> AuthService : genera nuevo hash de la nueva contrasena
   AuthService -> Repositorio : actualiza hash e invalida el token
   AuthService --> RecoveryInterface  : contrasena actualizada, puede iniciar sesion
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-09: Recuperar Contrasena — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      usecase "UC-AUTH-09 Recuperar Contrasena"
      usecase "UC-AUTH-02 Login"
      usecase "UC-AUTH-10 Verificar Email"
      "UC-AUTH-09 Recuperar Contrasena" ..> "UC-AUTH-02 Login" : habilita
      note bottom of "UC-AUTH-09 Recuperar Contrasena" : Patron similar a UC-AUTH-10:
tokens temporales con expiracion
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Adaptado de UC_ACC_04 TiendaMax v2.0.1.
       Sin referencias tecnologicas.

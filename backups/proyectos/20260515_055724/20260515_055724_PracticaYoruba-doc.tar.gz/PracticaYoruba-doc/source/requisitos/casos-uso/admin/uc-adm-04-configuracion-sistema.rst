.. meta::
   :artefacto: UC-ADM-04
   :tipo: Caso de Uso
   :subdominio: admin
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-adm-04:

=============================================
UC-ADM-04: Configuración del Sistema
=============================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-ADM-04
   * - **Nombre**
     - Configuracion del Sistema (SiteSettings)
   * - **Modulo**
     - Django admin (``apps.config`` — modelo ``SiteSettings``)
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Actores**
     - Superadministrador
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-001, BR-004, BR-009, BR-013, BR-014

1.2 Proposito
-------------

Permitir al superadministrador modificar los parametros globales del
sistema almacenados en el modelo ``SiteSettings``: tasas de IVA,
umbrales de stock, tiempos de expiracion, credenciales cifradas de
gateways de pago, y otros ajustes de comportamiento del sistema.

1.3 Alcance
-----------

**Incluido:** edicion de todos los campos de ``SiteSettings``,
con cifrado automatico de campos sensibles (credenciales de gateway).
**Excluido:** configuracion de gateways de pago (UC-CFG-01),
metodos de envio (UC-CFG-02).

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actores
-----------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Actor
     - Rol
   * - Superadministrador
     - Actor primario. Solo ``is_superuser = True`` puede modificar
       ``SiteSettings``.

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Superadmin
     - Accede al formulario de configuracion del sistema
   * - 2
     - Sistema
     - Presenta el registro ``SiteSettings`` con todos sus campos
       actuales. Los campos sensibles muestran solo los ultimos 4
       caracteres del valor cifrado.
   * - 3
     - Superadmin
     - Modifica los campos deseados
   * - 4
     - Sistema
     - Cifra los campos sensibles (credenciales de gateway) con
       la clave de cifrado del servidor (RNF-SEC-002), persiste
       los cambios y registra la accion en ``AccessAuditLog``
   * - 5
     - Sistema
     - Invalida los caches afectados por el cambio (p.ej.
       si cambia ``iva_rate``, invalida los caches de precios)
   * - 6
     - Sistema
     - Confirma el guardado. Los nuevos valores son efectivos
       de forma inmediata.

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Cambio de IVA
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el superadmin modifica ``iva_rate``.

- A1: El sistema invalida el cache de precios de producto (``catalogue:page:*``).
- A2: Los nuevos precios se recalculan en la siguiente solicitud al catalogo.

4.2 Alternativa B: Cambio de umbral de stock minimo
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el superadmin modifica ``min_stock_threshold``.

- B1: El nuevo umbral se aplica desde la siguiente ejecucion de UC-SYS-03.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Sin permiso de superadmin
     - HTTP 403. Solo ``is_superuser = True`` puede modificar
       ``SiteSettings``.
   * - EX-02
     - Error al cifrar credencial
     - El sistema no puede cifrar un campo sensible. Rechaza el
       guardado e informa al superadmin del error.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Guardado de configuracion (P95)
     - Menor a 600ms (incluye cifrado Fernet + invalidacion de caches)
   * - Carga del formulario SiteSettings (P95)
     - Menor a 200ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Cifrado de credenciales
     - Las credenciales de gateway se cifran con Fernet (AES-128-CBC)
       antes de persistirse — nunca en texto plano (RNF-SEC-002)
   * - Verificacion de is_superuser
     - Se verifica en cada peticion. SiteSettings es el artefacto
       de mayor impacto en el sistema — un cambio incorrecto
       afecta a todos los usuarios
   * - Campos enmascarados en la UI
     - Los campos cifrados muestran solo los ultimos 4 caracteres
       del valor cifrado, nunca el valor descifrado


----

PARTE 7: Datos Involucrados
============================

7.1 Entrada
-----------

Todos los campos de ``SiteSettings`` son opcionales individualmente
— el admin edita solo los que necesita cambiar.

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - iva_rate
     - Decimal (5,4)
     - NO
     - Nueva tasa de IVA. Ejemplo: 0.16 para 16%.
   * - free_shipping_threshold
     - Decimal (10,2) o nulo
     - NO
     - Monto mínimo para envío gratuito. Nulo = siempre con costo.
   * - order_timeout_minutes
     - Entero positivo
     - NO
     - Minutos antes de cancelar una orden PENDING_PAYMENT.
   * - min_stock_threshold
     - Entero positivo
     - NO
     - Umbral de stock bajo para alertas.
   * - ticket_auto_close_days
     - Entero positivo
     - NO
     - Días de inactividad para cierre automático de tickets.
   * - Credenciales de gateway
     - Texto (cifrado en destino)
     - NO
     - client_id y client_secret del gateway. Se cifran con Fernet
       antes de persistir (RNF-SEC-002). El admin los ingresa en texto
       claro — el cifrado es transparente.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion
     - Configuracion guardada. Los nuevos valores son efectivos
       de forma inmediata sin reiniciar el servidor.
   * - Caches invalidados
     - Los caches de precios y configuracion afectados por el cambio
       son invalidados automáticamente.

7.3 Salida (Casos de error)
-----------------------------

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Sin permiso de superadmin
     - HTTP 403
     - ``is_superuser = False``. No se aplican cambios.
   * - Error al cifrar credencial
     - HTTP 400
     - No se puede cifrar el campo sensible. Guardado rechazado.

----

Diagrama de Secuencia
-----------------------

.. uml::
   :caption: UC-ADM-04 — Configuracion del Sistema (SiteSettings)

   @startuml
   !include ../../../_static/plantuml-styles.puml

   actor Superadmin
   participant ConfigInterface
   participant SettingsRepository
   participant EncryptionService
   participant CacheStore
   participant AuditLog

   Superadmin -> ConfigInterface : accede al formulario SiteSettings
   ConfigInterface -> SettingsRepository : SiteSettings.get_solo()
   SettingsRepository --> ConfigInterface : SiteSettings (campos sensibles enmascarados)
   ConfigInterface --> Superadmin : formulario con valores actuales

   Superadmin -> ConfigInterface : modifica campos y guarda
   ConfigInterface -> EncryptionService : cifrar(campos_sensibles, SERVER_KEY)
   EncryptionService --> ConfigInterface : valores_cifrados
   ConfigInterface -> SettingsRepository : SiteSettings.save(campos_actualizados)
   SettingsRepository --> ConfigInterface : OK
   ConfigInterface -> CacheStore : invalidar(claves_afectadas)
   ConfigInterface -> AuditLog : registrar(superadmin, CAMBIO_CONFIGURACION, campos)
   ConfigInterface --> Superadmin : configuracion guardada y efectiva de inmediato

   note over EncryptionService
     RNF-SEC-002: client_id, client_secret,
     public_key se cifran con la clave
     del servidor antes de persistir.
   end note
   @enduml

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El superadmin edita un formulario con campos
legibles (tasas, umbrales, textos). Los campos sensibles muestran
solo los ultimos 4 caracteres. Al guardar, los cambios son efectivos
de inmediato sin reiniciar el servidor.

**Nivel Desarrollo:** Panel Admin → ``SiteSettings.get_solo()``
(singleton) → cifrado de campos sensibles → ``SiteSettings.save()``
→ invalidacion de caches → ``AccessAuditLog.create()``.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 45 55
   :header-rows: 1

   * - Interfaz publica (visible al superadmin)
     - Logica privada (invisible al superadmin)
   * - Formulario con campos agrupados por categoria.
       Campos sensibles enmascarados.
       Confirmacion de guardado inmediato.
     - Cifrado AES de credenciales (RNF-SEC-002).
       Invalidacion selectiva de caches segun campos modificados.
       Registro de auditoria con los campos que cambiaron.
       Verificacion de is_superuser en cada peticion.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Superadministrador (``is_superuser = True``).
  Es el UC mas privilegiado — afecta el comportamiento global del sistema.
- **Este UC es referenciado por:** UC-SYS-01..04 (leen
  ``SiteSettings`` para sus parametros operativos).

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El efecto del guardado varia segun el campo modificado:

- **Cambio de iva_rate** → invalida caches de precios de producto
- **Cambio de min_stock_threshold** → afecta las alertas de UC-SYS-03
- **Cambio de credencial de gateway** → el campo se cifra y el
  gateway usa el nuevo valor en la siguiente transaccion
- **Cambio de ticket_auto_close_days** → afecta el cierre automatico de UC-SUPP-04


Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-05
     - Version inicial. UC especificado desde cero.

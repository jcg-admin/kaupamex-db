.. meta::
   :artefacto: UC-ADM-01
   :tipo: Caso de Uso
   :subdominio: admin
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-adm-01:

=============================================
UC-ADM-01: Gestionar Usuarios (CRUD Admin)
=============================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-ADM-01
   * - **Nombre**
     - Gestionar Usuarios — CRUD Admin
   * - **Modulo**
     - Django admin (``apps.users``)
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - MEDIA
   * - **Actores**
     - Administrador con ``is_staff = True``
   * - **Relacionado**
     - UC-AUTH-11..15 (UCs de backoffice de usuarios ya especificados)
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Proporcionar al administrador una interfaz centralizada para gestionar
todos los registros ``User`` del sistema: listar, buscar, filtrar,
ver el detalle de cada cuenta, suspender, reactivar y crear nuevas
cuentas de administrador.

Este UC es el punto de entrada al conjunto de UCs de backoffice de
usuarios (UC-AUTH-11..15), que ya estan especificados individualmente.

1.3 Alcance
-----------

**Incluido en este UC:**

- Listado paginado de ``User`` con filtros por estado, rol y fecha
- Busqueda por email, username y nombre
- Acceso al detalle (UC-AUTH-12)
- Suspension (UC-AUTH-13) y reactivacion (UC-AUTH-14)
- Creacion de cuenta de administrador (UC-AUTH-15)
- Exportacion del listado a CSV

**Excluido de este UC:**

- Edicion del perfil del propio administrador (UC-AUTH-06)
- Gestion de permisos por rol (UC-ADM-02)

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actores
-----------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Actor
     - Rol
   * - Administrador
     - Actor primario. ``User.is_staff = True``.

2.2 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador esta autenticado con ``is_staff = True``

2.3 Postcondiciones
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El administrador tiene visibilidad completa del estado de las cuentas

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede al panel de administracion de usuarios
   * - 2
     - Sistema
     - Recupera todos los ``User`` ordenados por ``-User.date_joined``,
       con filtros de estado activo/inactivo y rol (staff/comprador)
   * - 3
     - Sistema
     - Presenta el listado paginado (20 por pagina) con:
       username, email, nombre, ``is_active``, ``is_staff``,
       ``date_joined``, ``last_login``
   * - 4
     - Admin
     - Aplica filtros o busqueda por email/username/nombre
   * - 5
     - Sistema
     - Filtra y actualiza el listado con los criterios AND acumulativos
   * - 6
     - Admin
     - Selecciona un usuario para ver su detalle (UC-AUTH-12),
       suspenderlo (UC-AUTH-13) o reactivarlo (UC-AUTH-14)

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Busqueda sin resultados
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 5, los filtros aplicados no retornan ningun ``User``.

- A1: El sistema muestra el estado de lista vacia con los filtros activos visibles.
- A2: El admin puede limpiar los filtros para ver todos los usuarios.

4.2 Alternativa B: Crear nueva cuenta de administrador
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el admin selecciona la accion de crear
nuevo administrador.

- B1: El sistema redirige a UC-AUTH-15.

4.3 Alternativa C: Exportar listado a CSV
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** En el paso 3, el admin solicita exportar el listado
con los filtros activos.

- C1: El sistema genera un CSV con username, email, nombre, estado,
  fecha de registro y ultimo acceso.
- C2: El CSV respeta los filtros activos en ese momento.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Acceso no autorizado
     - El usuario no tiene ``is_staff = True``. El sistema retorna
       HTTP 403 y redirige al panel de login del admin.
   * - EX-02
     - Error del repositorio
     - ``UserRepository`` no responde en el paso 2. El sistema
       retorna HTTP 503 e informa al admin del error temporal.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Carga del listado paginado (P95)
     - Menor a 300ms (20 registros por pagina)
   * - Respuesta con filtros activos (P95)
     - Menor a 200ms (consulta AND acumulativa con indice)
   * - Exportacion CSV del listado filtrado
     - Menor a 5s para hasta 10.000 usuarios

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Verificacion de is_staff
     - Se verifica en cada peticion — no se almacena en sesion
   * - Exportacion CSV
     - Solo disponible para usuarios con ``is_staff = True``
   * - Datos sensibles en listado
     - Las contrasenas NUNCA aparecen en ninguna vista ni en el CSV


----

PARTE 7: Datos Involucrados
============================

7.1 Entrada
-----------

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Filtro estado (is_active)
     - Booleano
     - NO
     - Filtra por cuentas activas o inactivas. Sin filtro = todas.
   * - Filtro rol (is_staff)
     - Booleano
     - NO
     - Filtra por administradores o compradores. Sin filtro = todos.
   * - Termino de busqueda
     - Texto
     - NO
     - Busqueda ``icontains`` sobre email, username y nombre. Sin termino = sin filtro.
   * - Pagina
     - Entero
     - NO
     - Pagina del listado. Default: 1. 20 registros por pagina.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Listado de usuarios
     - Lista paginada de ``User``. Por registro: username, email,
       nombre completo, ``is_active``, ``is_staff``, ``date_joined``,
       ``last_login``.
   * - Metadatos de paginacion
     - Total de usuarios encontrados, pagina actual, total de paginas.
   * - Filtros activos
     - Los criterios aplicados visibles en la interfaz para que
       el admin pueda limpiarlos individualmente.

7.3 Salida (Casos de error)
-----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Sin permiso de staff
     - HTTP 403
     - ``is_staff = False``. No se devuelven datos.
   * - Error del repositorio
     - HTTP 503
     - ``UserRepository`` no responde. No se devuelven datos.

----

Diagrama de Secuencia
-----------------------

.. uml::
   :caption: UC-ADM-01 — Gestionar Usuarios (CRUD Admin)

   @startuml
   !include ../../../_static/plantuml-styles.puml

   actor AdminPanel
   participant UserManagementInterface
   participant UserRepository

   AdminPanel -> UserManagementInterface : accede al panel de usuarios
   UserManagementInterface -> UserRepository : User.objects.order_by(-date_joined).paginate(20)
   UserRepository --> UserManagementInterface : Page[User]
   UserManagementInterface --> AdminPanel : listado con username, email, estado, rol

   alt aplica filtros o busqueda
     AdminPanel -> UserManagementInterface : filtra por estado/rol o busca por email
     UserManagementInterface -> UserRepository : User.filter(criterios_AND)
     UserRepository --> UserManagementInterface : Page[User] filtrada
     UserManagementInterface --> AdminPanel : listado actualizado
   end

   note over UserRepository
     UC-AUTH-12 (detalle), UC-AUTH-13 (suspender),
     UC-AUTH-14 (reactivar) se invocan desde aqui
   end note
   @enduml

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador ve una lista de cuentas que puede
filtrar, buscar y gestionar con botones de accion directa, sin conocer
la estructura de la tabla de usuarios ni las consultas SQL.

**Nivel Desarrollo:** Panel Admin → UserRepository (``User.objects``) →
tabla ``users_user`` en MySQL. Los UCs de backoffice (UC-AUTH-12..15)
son invocados como acciones desde el listado.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 45 55
   :header-rows: 1

   * - Interfaz publica (visible al admin)
     - Logica privada (invisible al admin)
   * - Listado paginado, filtros de estado y rol,
       buscador por email/nombre, botones de accion.
     - Paginacion de la consulta (``Paginator``).
       Construccion dinamica de filtros AND acumulativos.
       Verificacion de ``is_staff`` antes de cargar el panel.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Administrador generico (``is_staff = True``).
  Para acciones de creacion (UC-AUTH-15) se requiere ``is_superuser``.
- **Este UC es extendido por:** UC-AUTH-12 (detalle), UC-AUTH-13
  (suspender), UC-AUTH-14 (reactivar), UC-AUTH-15 (crear admin).

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El resultado del listado varia segun el criterio aplicado:

- **Sin filtros** → todos los ``User`` ordenados por registro
- **Filtro is_active=True** → solo cuentas activas
- **Filtro is_staff=True** → solo cuentas de administrador
- **Busqueda por email** → coincidencia ``icontains`` en email y nombre

8.5 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-ADM-01 — Asociaciones con UCs de backoffice

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor AdminPanel

   rectangle "Gestion de Usuarios" {
     usecase "UC-ADM-01 Listar Usuarios"01
     usecase "UC-AUTH-12 Ver Detalle"12
     usecase "UC-AUTH-13 Suspender"13
     usecase "UC-AUTH-14 Reactivar"14
     usecase "UC-AUTH-15 Crear Admin"15
   }

   AdminPanel --> UC_ADM01
   UC_ADM01 ..> UC_AUTH12 : <<include>>
   UC_ADM01 ..> UC_AUTH13 : <<extend>>
   UC_ADM01 ..> UC_AUTH14 : <<extend>>
   UC_ADM01 ..> UC_AUTH15 : <<extend>>
   @enduml


Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-05
     - Version inicial. UC especificado desde cero.

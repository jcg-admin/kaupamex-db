.. meta::
   :artefacto: UC-CFG-04
   :tipo: Caso de Uso
   :subdominio: settings
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-cfg-04:

=================================================
UC-CFG-04: Gestionar Contenido Estatico (Admin)
=================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CFG-04
   * - **Nombre**
     - Gestionar Contenido Estatico (Admin)
   * - **Modulo**
     - SETTINGS
   * - **BReq**
     - BReq-015
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador editar los textos de paginas estaticas del sitio: Sobre Nosotros, Terminos, FAQ.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Edicion del contenido HTML de las paginas estaticas: Sobre Nosotros, Terminos, Privacidad, FAQ
- Vista previa antes de publicar
- Versionado del contenido (historial de cambios)

**Excluido de este UC:**

- Datos de contacto del negocio — UC-CFG-05
- Configuracion de parametros del sistema — UC-CFG-03

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Sistema de Catalogo / Configuracion** segun el UC.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El admin tiene permisos de gestion de contenido

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El contenido estatico queda actualizado y visible en el sitio
   * - POST-02
     - El historial de versiones registra quien publico el cambio y cuando

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la gestion de contenido estatico
   * - 2
     - Sistema
     - Recupera la lista de ``StaticPage`` disponibles para edicion
   * - 3
     - Admin
     - Selecciona la pagina y edita el contenido
   * - 4
     - Admin
     - Vista previa y confirma la publicacion
   * - 5
     - Sistema
     - Persiste los cambios en ``StaticPage.content`` con versionado,
       registra ``StaticPage.updated_by`` y ``updated_at``

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Vista previa antes de publicar
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Descripcion:**

- A1: El admin ve como queda antes de confirmar.

4.2 Alternativa B: Revertir a version anterior
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Descripcion:**

- B1: El sistema guarda historial de versiones. El admin puede revertir.

4.3 Alternativa C: Programar publicacion de contenido para fecha futura
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El admin prepara el contenido con anticipacion.

- C1: El admin guarda como borrador y configura una fecha de publicacion automatica.
- C2: El sistema publica automaticamente en la fecha configurada.
- C3: El admin puede cancelar o modificar la publicacion programada antes de la fecha.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error del sistema
     - Se informa al actor de error temporal.

   * - EX-02
     - Contenido con referencias a imagenes no existentes
     - El HTML contiene URLs de imagenes que no existen. El sistema advierte al admin pero permite publicar si lo confirma.
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 400ms

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo administradores con permiso de contenido pueden editar

6.3 Confiabilidad
^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Consistencia
     - El sistema mantiene un historial de versiones con posibilidad de revertir

6.4 Usabilidad
^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Claridad
     - El actor ve la informacion necesaria para tomar decisiones

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - pagina_id
     - Enum
     - SI
     - Identificador de la pagina: SOBRE_NOSOTROS, TERMINOS, PRIVACIDAD, FAQ
   * - contenido_html
     - Texto HTML
     - SI
     - El nuevo contenido de la pagina en formato HTML limpio
   * - publicar
     - Booleano
     - NO
     - Si es true publica inmediatamente; si es false guarda como borrador

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - pagina_id
     - Identificador de la pagina actualizada
   * - version
     - Numero de version del contenido guardado
   * - estado
     - PUBLICADO o BORRADOR segun el campo publicar
   * - url_preview
     - URL de la vista previa si estado = BORRADOR

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Pagina no encontrada
     - 404
     - ``codigo_error = PAGINA_NO_ENCONTRADA``
   * - Contenido HTML invalido
     - 422
     - ``codigo_error = HTML_INVALIDO``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``
----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-015
   * - **Depende de**
     - —
   * - **Habilita**
     - —
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version inicial.
   * - 2.1.0
     - 2026-05-05
     - Pasos con entidades reales. Activadores referenciados.

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El admin edita el texto sin conocer como se almacena ni como se sirve.

**Nivel Desarrollo:** Interfaz → Servicio → Repositorio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Lo que el actor ve y hace directamente.
     - Las validaciones, consultas y actualizaciones internas del sistema.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante
- **Complemento de:** UC-CFG-05 (datos de contacto son un caso especial de configuracion)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

Ver PARTE 4 para variaciones de comportamiento.

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-04 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-CFG-04

   participant AdminPanel
   participant ConfigService
   participant Repositorio

   AdminPanel -> ConfigService  : envia contenido actualizado
   ConfigService -> Repositorio : persiste con versionado
   ConfigService --> AdminPanel  : contenido publicado
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-04 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-CFG-04 Contenido Estatico"
   Administrador --> "UC-CFG-04 Contenido Estatico"
   @enduml

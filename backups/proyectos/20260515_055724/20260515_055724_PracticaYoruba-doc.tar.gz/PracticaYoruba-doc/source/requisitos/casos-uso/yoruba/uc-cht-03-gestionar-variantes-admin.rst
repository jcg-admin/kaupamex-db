.. meta::
   :artefacto: UC-CHT-03
   :tipo: Caso de Uso
   :subdominio: chartsize
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: uml-06 derivacion — perspectiva Administrador

.. _uc-cht-03:

====================================================
UC-CHT-03: Gestionar Variantes de Producto (Admin)
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CHT-03
   * - **Nombre**
     - Gestionar Variantes de Producto (Admin)
   * - **Modulo**
     - CHARTSIZE
   * - **Criticidad**
     - CRITICA
   * - **Complejidad**
     - MEDIA
   * - **BReq**
     - BReq-003
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador configurar las variantes disponibles de un producto del dominio Yoruba: tipos de variante (tamano, presentacion, material), sus nombres y su disponibilidad. Sin este UC los visitantes ven UC-CHT-01 pero no existen variantes que seleccionar.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Crear tipos de variante y sus opciones para un producto
- Activar y desactivar variantes individuales
- Reordenar las variantes en la interfaz

**Excluido de este UC:**

- Configurar precio diferenciado por variante — UC-CHT-04
- Ver las variantes (Visitante) — UC-CHT-01

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Miembro del equipo que define la oferta de variantes de cada producto. Es el PROVEEDOR que configura las opciones que el CLIENTE (Visitante) podra seleccionar en UC-CHT-01 y UC-CHT-02.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Sistema de Catalogo**

Persiste la configuracion de variantes.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El producto existe en el sistema (UC-CAT-09 completado)
   * - PRE-02
     - El administrador tiene permisos de gestion de catalogo

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - Las variantes quedan configuradas y disponibles para el producto
   * - POST-02
     - Los visitantes pueden ver y seleccionar las variantes en UC-CHT-01

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - La configuracion de variantes no cambia


----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la configuracion de variantes del producto
   * - 2
     - Sistema
     - Muestra las variantes actuales si las hay
   * - 3
     - Admin
     - Define el tipo de variante: nombre del atributo (Tamano, Presentacion, etc.)
   * - 4
     - Admin
     - Agrega las opciones del tipo: Chico, Mediano, Grande / 100ml, 250ml, etc.
   * - 5
     - Admin
     - Para cada opcion define si tiene precio diferenciado (abre UC-CHT-04)
   * - 6
     - Admin
     - Define el stock inicial de cada variante
   * - 7
     - Admin
     - Ordena las variantes como apareceran al visitante
   * - 8
     - Sistema
     - Valida que las variantes sean unicas y consistentes
   * - 9
     - Sistema
     - Persiste la configuracion
   * - 10
     - Sistema
     - Las variantes quedan disponibles en UC-CHT-01

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Desactivar una variante
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** Una variante se agota o deja de ofrecerse.

- El admin desactiva la variante especifica.
- La variante aparece como no disponible en UC-CHT-01 sin desaparecer del selector.
- El stock de esa variante queda en cero.

4.2 Alternativa B: Agregar variante a producto existente
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** El admin agrega una nueva opcion a un tipo de variante ya configurado.

- La nueva opcion queda disponible para los visitantes inmediatamente.
- Las ordenes existentes con otras variantes no se ven afectadas.


4.3 Alternativa C: Reordenar el orden de presentacion de las variantes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El admin quiere que las variantes aparezcan en un orden especifico en UC-CHT-01.

- C1: El admin puede arrastrar y soltar las variantes para reordenarlas.
- C2: El orden guardado es el que se presenta en UC-CHT-01.
- C3: El primer elemento en el orden es la variante preseleccionada por defecto.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Variante duplicada
     - El admin intenta crear una opcion que ya existe. Se informa.

   * - EX-02
     - Eliminar variante con ordenes activas que la incluyen
     - La variante tiene ordenes activas. El sistema no permite eliminarla — solo puede desactivarse.
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Guardado de variantes (P95)
     - Menor a 600ms

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Solo administradores
     - Solo admins con permisos de catalogo
   * - Stock por variante
     - El sistema mantiene stock independiente por variante

6.3 Confiabilidad
^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Integridad de variantes
     - No pueden existir dos variantes identicas en el mismo producto

6.4 Usabilidad
^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Vista previa
     - El admin puede ver como quedara el selector de variantes antes de confirmar

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Tipo de variante
     - Texto
     - SI
     - Nombre del atributo: Tamano, Presentacion, Material, etc.
   * - Opciones de variante
     - Lista
     - SI
     - Las opciones disponibles con nombre y stock inicial.

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Variantes configuradas
     - Lista de variantes activas del producto disponibles en UC-CHT-01

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Variante duplicada
     - 409
     - ``codigo_error = VARIANTE_DUPLICADA``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``

----

Trazabilidad
=============

.. seealso:: Derivado aplicando :doc:`/base-cognitiva/uml/uml-06-introduccion-casos-uso`

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-003
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-CAT-09
   * - **Habilita**
     - UC-CHT-01, UC-CHT-02, UC-CHT-04
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`


8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario (Admin):** El administrador define los tipos y opciones
de variante del producto, sin conocer como se almacena el precio diferenciado
ni como se indexa para el selector de UC-CHT-01.

**Nivel Desarrollo:** Panel Admin → Servicio de Catalogo →
Repositorio de Variantes.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el Admin)
     - Logica privada (invisible para el Admin)
   * - Formulario de tipo de variante y opciones.
       Vista previa del selector que vera el visitante.
       Confirmacion de variantes guardadas.
     - Validacion de unicidad de opciones.
       Creacion de registros de inventario por variante.
       Propagacion al indice del catalogo.
       Registro en auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante (Admin hereda la vista del catalogo)
- **Depende de:** UC-CAT-09 (el producto debe existir)
- **Configura:** UC-CHT-01 y UC-CHT-02 (el visitante podra ver y seleccionar)
- **Habilita:** UC-CHT-04 (precio diferenciado por variante)

8.4 Polimorfismo — tipos de variante del dominio Yoruba
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: Polimorfismo — tipos de variante Yoruba

   @startuml
   !include ../../../_static/plantuml-styles.puml

   abstract class VariantType {
   + name : CharField
   + options : List<VariantOption>
   + render_selector() : Widget
   }

   class TamanoVariant {
   + options : [Chico, Mediano, Grande]
   + render_selector() : Widget
   }

   class PresentacionVariant {
   + options : [100ml, 250ml, 500ml]
   + render_selector() : Widget
   }

   class MaterialVariant {
   + options : [Cobre, Plata, Oro]
   + render_selector() : Widget
   }

   VariantType <|-- TamanoVariant
   VariantType <|-- PresentacionVariant
   VariantType <|-- MaterialVariant
   @enduml

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CHT-03 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-CHT-03: Gestionar Variantes de Producto (Admin)

   participant AdminPanel
   participant CatalogService
   participant VariantRepository

   AdminPanel -> CatalogService : envia tipo y opciones de variante
   CatalogService -> CatalogService : valida unicidad de cada opcion
   CatalogService -> VariantRepository : persiste las variantes con stock inicial por cada una
   VariantRepository --> CatalogService : variantes creadas
   CatalogService -> CatalogService : actualiza el producto con referencia a las variantes
   CatalogService -> VariantRepository : registra en auditoria
   CatalogService --> AdminPanel : variantes configuradas, selector disponible en UC-CHT-01
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CHT-03 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor Administrador

   usecase "UC-CHT-03 Gestionar Variantes"
   usecase "UC-CAT-09 Crear Producto"
   usecase "UC-CHT-04 Precio Diferenciado"
   usecase "UC-CHT-01 Ver Variantes"
   usecase "UC-CHT-02 Seleccionar Variante"

   Administrador --> "UC-CHT-03 Gestionar Variantes"
   "UC-CAT-09 Crear Producto"  ..> "UC-CHT-03 Gestionar Variantes" : habilita (producto debe existir)
   "UC-CHT-03 Gestionar Variantes"  ..> "UC-CHT-04 Precio Diferenciado" : habilita
   "UC-CHT-03 Gestionar Variantes"  ..> "UC-CHT-01 Ver Variantes" : configura (Visitante podra ver)
   "UC-CHT-01 Ver Variantes"  ..> "UC-CHT-02 Seleccionar Variante" : habilita
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Derivado de uml-06: perspectiva del Administrador como actor
       faltante en el analisis original del dominio.

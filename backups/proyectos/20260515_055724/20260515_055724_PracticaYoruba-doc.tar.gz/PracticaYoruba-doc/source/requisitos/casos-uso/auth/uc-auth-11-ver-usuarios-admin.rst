.. meta::
   :artefacto: UC-AUTH-11
   :tipo: Caso de Uso
   :subdominio: accounts
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-auth-11:

====================================================
UC-AUTH-11: Ver Listado de Usuarios (Admin)
====================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-11
   * - **Nombre**
     - Ver Listado de Usuarios (Admin)
   * - **Modulo**
     - ACCOUNTS (MOD-001)
   * - **BReq**
     - BReq-014
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador consultar el listado paginado de todos
los usuarios del sistema con capacidad de búsqueda y filtrado.
Es el punto de entrada para acceder al perfil completo de un
usuario (UC-AUTH-12), suspenderlo (UC-AUTH-13) o reactivarlo
(UC-AUTH-14).

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Listado paginado de todos los registros ``User`` del sistema.
- Búsqueda por ``User.username``, ``User.email`` o
  ``User.first_name`` / ``User.last_name``.
- Filtrado por estado de cuenta (``User.is_active``) y por
  tipo de usuario (``User.is_staff``).
- Acceso directo al perfil de un usuario (UC-AUTH-12).

**Excluido de este UC:**

- Ver el detalle completo de un usuario — UC-AUTH-12.
- Suspender un usuario — UC-AUTH-13.
- Reactivar un usuario — UC-AUTH-14.
- Crear un usuario administrador — UC-AUTH-15.
- Los campos ``User.password``, ``User.is_superuser`` y los
  campos internos nunca se exponen en este listado.

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

Accede al backoffice con ``User.is_staff = True``.

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Servicio de Cuentas** (``apps.users``)

Recupera el listado de usuarios paginado aplicando los filtros
de búsqueda.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El administrador tiene sesión activa con ``User.is_staff = True``

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El administrador ve el listado paginado de usuarios con
       información resumida de cada uno
   * - POST-02
     - El administrador tiene acceso directo al perfil de
       cualquier usuario desde el listado

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Administrador
     - Accede al panel de usuarios en el backoffice
   * - 2
     - Sistema
     - Recupera los registros ``User`` ordenados por
       ``date_joined`` descendente, paginados
   * - 3
     - Sistema
     - Presenta el listado. Por cada usuario muestra:
       ``User.id``, ``User.username``, ``User.email``,
       ``get_full_name()``, estado de cuenta
       (``User.is_active``), tipo (``User.is_staff``),
       ``User.date_joined`` y ``User.last_login``
   * - 4
     - Administrador
     - Revisa el listado y decide qué acción tomar

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Buscar usuario por identificador
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4, el administrador ingresa un
término en el campo de búsqueda.

- A1: El sistema filtra los registros ``User`` cuyo
  ``username``, ``email`` o nombre completo contengan
  el término ingresado (búsqueda insensible a mayúsculas).
- A2: El listado se actualiza mostrando solo los usuarios
  que coinciden con el término.
- A3: Si no hay coincidencias, el sistema muestra el estado
  vacío con el término buscado.

**Retorno:** Paso 3.

4.2 Alternativa B: Filtrar por estado de cuenta
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4, el administrador aplica el
filtro de estado: activos (``User.is_active = True``),
suspendidos (``User.is_active = False``) o todos.

- B1: El sistema vuelve al paso 2 aplicando el filtro.
- B2: El listado muestra solo los usuarios del estado
  seleccionado con el contador total actualizado.

**Retorno:** Paso 3.

4.3 Alternativa C: Acceder al perfil de un usuario
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4, el administrador selecciona
un usuario del listado para ver su perfil completo.

- C1: El sistema redirige a UC-AUTH-12 con el ``User.id``
  preseleccionado.

**Retorno:** UC-AUTH-12.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al recuperar el listado
     - El Servicio de Cuentas no puede consultar el
       repositorio. El sistema informa al administrador del
       error temporal. No se muestra ningún usuario.
       El administrador puede reintentar recargando el panel.

----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 400ms para cargar la primera página del listado

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo usuarios con ``User.is_staff = True``
   * - Datos excluidos
     - ``User.password``, ``User.is_superuser`` y campos
       internos de Django nunca aparecen en el listado

6.3 Usabilidad
^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Indicador visual
     - Los usuarios con ``User.is_active = False`` se muestran
       con indicador visual diferenciado para identificarlos
       rápidamente en el listado

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Req
     - Descripcion
   * - Término de búsqueda
     - ``CharField``
     - NO
     - Texto libre que se compara contra ``username``,
       ``email`` y nombre completo
   * - Filtro de estado
     - Enum
     - NO
     - Activos / Suspendidos / Todos.
       Por defecto muestra todos
   * - Filtro de tipo
     - Enum
     - NO
     - Todos / Solo administradores / Solo compradores

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

Por cada ``User`` en la página actual:

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - ``User.id``
     - Identificador para acceder a UC-AUTH-12
   * - ``User.username``
     - Nombre de usuario
   * - ``User.email``
     - Correo electrónico
   * - ``get_full_name()``
     - Nombre completo del usuario
   * - ``User.is_active``
     - Estado de la cuenta: activa o suspendida
   * - ``User.is_staff``
     - Tipo: administrador o comprador
   * - ``User.date_joined``
     - Fecha de registro en el sistema
   * - ``User.last_login``
     - Fecha y hora del último acceso (nulo si nunca accedió)

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Error al recuperar listado
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-014
   * - **Habilita**
     - UC-AUTH-12 (ver perfil), UC-AUTH-13 (suspender),
       UC-AUTH-14 (reactivar) — punto de entrada para los tres
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El administrador busca y filtra usuarios sin
conocer cómo se consulta el repositorio ni cómo se pagina la
respuesta.

**Nivel Desarrollo:** Panel Admin → Servicio de Cuentas
(``apps.users``) → Repositorio ``User`` con búsqueda y
paginación.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Campo de búsqueda. Filtros de estado y tipo.
       Listado paginado con columnas de usuario,
       estado y fechas. Acciones por fila.
     - Consulta al repositorio con filtros dinámicos.
       Paginación. Exclusión de ``password`` e
       ``is_superuser`` de la respuesta.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Administrador (``User.is_staff = True``)
- **Punto de entrada de:** UC-AUTH-12, UC-AUTH-13, UC-AUTH-14

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

- Sin filtros → muestra todos los usuarios
- Filtro activos → solo ``User.is_active = True``
- Filtro suspendidos → solo ``User.is_active = False``
- Filtro administradores → solo ``User.is_staff = True``
- Búsqueda → resultados que coincidan con el término

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-11 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-11

   participant AdminPanel
   participant AccountService
   participant Repositorio

   AdminPanel -> AccountService : solicita listado (filtros opcionales)
   AccountService -> Repositorio : consulta User con filtros y paginación
   Repositorio --> AccountService : página de registros User
   AccountService -> AccountService : excluye password e is_superuser
   AccountService --> AdminPanel : listado paginado con datos de usuario
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-11 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-AUTH-11 Ver Listado Usuarios"
   usecase "UC-AUTH-12 Ver Perfil Usuario"
   usecase "UC-AUTH-13 Suspender Usuario"
   usecase "UC-AUTH-14 Reactivar Usuario"
   usecase "UC-AUTH-15 Crear Admin"

   Administrador --> "UC-AUTH-11 Ver Listado Usuarios"
   "UC-AUTH-11 Ver Listado Usuarios" ..> "UC-AUTH-12 Ver Perfil Usuario"  : punto de entrada
   "UC-AUTH-11 Ver Listado Usuarios" ..> "UC-AUTH-13 Suspender Usuario"   : punto de entrada
   "UC-AUTH-11 Ver Listado Usuarios" ..> "UC-AUTH-14 Reactivar Usuario"   : punto de entrada
   "UC-AUTH-11 Ver Listado Usuarios" ..> "UC-AUTH-15 Crear Admin" : acceso al formulario de nuevo admin
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 1.0.0
     - 2026-05-05
     - Version inicial. Gap identificado en analisis-cobertura-backoffice.rst.

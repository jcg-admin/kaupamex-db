.. meta::
   :artefacto: UC-AUTH-06
   :tipo: Caso de Uso
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-auth-06:

======================================
UC-AUTH-06: Editar Perfil de Usuario
======================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-06
   * - **Nombre**
     - Editar Perfil de Usuario
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Depende de**
     - UC-AUTH-05
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al usuario autenticado actualizar su informacion de perfil:
nombre, apellido, telefono y avatar, sin que ello afecte sus
credenciales de acceso.

1.3 Alcance
-----------

**Incluido en este UC:**

- Edicion de nombre, apellido, telefono
- Carga y actualizacion del avatar
- Eliminacion del avatar actual

**Excluido de este UC:**

- Cambiar el email — requiere un proceso de verificacion propio (UC futuro)
- Cambiar la contrasena — UC-AUTH-08
- Gestionar direcciones — UC-AUTH-07

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Autenticado**

Persona que desea actualizar su informacion personal en el sistema.

2.2 Actores Secundarios
-----------------------

**Sistema de Cuentas**

Valida y persiste los cambios del perfil.

**Servicio de Archivos**

Procesa y almacena el avatar cuando el usuario sube uno nuevo.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario esta autenticado

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - Los datos del perfil quedan actualizados en el sistema
   * - POST-02
     - El evento de modificacion queda registrado en auditoria

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Desde el perfil (UC-AUTH-05), selecciona la opcion de editar
   * - 2
     - Sistema
     - Presenta el formulario de edicion con los datos actuales precargados
   * - 3
     - Usuario
     - Modifica uno o mas campos: nombre, apellido, telefono
   * - 4
     - Usuario
     - Opcionalmente sube un nuevo avatar (imagen)
   * - 5
     - Usuario
     - Solicita guardar los cambios
   * - 6
     - Sistema
     - Valida los campos modificados: formato, longitud, caracteres permitidos
   * - 7
     - Sistema
     - Si se subio un avatar: valida formato, tamanio y dimensiones de la imagen
   * - 8
     - Sistema
     - Persiste los cambios en el repositorio
   * - 9
     - Sistema
     - Si habia nuevo avatar: lo procesa y almacena, eliminando el anterior
   * - 10
     - Sistema
     - Registra el evento de modificacion en auditoria con los campos cambiados
   * - 11
     - Sistema
     - Confirma al usuario que el perfil fue actualizado exitosamente
   * - 12
     - Sistema
     - Presenta el perfil actualizado (UC-AUTH-05)

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Avatar con formato o tamanio invalido
---------------------------------------------------------

**Activador:** En el paso 7, el archivo de imagen no cumple los requisitos.

- A1: El sistema informa los requisitos no cumplidos (formato, tamanio maximo)
- A2: El resto de cambios del formulario se mantienen
- A3: El avatar anterior no se modifica

**Retorno:** Paso 4 con los demas campos conservados.

4.2 Alternativa B: El usuario elimina su avatar
------------------------------------------------

**Activador:** El usuario solicita eliminar el avatar actual.

- B1: El sistema elimina el avatar almacenado
- B2: El perfil queda sin avatar (usa el avatar por defecto del sistema)

**Retorno:** Paso 10 sin avatar.

4.3 Alternativa C: Sin cambios realizados
------------------------------------------

**Activador:** El usuario no modifica ningun campo y cancela la edicion.

- C1: El sistema descarta el formulario sin guardar nada
- C2: Vuelve a la vista del perfil sin cambios

**Retorno:** UC-AUTH-05.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al guardar
     - El repositorio falla al persistir los cambios.
       Los datos del perfil no se modifican. Se informa al usuario.
   * - EX-02
     - Error al procesar avatar
     - El procesamiento de la imagen falla.
       Los demas datos se guardan correctamente.
       Se informa al usuario del problema con el avatar.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Guardado de cambios (P95)
     - Menor a 500ms (sin avatar) o menor a 2s (con avatar)

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autenticacion obligatoria
     - Solo el propio usuario puede editar su perfil
   * - Validacion de archivos
     - Los avatares se validan en servidor para prevenir carga de archivos maliciosos
   * - Registro de cambios
     - Todos los cambios quedan registrados en auditoria

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Atomicidad
     - Los datos del perfil y el avatar se actualizan de forma consistente
   * - Conservacion ante fallo
     - Si el proceso de avatar falla, los datos textuales se guardan de igual forma

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Datos precargados
     - El formulario presenta los datos actuales del usuario para edicion
   * - Vista previa del avatar
     - Antes de guardar, el usuario puede ver como quedara el nuevo avatar
   * - Feedback inmediato
     - La confirmacion del guardado es clara e inmediata

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Nombre
     - Texto
     - NO
     - Longitud: 2 a 50 caracteres. Si se envia, no puede estar vacio.
   * - Apellido
     - Texto
     - NO
     - Longitud: 2 a 50 caracteres.
   * - Telefono
     - Texto
     - NO
     - Formato de telefono valido. Puede estar vacio.
   * - Avatar
     - Archivo de imagen
     - NO
     - Formatos: JPEG, PNG, WebP. Tamanio maximo configurado.
       Dimensiones minimas recomendadas para buena presentacion.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Perfil actualizado
     - Los datos del perfil con los nuevos valores guardados
   * - Confirmacion
     - Mensaje indicando que el perfil fue actualizado exitosamente

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Datos invalidos
     - 400
     - ``codigo_error = DATOS_INVALIDOS``
   * - Avatar invalido
     - 400
     - ``codigo_error = AVATAR_INVALIDO``
   * - No autenticado
     - 401
     - ``codigo_error = AUTENTICACION_REQUERIDA``
   * - Error del sistema
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-05
   * - **FR derivados**
     - Pendiente - Capa 3 (~6 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~12 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario autenticado actualiza su nombre o avatar sin conocer como se almacena ni valida.

**Nivel Desarrollo:** Interfaz de Perfil → Servicio de Autenticacion → Servicio de Archivos (avatar) → Repositorio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario con nombre y avatar actuales. Confirmacion de cambios guardados.
     - Validacion de campos. Almacenamiento del avatar en Servicio de Archivos. Actualizacion en repositorio. Registro en auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Comprador autenticado
- **Depende de:** UC-AUTH-05 (acceso desde el perfil)
- **No modifica:** email (campo de identidad) ni contrasena (UC-AUTH-08)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El comportamiento es uniforme para todos los campos editables.

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-06: Editar Perfil — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-06: Editar Perfil

   participant ProfileInterface
   participant AuthService
   participant FileService
   participant Repositorio

   ProfileInterface -> AuthService : envia campos a actualizar
   AuthService -> AuthService : valida los campos
   AuthService -> FileService : almacena nuevo avatar si cambio
   FileService --> AuthService : URL del nuevo avatar
   AuthService -> Repositorio : actualiza nombre y URL del avatar
   AuthService -> Repositorio : registra en auditoria
   AuthService --> ProfileInterface  : perfil actualizado
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-06: Editar Perfil — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      actor AuthUser
      usecase "UC-AUTH-06 Editar Perfil"
      usecase "UC-AUTH-05 Ver Perfil"
      AuthUser --> "UC-AUTH-06 Editar Perfil"
      "UC-AUTH-05 Ver Perfil" ..> "UC-AUTH-06 Editar Perfil" : habilita
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.

.. meta::
   :artefacto: UC-AUTH-02
   :tipo: Caso de Uso
   :dominio: requisitos
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: UC_ACC_01 TiendaMax v2.0.1

.. _uc-auth-02:

=======================================
UC-AUTH-02: Iniciar Sesion (Login)
=======================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-02
   * - **Nombre**
     - Iniciar Sesion (Login)
   * - **Version**
     - 2.0.0
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - CRITICA (punto de entrada al area protegida)
   * - **Complejidad**
     - MEDIA
   * - **Precedente**
     - UC-AUTH-01 (registrar), UC-AUTH-10 (verificar email)
   * - **Siguiente**
     - UC-CAT-01, UC-CART-01, UC-AUTH-05, UC-AUTH-06
   * - **Depende de**
     - UC-AUTH-01 y UC-AUTH-10
   * - **BReq**
     - BReq-001, BReq-009
   * - **BR aplicadas**
     - BR-013, BR-015

1.2 Proposito
-------------

Permitir a un usuario registrado y verificado autenticarse en el
sistema utilizando su identificador y contrasena, obteniendo
credenciales de sesion para acceder a funcionalidades protegidas
y mantener su sesion activa.

1.3 Alcance
-----------

**Incluido en este UC:**

- Formulario de inicio de sesion (identificador + contrasena)
- Validacion de credenciales (identificador existe, contrasena correcta)
- Verificacion de email validado y cuenta activa
- Emision de credenciales de sesion (acceso y renovacion)
- Control de intentos fallidos y bloqueo temporal
- Registro de auditoria de todos los intentos
- Gestion de sesion persistente

**Excluido de este UC:**

- Autenticacion mediante proveedores externos (OAuth, SSO) — UC futuro
- Autenticacion de dos factores (2FA) — UC futuro
- Sincronizacion de sesion entre multiples dispositivos
- CAPTCHA — evaluacion pendiente

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Registrado y Verificado**

Persona que desea acceder al area protegida del sistema.

Caracteristicas previas requeridas:

- Tiene una cuenta registrada con identificador unico
- Ha verificado su identidad (email confirmado)
- Su cuenta esta en estado activo
- No tiene una sesion activa en el dispositivo actual
- Esta en la pagina de inicio de sesion

Objetivos del actor:

- Autenticarse para acceder al catalogo, realizar compras y gestionar su cuenta

2.2 Actores Secundarios
-----------------------

**Sistema de Autenticacion**

Componente que valida credenciales, emite credenciales de sesion,
aplica control de intentos y registra todos los eventos de acceso.

Restricciones: mensajes de error genericos, comparacion en tiempo constante,
contrasena nunca en texto plano, comunicacion solo por canal cifrado.

**Servicio de Auditoria**

Registra todos los intentos de acceso (exitosos y fallidos) con informacion
de trazabilidad para analisis de seguridad.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario tiene cuenta registrada (UC-AUTH-01 completado)
   * - PRE-02
     - El usuario verifico su email (UC-AUTH-10 completado)
   * - PRE-03
     - La cuenta esta en estado activo (no suspendida ni eliminada)
   * - PRE-04
     - El usuario no tiene sesion activa vigente en el dispositivo
   * - PRE-05
     - El sistema esta disponible y el canal es seguro y cifrado
   * - PRE-06
     - El identificador/origen no esta bloqueado por intentos fallidos previos

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El usuario tiene credencial de acceso (vida corta) y de renovacion (vida larga)
   * - POST-02
     - El evento de acceso exitoso queda registrado en auditoria
   * - POST-03
     - El usuario puede acceder a las funcionalidades protegidas
   * - POST-04
     - El contador de intentos fallidos se restablece a cero
   * - POST-05
     - El registro del usuario refleja la fecha y hora del ultimo acceso exitoso

**Caso de fallo:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-F01
     - No se emiten credenciales de sesion
   * - POST-F02
     - El intento fallido queda registrado en auditoria
   * - POST-F03
     - El contador de intentos fallidos se incrementa
   * - POST-F04
     - Si se alcanza el limite, el acceso queda bloqueado temporalmente

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

Secuencia normal: el usuario se autentica exitosamente.

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Accede a la pagina de inicio de sesion del sistema
   * - 2
     - Sistema
     - Presenta formulario con campos identificador y contrasena,
       enlace a recuperar contrasena (UC-AUTH-09) y a crear cuenta (UC-AUTH-01)
   * - 3
     - Usuario
     - Ingresa su identificador (email)
   * - 4
     - Sistema
     - Valida el formato del identificador en tiempo real con retroalimentacion visual
   * - 5
     - Usuario
     - Ingresa su contrasena (campo con opcion de mostrar/ocultar)
   * - 6
     - Usuario
     - Opcionalmente activa la opcion "Recordarme"
   * - 7
     - Usuario
     - Solicita iniciar sesion
   * - 8
     - Sistema
     - Valida formato final de todos los campos.
       Deshabilita el boton y muestra indicador de procesamiento
   * - 9
     - Sistema
     - Verifica que el origen de la solicitud no esta bloqueado
       por exceso de intentos fallidos previos
   * - 10
     - Sistema
     - Valida el formato del identificador segun las reglas del sistema.
       Normaliza a minusculas
   * - 11
     - Sistema
     - Busca el identificador en el repositorio de usuarios
   * - 12
     - Sistema
     - Verifica que la cuenta tiene el email confirmado
   * - 13
     - Sistema
     - Verifica que la cuenta esta en estado activo
   * - 14
     - Sistema
     - Compara la contrasena ingresada con la almacenada de forma segura
       en tiempo constante (previene ataques de temporalizacion)
   * - 15
     - Sistema
     - Emite la credencial de acceso con datos de identificacion del usuario
       sin informacion sensible (vida corta)
   * - 16
     - Sistema
     - Emite la credencial de renovacion (vida larga, se invalida con cada uso;
       si "Recordarme" activo, la vida se extiende segun configuracion)
   * - 17
     - Sistema
     - Registra la fecha y hora del acceso exitoso en el perfil del usuario
   * - 18
     - Sistema
     - Registra en auditoria: identificador, origen, tipo=ACCESO,
       resultado=EXITOSO, timestamp
   * - 19
     - Sistema
     - Restablece el contador de intentos fallidos para ese identificador/origen
   * - 20
     - Sistema
     - Retorna las credenciales de sesion y los datos basicos del usuario.
       El usuario queda en el area protegida


Diagrama de Secuencia
---------------------

.. uml::
   :caption: Flujo de secuencia — UC-AUTH-02 Iniciar Sesion

      @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-02: Iniciar Sesion — Flujo Normal

   actor Usuario
   participant AccessInterface
   participant AuthService
   participant RateLimiter
   participant Repositorio
   participant AuditService

   Usuario -> AccessInterface: solicita iniciar sesion
   AccessInterface -> AccessInterface: valida formato de entrada
   AccessInterface -> AuthService: envia credenciales de acceso

   AuthService -> RateLimiter: verifica limite de intentos
   RateLimiter --> AuthService: dentro del limite permitido

   AuthService -> Repositorio: busca el identificador
   Repositorio --> AuthService: usuario encontrado

   AuthService -> AuthService: verifica email confirmado
   AuthService -> AuthService: verifica cuenta activa
   AuthService -> AuthService: compara contrasena\n(tiempo constante)

   AuthService -> AuthService: emite credencial de acceso
   AuthService -> AuthService: emite credencial de renovacion

   AuthService -> AuditService: registra acceso exitoso
   AuthService -> RateLimiter: restablece contador de intentos
   AuthService --> AccessInterface: credenciales de sesion

   UI --> U: acceso concedido

   @enduml

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Identificador no registrado
------------------------------------------------

**Activador:** En el paso 11, el identificador no existe en el sistema.

- 11A: El sistema no encuentra el identificador
- 11B: Registra el intento como ``FALLO_IDENTIFICADOR_NO_ENCONTRADO``
- 11C: Incrementa el contador de intentos fallidos para ese origen
- 11D: Retorna mensaje generico: *"Identificador o contrasena incorrectos"*
  (sin revelar si el identificador existe — proteccion contra enumeracion)
- 11E: El usuario puede reintentar

**Retorno:** Paso 3.

4.2 Alternativa B: Contrasena incorrecta
-----------------------------------------

**Activador:** En el paso 14, la contrasena no coincide.

- 14A: La comparacion segura indica que la contrasena no coincide
- 14B: Registra el intento como ``FALLO_CONTRASENA_INCORRECTA``
- 14C: Incrementa el contador de intentos fallidos
- 14D: Retorna el mismo mensaje generico que en A (no diferencia ambos errores)
- 14E: El campo identificador mantiene su valor; el de contrasena se limpia
- 14F: Si el contador alcanza el umbral, aplica bloqueo temporal (ver EX-01)

**Retorno:** Paso 5.

4.3 Alternativa C: Email no verificado
---------------------------------------

**Activador:** En el paso 12, el email no ha sido confirmado.

- 12A: El sistema detecta que el email no esta confirmado
- 12B: Registra el intento como ``FALLO_EMAIL_NO_VERIFICADO``
- 12C: Informa al usuario: *"Por favor verifica tu email antes de iniciar sesion"*
- 12D: Ofrece la opcion de reenviar el email de verificacion (UC-AUTH-10)
- 12E: No emite credenciales de sesion

**Retorno:** El usuario va a UC-AUTH-10.

4.4 Alternativa D: Cuenta inactiva o suspendida
-------------------------------------------------

**Activador:** En el paso 13, la cuenta no esta en estado activo.

- 13A: El sistema detecta que la cuenta no esta activa
- 13B: Registra el intento como ``FALLO_CUENTA_INACTIVA``
- 13C: Informa al usuario sobre el estado de su cuenta
- 13D: Proporciona informacion de contacto con soporte
- 13E: No emite credenciales de sesion

**Retorno:** El usuario contacta soporte.

4.5 Alternativa E: Tiempo de respuesta excedido
-------------------------------------------------

**Activador:** El sistema no responde en el tiempo maximo establecido.

- E1: La solicitud supera el tiempo maximo de espera
- E2: El sistema informa que la solicitud tomo demasiado tiempo
- E3: El usuario puede reintentar manualmente

**Retorno:** Paso 7.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Limite de intentos
     - El origen supero el numero maximo de intentos fallidos en la ventana
       de tiempo (BR-015). El sistema bloquea temporalmente, informa el tiempo
       de espera y registra el bloqueo en auditoria.
       El bloqueo expira automaticamente.
   * - EX-02
     - Repositorio no disponible
     - El repositorio de usuarios no responde. El sistema informa de un error
       temporal y no emite credenciales. El usuario puede reintentar.
   * - EX-03
     - Canal no seguro
     - La solicitud llega por canal no cifrado. El sistema rechaza la solicitud
       y redirige al canal seguro. La contrasena nunca se procesa en canal inseguro.
   * - EX-04
     - Solicitud invalida
     - Campos faltantes, tipos incorrectos o formato invalido. El sistema
       retorna error de validacion sin procesar la autenticacion.
   * - EX-05
     - Error al emitir credenciales
     - El proceso de emision falla internamente. El sistema registra el error
       e informa al usuario de un problema temporal.
       La cuenta no queda afectada.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 500ms en condiciones normales de carga
   * - Tiempo de respuesta (P99)
     - Menor a 1000ms
   * - Tiempo de respuesta (P50)
     - Menor a 200ms
   * - Capacidad concurrente
     - Sin degradacion de los tiempos anteriores al pico de usuarios definido
   * - Disponibilidad del endpoint
     - Segun SLO de BReq-007 (99.5% mensual)

Nota: la comparacion segura de contrasenas tiene duracion intencional
de 100-200ms para dificultar ataques de temporalizacion. Este tiempo
esta incluido en los objetivos anteriores.

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Almacenamiento de contrasenas
     - Las contrasenas NUNCA se almacenan en texto plano
   * - Comparacion de contrasenas
     - Debe realizarse en tiempo constante (previene timing attacks)
   * - Mensajes de error
     - No revelan si el identificador existe (proteccion contra enumeracion)
   * - Canal de comunicacion
     - Toda la informacion viaja por canal seguro cifrado
   * - Control de intentos
     - Maximo configurable de intentos fallidos antes de bloqueo.
       Aplica por identificador Y por origen de la solicitud
   * - Credenciales de sesion
     - Tiempo de vida definido, no reutilizables despues de expirar o revocar
   * - Registro de auditoria
     - TODOS los intentos quedan registrados.
       Los registros NO contienen la contrasena ni las credenciales
   * - Datos sensibles en logs
     - Contrasenas y credenciales NUNCA aparecen en ningun registro del sistema

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Disponibilidad
     - El endpoint de autenticacion cumple el SLO de BReq-007
   * - Degradacion controlada
     - Ante fallo del repositorio, el sistema informa sin perder consistencia
   * - Integridad de registros
     - El fallo en el registro de auditoria no impide la autenticacion exitosa
   * - Consistencia del contador
     - El contador de intentos es consistente bajo carga concurrente (BR-015)

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Claridad del formulario
     - Campos claramente identificados y diferenciados
   * - Retroalimentacion inmediata
     - Validacion de formato en tiempo real con indicacion visual
   * - Visibilidad de contrasena
     - El usuario puede alternar entre ver y ocultar la contrasena
   * - Prevencion de doble envio
     - El boton se deshabilita durante el procesamiento
   * - Indicador de progreso
     - Indicador visual durante el procesamiento de la solicitud
   * - Mensajes de error
     - Claros y orientados a la accion que el usuario puede tomar
   * - Accesibilidad
     - Navegable por teclado, compatible con lectores de pantalla (WCAG 2.1 AA)
   * - Adaptabilidad
     - Funciona en dispositivos moviles y de escritorio

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

Datos que el usuario proporciona al sistema:

.. list-table::
   :widths: 20 12 12 56
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion y reglas de validacion
   * - Identificador
     - Texto (email)
     - SI
     - Email del usuario registrado.
       Formato RFC 5322 (usuario@dominio.tld).
       Longitud: 5 a 254 caracteres.
       Se normaliza a minusculas antes de buscar.
       No puede estar vacio.
   * - Contrasena
     - Texto
     - SI
     - Contrasena establecida durante el registro.
       Longitud: 1 a 256 caracteres.
       Distingue mayusculas y minusculas.
       No se valida fuerza en el login.
       NUNCA se registra en logs.
   * - Recordarme
     - Booleano
     - NO
     - Si verdadero: la credencial de renovacion tiene mayor tiempo de vida.
       Por defecto: falso.

7.2 Salida (Caso exitoso)
--------------------------

Datos que el sistema retorna cuando la autenticacion es exitosa:

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Credencial de acceso
     - Credencial de vida corta para incluir en cada solicitud a recursos protegidos.
       Contiene: identificador del usuario, rol, timestamps de emision y expiracion.
       NO contiene contrasena ni datos sensibles.
   * - Credencial de renovacion
     - Credencial de vida larga para obtener nuevas credenciales de acceso.
       Se invalida despues de cada uso (rotacion automatica).
       Se invalida al cerrar sesion (UC-AUTH-03).
   * - Datos basicos del usuario
     - Para mostrar en la interfaz: identificador interno, email,
       nombre visible, rol en el sistema, referencia al avatar si existe.

7.3 Salida (Casos de error)
----------------------------

Respuestas del sistema ante condiciones de error:

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion del mensaje y datos de respuesta
   * - Credenciales invalidas
     - 401
     - Mensaje generico sin distinguir identificador incorrecto
       de contrasena incorrecta.
       ``codigo_error = CREDENCIALES_INVALIDAS``
   * - Email no verificado
     - 401
     - Indica verificacion pendiente.
       Incluye opcion de reenviar el email.
       ``codigo_error = EMAIL_NO_VERIFICADO``
   * - Cuenta inactiva
     - 401
     - Indica cuenta suspendida.
       Proporciona contacto con soporte.
       ``codigo_error = CUENTA_INACTIVA``
   * - Limite de intentos
     - 429
     - Indica bloqueo temporal con tiempo restante.
       ``codigo_error = LIMITE_INTENTOS_EXCEDIDO``
   * - Datos invalidos
     - 400
     - Describe campos con formato incorrecto.
       ``codigo_error = DATOS_INVALIDOS``
   * - Error del sistema
     - 500
     - Mensaje generico temporal, sin detalles internos.
       ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001 (plataforma), BReq-009 (seguridad)
   * - **BR**
     - BR-013 (auditabilidad), BR-015 (rate limiting atomico)
   * - **Depende de**
     - UC-AUTH-01, UC-AUTH-10
   * - **Habilita**
     - UC-CAT-01, UC-CART-01, UC-ORD-01, UC-AUTH-05, UC-AUTH-06
   * - **FR derivados**
     - Pendiente - Capa 3 (~8 FR estimados)
   * - **Pseudocode**
     - Pendiente - Capa 4
   * - **Tests**
     - Pendiente - Capa 5 (~16 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El comprador introduce sus credenciales y accede a su cuenta
sin necesidad de conocer como se verifica la identidad ni como se crea la sesion.

**Nivel Desarrollo:** Interfaz de Acceso → Servicio de Autenticacion →
Repositorio de Usuarios → Servicio de Sesion.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Formulario de email y contrasena.
       Mensaje de error generico si falla.
       Redireccion a la pagina de inicio al exito.
     - Verificacion del hash de contrasena.
       Creacion y firma del token de sesion.
       Registro del evento en auditoria.
       Incremento del contador de intentos fallidos.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante (el Comprador hereda todos sus UC)
- **Este UC incluye:** UC-AUTH-04 (renovar sesion) — ``<<include>>`` implicito
- **Este UC es extendido por:** N/A
- **Habilita:** todos los UC de usuario autenticado (UC-ORD, UC-PAY, UC-PERFIL)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El comportamiento varia segun el resultado de la verificacion:

- **Credenciales validas** → crea sesion y redirige
- **Credenciales invalidas** → incrementa contador, responde error generico
- **Cuenta bloqueada** → informa bloqueo y ofrece recuperacion (UC-AUTH-09)
- **Email no verificado** → informa que debe verificar y reenviar email (UC-AUTH-10)

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-02 — Envio de mensajes (participantes abstractos)

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-02: Iniciar Sesion

   participant AccessInterface
   participant AuthService
   participant Repositorio
   participant SessionStore

   AccessInterface -> AuthService : envia credenciales (email, contrasena)

   AuthService -> Repositorio : busca usuario por email
   Repositorio --> AuthService : datos del usuario o no encontrado

   alt Credenciales validas y cuenta activa
   AuthService -> AuthService : verifica hash de contrasena
   AuthService -> SessionStore : crea token de sesion
   SessionStore --> AuthService : token firmado
   AuthService -> Repositorio : registra evento de acceso exitoso
   AuthService --> AccessInterface : acceso concedido + token
   else Credenciales invalidas
   AuthService -> Repositorio : incrementa contador de intentos
   AuthService --> AccessInterface : error de autenticacion (generico)
   else Cuenta bloqueada
   AuthService --> AccessInterface : cuenta bloqueada, ofrece recuperacion
   end
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-02 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction
   actor Comprador
   actor Visitante

   usecase "UC-AUTH-02 Iniciar Sesion"
   usecase "UC-AUTH-04 Renovar Sesion"
   usecase "UC-AUTH-09 Recuperar Contrasena"
   usecase "UC-ORD-01 Crear Orden"

   Visitante  <|-- Comprador
   Comprador  --> "UC-AUTH-02 Iniciar Sesion"
   "UC-AUTH-02 Iniciar Sesion" ..> "UC-AUTH-04 Renovar Sesion" : <<include>>
   RECUP ..|> "UC-AUTH-02 Iniciar Sesion" : alternativa de acceso
   "UC-AUTH-02 Iniciar Sesion" ..> "UC-ORD-01 Crear Orden"  : habilita (postcondicion)
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa con las 7 partes requeridas.
       Adaptado de UC_ACC_01 TiendaMax v2.0.1.
       Sin referencias tecnologicas — la tecnologia vive en ADRs y stack.rst.
       La tecnologia vive en ADRs y stack.rst.
       Diagramas en PlantUML.

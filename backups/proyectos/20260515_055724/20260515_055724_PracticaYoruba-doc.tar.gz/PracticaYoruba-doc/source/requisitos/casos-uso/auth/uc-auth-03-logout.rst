.. meta::
   :artefacto: UC-AUTH-03
   :tipo: Caso de Uso
   :dominio: requisitos
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30
   :fuente: UC_ACC_10 TiendaMax v2.0.1

.. _uc-auth-03:

=======================================
UC-AUTH-03: Cerrar Sesion (Logout)
=======================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-03
   * - **Nombre**
     - Cerrar Sesion (Logout)
   * - **Version**
     - 2.0.0
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Precedente**
     - UC-AUTH-02 (debe existir una sesion activa)
   * - **Siguiente**
     - UC-AUTH-02 (el usuario puede volver a iniciar sesion)
   * - **BReq**
     - BReq-009
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al usuario autenticado terminar su sesion de forma segura,
invalidando sus credenciales de sesion activas de modo que no puedan
reutilizarse aunque alguien llegara a obtenerlas posteriormente.

1.3 Alcance
-----------

**Incluido en este UC:**

- Invalidacion de las credenciales de renovacion de sesion
- Limpieza del estado de sesion en el lado del cliente
- Registro del evento de cierre en el log de auditoria
- Redireccion al estado no autenticado

**Excluido de este UC:**

- Cierre de sesion en todos los dispositivos simultaneamente — UC futuro
- Cierre de sesion forzado por el administrador — UC-ADM-01

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Autenticado**

Persona con una sesion activa que desea terminar su sesion de forma
segura. Puede ser tanto por decision propia como por abandonar el
dispositivo.

Objetivos del actor:

- Garantizar que nadie mas pueda usar su cuenta en este dispositivo
- Dejar el sistema en estado seguro

2.2 Actores Secundarios
-----------------------

**Sistema de Autenticacion**

Invalida las credenciales de sesion activas en el repositorio de sesiones.
Garantiza que las credenciales revocadas no puedan usarse para
obtener nuevas credenciales de acceso.

**Servicio de Auditoria**

Registra el evento de cierre de sesion para trazabilidad y analisis
de comportamiento del usuario.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario tiene una sesion activa vigente (UC-AUTH-02 completado)
   * - PRE-02
     - El usuario posee credenciales de sesion validas

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - Las credenciales de renovacion quedan revocadas en el sistema
   * - POST-02
     - El estado de sesion del cliente queda limpio (sin credenciales activas)
   * - POST-03
     - El usuario queda en estado no autenticado
   * - POST-04
     - Las credenciales revocadas no pueden usarse para obtener nuevas
       credenciales de acceso
   * - POST-05
     - El evento de cierre de sesion queda registrado en el log de auditoria

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Solicita cerrar sesion (a traves del menu de usuario, boton de salida
       u otro elemento de la interfaz claramente identificado)
   * - 2
     - Sistema
     - Recibe la solicitud junto con las credenciales de renovacion activas
   * - 3
     - Sistema
     - Valida que la solicitud provenga de una sesion activa reconocida
   * - 4
     - Sistema
     - Revoca las credenciales de renovacion en el repositorio de sesiones
       de modo que no puedan usarse para obtener nuevas credenciales de acceso
   * - 5
     - Sistema
     - Registra el evento en el log de auditoria:
       identificador de usuario, origen, tipo=CIERRE_SESION,
       resultado=EXITOSO, timestamp
   * - 6
     - Sistema
     - Elimina el estado de sesion del lado del cliente
       (credenciales almacenadas, estado de autenticacion)
   * - 7
     - Sistema
     - Confirma al usuario que la sesion ha sido cerrada exitosamente
   * - 8
     - Sistema
     - Redirige al usuario a la pagina publica del sistema
       (catalogo o pagina de inicio de sesion)

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Credenciales ya revocadas
---------------------------------------------

**Activador:** En el paso 4, las credenciales de renovacion ya habian
sido revocadas previamente (por ejemplo, por expiracion natural).

- A1: El sistema detecta que las credenciales no estan activas
- A2: Procede igualmente con la limpieza del estado del cliente
- A3: Registra el evento indicando el estado previo
- A4: Confirma al usuario que la sesion fue cerrada

**Retorno:** El resultado para el usuario es identico al caso exitoso.
No se genera error visible.

4.2 Alternativa B: Sesion expirada de forma natural
-----------------------------------------------------

**Activador:** El usuario intenta cerrar sesion pero sus credenciales
de acceso ya expiraron por inactividad.

- B1: El sistema detecta la expiracion durante la validacion
- B2: Limpia el estado del cliente de todas formas
- B3: Informa al usuario que su sesion habia expirado
- B4: Redirige a la pagina de inicio de sesion

**Retorno:** El usuario queda en estado no autenticado.

4.3 Alternativa C: Cierre de sesion desde todos los dispositivos
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El usuario selecciona cerrar sesion en todos sus dispositivos.

- C1: El sistema invalida todos los tokens activos del usuario.
- C2: Los demas dispositivos quedan desconectados en su proximo request.
- C3: El evento se registra como cierre masivo en auditoria.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error al revocar credenciales
     - El repositorio de sesiones no responde durante la revocacion.
       El sistema limpia el estado del cliente de todas formas e
       informa de un error parcial. Las credenciales podrian seguir
       tecnicamente activas hasta su expiracion natural.
   * - EX-02
     - Solicitud sin credenciales
     - La solicitud de cierre llega sin credenciales de sesion validas.
       El sistema limpia el estado del cliente y redirige al estado
   * - EX-03
     - Token ya expirado
     - El token de sesion ya habia expirado antes del logout. El sistema considera el logout exitoso y limpia cualquier dato de sesion residual.
       no autenticado. No genera error visible al usuario.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 200ms (operacion simple de revocacion)
   * - Disponibilidad
     - El cierre de sesion debe funcionar incluso si el servicio de auditoria
       no esta disponible temporalmente

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Revocacion efectiva
     - Las credenciales revocadas NO pueden usarse para obtener nuevas
       credenciales de acceso, incluso si no han expirado por tiempo
   * - Limpieza del cliente
     - El estado de sesion del lado del cliente queda completamente limpio
       incluso si la revocacion en el servidor falla
   * - Registro
     - El evento de cierre queda registrado para auditoria de seguridad
   * - Idempotencia
     - Multiples solicitudes de cierre de sesion no generan errores

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Resultado garantizado para el usuario
     - Independientemente de lo que ocurra en el servidor, el usuario
       siempre queda en estado no autenticado desde su perspectiva
   * - Degradacion controlada
     - Si el repositorio de sesiones falla, el cierre procede del lado
       del cliente y las credenciales expiran por tiempo

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Acceso visible
     - La opcion de cerrar sesion debe ser claramente visible en la
       interfaz en todo momento cuando el usuario esta autenticado
   * - Confirmacion inmediata
     - El usuario recibe confirmacion visible de que la sesion fue cerrada
   * - Sin friccion
     - El cierre de sesion debe ser posible con un solo clic, sin
       confirmaciones adicionales innecesarias

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Credencial de renovacion
     - Texto
     - SI
     - La credencial de renovacion activa de la sesion del usuario.
       Es la que se revoca para invalidar la sesion.
       Se transmite de forma segura.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Confirmacion de cierre
     - Mensaje indicando que la sesion fue cerrada exitosamente
   * - Redireccion
     - El sistema redirige al usuario a la pagina publica

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Credencial invalida
     - 400
     - La credencial proporcionada no es valida.
       ``codigo_error = CREDENCIAL_INVALIDA``
   * - Error del sistema
     - 500
     - Error temporal al revocar. El cliente limpia su estado de igual forma.
       ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-009 (seguridad)
   * - **BR**
     - BR-013 (auditabilidad)
   * - **Depende de**
     - UC-AUTH-02
   * - **FR derivados**
     - Pendiente - Capa 3 (~4 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~8 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario autenticado cierra su sesion y queda como visitante anonimo, sin conocer como se invalida el token.

**Nivel Desarrollo:** Interfaz → Servicio de Autenticacion → Servicio de Sesion.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Boton de cerrar sesion. Redireccion a la pagina de inicio como visitante.
     - Invalidacion del token de sesion. Limpieza de datos de sesion en el cliente. Registro del evento en auditoria.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Comprador hereda de Visitante
- **Inverso de:** UC-AUTH-02 (login)
- **Este UC habilita:** el actor pasa al estado Visitante

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El comportamiento es uniforme. No aplica polimorfismo.

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-03: Cerrar Sesion — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-03: Cerrar Sesion

   participant AuthInterface
   participant AuthService
   participant SessionStore

   AuthInterface -> AuthService : solicita cerrar sesion
   AuthService -> SessionStore : invalida el token activo
   SessionStore --> AuthService : token invalidado
   AuthService -> AuthService : registra evento en auditoria
   AuthService --> AuthInterface : sesion cerrada, redirige a inicio
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-03: Cerrar Sesion — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      actor AuthUser
      usecase "UC-AUTH-03 Logout"
      usecase "UC-AUTH-02 Login"
      AuthUser --> "UC-AUTH-03 Logout"
      "UC-AUTH-03 Logout" ..> "UC-AUTH-02 Login" : inverso de (el usuario puede volver a entrar)
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Adaptado de UC_ACC_10 TiendaMax v2.0.1.
       Sin referencias tecnologicas.

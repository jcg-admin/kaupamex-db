.. meta::
   :artefacto: UC-ADM-03
   :tipo: Caso de Uso
   :subdominio: admin
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-adm-03:

=========================================
UC-ADM-03: Auditoría (Activity Log)
=========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-ADM-03
   * - **Nombre**
     - Auditoria — Activity Log
   * - **Modulo**
     - Django admin (``apps.users`` — modelo ``AccessAuditLog``)
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Actores**
     - Superadministrador
   * - **BReq**
     - BReq-010
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al superadministrador consultar el registro de auditoría del
sistema. El modelo ``AccessAuditLog`` captura eventos de autenticacion,
cambios de contrasena, modificaciones criticas de configuracion y
acciones admin importantes.

1.3 Alcance
-----------

**Incluido:** consulta del historial de eventos de ``AccessAuditLog``
con filtros por usuario, tipo de evento, resultado y rango de fechas.
**Excluido:** los eventos se generan automaticamente por los respectivos UCs;
este UC solo los consulta.

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actores
-----------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Actor
     - Rol
   * - Superadministrador
     - Actor primario. Solo ``is_superuser = True`` puede leer el log completo.

2.2 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El actor tiene ``User.is_superuser = True``

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Superadmin
     - Accede al panel de auditoria
   * - 2
     - Sistema
     - Recupera todos los ``AccessAuditLog`` ordenados por
       ``-AccessAuditLog.timestamp``, paginados a 50 por pagina
   * - 3
     - Superadmin
     - Aplica filtros: usuario, tipo de evento
       (``LOGIN``, ``LOGOUT``, ``CAMBIO_CONTRASENA``, etc.),
       resultado (``EXITOSO``, ``FALLIDO``), rango de fechas
   * - 4
     - Sistema
     - Presenta los registros con: timestamp, usuario, tipo de evento,
       resultado, IP del cliente y metadata (si aplica)
   * - 5
     - Superadmin
     - Puede exportar el log filtrado a CSV para analisis externo

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Filtrar por usuario especifico
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, el superadmin filtra por un ``User``
especifico.

- A1: El sistema muestra solo los eventos de ese usuario.
- A2: Util para investigar actividad sospechosa de una cuenta.

4.2 Alternativa B: Exportar log a CSV
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 5, el superadmin solicita exportar.

- B1: El CSV incluye todos los campos del ``AccessAuditLog`` del periodo filtrado.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Sin permiso de superadmin
     - Un admin sin ``is_superuser`` intenta acceder. El sistema
       retorna HTTP 403.
   * - EX-02
     - Log sin registros en el periodo
     - No existen ``AccessAuditLog`` para los filtros aplicados.
       El sistema muestra el estado de lista vacia.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Carga del log paginado (P95)
     - Menor a 500ms (50 registros por pagina con indices)
   * - Exportacion CSV del log filtrado
     - Menor a 10s para hasta 50.000 registros de auditoria

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Verificacion de is_superuser
     - Se verifica en cada peticion — el log de auditoria es el
       artefacto mas sensible del sistema
   * - Solo lectura
     - El log de auditoria es inmutable. Este UC nunca escribe,
       modifica ni elimina registros de AccessAuditLog
   * - Leer el log no genera entrada en el log
     - La consulta de auditoria no se registra a si misma


----

PARTE 7: Datos Involucrados
============================

7.1 Entrada
-----------

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Filtro usuario
     - Entero (PK) o texto
     - NO
     - ``User.pk`` o email del usuario a filtrar. Sin filtro = todos.
   * - Filtro tipo de evento
     - Texto (choices)
     - NO
     - LOGIN, LOGOUT, CAMBIO_CONTRASENA, MODIFICACION_PERMISOS, etc.
       Sin filtro = todos los tipos.
   * - Filtro resultado
     - Texto (choices)
     - NO
     - EXITOSO o FALLIDO. Sin filtro = ambos.
   * - Fecha desde
     - Fecha (ISO 8601)
     - NO
     - Inicio del rango de fechas. Sin filtro = sin límite inferior.
   * - Fecha hasta
     - Fecha (ISO 8601)
     - NO
     - Fin del rango de fechas. Sin filtro = hasta hoy.
   * - Pagina
     - Entero
     - NO
     - Pagina del listado. Default: 1. 50 registros por pagina.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Listado de eventos
     - Lista paginada de ``AccessAuditLog`` ordenada por
       ``-timestamp``. Por registro: timestamp, usuario (email),
       tipo de evento, resultado (EXITOSO/FALLIDO), IP del cliente
       y metadata adicional si existe.
   * - Metadatos de paginacion
     - Total de registros encontrados, pagina actual, total de paginas.

7.3 Salida (Casos de error)
-----------------------------

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Sin permiso de superadmin
     - HTTP 403
     - ``is_superuser = False``. No se devuelven datos.
   * - Sin registros para los filtros
     - HTTP 200
     - Lista vacía. No es un error — es el resultado esperado.

----

Diagrama de Secuencia
-----------------------

.. uml::
   :caption: UC-ADM-03 — Auditoria (Activity Log)

   @startuml
   !include ../../../_static/plantuml-styles.puml

   actor Superadmin
   participant AuditInterface
   participant AuditLogRepository

   Superadmin -> AuditInterface : accede al panel de auditoria
   AuditInterface -> AuditLogRepository : AccessAuditLog.order_by(-timestamp).paginate(50)
   AuditLogRepository --> AuditInterface : Page[AccessAuditLog]
   AuditInterface --> Superadmin : listado con timestamp, usuario, evento, resultado, IP

   alt aplica filtros
     Superadmin -> AuditInterface : filtra (usuario, tipo_evento, resultado, fechas)
     AuditInterface -> AuditLogRepository : AccessAuditLog.filter(criterios)
     AuditLogRepository --> AuditInterface : Page[AccessAuditLog] filtrada
     AuditInterface --> Superadmin : listado filtrado
   end

   alt exportar a CSV
     Superadmin -> AuditInterface : solicita CSV del periodo filtrado
     AuditInterface -> AuditLogRepository : AccessAuditLog.filter(criterios).values()
     AuditLogRepository --> AuditInterface : queryset completo
     AuditInterface --> Superadmin : archivo CSV descargado
   end
   @enduml

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El superadmin lee eventos del sistema filtrados
por usuario, tipo y fecha, sin conocer la estructura interna de
``AccessAuditLog`` ni cómo se generan los eventos.

**Nivel Desarrollo:** Panel Admin → ``AccessAuditLog.filter()``
(solo lectura) → tabla ``users_accessauditlog`` en MySQL.
Los eventos son escritos por los UCs que los generan (AUTH, ADM-02,
ADM-04) — este UC solo los consume.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 45 55
   :header-rows: 1

   * - Interfaz publica (visible al superadmin)
     - Logica privada (invisible al superadmin)
   * - Filtros por usuario, tipo de evento y fecha.
       Listado con timestamp, evento y resultado.
       Boton de exportacion a CSV.
     - Construccion dinamica de filtros AND.
       Paginacion de la consulta.
       Verificacion de is_superuser en cada peticion.
       Generacion del CSV por streaming para grandes volumenes.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Superadministrador. Es el UC de mayor
  restriccion de acceso en el sistema (requiere ``is_superuser``).
- **Este UC es de solo lectura:** No genera ningun evento en
  ``AccessAuditLog`` — leer el log no se registra en el log.

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El resultado varia segun los filtros aplicados:

- **Sin filtros** → todos los eventos del sistema ordenados por fecha
- **Filtro por usuario** → historial completo de una cuenta especifica
- **Filtro FALLIDO** → eventos fallidos para detectar ataques o errores
- **Exportar CSV** → el mismo resultado en formato descargable


Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-05
     - Version inicial. UC especificado desde cero.

.. meta::
   :artefacto: UC-ADM-05
   :tipo: Caso de Uso
   :subdominio: admin
   :estado: Especificado
   :version: 1.0.0
   :fecha_creacion: 2026-05-05

.. _uc-adm-05:

=========================================
UC-ADM-05: Backup Automático
=========================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-ADM-05
   * - **Nombre**
     - Backup Automatico del Sistema
   * - **Modulo**
     - Infra / cron (fuera de Django — proceso del servidor)
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Actores**
     - Sistema (cron), Superadministrador (monitoreo)
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Garantizar la disponibilidad de copias de seguridad recientes de la
base de datos MySQL y de los archivos de media (imagenes de productos,
avatars) mediante un proceso automatico programado por cron.

El proceso usa ``mysqldump`` para la BD y ``rsync`` o ``tar`` para
los archivos de media, y sube los backups a AWS S3.

1.3 Alcance
-----------

**Incluido:** dump de MySQL, compresion, subida a S3, verificacion
de integridad por MD5, notificacion al admin si el backup falla.
**Excluido:** restauracion del backup (procedimiento manual de devops).

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actores
-----------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Actor
     - Rol
   * - Sistema (cron)
     - Actor primario. Se ejecuta automaticamente segun schedule.
   * - Superadministrador
     - Actor secundario. Recibe notificacion si el backup falla.

2.2 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El cron esta configurado en el servidor (CNST-ARQ-001 T6)
   * - PRE-02
     - Las credenciales de AWS S3 estan configuradas en el servidor

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Sistema (cron)
     - Dispara el script de backup segun el schedule (diario a las 03:00 UTC)
   * - 2
     - Sistema
     - Ejecuta ``mysqldump`` sobre la base de datos de produccion.
       Comprime el dump con ``xz`` nivel 6.
   * - 3
     - Sistema
     - Calcula el MD5 del archivo comprimido para verificacion de integridad
   * - 4
     - Sistema
     - Sube el archivo a ``s3://practicayoruba-backups/db/YYYY-MM-DD/``
       usando ``aws s3 cp``
   * - 5
     - Sistema
     - Ejecuta el backup de media: comprime ``/var/www/media/``
       y sube a ``s3://practicayoruba-backups/media/YYYY-MM-DD/``
   * - 6
     - Sistema
     - Elimina backups locales temporales. Registra el resultado
       (exito/fallo) en el log del sistema.

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Fallo en la subida a S3
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 4 o 5, ``aws s3 cp`` retorna error.

- A1: El sistema reintenta 3 veces con backoff exponencial.
- A2: Si persiste el fallo, notifica al superadmin por email.
- A3: El archivo local se conserva hasta la proxima ejecucion exitosa.

4.2 Alternativa B: Backup manual bajo demanda
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** El superadmin necesita un backup inmediato antes de
una operacion critica.

- B1: El superadmin ejecuta el script manualmente desde el servidor.
- B2: El proceso es identico al automatico.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - mysqldump falla
     - El proceso registra el error en log y notifica al superadmin.
       No se genera archivo de backup para ese ciclo.
   * - EX-02
     - Espacio en disco insuficiente para el dump local
     - El proceso notifica al superadmin y aborta el ciclo.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Ciclo completo de backup (BD + media)
     - Menor a 30 minutos en condiciones normales de produccion
   * - Ventana de ejecucion
     - 03:00-03:30 UTC — fuera del horario de mayor trafico

6.2 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Verificacion de integridad
     - El MD5 del archivo generado se calcula y registra antes
       de considerarse el backup completo
   * - Reintento automatico
     - 3 reintentos con backoff exponencial ante fallo de subida a S3
   * - Notificacion de fallo
     - El superadmin recibe email si cualquier paso del ciclo falla

6.3 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Credenciales de AWS
     - Solo en variables de entorno del servidor — nunca en codigo
       ni en el repositorio (RNF-SEC-002)
   * - Archivos temporales locales
     - Se eliminan al finalizar el ciclo — no persisten en disco


----

PARTE 7: Datos Involucrados
============================

UC-ADM-05 es un proceso del sistema (cron) — no tiene formulario
de entrada interactivo. Los "datos de entrada" son la configuración
del entorno del servidor.

7.1 Entrada (Configuración del proceso)
----------------------------------------

.. list-table::
   :widths: 25 15 10 50
   :header-rows: 1

   * - Parametro
     - Tipo
     - Origen
     - Descripcion
   * - DATABASE_URL
     - Variable de entorno
     - Servidor
     - Cadena de conexion a MySQL para ``mysqldump``.
   * - AWS_ACCESS_KEY_ID / SECRET
     - Variables de entorno
     - Servidor
     - Credenciales de AWS S3 para ``aws s3 cp``.
   * - S3_BUCKET
     - Variable de entorno
     - Servidor
     - Nombre del bucket destino. Ejemplo: ``practicayoruba-backups``.
   * - MEDIA_DIR
     - Variable de entorno
     - Servidor
     - Ruta del directorio de media. Default: ``/var/www/media/``.

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Artefacto
     - Descripcion
   * - Archivo de BD en S3
     - ``s3://practicayoruba-backups/db/YYYY-MM-DD/dump.xz``
       con su MD5 registrado en el log del sistema.
   * - Archivo de media en S3
     - ``s3://practicayoruba-backups/media/YYYY-MM-DD/media.tar.xz``
   * - Entrada en log del sistema
     - Resultado (exito/fallo), timestamp, tamaño de archivos y MD5.

7.3 Salida (Casos de error)
-----------------------------

.. list-table::
   :widths: 35 12 53
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - mysqldump falla
     - Exit code != 0
     - Entrada en log + email al superadmin. No se genera archivo.
   * - Espacio en disco insuficiente
     - Exit code != 0
     - Entrada en log + email al superadmin. Proceso abortado.
   * - aws s3 cp falla tras 3 reintentos
     - Exit code != 0
     - Archivo local conservado. Email al superadmin.

----

Diagrama de Secuencia
-----------------------

.. uml::
   :caption: UC-ADM-05 — Backup Automatico (proceso cron)

   @startuml
   !include ../../../_static/plantuml-styles.puml

   participant CronScheduler
   participant BackupScript
   participant MariaDB
   participant "AWS S3"                   as S3
   participant SystemLog

   CronScheduler -> BackupScript : dispara script segun schedule diario
   BackupScript -> MariaDB : mysqldump produccion
   MariaDB --> BackupScript : dump.sql
   BackupScript -> BackupScript : comprimir con xz nivel 6
   BackupScript -> BackupScript : calcular MD5 del .xz
   BackupScript -> S3 : aws s3 cp dump.xz s3://practicayoruba-backups/db/YYYY-MM-DD/
   S3 --> BackupScript : OK
   BackupScript -> S3 : aws s3 cp media.tar.xz s3://practicayoruba-backups/media/YYYY-MM-DD/
   S3 --> BackupScript : OK
   BackupScript -> BackupScript : eliminar archivos locales temporales
   BackupScript -> SystemLog : registrar resultado (exito, timestamp, tamano, MD5)
   @enduml

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario (Superadmin):** Recibe una notificacion por email si
el backup falla. En caso de exito, puede verificar los archivos en
S3 con el MD5 del log.

**Nivel Desarrollo:** Cron → script bash → ``mysqldump`` + ``xz`` +
``md5sum`` → ``aws s3 cp`` → log del sistema. El proceso es
completamente autonomo y no requiere interaccion humana en el happy path.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 45 55
   :header-rows: 1

   * - Interfaz publica (visible al superadmin)
     - Logica privada (invisible al superadmin)
   * - Notificacion de fallo por email.
       Log de resultado (exito/fallo, MD5, tamano).
       Archivo en S3 verificable por checksum.
     - Configuracion del cron en el servidor.
       Credenciales de AWS S3 en variables de entorno.
       Algoritmo de compresion xz nivel 6.
       Logica de reintento con backoff exponencial.
       Seleccion de directorios de media a incluir.

8.3 Herencia
^^^^^^^^^^^^

- **Actor primario es el Sistema (cron):** No hay actor humano en
  el flujo principal. El superadmin solo aparece como receptor
  de notificaciones de fallo.
- **Este UC es independiente de Django:** El proceso usa herramientas
  del sistema operativo (mysqldump, aws cli) y no pasa por el
  framework de la aplicacion.

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El resultado varia segun el estado del proceso:

- **Exito completo** → ambos backups (BD + media) subidos a S3
  con MD5 registrado
- **Fallo en mysqldump** → ningún archivo generado; notificacion al admin
- **Fallo en S3 con reintento** → 3 reintentos con backoff exponencial;
  si persiste, notificacion y archivo local conservado
- **Ejecucion manual** → identico al automatico (Alt. B)


Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-05
     - Version inicial. UC especificado desde cero.

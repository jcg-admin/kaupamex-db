.. meta::
   :artefacto: UC-AUTH-05
   :tipo: Caso de Uso
   :subdominio: auth
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-auth-05:

=====================================
UC-AUTH-05: Ver Perfil de Usuario
=====================================

PARTE 1: Informacion General
==============================

1.1 Identificacion
------------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-AUTH-05
   * - **Nombre**
     - Ver Perfil de Usuario
   * - **Modulo**
     - ACCOUNTS
   * - **Criticidad**
     - ALTO
   * - **Complejidad**
     - BAJA
   * - **Depende de**
     - UC-AUTH-02
   * - **BReq**
     - BReq-001
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
-------------

Permitir al usuario autenticado consultar la informacion de su cuenta:
datos personales, email, historial de actividad reciente y acceso
a otras funciones de gestion de cuenta.

1.3 Alcance
-----------

**Incluido en este UC:**

- Visualizacion de nombre, apellido, email y avatar
- Acceso a las opciones de gestion de cuenta
- Indicador del estado de verificacion del email

**Excluido de este UC:**

- Editar los datos del perfil — UC-AUTH-06
- Gestionar direcciones — UC-AUTH-07
- Cambiar contrasena — UC-AUTH-08
- Ver historial de ordenes — UC-ORD-05

----

PARTE 2: Actores y Precondiciones
===================================

2.1 Actor Principal
-------------------

**Usuario Autenticado**

Persona con sesion activa que desea revisar su informacion de cuenta.

2.2 Actores Secundarios
-----------------------

**Sistema de Cuentas**

Recupera y presenta la informacion del perfil del usuario autenticado.

2.3 Precondiciones
------------------

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El usuario esta autenticado (UC-AUTH-02 completado)

2.4 Postcondiciones
-------------------

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - El usuario ve su informacion de perfil actualizada
   * - POST-02
     - El porcentaje de completitud del perfil queda calculado y visible

----

PARTE 3: Flujo Principal (Happy Path)
=======================================

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Usuario
     - Accede a la seccion de perfil desde el menu de usuario
   * - 2
     - Sistema
     - Verifica que el JWT de la solicitud es valido y que
       ``User.is_active = True`` para la cuenta asociada
   * - 3
     - Sistema
     - Recupera el registro ``User`` completo del repositorio:
       ``User.first_name``, ``User.last_name``, ``User.email``,
       ``User.email_verified_at``, ``User.avatar``,
       ``User.date_joined``, ``User.last_login``,
       y el conteo de ``Address`` asociadas al usuario
   * - 4
     - Sistema
     - Presenta el perfil: nombre completo, email, avatar (si tiene),
       estado de verificacion del email, fecha de registro,
       y accesos rapidos a editar perfil, gestionar direcciones,
       cambiar contrasena, ver ordenes

   * - 5
     - Sistema
     - Calcula ``profile_completeness`` evaluando los cinco campos
       opcionales (``User.first_name``, ``User.last_name``,
       ``User.phone``, ``User.avatar``, y existencia de al menos
       una ``Address``) con peso 20% cada uno, y determina
       ``pending_fields`` con los campos aun sin completar

----

PARTE 4: Rutas Alternativas
=============================

4.1 Alternativa A: Email no verificado
---------------------------------------

**Activador:** En el paso 4, el email del usuario no esta verificado.

- A1: Se muestra un aviso visible de que el email no esta verificado
- A2: Se ofrece la opcion de reenviar el email de verificacion (UC-AUTH-10)

**Retorno:** Paso 4 con aviso de verificacion pendiente.


4.2 Alternativa B: Usuario sin avatar configurado
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Activador:** En el paso 3, ``User.avatar`` no tiene valor (campo vacio o nulo).

- B1: El sistema muestra el avatar por defecto del sistema
- B2: Se presenta claramente la opcion de subir un avatar propio
- B3: El resto del perfil se muestra normalmente

4.3 Alternativa C: Perfil con datos incompletos
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** En el paso 5, ``pending_fields`` contiene al menos un campo — es decir, ``profile_completeness`` es inferior a 100.

- C1: El perfil se muestra con los campos completados.
- C2: Se presenta un indicador de completitud con sugerencia de llenar los campos en ``pending_fields``.
- C3: El porcentaje ``profile_completeness`` visible incentiva al comprador a completar su perfil.

----

PARTE 5: Excepciones del Sistema
==================================

5.1 Excepciones del Sistema
----------------------------

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Sin autenticacion
     - El usuario no tiene sesion activa.
       El sistema redirige al inicio de sesion (UC-AUTH-02).
   * - EX-02
     - Error al recuperar perfil
     - ``UserRepository`` no responde o retorna error en el paso 3.
       La cuenta del usuario no se modifica. El sistema retorna
       HTTP 503 con ``codigo_error = ERROR_SISTEMA`` e indica
       al usuario que intente de nuevo en unos momentos.

----

PARTE 6: Requisitos No Funcionales
=====================================

6.1 Performance
---------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Carga del perfil (P95)
     - Menor a 300ms

6.2 Seguridad
-------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autenticacion obligatoria
     - Solo el propio usuario puede ver su perfil
   * - Sin datos sensibles en la vista
     - La contrasena nunca se muestra, ni siquiera de forma enmascarada

6.3 Confiabilidad
-----------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Datos actualizados
     - La informacion mostrada corresponde al estado actual de la cuenta

6.4 Usabilidad
--------------

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Accesos rapidos
     - Las opciones de gestion de cuenta son claramente accesibles desde el perfil
   * - Avatar visible
     - Si el usuario tiene avatar, se muestra prominentemente

----

PARTE 7: Datos Involucrados
==============================

7.1 Entrada
-----------

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - Sesion activa
     - Sistema
     - Automatico
     - Identifica al usuario autenticado

7.2 Salida (Caso exitoso)
--------------------------

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - Datos del perfil
     - Nombre, apellido, email, estado de verificacion, fecha de registro,
       referencia al avatar, fecha del ultimo acceso

7.3 Salida (Casos de error)
----------------------------

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - No autenticado
     - 401
     - ``codigo_error = AUTENTICACION_REQUERIDA``
   * - Error del sistema
     - 500
     - ``codigo_error = ERROR_SISTEMA``

----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-001
   * - **BR**
     - BR-013
   * - **Depende de**
     - UC-AUTH-02
   * - **Habilita**
     - UC-AUTH-06, UC-AUTH-07, UC-AUTH-08
   * - **FR derivados**
     - Pendiente - Capa 3 (~3 FR estimados)
   * - **Tests**
     - Pendiente - Capa 5 (~6 tests TDD)


----

PARTE 8: Analisis OOP
----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El usuario autenticado consulta sus datos de cuenta sin conocer como se recuperan ni como se presentan.

**Nivel Desarrollo:** Interfaz de Perfil → Servicio de Autenticacion → Repositorio de Usuarios.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Datos del perfil: nombre, email, fecha de registro, avatar. Lista de opciones de gestion.
     - Consulta al repositorio de usuarios. Generacion de URL del avatar. Calculo de datos derivados (ordenes realizadas).

8.3 Herencia
^^^^^^^^^^^^

- **Actor:** Comprador autenticado
- **Este UC habilita:** UC-AUTH-06 (editar), UC-AUTH-07 (direcciones), UC-AUTH-08 (contrasena)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

El comportamiento es uniforme. No aplica polimorfismo.

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-05: Ver Perfil — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-AUTH-05: Ver Perfil

   participant ProfileInterface
   participant AuthService
   participant UserRepository

   ProfileInterface -> AuthService : solicita datos del perfil
   AuthService -> UserRepository : recupera User con avatar, email_verified_at y Address count
   UserRepository --> AuthService : registro User completo
   AuthService --> ProfileInterface  : perfil con nombre, email, avatar, opciones de gestion
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-AUTH-05: Ver Perfil — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

      actor AuthUser
      usecase "UC-AUTH-05 Ver Perfil"
      usecase "UC-AUTH-06 Editar Perfil"
      usecase "UC-AUTH-07 Direcciones"
      usecase "UC-AUTH-08 Contrasena"
      AuthUser --> "UC-AUTH-05 Ver Perfil"
      "UC-AUTH-05 Ver Perfil" ..> "UC-AUTH-06 Editar Perfil" : habilita
      "UC-AUTH-05 Ver Perfil" ..> "UC-AUTH-07 Direcciones"  : habilita
      "UC-AUTH-05 Ver Perfil" ..> "UC-AUTH-08 Contrasena"  : habilita
   @enduml

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version completa. Sin referencias tecnologicas.
   * - 2.1.0
     - 2026-05-05
     - Pasos 2, 3 y 5 reescritos con entidades reales (User, JWT,
       profile_completeness, pending_fields, Address).
       Alt B y C: activadores referenciados a pasos concretos.
       EX-02: UserRepository + HTTP 503 especificados.
       Diagrama: AccountsService y UserRepository (nombres reales).

.. meta::
   :artefacto: UC-CFG-05
   :tipo: Caso de Uso
   :subdominio: settings
   :estado: Especificado
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _uc-cfg-05:

================================================
UC-CFG-05: Gestionar Datos de Contacto (Admin)
================================================

PARTE 1: Informacion General
------------------------------

1.1 Identificacion
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **ID UC**
     - UC-CFG-05
   * - **Nombre**
     - Gestionar Datos de Contacto (Admin)
   * - **Modulo**
     - SETTINGS
   * - **BReq**
     - BReq-015
   * - **BR aplicadas**
     - BR-013

1.2 Proposito
^^^^^^^^^^^^^

Permitir al administrador actualizar los datos de contacto del negocio: email, telefono, direccion y redes sociales.

1.3 Alcance
^^^^^^^^^^^

**Incluido en este UC:**

- Actualizacion de email, telefono, direccion y redes sociales del negocio
- Los cambios son visibles inmediatamente en el footer y la pagina de contacto

**Excluido de este UC:**

- Contenido de paginas estaticas — UC-CFG-04
- Configuracion general del sistema — UC-CFG-03

----

PARTE 2: Actores y Precondiciones
-----------------------------------

2.1 Actor Principal
^^^^^^^^^^^^^^^^^^^

**Administrador**

2.2 Actores Secundarios
^^^^^^^^^^^^^^^^^^^^^^^

**Sistema de Catalogo / Configuracion** segun el UC.

2.3 Precondiciones
^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Precondicion
   * - PRE-01
     - El admin tiene permisos de configuracion

2.4 Postcondiciones
^^^^^^^^^^^^^^^^^^^

**Caso exitoso:**

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Postcondicion
   * - POST-01
     - Los datos de contacto actualizados son visibles en el sitio
   * - POST-02
     - Los datos actualizados son visibles de inmediato en el footer y la pagina de contacto

----

PARTE 3: Flujo Principal (Happy Path)
---------------------------------------

.. list-table::
   :widths: 5 15 80
   :header-rows: 1

   * - Paso
     - Actor
     - Descripcion
   * - 1
     - Admin
     - Accede a la gestion de datos de contacto
   * - 2
     - Sistema
     - Recupera los valores actuales de ``SiteSettings``
   * - 3
     - Admin
     - Actualiza los campos deseados
   * - 4
     - Sistema
     - Valida los campos y persiste los cambios en ``SiteSettings``,
       registra el administrador responsable en auditoria
   * - 5
     - Sistema
     - Los cambios en ``SiteSettings`` son visibles de forma inmediata
       en las respuestas del sistema

----

PARTE 4: Rutas Alternativas
-----------------------------

4.1 Alternativa A: Agregar nueva red social
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Descripcion:**

- A1: El admin agrega la URL de la nueva plataforma.

4.2 Alternativa B: Eliminar un canal de contacto
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

**Descripcion:**

- B1: El admin elimina el campo. Desaparece del sitio.

4.3 Alternativa C: Agregar nueva plataforma de red social no listada
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

**Activador:** El negocio crea presencia en una plataforma nueva que el sistema no tiene preconfigurada.

- C1: El admin puede agregar una red social personalizada con nombre e icono.
- C2: El sistema la agrega al footer y pagina de contacto con el icono generico o el cargado por el admin.

----

PARTE 5: Excepciones del Sistema
----------------------------------

5.1 Excepciones del Sistema
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 15 20 65
   :header-rows: 1

   * - ID
     - Nombre
     - Descripcion y respuesta
   * - EX-01
     - Error del sistema
     - Se informa al actor de error temporal.

   * - EX-02
     - URL de red social que no responde
     - La URL ingresada no es accesible. El sistema advierte que la URL no respondio pero permite guardarla si el admin confirma (puede ser un problema temporal).
----

PARTE 6: Requisitos No Funcionales
-------------------------------------

6.1 Performance
^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Metrica
     - Objetivo
   * - Tiempo de respuesta (P95)
     - Menor a 400ms

6.2 Seguridad
^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Autorizacion
     - Solo administradores con permiso de configuracion pueden modificar

6.3 Confiabilidad
^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Consistencia
     - Los datos de contacto publicados son identicos a los guardados en la configuracion

6.4 Usabilidad
^^^^^^^^^^^^^^

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Claridad
     - El actor ve la informacion necesaria para tomar decisiones

----

PARTE 7: Datos Involucrados
-----------------------------

7.1 Entrada
^^^^^^^^^^^

.. list-table::
   :widths: 20 15 15 50
   :header-rows: 1

   * - Campo
     - Tipo
     - Requerido
     - Descripcion
   * - email
     - Email
     - NO
     - Email de contacto del negocio
   * - telefono
     - Texto
     - NO
     - Numero de telefono con codigo de pais
   * - direccion
     - Texto
     - NO
     - Direccion fisica del negocio
   * - redes_sociales
     - Objeto JSON
     - NO
     - Mapa de plataforma a URL: {instagram: url, facebook: url, ...}

7.2 Salida (Caso exitoso)
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Dato
     - Descripcion
   * - datos_actualizados
     - Objeto con los datos de contacto persistidos
   * - timestamp
     - Fecha y hora del cambio

7.3 Salida (Casos de error)
^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 30 12 58
   :header-rows: 1

   * - Escenario
     - Codigo
     - Descripcion
   * - Email invalido
     - 422
     - ``codigo_error = EMAIL_INVALIDO``
   * - URL de red social invalida
     - 422
     - ``codigo_error = URL_INVALIDA``
   * - Sin autorizacion
     - 403
     - ``codigo_error = SIN_AUTORIZACION``
----

Trazabilidad
=============

.. list-table::
   :widths: 25 75
   :header-rows: 0

   * - **BReq**
     - BReq-015
   * - **Depende de**
     - UC-CFG-03
   * - **Habilita**
     - —
   * - **FR derivados**
     - Pendiente - Capa 3
   * - **Tests**
     - Pendiente - Capa 5 (TDD)

Historial
=========

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambios
   * - 2.0.0
     - 2026-04-30
     - Version inicial.
   * - 2.1.0
     - 2026-05-05
     - Pasos con entidades reales. Activadores referenciados.

----

PARTE 8: Analisis OOP
-----------------------

.. seealso::

   Estandar: :doc:`/normativa/estandares/metodologia/metodologia-oop-uc`

8.1 Abstraccion
^^^^^^^^^^^^^^^

**Nivel Usuario:** El admin actualiza los datos sin conocer donde se usan en el sitio.

**Nivel Desarrollo:** Interfaz → Servicio → Repositorio.

8.2 Encapsulamiento
^^^^^^^^^^^^^^^^^^^

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Interfaz publica (visible para el actor)
     - Logica privada (invisible para el actor)
   * - Lo que el actor ve y hace directamente.
     - Las validaciones, consultas y actualizaciones internas del sistema.

8.3 Herencia
^^^^^^^^^^^^

- **Actor hereda de:** Visitante
- **Complemento de:** UC-CFG-04 (contenido estatico)

8.4 Polimorfismo
^^^^^^^^^^^^^^^^

Ver PARTE 4 para variaciones de comportamiento.

8.5 Envio de mensajes
^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-05 — Envio de mensajes

   @startuml
   !include ../../../_static/plantuml-styles.puml

   title UC-CFG-05

   participant AdminPanel
   participant ConfigService
   participant Repositorio

   AdminPanel -> ConfigService  : envia datos de contacto actualizados
   ConfigService -> ConfigService  : valida formatos (email, URL)
   ConfigService -> Repositorio : persiste los datos
   ConfigService --> AdminPanel  : datos visibles en el sitio
   @enduml

8.6 Asociaciones formales
^^^^^^^^^^^^^^^^^^^^^^^^^^

.. uml::
   :caption: UC-CFG-05 — Asociaciones

   @startuml
   !include ../../../_static/plantuml-styles.puml

   left to right direction

   actor Administrador
   usecase "UC-CFG-05 Datos de Contacto"
   usecase "UC-CFG-04 Contenido Estatico"
   Administrador --> "UC-CFG-05 Datos de Contacto"
   "UC-CFG-04 Contenido Estatico" ..> "UC-CFG-05 Datos de Contacto" : complementario
   @enduml

.. meta::
   :artefacto: INDEX_METODOLOGIA
   :tipo: Indice
   :dominio: requisitos
   :subdominio: metodologia
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :autor: Equipo PracticaYoruba

===========================================================
Metodologia aplicada — como documentar requisitos
===========================================================

Sub-seccion con el **plan operativo** y los **ejemplos aplicados
al dominio PracticaYoruba** que guian la generacion de los
artefactos de requisitos (BReq, BR, UC, FR).

Marco aplicado
==============

**Requirements Management** (ISO 29148 / IEEE) — las cinco
fases del ciclo RM: elicitacion, analisis, especificacion,
validacion y gestion.

Convencion de codigo
====================

Clases, funciones y atributos en **ingles**.
Comentarios, docstrings y texto narrativo en **español**.

.. code-block:: python

   class OrderService:
       def create_order(self, cart, user):
           # Crear la orden a partir del carrito de sesion
           order = Order.objects.create(user=user)
           return order

.. toctree::
   :maxdepth: 1
   :caption: Plan operativo

   plan-documentacion-uc

.. toctree::
   :maxdepth: 1
   :caption: Analisis y modelado

   orientacion-objetos

.. toctree::
   :maxdepth: 1
   :caption: UML — relaciones y estructura

   relaciones-uml
   agregacion-interfaces

.. toctree::
   :maxdepth: 1
   :caption: UML — casos de uso

   casos-uso-especificacion
   casos-uso-diagramas

.. toctree::
   :maxdepth: 1
   :caption: UML — comportamiento

   diagramas-estados
   diagramas-actividades

.. toctree::
   :maxdepth: 1
   :caption: UML — arquitectura

   diagramas-componentes
   diagramas-distribucion

.. toctree::
   :maxdepth: 1
   :caption: Patrones de diseno


.. note::

   ``analisis-dominio``, ``diagramas-secuencias`` y
   ``patrones-diseno`` son Fase B — sus ejemplos se reescriben
   con el dominio real de PracticaYoruba (ecommerce Yoruba,
   login/checkout/webhook, Strategy para pagos).

.. meta::
   :artefacto: BR-005
   :tipo: Regla de Negocio
   :subtipo: Restriccion (Constraint)
   :modalidad: Prohibicion (Prohibition)
   :estado: Vigente
   :version: 2.0.0
   :fecha_creacion: 2026-04-30

.. _br_005:

=======================================
BR-005: Snapshots inmutables en ordenes
=======================================

Enunciado
---------

``OrderItem``, ``OrderAddress`` y ``OrderValue`` son copias inmutables
de los datos al momento exacto del checkout. Si el precio, el nombre,
el SKU o la direccion cambian despues de confirmada la orden, la orden
existente **no cambia**.

Clasificacion
-------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **Tipo**
     - Restriccion (Constraint)
   * - **Modalidad**
     - Prohibicion — el sistema NO PUEDE modificar los datos
       de la orden despues del checkout
   * - **Estatica**
     - Si — no depende de valores configurables
   * - **Fuente**
     - BReq-004 (checkout), BReq-010 (auditoria)

La modalidad Prohibition es la senal definitiva: el enunciado declara
explicitamente lo que el sistema **NO puede hacer**. Actua como
precondicion en todos los UCs que manipulan ordenes existentes.

Justificacion
-------------

Garantiza la integridad historica. Un comprador siempre puede verificar
exactamente lo que pago, al precio que lo pago, con la direccion que
uso al momento de la compra. La auditoria requiere reproducibilidad
exacta del estado al momento de la transaccion.

Impacto en el sistema
---------------------

- **Modulos afectados:** ORDER (OrderItem, OrderAddress, OrderValue)
- **UCs que la aplican:** UC-ORD-02, UC-ORD-04, UC-ORD-05

Implementacion tecnica
----------------------

Los campos de snapshot no son FKs dinamicas al catalogo — son copias
del valor exacto al momento de la orden:

.. code-block:: python

   # apps/orders/models.py
   class OrderItem(BaseModel):
       """
       Snapshot inmutable del producto al momento del checkout.
       BR-005: los campos no son FK dinamicas al catalogo.
       """
       order            = models.ForeignKey(Order, on_delete=models.CASCADE)
       product_id       = models.PositiveIntegerField()   # referencia historica
       name_at_moment   = models.CharField(max_length=255)  # snapshot
       sku_at_moment    = models.CharField(max_length=100)   # snapshot
       price_at_moment  = models.DecimalField(max_digits=10, decimal_places=2)
       quantity         = models.PositiveIntegerField()

Verificacion
------------

- ``OrderItem.price_at_moment`` se llena al crear la orden, no es FK a
  ``Product.price``.
- ``OrderAddress`` copia los campos del perfil — no referencia al perfil.
- Los tests de ``UC-ORD-02`` verifican que cambiar ``Product.price``
  despues de la orden no altera ``OrderItem.price_at_moment``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-ORD-01.02 (crear OrderItem con snapshot de precio, nombre y SKU)
- FR-ORD-02.01 (retornar precios del snapshot, no del catalogo)
- FR-ORD-04.02 (restaurar stock usa cantidades del snapshot)

**RNFs relacionados:**

- :ref:`rnf-proc-002`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.
   * - 2.0.0
     - 2026-05-14
     - Agregada clasificacion formal de tipo (Restriccion/Prohibition),
       implementacion tecnica y referencia a uso como ejemplo pedagogico
       en FND-02 seccion 3.2.

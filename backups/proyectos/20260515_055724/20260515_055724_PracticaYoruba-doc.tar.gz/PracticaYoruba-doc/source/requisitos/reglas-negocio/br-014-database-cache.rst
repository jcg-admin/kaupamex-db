.. meta::
   :artefacto: BR-014
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_014:

===================================
BR-014: DatabaseCache en produccion
===================================

Enunciado
---------

El backend de cache en produccion **debe** ser ``DatabaseCache`` (tabla el repositorio). ``LocMemCache`` esta prohibido en produccion con Apache + mod_wsgi multiproceso.

Justificacion
-------------

Con mod_wsgi cada proceso worker tiene su propio espacio de memoria. ``LocMemCache`` no se comparte entre workers, haciendo el throttling inconsistente. ``DatabaseCache`` es compartido porque usa el repositorio.

Impacto en el sistema
---------------------

- **Modulos afectados:** Todos los modulos que usen cache
- **UCs que la aplican:** —

Verificacion
------------

``settings.py`` debe tener ``CACHES`` con ``DatabaseCache``. La tabla ``cache_table`` se crea con ``manage.py createcachetable``. ``LocMemCache`` solo en ``config.settings.testing``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CAT-01.01 (categorias cacheadas via DatabaseCache)
- FR-AUTH-02.01 (contador de intentos fallidos en cache)

**RNFs relacionados:**

- RNF-PERF-001 (DatabaseCache mejora latencia en lectura)
- RNF-SEC-004 (rate limiting implementado sobre DatabaseCache)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

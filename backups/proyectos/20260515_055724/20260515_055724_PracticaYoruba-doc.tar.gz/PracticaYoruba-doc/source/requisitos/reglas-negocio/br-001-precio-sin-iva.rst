.. meta::
   :artefacto: BR-001
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_001:

=========================================
BR-001: Precio de catalogo no incluye IVA
=========================================

Enunciado
---------

El precio mostrado en el catalogo de productos **no incluye IVA**. El impuesto se calcula y muestra unicamente en el checkout.

Justificacion
-------------

Separa el precio base del impuesto. ``PricingService`` es la unica fuente de verdad del precio final. El ``tax_rate`` es configurable en ``SiteSettings`` sin tocar los precios del catalogo.

Impacto en el sistema
---------------------

- **Modulos afectados:** CATALOGUE, ORDER (PricingService)
- **UCs que la aplican:** UC-CAT-01, UC-CAT-02, UC-ORD-01

Verificacion
------------

``Product.price`` almacena precio antes de impuesto. ``PricingService`` aplica ``SiteSettings.tax_rate``. ``OrderValue.taxes`` guarda el IVA en el snapshot.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CAT-01.01 (precio con IVA calculado en listado)
- FR-CAT-02.01 (precio con IVA en ficha del producto)
- FR-ORD-01.02 (snapshot de precio sin IVA en OrderItem)

**RNFs relacionados:**

- :ref:`rnf-usab-001`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

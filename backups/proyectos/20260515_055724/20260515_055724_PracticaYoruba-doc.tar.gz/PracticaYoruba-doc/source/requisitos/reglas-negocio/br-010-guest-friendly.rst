.. meta::
   :artefacto: BR-010
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_010:

=========================================================
BR-010: CONTACT, QUESTION y NEWSLETTER son guest-friendly
=========================================================

Enunciado
---------

Los modulos CONTACT, QUESTION y NEWSLETTER no requieren autenticacion JWT. Un visitante anonimo puede preguntar, contactar y suscribirse.

Justificacion
-------------

Reduce la friccion para que un cliente potencial se comunique antes de decidir si se registra.

Impacto en el sistema
---------------------

- **Modulos afectados:** CONTACT, QUESTION, NEWSLETTER
- **UCs que la aplican:** UC-COM-01, UC-COM-02, UC-COM-03

Verificacion
------------

Los endpoints de estos modulos tienen ``permission_classes = [AllowAny]``. No hay FK obligatorio a ``User`` en ninguno de los tres modelos.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CART-01.02 (agregar al carrito sin autenticacion)
- FR-AUTH-01.04 (crear cuenta en cualquier momento sin perder el carrito)

**RNFs relacionados:**

- :ref:`rnf-sec-003`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

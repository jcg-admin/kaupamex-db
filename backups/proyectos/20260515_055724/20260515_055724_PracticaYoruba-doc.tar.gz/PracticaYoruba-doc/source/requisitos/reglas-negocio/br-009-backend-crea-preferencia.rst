.. meta::
   :artefacto: BR-009
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_009:

===========================================
BR-009: Backend crea la preferencia de pago
===========================================

Enunciado
---------

El backend crea la preferencia en el gateway y devuelve la URL de checkout al frontend. El frontend nunca maneja credenciales secretas.

Justificacion
-------------

``MP_ACCESS_TOKEN`` y ``PAYPAL_CLIENT_SECRET`` son secretos del servidor. Exponerlos al frontend comprometeria la seguridad de la cuenta del comercio.

Impacto en el sistema
---------------------

- **Modulos afectados:** PAYMENT
- **UCs que la aplican:** UC-PAY-01, UC-PAY-02

Verificacion
------------

Las credenciales secretas solo existen en ``.env`` del servidor. El frontend recibe unicamente la URL de redirect o el Public Key.

Trazabilidad
------------

**FRs que la aplican:**

- FR-PAY-01.01 (el backend hace POST a MP con el access_token)
- FR-PAY-02.01 (el backend hace POST a PayPal con el client_secret)
- FR-PAY-01-EXT.02 (el backend configura las cuotas en la preferencia)

**RNFs relacionados:**

- :ref:`rnf-sec-002`
- :ref:`rnf-sec-006`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

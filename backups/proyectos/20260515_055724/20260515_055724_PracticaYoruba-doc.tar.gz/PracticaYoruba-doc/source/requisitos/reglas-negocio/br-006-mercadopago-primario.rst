.. meta::
   :artefacto: BR-006
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_006:

==========================================
BR-006: Mercado Pago como gateway primario
==========================================

Enunciado
---------

Mercado Pago es el gateway de pago primario y obligatorio desde Sprint 0.

Justificacion
-------------

Mercado Pago domina en Mexico con 101 metodos activos (tarjeta, OXXO, SPEI, MSI). La cuenta del proyecto esta verificada con site_id MLM.

Impacto en el sistema
---------------------

- **Modulos afectados:** PAYMENT, SITE_SETTINGS
- **UCs que la aplican:** UC-PAY-01, UC-PAY-03

Verificacion
------------

``PaymentMethod`` con ``provider=mercado_pago`` debe existir con ``is_active=True``. ``MP_ACCESS_TOKEN`` debe estar en ``.env``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-PAY-01.01 (crear preferencia en MP como gateway por defecto)
- FR-CFG-01.01 (las credenciales de MP se configuran primero)

**RNFs relacionados:**

- :ref:`rnf-sec-002`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

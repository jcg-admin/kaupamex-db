.. meta::
   :artefacto: BR-015
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_015:

=======================================================
BR-015: Rate limiting obligatorio en endpoints criticos
=======================================================

Enunciado
---------

Los endpoints de login, checkout y pago deben tener rate limiting con el modelo ``RateLimit`` custom y ``SELECT FOR UPDATE``. Los endpoints generales usan DRF Throttling + ``DatabaseCache``.

Justificacion
-------------

DRF Throttling tiene race conditions bajo alta concurrencia. Para endpoints donde la precision es mandatoria (login: brute force, checkout: duplicados) se necesita atomicidad real via ``SELECT FOR UPDATE`` en el repositorio.

Impacto en el sistema
---------------------

- **Modulos afectados:** PAYMENT, ORDER, ACCOUNTS
- **UCs que la aplican:** UC-AUTH-02, UC-PAY-01, UC-PAY-02, UC-ORD-04

Verificacion
------------

Los endpoints criticos usan una ``ThrottleClass`` que llama al modelo ``RateLimit`` con ``transaction.atomic()`` y ``select_for_update()``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-AUTH-02.01 (max 5 intentos login por IP en 15 min)
- FR-AUTH-09.01 (max 3 solicitudes de recovery por hora)
- FR-COM-01.01 (max 3 mensajes de contacto en 24h)

**RNFs relacionados:**

- RNF-SEC-004 (define los umbrales de rate limiting por endpoint)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

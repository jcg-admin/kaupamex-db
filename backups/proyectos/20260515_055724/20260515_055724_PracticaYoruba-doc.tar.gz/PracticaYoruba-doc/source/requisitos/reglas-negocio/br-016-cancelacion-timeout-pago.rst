.. meta::
   :artefacto: BR-016
   :tipo: Regla de Negocio
   :subtipo: Desencadenador (Trigger)
   :modalidad: Obligacion (Obligation)
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

.. _br_016:

===============================================
BR-016: Cancelacion automatica por timeout de pago
===============================================

Enunciado
---------

SI una orden lleva mas del tiempo configurado en ``SiteSettings``
en estado ``PENDIENTE_PAGO`` sin registrar pago alguno,
ENTONCES el sistema debe cancelarla automaticamente, restaurar
el stock reservado e informar al comprador.

Clasificacion
-------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **Tipo**
     - Desencadenador (Trigger)
   * - **Modalidad**
     - Obligacion — el sistema DEBE actuar cuando se cumple la condicion
   * - **Estatica**
     - No — el intervalo de tolerancia es configurable en
       ``SiteSettings.order_timeout_minutes``
   * - **Fuente**
     - BReq-004 (checkout), BReq-010 (operacion)

Por que es un Desencadenador y no otro tipo:

- El IF-THEN es explicito: la condicion es temporal (paso del tiempo),
  no una decision humana.
- El actor es el **Tiempo**, no un usuario.
- Las acciones resultantes son observables: el comprador ve su orden
  cancelada, el administrador ve el stock restaurado.
- Genera un UC completo: UC-SYS-01.

Justificacion
-------------

Sin esta regla, el stock queda bloqueado indefinidamente por ordenes
que nunca seran pagadas, impidiendo que otros compradores adquieran
esos productos. El negocio necesita liberar el inventario de ordenes
abandonadas en el flujo de pago.

Impacto en el sistema
---------------------

- **Modulos afectados:** ORDER, INVENTORY, NOTIFICATIONS
- **UCs que genera:** UC-SYS-01: Cancelar Orden por Timeout de Pago

Trazabilidad
------------

.. code-block:: text

   BR-016 (Desencadenador)
   |
   +---> UC-SYS-01: Cancelar Orden por Timeout de Pago
         |
         +---> FR-SYS-01.01: identificar ordenes con timeout vencido
         +---> FR-SYS-01.02: cancelar, restaurar stock y notificar
         |
         +---> UC-INV-03: Restaurar Stock (accion interna)
         +---> UC-NOT-02: Email Estado Orden — cancelacion (asincrono)

**FRs que la aplican:**

- FR-SYS-01.01 (detectar ordenes con estado PENDIENTE_PAGO expirado)
- FR-SYS-01.02 (cancelar con select_for_update — idempotencia)

Implementacion tecnica
----------------------

.. code-block:: python

   # apps/orders/management/commands/cancel_timeout_orders.py
   class Command(BaseCommand):
       """Management command que implementa BR-016."""

       def handle(self, *args, **options):
           timeout = SiteSettings.get_current().order_timeout_minutes
           cutoff  = timezone.now() - timedelta(minutes=timeout)

           for order in Order.objects.filter(
               status=OrderStatus.PENDIENTE_PAGO,
               created_at__lt=cutoff,
           ):
               with transaction.atomic():
                   refreshed = Order.objects.select_for_update().get(pk=order.pk)
                   if refreshed.status != OrderStatus.PENDIENTE_PAGO:
                       continue  # pagada o cancelada en paralelo
                   refreshed.status = OrderStatus.CANCELADA_TIMEOUT
                   refreshed.save()
                   for item in refreshed.items.all():
                       item.product.stock += item.quantity
                       item.product.save()
                   send_order_cancelled_email.delay(order_id=refreshed.pk)

Verificacion
------------

Los tests de UC-SYS-01 verifican:

1. Una orden en ``PENDIENTE_PAGO`` con ``created_at`` antes del cutoff
   queda en ``CANCELADA_TIMEOUT`` tras ejecutar el comando.
2. El stock de cada ``OrderItem`` se suma al ``Product.stock`` (restauracion).
3. Si la orden ya fue pagada (concurrencia), el comando la omite sin error.
4. El email de cancelacion se encola (mock de celery).

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Creada como ejemplo pedagogico de Desencadenador
       (Trigger/Obligation) en FND-02 seccion 3.3. Reemplaza el ejemplo
       generico BR-TRIG-001 (quimico vencido).

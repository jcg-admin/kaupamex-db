.. meta::
   :tipo: Indice
   :estado: Vigente

=================
Reglas de Negocio
=================

Reglas que gobiernan el comportamiento del sistema PracticaYoruba.
Cada regla es inmutable una vez aprobada. Los cambios generan
una nueva BR que puede superseder a la anterior.

.. list-table::
   :widths: 15 85
   :header-rows: 1

   * - ID
     - Titulo
   * - BR-001
     - Precio de catalogo no incluye IVA
   * - BR-002
     - IVA calculado en checkout
   * - BR-003
     - Carrito en sesion Django (MVP)
   * - BR-004
     - Carrito no requiere autenticacion
   * - BR-005
     - Snapshots inmutables en ordenes
   * - BR-006
     - Mercado Pago como gateway primario
   * - BR-007
     - PayPal disponible desde Sprint 0
   * - BR-008
     - Stripe es extension futura
   * - BR-009
     - Backend crea la preferencia de pago
   * - BR-010
     - CONTACT, QUESTION y NEWSLETTER son guest-friendly
   * - BR-011
     - Ordenes de guest permitidas
   * - BR-012
     - Un solo descuento activo por producto
   * - BR-013
     - Todos los modelos heredan de AbstractBaseModel
   * - BR-014
     - DatabaseCache en produccion
   * - BR-015
     - Rate limiting obligatorio en endpoints criticos
   * - BR-016
     - Cancelacion automatica por timeout de pago
   * - BR-017
     - Alerta automatica de stock minimo
   * - BR-018
     - Desactivacion automatica de vouchers expirados
   * - BR-019
     - Reintento automatico de emails fallidos

.. toctree::
   :maxdepth: 1
   :hidden:

   br-001-precio-sin-iva
   br-002-iva-en-checkout
   br-003-carrito-en-sesion
   br-004-carrito-sin-login
   br-005-snapshots-inmutables
   br-006-mercadopago-primario
   br-007-paypal-mvp
   br-008-stripe-futuro
   br-009-backend-crea-preferencia
   br-010-guest-friendly
   br-011-orden-guest
   br-012-un-descuento-por-producto
   br-013-abstract-base-model
   br-014-database-cache
   br-015-rate-limiting
   br-016-cancelacion-timeout-pago
   br-017-alerta-stock-minimo
   br-018-desactivar-vouchers-expirados
   br-019-reintento-emails-fallidos

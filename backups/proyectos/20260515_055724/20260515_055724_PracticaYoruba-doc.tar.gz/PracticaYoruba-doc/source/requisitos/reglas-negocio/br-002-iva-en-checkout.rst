.. meta::
   :artefacto: BR-002
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_002:

=================================
BR-002: IVA calculado en checkout
=================================

Enunciado
---------

El IVA del 16% (Mexico) se aplica en el checkout a traves de ``PricingService``. Formula: ``total = subtotal_neto * (1 + tax_rate)``.

Justificacion
-------------

Centralizar el calculo garantiza consistencia. El ``tax_rate`` es configurable por region via ``SiteSettings`` sin modificar codigo.

Impacto en el sistema
---------------------

- **Modulos afectados:** ORDER (PricingService), SITE_SETTINGS
- **UCs que la aplican:** UC-ORD-01, UC-ORD-04

Verificacion
------------

``tax_rate`` se lee de ``SiteSettings``, no esta hardcodeado. Tests deben verificar el calculo con distintos valores de ``tax_rate``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CART-02.02 (desglose de IVA en el carrito)
- FR-ORD-01.02 (OrderValue.tax captura el IVA al momento del checkout)

**RNFs relacionados:**

- :ref:`rnf-usab-001`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

.. meta::
   :artefacto: BR-019
   :tipo: Regla de Negocio
   :subtipo: Desencadenador (Trigger)
   :modalidad: Obligacion (Obligation)
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

.. _br_019:

=====================================================
BR-019: Reintento automatico de emails fallidos
=====================================================

Enunciado
---------

SI un email transaccional queda en estado FALLIDO y su campo
``reintento_en`` es menor o igual al momento actual,
ENTONCES el sistema debe reenviarlo automaticamente con backoff
exponencial hasta alcanzar el maximo de reintentos configurado.

Clasificacion
-------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **Tipo**
     - Desencadenador (Trigger)
   * - **Modalidad**
     - Obligacion — el sistema DEBE reintentar cuando la condicion
       temporal se cumple
   * - **Estatica**
     - No — el maximo de reintentos y el backoff son configurables
   * - **Fuente**
     - BReq-004 (operacion), BReq-013 (comunicaciones transaccionales)

Por que es un Desencadenador y no otro tipo:

- El IF-THEN es explicito: la condicion combina el estado FALLIDO y
  la condicion temporal ``reintento_en <= now()``.
- El actor es el Tiempo: nadie aprieta un boton para disparar el reintento.
- La accion es observable: el email pasa a ENVIADO o a FALLIDO_DEFINITIVO.
- Genera un UC completo: UC-SYS-04.

La diferencia con BR-016 (timeout de pago) y BR-018 (vouchers) es que
esta BR tiene un estado intermedio: el email puede reintentar N veces
antes de quedar en FALLIDO_DEFINITIVO. Las otras dos BRs actuan una
sola vez sobre la condicion.

Justificacion
-------------

Los errores de entrega de email son transitorios con frecuencia
(servidor del destinatario sobrecargado, timeout de red). Sin
reintento automatico, el comprador no recibe confirmaciones ni
actualizaciones de estado de su orden, degradando la confianza en
la plataforma. El backoff exponencial protege al proveedor de email
de sobrecarga.

Impacto en el sistema
---------------------

- **Modulos afectados:** NOTIFICATIONS (EmailQueue, EmailService)
- **UCs que genera:** UC-SYS-04: Reenviar Emails de Notificacion Fallidos
- **Complementario con:** UC-INC-03 (que encola el email inicial y
  registra el intento — primera linea)

Trazabilidad
------------

.. code-block:: text

   BR-019 (Desencadenador)
   |
   +---> UC-SYS-04: Reenviar Emails de Notificacion Fallidos
         |
         +---> FR-SYS-04.01: consultar emails FALLIDO con reintento_en <= ahora
         +---> FR-SYS-04.02: reintentar con backoff exponencial
         +---> FR-SYS-04.03: marcar FALLIDO_DEFINITIVO al agotar reintentos
         |
         +---> UC-INC-03: Enviar Email con Plantilla (encola el email original)
         +---> UC-NOT-01..05: Emails automaticos (cuyos fallidos esta BR reintenta)

**FRs que la aplican:**

- FR-SYS-04.01 (consultar la cola de emails con estado FALLIDO y
  ``reintento_en`` vencido)
- FR-SYS-04.02 (reintentar y calcular la siguiente fecha con backoff)
- FR-SYS-04.03 (marcar FALLIDO_DEFINITIVO y notificar al admin si aplica)

Implementacion tecnica
----------------------

.. code-block:: python

   # apps/notifications/management/commands/retry_failed_emails.py
   class Command(BaseCommand):
       """Management command que implementa BR-019."""

       MAX_RETRIES = 5  # configurable via settings

       def handle(self, *args, **options):
           candidates = EmailQueue.objects.filter(
               status=EmailStatus.FALLIDO,
               reintento_en__lte=timezone.now(),
               retry_count__lt=self.MAX_RETRIES,
           )
           for email in candidates:
               try:
                   send_email(email)
                   email.status = EmailStatus.ENVIADO
               except (TransientError, TimeoutError):
                   email.retry_count += 1
                   email.reintento_en = timezone.now() + timedelta(
                       minutes=2 ** email.retry_count  # backoff exponencial
                   )
                   if email.retry_count >= self.MAX_RETRIES:
                       email.status = EmailStatus.FALLIDO_DEFINITIVO
               email.save()

Verificacion
------------

Los tests de UC-SYS-04 verifican:

1. Un email en FALLIDO con ``reintento_en`` vencido pasa a ENVIADO
   si el servicio responde correctamente.
2. Si el servicio falla, ``retry_count`` se incrementa y ``reintento_en``
   avanza con backoff exponencial.
3. Al alcanzar ``MAX_RETRIES``, el email pasa a FALLIDO_DEFINITIVO.
4. Los emails con ``reintento_en`` futuro no se procesan en esa ejecucion.

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Desencadenador/Obligation para reintento de
       emails fallidos con backoff exponencial. Vinculada a UC-SYS-04.

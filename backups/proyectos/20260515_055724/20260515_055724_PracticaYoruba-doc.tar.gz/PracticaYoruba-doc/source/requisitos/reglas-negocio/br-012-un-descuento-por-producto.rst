.. meta::
   :artefacto: BR-012
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_012:

=============================================
BR-012: Un solo descuento activo por producto
=============================================

Enunciado
---------

Un producto puede tener como maximo un ``ProductDiscount`` activo en un momento dado. Los descuentos no se acumulan.

Justificacion
-------------

Simplifica ``PricingService`` y evita precios negativos o descuentos impredecibles por acumulacion.

Impacto en el sistema
---------------------

- **Modulos afectados:** DASHBOARD, ORDER (PricingService)
- **UCs que la aplican:** UC-CAT-02, UC-ORD-01

Verificacion
------------

``PricingService`` lee el primer ``ProductDiscount`` activo. La unicidad se puede reforzar con validacion en el admin.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CART-04.02 (solo un voucher activo por carrito — el anterior se reemplaza)
- FR-CART-02.02 (el calculo de totales aplica un solo descuento)

**RNFs relacionados:**

- :ref:`rnf-usab-001`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

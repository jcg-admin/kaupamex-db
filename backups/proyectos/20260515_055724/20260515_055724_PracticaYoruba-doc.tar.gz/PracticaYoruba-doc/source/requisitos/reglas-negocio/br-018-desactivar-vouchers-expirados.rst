.. meta::
   :artefacto: BR-018
   :tipo: Regla de Negocio
   :subtipo: Desencadenador (Trigger)
   :modalidad: Obligacion (Obligation)
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

.. _br_018:

=============================================
BR-018: Desactivacion automatica de vouchers expirados
=============================================

Enunciado
---------

SI la fecha ``valid_until`` de un voucher activo ha sido superada,
ENTONCES el sistema debe desactivarlo automaticamente para impedir
que pueda aplicarse en nuevos carritos.

Clasificacion
-------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **Tipo**
     - Desencadenador (Trigger)
   * - **Modalidad**
     - Obligacion — el sistema DEBE desactivar el voucher sin intervencion
       humana cuando la condicion temporal se cumple
   * - **Estatica**
     - No — la fecha ``valid_until`` es configurada por el administrador
       en cada voucher individualmente
   * - **Fuente**
     - BReq-004 (checkout / integridad de promociones)

Por que es un Desencadenador y no otro tipo:

- El IF-THEN es explicito: la condicion es temporal (fecha superada).
- El actor es el Tiempo, no un usuario.
- La accion resultante es observable: el voucher pasa a inactivo y
  ya no puede aplicarse en UC-CART-04.
- Genera un UC completo: UC-SYS-02.
- Se distingue de UC-PRO-03 (desactivacion manual por el admin):
  esta BR opera automaticamente sin decision humana.

Justificacion
-------------

Un voucher vencido que sigue activo puede aplicarse en el checkout
si UC-CART-04 no verifica la fecha en tiempo real. La desactivacion
proactiva garantiza coherencia entre el estado del voucher y su
vigencia real, independientemente de cuando llegue la proxima solicitud
de checkout.

Impacto en el sistema
---------------------

- **Modulos afectados:** VOUCHER (VoucherService)
- **UCs que genera:** UC-SYS-02: Desactivar Vouchers Expirados
- **Complementario con:** UC-CART-04 (que valida la vigencia en tiempo
  real al aplicar el voucher — segunda linea de defensa)

Trazabilidad
------------

.. code-block:: text

   BR-018 (Desencadenador)
   |
   +---> UC-SYS-02: Desactivar Vouchers Expirados
         |
         +---> FR-SYS-02.01: identificar vouchers activos con valid_until < ahora
         +---> FR-SYS-02.02: marcar como inactivos y registrar en auditoria
         |
         +---> UC-CART-04: Aplicar Cupon (segunda linea de defensa — valida en tiempo real)
         +---> UC-PRO-03: Desactivar Voucher Admin (alternativa manual)

**FRs que la aplican:**

- FR-SYS-02.01 (consultar vouchers activos cuya ``valid_until`` es anterior a ``now()``)
- FR-SYS-02.02 (actualizar ``is_active = False`` y registrar el evento)

Implementacion tecnica
----------------------

.. code-block:: python

   # apps/promotions/management/commands/expire_vouchers.py
   class Command(BaseCommand):
       """Management command que implementa BR-018."""

       def handle(self, *args, **options):
           expired = Voucher.objects.filter(
               is_active=True,
               valid_until__lt=timezone.now(),
           )
           count = expired.update(is_active=False)
           self.stdout.write(f'{count} voucher(s) expirados desactivados.')

Verificacion
------------

Los tests de UC-SYS-02 verifican:

1. Un voucher con ``valid_until`` anterior a ``now()`` queda con
   ``is_active = False`` tras ejecutar el comando.
2. Un voucher con ``valid_until`` posterior a ``now()`` no se modifica.
3. El comando es idempotente: ejecutarlo dos veces no cambia el resultado.

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Desencadenador/Obligation para vouchers expirados.
       Vinculada a UC-SYS-02. Complementaria con UC-CART-04
       (validacion en tiempo real).

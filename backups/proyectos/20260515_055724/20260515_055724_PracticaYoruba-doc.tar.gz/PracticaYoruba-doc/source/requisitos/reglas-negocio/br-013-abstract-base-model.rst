.. meta::
   :artefacto: BR-013
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_013:

======================================================
BR-013: Todos los modelos heredan de AbstractBaseModel
======================================================

Enunciado
---------

Todos los modelos Django del proyecto deben heredar de ``AbstractBaseModel``, que agrega ``created_at`` y ``updated_at`` automaticos.

Justificacion
-------------

Constraint R1 del proyecto: todos los datos deben ser auditables. Sin timestamps no hay forma de rastrear cuando se creo o modifico un registro.

Impacto en el sistema
---------------------

- **Modulos afectados:** Todos los modulos
- **UCs que la aplican:** Todos los UCs

Verificacion
------------

Verificar en cada nueva migracion que el modelo hereda de ``AbstractBaseModel``. El schema audit busca tablas sin ``created_at`` y ``updated_at``.

Trazabilidad
------------

**FRs que la aplican:**

- Todos los modelos del sistema heredan AbstractBaseModel
- FR-ORD-01.02 (created_at registra el momento exacto del checkout)

**RNFs relacionados:**

- RNF-PROC-002 (created_at/updated_at son parte del registro de auditoria)

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

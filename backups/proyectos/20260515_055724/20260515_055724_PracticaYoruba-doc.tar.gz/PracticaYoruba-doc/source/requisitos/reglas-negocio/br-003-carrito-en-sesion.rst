.. meta::
   :artefacto: BR-003
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_003:

======================================
BR-003: Carrito en sesion Django (MVP)
======================================

Enunciado
---------

El carrito vive en la sesion Django en el MVP. No hay tabla ``CartItem`` en la base de datos.

Justificacion
-------------

Simplifica el MVP y elimina la logica de merge entre carrito anonimo y autenticado. La sesion usa ``SESSION_ENGINE=db`` (tabla ``django_session`` en el repositorio).

Impacto en el sistema
---------------------

- **Modulos afectados:** CART
- **UCs que la aplican:** UC-CART-01, UC-CART-02, UC-CART-03, UC-CART-04

Verificacion
------------

Verificar que no existe migracion de ``CartItem`` en la BD. El carrito se almacena en ``request.session``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CART-02.01 (recuperar carrito de sesion para visitante anonimo)
- FR-INC-02.01 (logica de recuperacion sesion vs BD)

**RNFs relacionados:**

- :ref:`rnf-sec-003`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

.. meta::
   :artefacto: BR-004
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_004:

=========================================
BR-004: Carrito no requiere autenticacion
=========================================

Enunciado
---------

Un usuario no autenticado puede agregar, modificar y eliminar items del carrito. El login se requiere unicamente al iniciar el checkout.

Justificacion
-------------

Reduce la friccion en el proceso de compra. Un cliente que no puede agregar sin registrarse abandona la tienda.

Impacto en el sistema
---------------------

- **Modulos afectados:** CART, ORDER
- **UCs que la aplican:** UC-CART-01, UC-ORD-01

Verificacion
------------

Los endpoints del carrito tienen ``permission_classes = [AllowAny]``. El primer paso del checkout verifica autenticacion.

Trazabilidad
------------

**FRs que la aplican:**

- FR-CART-01.02 (agregar item sin JWT requerido)
- FR-CART-02.01 (ver carrito con AllowAny permission)

**RNFs relacionados:**

- :ref:`rnf-sec-001`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

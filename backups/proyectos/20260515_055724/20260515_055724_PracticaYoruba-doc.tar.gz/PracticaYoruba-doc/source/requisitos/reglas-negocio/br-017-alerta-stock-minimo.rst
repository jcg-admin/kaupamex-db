.. meta::
   :artefacto: BR-017
   :tipo: Regla de Negocio
   :subtipo: Desencadenador (Trigger)
   :modalidad: Obligacion (Obligation)
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

.. _br_017:

=========================================
BR-017: Alerta automatica de stock minimo
=========================================

Enunciado
---------

SI el stock disponible de un producto cae por debajo del umbral minimo
configurado en ``SiteSettings.min_stock_threshold``,
ENTONCES el sistema debe notificar al administrador para que gestione
el reabastecimiento a tiempo.

Clasificacion
-------------

.. list-table::
   :widths: 30 70
   :header-rows: 0

   * - **Tipo**
     - Desencadenador (Trigger)
   * - **Modalidad**
     - Obligacion — el sistema DEBE notificar cuando se cumple la condicion
   * - **Estatica**
     - No — el umbral ``min_stock_threshold`` es configurable en
       ``SiteSettings`` por el administrador
   * - **Fuente**
     - BReq-014 (operacion del negocio)

Por que es un Desencadenador y no otro tipo:

- El IF-THEN es explicito: la condicion es un valor numerico que cruza
  un umbral, no una decision humana.
- El activador puede ser inline (en el mismo flujo de
  ``InventoryService.decrement_stock``) o periodico (revision de
  ``v_low_stock`` via cron).
- La accion resultante es observable: el administrador recibe una
  notificacion y puede actuar sobre el inventario.
- Genera un UC completo: UC-SYS-03.

Justificacion
-------------

Prevenir la ruptura de stock que genera ventas perdidas y deteriora
la experiencia del comprador. Sin esta regla el administrador solo
descubre el problema cuando ya no hay unidades disponibles, momento
en que la recuperacion es mas costosa que el reabastecimiento proactivo.

Impacto en el sistema
---------------------

- **Modulos afectados:** CATALOGUE (InventoryService), NOTIFICATIONS
- **UCs que genera:** UC-SYS-03: Notificar Stock Minimo Alcanzado
- **Vista SQL relacionada:** ``v_low_stock`` en PracticaYoruba-db

Trazabilidad
------------

.. code-block:: text

   BR-017 (Desencadenador)
   |
   +---> UC-SYS-03: Notificar Stock Minimo Alcanzado
         |
         +---> FR-SYS-03.01: detectar productos con stock <= min_stock_threshold
         +---> FR-SYS-03.02: notificar al administrador con detalle consolidado
         |
         +---> UC-INV-02: Decrementar Stock (evento que puede activar la BR)
         +---> UC-NOT-07: Notificacion Manual Admin (patron de notificacion)

**FRs que la aplican:**

- FR-SYS-03.01 (detectar stock bajo via ``v_low_stock`` o inline post-venta)
- FR-SYS-03.02 (notificar con deduplicacion: una alerta por producto en 24h)

**Vista SQL (PracticaYoruba-db v2.0.0):**

- ``v_low_stock`` — expone productos con ``stock < min_stock_threshold``
- ``fn_stock_status`` — clasifica OUT_OF_STOCK vs LOW_STOCK

Implementacion tecnica
----------------------

.. code-block:: python

   # apps/inventory/services.py
   class InventoryService:

       def decrement_stock(self, product: Product, quantity: int) -> None:
           """
           Decrementa el stock y verifica BR-017 despues de cada cambio.
           La alerta se dispara en el mismo flujo — no requiere proceso periodico.
           """
           with transaction.atomic():
               product.stock = F('stock') - quantity
               product.save(update_fields=['stock'])
               product.refresh_from_db()

               threshold = SiteSettings.get_current().min_stock_threshold
               if product.stock < threshold:
                   self._notify_low_stock(product, threshold)

       def _notify_low_stock(self, product: Product, threshold: int) -> None:
           """Encola la notificacion si no existe alerta reciente (24h)."""
           already_notified = StockAlert.objects.filter(
               product=product,
               created_at__gte=timezone.now() - timedelta(hours=24),
           ).exists()
           if not already_notified:
               send_low_stock_alert.delay(product_id=product.pk)

Verificacion
------------

Los tests de UC-SYS-03 verifican:

1. Al decrementar el stock de un producto por debajo del umbral, se
   encola la tarea de notificacion al administrador.
2. Si ya existe una alerta para ese producto en las ultimas 24 horas,
   no se encola una segunda alerta (deduplicacion).
3. La vista ``v_low_stock`` retorna el producto cuando su stock es
   inferior a ``min_stock_threshold``.

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Desencadenador/Obligation para stock minimo.
       Vinculada a UC-SYS-03, v_low_stock y fn_stock_status de
       PracticaYoruba-db v2.0.0.

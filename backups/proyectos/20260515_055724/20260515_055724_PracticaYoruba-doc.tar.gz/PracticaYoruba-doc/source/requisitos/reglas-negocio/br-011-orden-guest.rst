.. meta::
   :artefacto: BR-011
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_011:

===================================
BR-011: Ordenes de guest permitidas
===================================

Enunciado
---------

``Order.user_id`` es opcional. Una orden puede completarse sin que el usuario tenga cuenta en el sistema.

Justificacion
-------------

Permite ventas a clientes que no quieren registrarse. El registro se puede ofrecer post-compra.

Impacto en el sistema
---------------------

- **Modulos afectados:** ORDER
- **UCs que la aplican:** UC-ORD-04

Verificacion
------------

El campo ``user_id`` en ``Order`` tiene ``null=True, blank=True``. ``OrderService`` no debe fallar si ``user`` es ``None``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-ORD-01.02 (Order.guest_email captura el email del invitado en el snapshot)
- FR-INC-01.01 (verificacion de propiedad por order_number + guest_email)

**RNFs relacionados:**

- :ref:`rnf-sec-003`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

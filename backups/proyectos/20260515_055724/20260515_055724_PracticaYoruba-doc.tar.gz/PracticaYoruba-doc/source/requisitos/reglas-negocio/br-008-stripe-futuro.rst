.. meta::
   :artefacto: BR-008
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_008:

==================================
BR-008: Stripe es extension futura
==================================

Enunciado
---------

Stripe no es parte del MVP. El ``Strategy Pattern`` soporta su incorporacion sin cambios en ``OrderService`` cuando sea necesario.

Justificacion
-------------

Stripe tiene comisiones mas altas en Mexico y menor adopcion local. No hay necesidad operativa en el MVP.

Impacto en el sistema
---------------------

- **Modulos afectados:** PAYMENT
- **UCs que la aplican:** —

Verificacion
------------

No debe haber ``StripeStrategy`` implementada en MVP. Si se crea el ``PaymentMethod`` en BD, debe tener ``is_active=False``.

Trazabilidad
------------

**FRs que la aplican:**

- Sin FRs actuales — se implementara en una version futura

**RNFs relacionados:**

- N/A

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

.. meta::
   :artefacto: BR-007
   :tipo: Regla de Negocio
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _br_007:

========================================
BR-007: PayPal disponible desde Sprint 0
========================================

Enunciado
---------

PayPal es el segundo gateway de pago y debe estar disponible desde Sprint 0. No es una funcionalidad de Phase 2.

Justificacion
-------------

El sitio real (ojayoruba.com) tiene PayPal activo en modo produccion (env=live, country=ES). No hay razon para diferirlo.

Impacto en el sistema
---------------------

- **Modulos afectados:** PAYMENT, SITE_SETTINGS
- **UCs que la aplican:** UC-PAY-02, UC-PAY-03

Verificacion
------------

``PaymentMethod`` con ``provider=paypal`` debe existir con ``is_active=True``. ``PAYPAL_CLIENT_ID`` y ``PAYPAL_CLIENT_SECRET`` deben estar en ``.env``.

Trazabilidad
------------

**FRs que la aplican:**

- FR-PAY-02.01 (crear orden en PayPal como gateway secundario)
- FR-CFG-01.01 (PayPal se configura como alternativa)

**RNFs relacionados:**

- :ref:`rnf-sec-002`

Historial
---------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial.

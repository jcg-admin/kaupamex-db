.. meta::
   :artefacto: FR-CART-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-06-02:

================================================================
FR-CART-06.02: Fusionar el carrito anonimo con el del usuario autenticado
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-06.02
   * - **Nombre**
     - Combinar items del carrito anonimo con el carrito persistente del usuario
   * - **UC Origen**
     - UC-CART-06: Sincronizar Carrito tras Login
   * - **Paso UC**
     - Pasos 2, 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart — CartMergeService)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE fusionar el carrito de la sesion anonima con el
   carrito guardado del usuario autenticado CUANDO el usuario inicia
   sesion y tiene items en su carrito de sesion.

**Descripcion:**

Este proceso ocurre automáticamente tras el login exitoso,
desencadenado por la señal ``user_logged_in`` o en el endpoint
de login de FR-AUTH-02.15.

Algoritmo de fusión en transacción atómica:

El sistema recupera el ``SavedCart`` del usuario autenticado si existe.
Para cada item del carrito anónimo de sesión:

- Si el item ya existe en el ``SavedCart`` del usuario (misma clave),
  el sistema suma las cantidades. Si la suma supera el
  ``ProductVariant.stock`` actual, la cantidad se ajusta al stock
  disponible y el ajuste se registra para informar al usuario.
- Si el item no existe en el ``SavedCart`` del usuario, se agrega
  directamente.

Al finalizar el recorrido, el sistema persiste el carrito fusionado
en ``SavedCart.items`` (actualizando el existente o creando uno nuevo).

Tras la fusion, el carrito de sesion anonimo se elimina (paso 6)
y el carrito del usuario queda en ``request.session['cart']``
con el contenido fusionado.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Fusion con producto comun — suma cantidades
   DADO carrito anonimo {producto_A: qty=2} y carrito usuario {producto_A: qty=1}
   CUANDO se fusionan
   ENTONCES carrito resultante {producto_A: qty=3}
   Y no hay items duplicados

   Escenario 2: Fusion con productos distintos — ambos preservados
   DADO carrito anonimo {producto_B: qty=1} y carrito usuario {producto_A: qty=2}
   CUANDO se fusionan
   ENTONCES carrito resultante {producto_A: qty=2, producto_B: qty=1}
   Y ninguno de los dos se pierde

   Escenario 3: Suma supera el stock — ajuste automatico informado
   DADO carrito anonimo {producto_A: qty=5} + carrito usuario {producto_A: qty=4} con stock=6
   CUANDO se fusionan
   ENTONCES carrito resultante {producto_A: qty=6} (ajustado al max de stock)
   Y la respuesta incluye aviso: "Producto A: ajustado a 6 unidades (stock limitado)"

   Escenario 4: Usuario sin carrito previo — carrito anonimo pasa directamente
   DADO usuario sin SavedCart y carrito anonimo con 3 items
   CUANDO inicia sesion
   ENTONCES se crea un SavedCart con los 3 items del carrito anonimo
   Y no hay fusion (no habia carrito previo)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion), BR-004 (carrito sin
  login — los items del carrito anonimo deben preservarse)
- **RNF aplicables:** RNF-AVAIL-002 (idempotencia — si la fusion se
  ejecuta dos veces el resultado es el mismo)
- **Notas:** El carrito anonimo de sesion se elimina tras la fusion
  exitosa. Si la fusion falla (EX-01), el carrito anonimo permanece
  en sesion para que el usuario no pierda sus items.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-06: Sincronizar Carrito tras Login
   * - **Depende de**
     - FR-AUTH-02.15 (login exitoso completado — user autenticado)
   * - **Requerido por**
     - FR-CART-06.03 (presentar el carrito fusionado al usuario)
   * - **BR**
     - BR-003, BR-004
   * - **Test**
     - TST-FR-CART-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-6 de UC-CART-06

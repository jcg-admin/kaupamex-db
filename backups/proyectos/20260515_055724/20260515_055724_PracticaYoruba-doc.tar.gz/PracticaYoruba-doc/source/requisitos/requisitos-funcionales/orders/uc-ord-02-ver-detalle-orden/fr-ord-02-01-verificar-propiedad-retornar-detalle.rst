.. meta::
   :artefacto: FR-ORD-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-02-01:

============================================================
FR-ORD-02.01: Verificar propiedad y retornar detalle
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-02.01
   * - **Nombre**
     - Verificar propiedad de la orden y retornar su detalle completo
   * - **UC Origen**
     - UC-ORD-02: Ver detalle de orden
   * - **Paso UC**
     - Pasos 2-5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la propiedad de la orden y retornar
   su detalle completo CUANDO el actor la consulta.

**Descripcion:**

Verificacion de propiedad (UC-INC-01):

- Actor autenticado: ``Order.user_id == request.user.id``
- Visitante con numero de orden: verifica ``order_number + guest_email``

Datos del detalle retornados:

- Cabecera: ``order_number``, ``status``, ``created_at``
- Items (desde snapshot BR-005): ``product_name``, ``variant_label``,
  ``sku``, ``unit_price``, ``quantity``, ``subtotal_item``
- Direccion de envio (snapshot): todos los campos de ``OrderAddress``
- Valores: ``subtotal``, ``discount``, ``voucher_code``,
  ``shipping_cost``, ``tax``, ``total``
- Metodo de pago utilizado y estado del pago
- Info de envio: metodo, courier, tracking_number, estimated_delivery
- Acciones disponibles segun el estado actual de la orden

----

3. Criterio de Aceptacion
--------------------------

::

   DADO actor que consulta el detalle de una orden
   CUANDO se procesa la solicitud
   ENTONCES ve todos los datos de la orden si tiene derecho

   Escenario 1: Comprador ve su propia orden
   DADO comprador autenticado dueno de la orden PY-20260430-ABCD1234
   CUANDO consulta GET /api/v1/orders/PY-20260430-ABCD1234/
   ENTONCES recibe el detalle completo con items, valores y estado

   Escenario 2: Comprador intenta ver orden ajena
   DADO comprador autenticado que NO es dueno de la orden
   CUANDO consulta la orden
   ENTONCES error 404 (sin revelar que la orden existe)

   Escenario 3: Precios del snapshot no cambian
   DADO orden con unit_price = 100 en el OrderItem
   Y el admin sube el precio del producto a 150 hoy
   CUANDO el comprador ve el detalle
   ENTONCES ve 100 (el precio al momento del checkout)
   Y no ve 150 (el precio actual del catalogo)

   Escenario 4: Acciones segun estado
   DADO orden en estado PENDING_PAYMENT
   CUANDO se retorna el detalle
   ENTONCES la respuesta incluye actions: ["completar_pago"]
   DADO orden en estado ENTREGADA
   ENTONCES la respuesta incluye actions: ["dejar_resena"]

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (snapshot inmutable de la orden)
- **RNF:** RNF-SEC-003 (aislamiento), RNF-PERF-001 (< 400ms P95)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-02: Ver detalle de orden
   * - **Depende de**
     - FR-ORD-01.02 (la orden fue creada con snapshot)
   * - **Requerido por**
     - Acciones contextuales: FR-ORD-04.01, FR-PAY-05.01, FR-REV-01.01
   * - **Include**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **BR**
     - BR-005
   * - **Test**
     - TST-FR-ORD-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-02

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inc-01-verificar-propiedad-orden
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inc-01-02-verificar-propiedad-con-404
   fr-inc-01-verificar-propiedad-orden-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-04-webhook-paypal
===================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-04-01-verificar-y-procesar-paypal
   fr-pay-04-02-capturar-pago-paypal

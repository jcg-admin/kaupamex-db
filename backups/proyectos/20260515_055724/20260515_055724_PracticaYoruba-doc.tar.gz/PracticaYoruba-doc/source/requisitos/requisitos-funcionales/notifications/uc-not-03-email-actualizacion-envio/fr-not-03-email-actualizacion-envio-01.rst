.. meta::
   :artefacto: FR-NOT-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-03-01:

FR-NOT-03.01: Enviar email de actualizacion del courier
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-03.01
   * - **Nombre**
     - Enviar email de actualizacion del courier
   * - **UC Origen**
     - UC-NOT 03 EMAIL ACTUALIZACION ENVIO
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE notificar al comprador CUANDO el courier reporta un evento significativo.

**Descripcion:**

Eventos del courier que generan email:

- Primera actualizacion en transito
- Intento de entrega fallido
- Entrega exitosa

Los estados intermedios (en bodega, en vehiculo) no generan email para no saturar al comprador.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Intento de entrega fallido
   DADO evento FAILED_ATTEMPT del courier
   CUANDO se procesa el webhook
   ENTONCES el comprador recibe email indicando que intentaron entregar
   Y se informa el proximo intento o como reprogramar


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Solo los eventos con impacto real para el comprador generan email.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 03 EMAIL ACTUALIZACION ENVIO
   * - **Depende de**
     - FR-LOG-04.01 (webhook del courier procesado)
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 03 EMAIL ACTUALIZACION ENVIO

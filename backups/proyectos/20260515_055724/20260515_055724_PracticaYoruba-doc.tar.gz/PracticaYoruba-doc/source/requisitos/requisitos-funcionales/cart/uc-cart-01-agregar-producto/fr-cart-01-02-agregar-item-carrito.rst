.. meta::
   :artefacto: FR-CART-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-01-02:

===================================================
FR-CART-01.02: Agregar o incrementar item
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-01.02
   * - **Nombre**
     - Crear o incrementar el CartItem en el carrito activo
   * - **UC Origen**
     - UC-CART-01: Agregar producto al carrito
   * - **Paso UC**
     - Pasos 3-4 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear un nuevo CartItem o incrementar la cantidad
   de uno existente CUANDO el stock es suficiente.

**Descripcion:**

Comportamiento upsert del carrito:

1. Recupera el carrito activo (UC-INC-02: sesion para anonimos, BD para autenticados)
2. Busca si ya existe un CartItem con la misma variante en ese carrito
3. Si NO existe: crea ``CartItem(cart, variant, quantity, unit_price)``
   capturando ``unit_price = variant.effective_price()`` en el momento
4. Si YA existe: ``item.quantity += cantidad_solicitada``
5. ``unit_price`` en el CartItem refleja el precio actual — no es snapshot
   (el snapshot ocurre en el checkout con OrderItem)

La operacion es atomica dentro de una transaccion.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO stock verificado como suficiente
   CUANDO se agrega el item
   ENTONCES el carrito refleja el cambio de inmediato

   Escenario 1: Item nuevo en el carrito
   DADO variante no existente en el carrito
   CUANDO se agrega con cantidad = 1
   ENTONCES aparece un nuevo CartItem con quantity = 1
   Y unit_price = precio actual de la variante con IVA

   Escenario 2: Item ya existente — incremento
   DADO variante ya con quantity = 2 en el carrito
   CUANDO se agrega con cantidad = 1
   ENTONCES el CartItem tiene quantity = 3
   Y no se crea un segundo registro

   Escenario 3: Precio cambia entre sesiones
   DADO item en carrito con unit_price = 100
   Y el admin cambia el precio del producto a 120
   CUANDO el comprador agrega una unidad mas
   ENTONCES unit_price se actualiza a 120 para todas las unidades
   Y se muestra un aviso de que el precio cambio

   Escenario 4: Visitante anonimo
   DADO visitante sin cuenta y sin sesion de carrito
   CUANDO agrega un item por primera vez
   ENTONCES se crea un Cart nuevo con session_key de la sesion Django
   Y el item queda en ese carrito de sesion

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-004 (carrito sin login: el visitante puede
  agregar sin estar autenticado)
- **Notas:** El ``unit_price`` del CartItem NO es un snapshot inmutable
  — se actualiza. El snapshot inmutable ocurre en OrderItem al hacer
  checkout (BR-005).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-01: Agregar producto al carrito
   * - **Depende de**
     - FR-CART-01.01 (stock verificado)
   * - **Requerido por**
     - FR-CART-02.01 (ver el carrito con el nuevo item)
   * - **Include**
     - UC-INC-02 (recuperar carrito de sesion)
   * - **BR**
     - BR-004
   * - **Test**
     - TST-FR-CART-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-01

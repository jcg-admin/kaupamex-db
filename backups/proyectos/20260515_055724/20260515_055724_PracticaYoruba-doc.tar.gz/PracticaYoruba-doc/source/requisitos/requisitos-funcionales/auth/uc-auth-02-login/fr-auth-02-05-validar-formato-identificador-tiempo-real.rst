.. meta::
   :artefacto: FR-AUTH-02.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-05:

=============================================================
FR-AUTH-02.05: Validar formato del identificador en tiempo real
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.05
   * - **Nombre**
     - Retroalimentacion visual inmediata al escribir el identificador
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (validacion en cliente — sin llamada al servidor)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Validacion — Frontend

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato del identificador en tiempo real
   y dar retroalimentacion visual CUANDO el visitante escribe en el
   campo identificador.

**Descripcion:**

La validacion ocurre en el cliente (frontend) sin llamadas al servidor.
Se activa en el evento ``blur`` (al salir del campo) y en ``input``
(mientras escribe, con debounce de 300ms).

Reglas de formato validadas:

- Si el identificador contiene ``@``: valida formato de email segun
  el patron ``/^[^\s@]+@[^\s@]+\.[^\s@]+$/``
- Si no contiene ``@``: valida como username — longitud 3-150 chars,
  solo caracteres ``[\w.@+-]`` (mismas reglas de Django)

Retroalimentacion visual:

- **Neutro** (mientras escribe, sin salir del campo): sin indicador
- **Valido** (blur con formato correcto): borde verde + check icon
- **Invalido** (blur con formato incorrecto): borde rojo + mensaje
  inline debajo del campo

El mensaje de error es de formato, nunca revela si el
identificador existe en el sistema.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email con formato valido
   DADO campo identificador con valor "usuario@ejemplo.com"
   CUANDO el visitante sale del campo (blur)
   ENTONCES el campo muestra borde verde y check icon
   Y no hay mensaje de error

   Escenario 2: Email con formato invalido
   DADO campo identificador con valor "no-es-un-email"
   CUANDO el visitante sale del campo
   ENTONCES el campo muestra borde rojo
   Y aparece el mensaje "Ingresa un formato valido: usuario@dominio.com"
   Y el boton de envio permanece habilitado (el bloqueo por formato
   invalido ocurre en el paso 8)

   Escenario 3: Username valido
   DADO campo identificador con valor "juanito123"
   CUANDO el visitante sale del campo
   ENTONCES el campo muestra borde verde (formato de username correcto)

   Escenario 4: Campo vacio al hacer blur
   DADO campo identificador vacio
   CUANDO el visitante sale del campo
   ENTONCES el campo muestra borde rojo con mensaje "Este campo es obligatorio"

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna — validacion de formato, no de negocio
- **RNF aplicables:** RNF-USAB-001 (mensajes de error comprensibles),
  RNF-USAB-002 (retroalimentacion inmediata)
- **Notas:** Esta validacion es del FORMATO solamente. Si el
  identificador tiene formato valido pero no existe en el sistema,
  eso se detecta en el servidor (FR-AUTH-02.09), no aqui.
  Nunca se llama al servidor para comprobar existencia en tiempo real.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.04 (formulario presentado con el campo identificador)
   * - **Requerido por**
     - FR-AUTH-02.06 (validacion final antes del envio al servidor)
   * - **Test**
     - TST-FR-AUTH-02.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 4 de UC-AUTH-02

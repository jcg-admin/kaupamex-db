.. meta::
   :artefacto: FR-LOG-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-01-01:

FR-LOG-01.01: Crear guia de envio para la orden
===============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-01.01
   * - **Nombre**
     - Crear guia de envio para la orden
   * - **UC Origen**
     - UC-LOG 01 CREAR GUIA ENVIO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la guia de envio y cambiar el estado de la orden a SHIPPED CUANDO el admin la registra.

**Descripcion:**

El admin selecciona:

- ``courier``: el transportista a usar
- ``service_type``: STANDARD o EXPRESS
- ``tracking_number`` (opcional en este paso, puede agregarse despues)

Al crear la guia:

- ``ShipmentGuide`` se crea con status=PENDING
- ``Order.status = SHIPPED``
- ``ShipmentGuide.shipped_at = now()``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Guia creada con numero de rastreo
   DADO admin que ingresa courier DHL y tracking 1234567890
   CUANDO crea la guia
   ENTONCES ShipmentGuide queda con tracking_number='1234567890'
   Y Order.status = SHIPPED
   Y el comprador recibe notificacion de envio

   Escenario: Guia creada sin numero de rastreo
   DADO admin que registra la guia sin tracking todavia
   CUANDO crea la guia
   ENTONCES ShipmentGuide.tracking_number queda en blanco
   Y puede actualizarse en UC-LOG-02


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El numero de tracking puede agregarse despues en UC-LOG-02.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 01 CREAR GUIA ENVIO
   * - **Depende de**
     - Orden en PAYMENT_CONFIRMED o IN_PREPARATION
   * - **Requerido por**
     - FR-LOG-02.01 (agregar tracking)
   * - **Test**
     - TST-FR-LOG-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 01 CREAR GUIA ENVIO

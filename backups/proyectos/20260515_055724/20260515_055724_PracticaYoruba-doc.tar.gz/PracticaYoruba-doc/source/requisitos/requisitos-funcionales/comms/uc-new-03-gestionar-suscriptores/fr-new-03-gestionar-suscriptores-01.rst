.. meta::
   :artefacto: FR-NEW-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-new-03-01:

FR-NEW-03.01: Listar y exportar suscriptores activos
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-03.01
   * - **Nombre**
     - Listar y exportar suscriptores activos
   * - **UC Origen**
     - UC-NEW 03 GESTIONAR SUSCRIPTORES
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista de suscriptores activos y permitir la exportacion CUANDO el admin la gestiona.

**Descripcion:**

Lista paginada con: ``email``, ``subscribed_at``, ``is_active``.
Exportacion: CSV con email y fecha de suscripcion (minimo de datos por GDPR).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Exportar suscriptores activos
   DADO admin que solicita la exportacion
   CUANDO se genera
   ENTONCES descarga CSV con email y subscribed_at de los activos solamente

   Escenario: Busqueda por email
   DADO admin que busca 'juan@'
   CUANDO filtra
   ENTONCES aparecen solo los suscriptores con ese patron en el email


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El CSV solo incluye email y fecha — sin datos personales adicionales (principio de minimizacion).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW 03 GESTIONAR SUSCRIPTORES
   * - **Depende de**
     - Suscriptores registrados
   * - **Requerido por**
     - FR-NEW-04.01 (enviar campana a la lista)
   * - **Test**
     - TST-FR-NEW-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NEW 03 GESTIONAR SUSCRIPTORES

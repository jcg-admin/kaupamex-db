.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-04-email-devolucion-procesada
===============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-04-02-encolar-email-devolucion
   fr-not-04-email-devolucion-procesada-01

.. meta::
   :artefacto: FR-REV-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-REV-01.02: Verificar elegibilidad y crear resena en estado pendiente de moderacion
======================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-01.02
   * - **Nombre**
     - Verificar que el comprador recibio el producto, validar contenido y crear Review pendiente
   * - **UC Origen**
     - UC-REV-01: Dejar Resena
   * - **Paso UC**
     - Pasos 2, 3, 10 y 11 del flujo principal
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el comprador recibio el producto,
   que no existe ya una resena suya, y crear la Review en estado
   PENDING_MODERATION CUANDO el comprador envía su valoracion.

**Descripcion:**

**Descripcion:**

El sistema aplica las validaciones en el orden siguiente, parando
en la primera que falle:

1. Verifica que existe un ``OrderItem`` con ``order__user = user``,
   ``product_id`` igual al producto y ``order__status = 'DELIVERED'``.
   Si no existe → ``COMPRA_NO_VERIFICADA``.
2. Verifica que no existe ya un ``Review`` del mismo ``user`` para
   ese ``product_id`` → ``RESENA_DUPLICADA``.
3. Valida que ``rating`` esté entre 1 y 5 inclusive →
   ``CALIFICACION_INVALIDA``.
4. Valida que el cuerpo tenga al menos 10 caracteres →
   ``CUERPO_DEMASIADO_CORTO``.

Si pasa todas las validaciones, crea un ``Review`` con el ``User``,
el ``product_id``, la referencia al ``OrderItem`` entregado, el
``rating``, el título truncado a 100 caracteres, el cuerpo truncado
a 2000 caracteres y ``status = 'PENDING_MODERATION'``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Resena creada correctamente
   DADO comprador que recibio el producto y nunca lo reseno
   CUANDO envía su resena con rating=5 y body de 50 caracteres
   ENTONCES Review creada con status=PENDING_MODERATION
   Y la resena no es publica hasta que el admin la apruebe (FR-REV-03.01)

   Escenario 2: Comprador sin compra del producto
   DADO usuario que no compro el producto intenta resenar
   CUANDO el sistema verifica
   ENTONCES HTTP 403 con COMPRA_NO_VERIFICADA

   Escenario 3: Resena duplicada — protegido
   DADO comprador que ya tiene una resena aprobada del producto
   CUANDO intenta dejar otra
   ENTONCES HTTP 409 con RESENA_DUPLICADA

----

4. Reglas y Restricciones
--------------------------

- **Notas:** La resena solo se crea si el comprador tiene al menos
  una orden en estado DELIVERED con ese producto. No basta con haber
  comprado — tiene que haber recibido el pedido.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV-01: Dejar Resena
   * - **Requerido por**
     - FR-REV-03.01 (el admin modera la resena)
   * - **Test**
     - TST-FR-REV-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 3, 10 y 11 de UC-REV-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

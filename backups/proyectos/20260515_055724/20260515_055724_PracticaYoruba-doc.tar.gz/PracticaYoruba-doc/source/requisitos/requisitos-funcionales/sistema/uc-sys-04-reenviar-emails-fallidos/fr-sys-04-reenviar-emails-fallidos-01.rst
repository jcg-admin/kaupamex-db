.. meta::
   :artefacto: FR-SYS-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-sys-04-01:

FR-SYS-04.01: Reintentar envio de emails fallidos con backoff
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-04.01
   * - **Nombre**
     - Reintentar envio de emails fallidos con backoff
   * - **UC Origen**
     - UC-SYS 04 REENVIAR EMAILS FALLIDOS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-001 ACCOUNTS via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE reintentar el envio de emails fallidos con espera progresiva CUANDO el Actor Tiempo lo dispara.

**Descripcion:**

Tarea periodica (cada 5 minutos):

1. Busca emails con ``status=FAILED AND retry_count < 4``
2. Calcula el tiempo de espera: ``5 * 2^retry_count`` minutos
   (intento 1: 5min, 2: 10min, 3: 20min, 4: no reintenta — FAILED_DEFINITIVO)
3. Si el tiempo de espera paso: reintenta el envio
4. Si falla de nuevo: ``retry_count += 1``
5. Al 4° fallo: ``status = FAILED_DEFINITIVO`` — notifica al admin

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reintento exitoso en el segundo intento
   DADO email con retry_count=1 y la espera de 10 minutos pasada
   CUANDO la tarea lo procesa
   ENTONCES el email se envia exitosamente
   Y status=SENT

   Escenario: Email marcado como FAILED_DEFINITIVO
   DADO email con retry_count=4
   CUANDO la tarea lo evalua
   ENTONCES status=FAILED_DEFINITIVO
   Y el admin recibe una notificacion para gestion manual


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-003 (backoff exponencial)`
- **Notas:** El backoff exponencial protege al proveedor de email de sobrecarga durante sus mantenimientos.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS 04 REENVIAR EMAILS FALLIDOS
   * - **Depende de**
     - Actor Tiempo (tarea periodica)
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-SYS-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-SYS 04 REENVIAR EMAILS FALLIDOS

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-03-ver-estado-envio
=====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-03-02-recuperar-estado-y-url-seguimiento
   fr-log-03-ver-estado-envio-01

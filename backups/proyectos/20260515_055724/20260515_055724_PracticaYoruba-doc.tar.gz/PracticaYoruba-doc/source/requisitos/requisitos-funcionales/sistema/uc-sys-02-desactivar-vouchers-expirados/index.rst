.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-sys-02-desactivar-vouchers-expirados
==================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-sys-02-02-desactivar-vouchers-vencidos
   fr-sys-02-desactivar-vouchers-expirados-01

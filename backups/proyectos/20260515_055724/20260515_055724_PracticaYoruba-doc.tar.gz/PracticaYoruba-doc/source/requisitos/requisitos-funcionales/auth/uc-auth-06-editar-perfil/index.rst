.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-06-editar-perfil
===================================

**5 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-06-01-actualizar-campos-perfil
   fr-auth-06-02-presentar-formulario-edicion
   fr-auth-06-03-validar-campos-modificados
   fr-auth-06-04-validar-y-procesar-avatar
   fr-auth-06-05-registrar-auditoria-cambios

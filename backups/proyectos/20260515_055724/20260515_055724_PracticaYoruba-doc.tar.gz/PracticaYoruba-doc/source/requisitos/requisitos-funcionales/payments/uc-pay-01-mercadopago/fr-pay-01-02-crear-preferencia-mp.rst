.. meta::
   :artefacto: FR-PAY-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-01.02: Crear preferencia de pago en el Gateway de Pago y redirigir
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-01.02
   * - **Nombre**
     - Verificar la orden, crear la preferencia de pago y redirigir al comprador
   * - **UC Origen**
     - UC-PAY-01: Pago con Mercado Pago
   * - **Paso UC**
     - Pasos 2, 3, 4 y 6 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la orden, crear la preferencia de pago
   en el Gateway de Pago usando las credenciales del servidor y
   redirigir al comprador a la interfaz de pago CUANDO el comprador
   selecciona Mercado Pago como metodo.

**Descripcion:**

Las credenciales del Gateway de Pago nunca pasan al frontend (BR-009).
Toda la comunicación con el gateway ocurre en el servidor.

El sistema descifra en memoria el ``SiteSettings.mp_access_token``
(RNF-SEC-002) e inicializa el cliente de MercadoPago. Construye la
preferencia con los ``OrderItem`` de la orden (id, nombre, cantidad y
precio unitario del snapshot), el email del comprador (``User.email`` o
``Order.guest_email`` si es invitado), las URLs de retorno para los
casos éxito/fallo/pendiente, el modo ``auto_return`` y
``external_reference = Order.order_number`` para correlacionar el webhook.

Tras obtener la respuesta del gateway, el sistema crea un registro
``Payment`` con ``gateway = 'MERCADOPAGO'``, ``status = 'PENDING'`` y
el ``preference_id`` recibido. Retorna la ``init_point`` (URL de la
interfaz de pago del gateway) para redirigir al comprador.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Preferencia creada y comprador redirigido
   DADO orden en PENDING_PAYMENT seleccionando Mercado Pago
   CUANDO el sistema crea la preferencia
   ENTONCES se crea Payment con preference_id del gateway
   Y el comprador es redirigido a la URL de pago del gateway
   Y las credenciales del gateway no aparecen en ninguna respuesta al frontend

   Escenario 2: Gateway no disponible — error controlado
   DADO fallo en la API del Gateway de Pago
   CUANDO el sistema intenta crear la preferencia
   ENTONCES HTTP 503 con mensaje "El servicio de pago no esta disponible."
   Y la orden permanece en PENDING_PAYMENT (no se crea Payment)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-009 (credenciales del gateway solo en el servidor)
- **RNF aplicables:** RNF-SEC-002 (cifrado de credenciales en reposo)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-01: Pago con Mercado Pago
   * - **Depende de**
     - FR-ORD-01.03 (la orden fue creada con snapshots)
   * - **Requerido por**
     - FR-PAY-03.01 (webhook de confirmacion del gateway)
   * - **Test**
     - TST-FR-PAY-01.02 (pendiente — mock del cliente del gateway)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 y 6 de UC-PAY-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

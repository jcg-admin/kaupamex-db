.. meta::
   :artefacto: FR-AUTH-02.20
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-20:

================================================================
FR-AUTH-02.20: EX-05 — Manejar fallo interno al emitir credenciales
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.20
   * - **Nombre**
     - EX-05: Retornar 500 generico si falla la emision de tokens JWT
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - EX-05 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Confiabilidad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar un error 500 generico sin exponer la causa
   interna CUANDO falla el proceso de firma o emision de los tokens JWT.

**Descripcion:**

Esta excepción ocurre en los pasos FR-AUTH-02.03 (access token) o
FR-AUTH-02.11 (refresh token). Las causas posibles son:

- La clave de firma del Servicio de Autenticación no está configurada
  o tiene un valor inválido.
- Error interno en el proceso de firma JWT (muy infrecuente).
- Fallo al registrar el token en el repositorio de sesiones activas.

Cuando se produce este error, el sistema:

- Retorna HTTP 500 al cliente con el mensaje genérico «Ocurrió un
  error interno. Intenta de nuevo.», sin exponer la causa interna.
- No modifica la cuenta del usuario — ningún dato del usuario
  queda afectado.
- No incrementa el contador de intentos fallidos del origen —
  el fallo es del sistema, no del usuario.
- Registra el error con nivel CRITICAL en el log del servidor
  para que el administrador lo trate como incidente prioritario.

Este error es extremadamente infrecuente en producción. Si ocurre
de forma repetida indica un problema de configuración del Servicio
de Autenticación que debe resolverse como incidente crítico.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: SIGNING_KEY invalida
   DADO SIMPLE_JWT.SIGNING_KEY configurada con un valor invalido
   CUANDO el sistema intenta firmar el access token
   ENTONCES TokenBackendError es capturado
   Y respuesta HTTP 500 con {"codigo_error": "ERROR_SISTEMA"}
   Y el body NO contiene el mensaje interno de simplejwt
   Y el log registra el error con nivel CRITICAL

   Escenario 2: La cuenta del usuario no queda bloqueada
   DADO fallo en la emision de tokens (EX-05)
   CUANDO el usuario lo reintenta (asumiendo que el admin corrio el problema)
   ENTONCES el nuevo intento se procesa normalmente
   Y el usuario puede autenticarse si las credenciales son correctas
   Y el contador de intentos de la IP no fue incrementado por el fallo anterior

   Escenario 3: Diferencia con EX-02 (repositorio)
   DADO EX-05 (fallo en JWT) vs EX-02 (fallo en BD)
   CUANDO ambos ocurren
   ENTONCES ambos retornan 500 con el mismo mensaje generico al cliente
   Y la diferencia esta en el log: EX-02 es OperationalError, EX-05 es TokenBackendError
   Y el administrador puede diagnosticar por el tipo de excepcion en el log

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-AVAIL-001 (disponibilidad — este error
  afecta la disponibilidad del servicio de autenticacion)
- **Notas:** Este error es extremadamente raro en produccion.
  Si ocurre repetidamente es una señal de configuracion incorrecta
  de SIGNING_KEY y debe tratarse como incidente critico.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Detectado en**
     - FR-AUTH-02.03 y FR-AUTH-02.11 (emision de tokens)
   * - **Requerido por**
     - El administrador monitorea el log de nivel CRITICAL
   * - **RNF**
     - RNF-AVAIL-001
   * - **Test**
     - TST-FR-AUTH-02.20 (pendiente — mock de error del Servicio de Autenticacion)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-05 de UC-AUTH-02

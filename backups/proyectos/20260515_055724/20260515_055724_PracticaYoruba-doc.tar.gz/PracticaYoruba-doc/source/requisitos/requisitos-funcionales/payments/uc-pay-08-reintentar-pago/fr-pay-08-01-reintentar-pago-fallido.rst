.. meta::
   :artefacto: FR-PAY-08.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-08-01:

FR-PAY-08.01: Crear nuevo intento de pago para orden fallida
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-08.01
   * - **Nombre**
     - Crear nuevo intento de pago para orden fallida
   * - **UC Origen**
     - UC-PAY-08: Reintentar pago
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-007 PAYMENT + MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE permitir crear un nuevo intento de pago CUANDO el pago anterior fallo y la orden sigue en PENDING_PAYMENT.

**Descripcion:**

Condiciones para reintentar:

- ``Order.status = PENDING_PAYMENT``
- El Payment anterior tiene ``status = FAILED`` o ``status = CANCELLED``
- La orden no supero el timeout de pago (UC-SYS-01)

Proceso:

1. Verifica elegibilidad
2. El comprador puede seleccionar el mismo gateway u otro diferente
3. Crea una nueva preferencia/orden en el gateway seleccionado
4. Crea un nuevo registro ``Payment`` (el anterior queda como FAILED en el historial)
5. Redirige al comprador al nuevo flujo de pago

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reintento con el mismo gateway
   DADO orden en PENDING_PAYMENT con Payment FAILED en MP
   CUANDO el comprador reintenta con MP
   ENTONCES se crea una nueva preferencia en MP
   Y el Payment anterior queda como FAILED en el historial

   Escenario: Reintento con gateway diferente
   DADO comprador que quiere intentar con PayPal en lugar de MP
   CUANDO selecciona PayPal
   ENTONCES se crea la orden en PayPal
   Y ambos intentos (MP fallido y PayPal pendiente) quedan en historial

   Escenario: Orden ya expirada
   DADO orden cuyo timeout ya vencio (UC-SYS-01 la cancelo)
   CUANDO se intenta reintentar
   ENTONCES error 422: ORDEN_CANCELADA
   Y se sugiere crear una nueva orden desde el catalogo


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PERF-002 (tiempo de respuesta escritura)`
- **Notas:** El sistema no limita el numero de reintentos, pero UC-SYS-01 cancela la orden si el timeout vence.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-08: Reintentar pago
   * - **Depende de**
     - FR-PAY-05.01 (estado FAILED verificado)
   * - **Requerido por**
     - FR-PAY-03.01 o FR-PAY-04.01 (webhook confirma el nuevo intento)
   * - **Test**
     - TST-FR-PAY-08.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-08

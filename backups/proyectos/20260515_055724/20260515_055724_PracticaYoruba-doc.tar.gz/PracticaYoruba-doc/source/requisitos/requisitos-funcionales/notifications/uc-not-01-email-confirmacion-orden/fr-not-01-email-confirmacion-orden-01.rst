.. meta::
   :artefacto: FR-NOT-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-01-01:

FR-NOT-01.01: Enviar email de confirmacion de orden
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-01.01
   * - **Nombre**
     - Enviar email de confirmacion de orden
   * - **UC Origen**
     - UC-NOT 01 EMAIL CONFIRMACION ORDEN
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar el email de confirmacion CUANDO la orden es creada y el pago confirmado.

**Descripcion:**

Plantilla ``confirmacion_orden`` con:

- ``order_number``, ``order_date``
- Lista de items con nombre, variante, cantidad, precio
- Subtotal, descuento, envio, total
- Direccion de envio
- Estimado de entrega

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email enviado tras pago confirmado
   DADO webhook de pago aprobado
   CUANDO FR-PAY-03.02 confirma la orden
   ENTONCES se encola el email de confirmacion
   Y el comprador lo recibe en su correo

   Escenario: Fallo en el envio — reintento
   DADO proveedor de email no disponible
   CUANDO se intenta enviar
   ENTONCES el envio queda en cola para UC-SYS-04
   Y se reintentara con backoff exponencial


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-003`
- **Notas:** El email se encola, no se envia sincrono. Si el proveedor falla, UC-SYS-04 reintenta.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 01 EMAIL CONFIRMACION ORDEN
   * - **Depende de**
     - FR-ORD-01.03 (orden creada) o FR-PAY-03.02 (pago confirmado)
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 01 EMAIL CONFIRMACION ORDEN

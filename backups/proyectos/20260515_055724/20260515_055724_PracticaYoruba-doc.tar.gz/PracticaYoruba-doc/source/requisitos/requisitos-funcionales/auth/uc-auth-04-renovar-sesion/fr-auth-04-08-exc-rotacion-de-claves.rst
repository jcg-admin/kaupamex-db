.. meta::
   :artefacto: FR-AUTH-04.08
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-04.08: EX-03 — Rotacion de claves de firma
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.08
   * - **Nombre**
     - EX-03: Invalidar sesion si la clave de firma fue rotada por seguridad
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - EX-03 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS (la clave de firma del Servicio de Autenticacion)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Seguridad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE invalidar la sesion y solicitar reautenticacion
   CUANDO la clave de firma JWT fue rotada y el token del usuario
   tiene la firma de la clave anterior.

**Descripcion:**

La rotacion de ``la clave de firma del Servicio de Autenticacion`` ocurre cuando:

- Se sospecha que la clave fue comprometida
- Como parte de una politica de seguridad programada

Al rotar la clave, todos los tokens firmados con la clave anterior
quedan invalidos — su firma no puede ser verificada con la nueva clave.

Cuando esto ocurre:

1. El intento de decodificar el token lanza un error de firma invalida
2. El sistema lo trata como un token invalido (no como expirado)
3. HTTP 401 con ``codigo_error: SESION_INVALIDA``
4. El cliente redirige al usuario al login

Procedimiento de rotacion de clave (operacion del administrador):

1. Cambiar ``la clave de firma del Servicio de Autenticacion`` en ``la configuracion del entorno de produccion``
2. Reiniciar los procesos del servidor web
3. Todos los usuarios activos seran redirigidos al login en su
   proxima renovacion (maximo 15 minutos para los que tienen
   access token vigente)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token con clave anterior tras rotacion
   DADO SIGNING_KEY rotada en el servidor
   CUANDO un usuario con token de la clave anterior intenta renovar
   ENTONCES HTTP 401 con {"codigo_error": "SESION_INVALIDA",
   "mensaje": "Tu sesion no es valida. Inicia sesion de nuevo."}
   Y el usuario es redirigido al login

   Escenario 2: Todos los usuarios reconectados en < 15 minutos
   DADO rotacion de clave ejecutada a las 14:00
   CUANDO se mide el tiempo hasta que todos los usuarios se re-autentican
   ENTONCES a las 14:15 (1 ciclo de access token) todos los usuarios
   con acceso activo necesitaron re-autenticarse
   Y el sistema vuelve a operar normalmente con la nueva clave

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (la rotacion de claves es una practica
  de seguridad recomendada aunque disruptiva)
- **Notas:** La rotacion de claves es un evento extraordinario.
  En operacion normal no deberia ocurrir. Si se necesita invalidar
  sesiones de un usuario especifico, es preferible usar la blacklist
  (logout masivo del admin) que rotar la clave global.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Detectado en**
     - FR-AUTH-04.02 (verificacion de la firma del token)
   * - **ADR relacionado**
     - ADR-003 (JWT con el Servicio de Autenticacion)
   * - **Test**
     - TST-FR-AUTH-04.08 (pendiente — cambio manual de SIGNING_KEY en test)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-03 de UC-AUTH-04

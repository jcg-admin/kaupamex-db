.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-07-solicitar-reembolso
========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-07-01-verificar-elegibilidad-reembolso
   fr-pay-07-02-validar-y-solicitar-reembolso

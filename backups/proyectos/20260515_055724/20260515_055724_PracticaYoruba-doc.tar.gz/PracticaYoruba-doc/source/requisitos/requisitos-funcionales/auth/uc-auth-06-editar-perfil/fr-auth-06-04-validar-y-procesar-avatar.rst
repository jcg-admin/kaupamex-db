.. meta::
   :artefacto: FR-AUTH-06.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-06.04: Validar formato del avatar y reemplazar el anterior
===================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-06.04
   * - **Nombre**
     - Validar formato/tamanio del avatar nuevo y eliminar el anterior al guardar
   * - **UC Origen**
     - UC-AUTH-06: Editar Perfil
   * - **Paso UC**
     - Pasos 7 y 9 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Validacion + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el archivo de avatar, procesar la imagen
   y reemplazar el avatar anterior CUANDO el usuario sube un nuevo avatar.

**Descripcion:**

**Validacion del avatar (paso 7):**

Verificaciones en el servidor usando la libreria de procesamiento de imagenes:

- **Formato:** JPEG, PNG o WebP. Cualquier otro formato → 400 AVATAR_INVALIDO
- **Tamaño del archivo:** <= ``SiteSettings.avatar_max_size_mb`` (default: 5MB)
- **Dimensiones minimas:** 200x200 pixeles (para buena presentacion)
- **Contenido:** verificar que el archivo es realmente una imagen y no
  un ejecutable con extension cambiada. El sistema intenta abrir e
  inspeccionar el archivo con la librería de procesamiento de imágenes.
  Si el archivo no es una imagen válida (``IOError`` o ``SyntaxError``
  al leer su estructura), el sistema rechaza la solicitud con
  ``AVATAR_INVALIDO``.

**Procesamiento del avatar (paso 9):**

1. Redimensionar si supera 800x800 pixeles (preservando aspect ratio)
2. Convertir a WebP para optimizar el almacenamiento
3. Guardar con el path: ``avatars/user_{pk}_{timestamp}.webp``
4. Eliminar el avatar anterior si existia
5. Actualizar ``User.avatar`` con el nuevo path

La eliminacion del avatar anterior es parte del mismo proceso
para no acumular archivos huerfanos.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Avatar JPEG valido — procesado y guardado
   DADO archivo JPEG de 2MB y 1024x768 pixels
   CUANDO el usuario lo sube
   ENTONCES se convierte a WebP y se guarda en el storage
   Y el avatar anterior (si habia) es eliminado
   Y User.avatar apunta al nuevo archivo

   Escenario 2: Formato invalido — error especifico
   DADO archivo PDF renombrado a .jpg
   CUANDO el sistema intenta abrirlo con Pillow
   ENTONCES IOError/SyntaxError → HTTP 400
   Y el body incluye {"codigo_error": "AVATAR_INVALIDO",
   "mensaje": "El archivo no es una imagen valida. Usa JPEG, PNG o WebP."}
   Y el avatar anterior NO se modifica

   Escenario 3: Imagen demasiado grande — redimensionada automaticamente
   DADO imagen de 3000x2000 pixels y 4MB
   CUANDO se procesa
   ENTONCES se redimensiona a 800x533 (misma proporcion)
   Y el archivo resultante pesa menos que el original

   Escenario 4: Error en almacenamiento — datos textuales guardados igual
   DADO fallo en el storage al guardar el avatar nuevo
   CUANDO ocurre EX-02
   ENTONCES los datos textuales (nombre, telefono) se guardaron correctamente
   Y el avatar anterior permanece sin cambios
   Y el usuario recibe un mensaje de que el avatar no pudo actualizarse

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (validacion de archivos en servidor
  para prevenir upload de archivos maliciosos)
- **Notas:** La validacion de archivos SIEMPRE ocurre en el servidor.
  La validacion en cliente (tipo MIME del browser) es solo UX.
  Un atacante puede enviar un ejecutable con extension .jpg — el validador de imagenes
  lo detectara al intentar abrirlo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-06: Editar Perfil
   * - **Depende de**
     - FR-AUTH-06.03 (campos de texto validados)
   * - **Requerido por**
     - FR-AUTH-06.01 (persistir todos los cambios incluyendo el avatar)
   * - **Test**
     - TST-FR-AUTH-06.04 (pendiente — test con mock del procesador de imagenes y archivos reales)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 7 y 9 de UC-AUTH-06
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Logica de validacion de contenido preservada en texto.

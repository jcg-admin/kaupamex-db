.. meta::
   :artefacto: FR-WISH-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-WISH-03.02: Verificar stock y agregar el producto de la wishlist al carrito
===============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-03.02
   * - **Nombre**
     - Verificar disponibilidad, agregar al carrito y opcionalmente eliminar de la wishlist
   * - **UC Origen**
     - UC-WISH-03: Mover de Wishlist al Carrito
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-011 WISHLIST + MOD-005 CART
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la disponibilidad de stock, agregar el
   producto al carrito de sesion y opcionalmente eliminar el item
   de la wishlist CUANDO el comprador mueve un item al carrito.

**Descripcion:**

La operación es una composición de FR-CART-01.01 (agregar al carrito)
con la eliminación opcional de la wishlist.

El sistema recupera el ``WishlistItem`` del usuario por su
identificador. Invoca la lógica de agregar al carrito de FR-CART-01.01
con ``product_id``, ``variant_id`` y cantidad 1. Si el parámetro
``remove_from_wishlist`` está activo (valor por defecto), elimina el
``WishlistItem`` tras el agregado al carrito. Si el producto no tiene
stock, no se agrega al carrito y el ``WishlistItem`` permanece con
indicador ``OUT_OF_STOCK``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto movido al carrito y eliminado de la lista
   DADO item en la wishlist con stock disponible
   CUANDO el comprador hace clic en "Agregar al carrito"
   ENTONCES el producto esta en el carrito
   Y el item desaparece de la wishlist (remove_from_wishlist=True por defecto)

   Escenario 2: Sin stock — no se agrega al carrito
   DADO item en la wishlist con stock=0
   CUANDO el comprador hace clic
   ENTONCES HTTP 409 con STOCK_INSUFICIENTE
   Y el item permanece en la wishlist con availability=OUT_OF_STOCK

   Escenario 3: Mover sin eliminar de la wishlist
   DADO comprador que quiere agregar al carrito pero mantener en la lista
   CUANDO POST con remove_from_wishlist=false
   ENTONCES el producto esta en el carrito
   Y el item sigue en la wishlist

----

4. Reglas y Restricciones
--------------------------

- **Notas:** Esta operacion reutiliza FR-CART-01.01 completamente.
  No duplica la logica de agregar al carrito.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH-03: Mover Wishlist al Carrito
   * - **Depende de**
     - FR-CART-01.01 (agregar al carrito)
   * - **Test**
     - TST-FR-WISH-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-WISH-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pro-02-editar-voucher-admin
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pro-02-02-editar-y-auditar-cambio
   fr-pro-02-editar-voucher-admin-01

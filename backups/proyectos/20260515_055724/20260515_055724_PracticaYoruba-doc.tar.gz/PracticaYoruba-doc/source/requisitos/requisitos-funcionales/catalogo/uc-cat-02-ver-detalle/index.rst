.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-02-ver-detalle
================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-02-01-retornar-ficha-producto
   fr-cat-02-02-recuperar-ficha-completa-producto

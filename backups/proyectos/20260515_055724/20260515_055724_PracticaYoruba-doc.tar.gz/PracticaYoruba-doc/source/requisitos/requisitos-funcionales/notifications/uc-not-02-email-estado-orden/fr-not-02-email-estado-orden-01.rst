.. meta::
   :artefacto: FR-NOT-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-02-01:

FR-NOT-02.01: Enviar email de actualizacion de estado
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-02.01
   * - **Nombre**
     - Enviar email de actualizacion de estado
   * - **UC Origen**
     - UC-NOT 02 EMAIL ESTADO ORDEN
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar email al comprador CUANDO el estado de la orden cambia.

**Descripcion:**

Eventos que disparan este email:

- Orden en preparacion: plantilla ``orden_en_preparacion``
- Orden enviada: plantilla ``orden_enviada`` con tracking
- Orden entregada: plantilla ``orden_entregada``
- Orden cancelada: plantilla ``orden_cancelada`` con el motivo

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email de orden enviada con tracking
   DADO orden que pasa a SHIPPED con tracking_number
   CUANDO se dispara la notificacion
   ENTONCES el comprador recibe el email con el numero de rastreo y la URL

   Escenario: Comprador sin notificaciones de estado activas
   DADO comprador que desactivo notificaciones de estado en UC-NOT-06
   CUANDO el estado cambia
   ENTONCES el email se omite silenciosamente


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Las preferencias de notificacion del comprador se verifican antes de enviar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 02 EMAIL ESTADO ORDEN
   * - **Depende de**
     - Cambio de estado de la orden
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 02 EMAIL ESTADO ORDEN

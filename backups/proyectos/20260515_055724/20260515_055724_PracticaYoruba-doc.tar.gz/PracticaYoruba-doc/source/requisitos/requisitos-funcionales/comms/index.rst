.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — COMMS
===============================

**11 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-com-01-formulario-contacto
     - 1
   * - uc-com-02-ver-mensajes-contacto
     - 1
   * - uc-com-03-responder-mensaje-contacto
     - 1
   * - uc-new-01-suscribirse
     - 1
   * - uc-new-02-desuscribirse
     - 1
   * - uc-new-03-gestionar-suscriptores
     - 1
   * - uc-new-04-enviar-campana-newsletter
     - 1
   * - uc-qst-01-hacer-pregunta
     - 1
   * - uc-qst-02-ver-preguntas
     - 1
   * - uc-qst-03-responder-pregunta-admin
     - 1
   * - uc-qst-04-moderar-preguntas-admin
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-com-01-formulario-contacto/index
   uc-com-02-ver-mensajes-contacto/index
   uc-com-03-responder-mensaje-contacto/index
   uc-new-01-suscribirse/index
   uc-new-02-desuscribirse/index
   uc-new-03-gestionar-suscriptores/index
   uc-new-04-enviar-campana-newsletter/index
   uc-qst-01-hacer-pregunta/index
   uc-qst-02-ver-preguntas/index
   uc-qst-03-responder-pregunta-admin/index
   uc-qst-04-moderar-preguntas-admin/index

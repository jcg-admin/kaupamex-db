.. meta::
   :artefacto: FR-CART-04.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CART-04.04: Persistir el cupon en sesion y confirmar el descuento
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-04.04
   * - **Nombre**
     - Asociar el cupon validado al carrito y presentar el desglose de descuento
   * - **UC Origen**
     - UC-CART-04: Aplicar Cupon
   * - **Paso UC**
     - Pasos 10 y 11 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER + MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE guardar el cupon en la sesion del carrito y
   retornar el desglose completo con el descuento aplicado CUANDO
   el cupon ha sido validado y el beneficio calculado.

**Descripcion:**

El cupón se almacena en la sesión — no se incrementa ``Voucher.current_uses``
en este momento. El contador se incrementa al confirmar la orden
(FR-ORD-01.05), porque el visitante puede abandonar el carrito
sin completar la compra.

El sistema persiste en ``session['cart_voucher']`` los campos:
código del cupón, identificador primario del ``Voucher``, tipo de
descuento (``PERCENTAGE``, ``FIXED`` o ``FREE_SHIPPING``), valor del
descuento y el importe calculado para el carrito actual.

Respuesta HTTP 200:

.. code-block:: json

   {
     "cupon_aplicado": {
       "codigo": "BIENVENIDO20",
       "tipo": "PERCENTAGE",
       "valor": 20.0,
       "descuento_calculado": 340.00
     },
     "carrito": {
       "subtotal": 1700.00,
       "descuento": 340.00,
       "total_con_descuento": 1360.00,
       "items_count": 2
     }
   }

Si ya habia un cupon y el visitante confirmo el reemplazo (Alt. E):
el cupon anterior se elimina de la sesion y se aplica el nuevo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cupon de porcentaje aplicado
   DADO cupon BIENVENIDO20 de 20% y carrito con subtotal $1700
   CUANDO se aplica
   ENTONCES cart_voucher en sesion tiene calculated_discount=340.00
   Y la respuesta muestra subtotal=1700, descuento=340, total=1360

   Escenario 2: Cupon de monto fijo aplicado
   DADO cupon AHORRA50 de $50 fijo y carrito con subtotal $300
   CUANDO se aplica
   ENTONCES calculated_discount = min(50, 300) = 50
   Y total_con_descuento = 250

   Escenario 3: Cupon persiste en sesion entre requests
   DADO cupon aplicado en el carrito
   CUANDO el visitante navega a otra pagina y vuelve al carrito
   ENTONCES el cupon sigue aplicado (esta en la sesion)
   Y el descuento se muestra automaticamente en GET /api/v1/cart/

   Escenario 4: Cupon NO incrementa current_uses hasta el checkout
   DADO cupon aplicado al carrito
   CUANDO se revisa Voucher.current_uses en la BD
   ENTONCES current_uses no cambio (sigue siendo el mismo)
   Y el incremento ocurrira en FR-ORD-01.05 al confirmar la orden

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-008 (Voucher poliformico — el calculo del
  beneficio usa el Strategy Pattern segun discount_type)
- **Notas:** El descuento no puede exceder el subtotal del carrito.
  ``calculated_discount = min(beneficio_calculado, subtotal_carrito)``

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-04: Aplicar Cupon
   * - **Depende de**
     - FR-CART-04.01 (beneficio calculado), FR-CART-04.03 (cupon validado)
   * - **Requerido por**
     - FR-ORD-01.05 (al hacer checkout: incrementar current_uses)
   * - **Test**
     - TST-FR-CART-04.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 10 y 11 de UC-CART-04

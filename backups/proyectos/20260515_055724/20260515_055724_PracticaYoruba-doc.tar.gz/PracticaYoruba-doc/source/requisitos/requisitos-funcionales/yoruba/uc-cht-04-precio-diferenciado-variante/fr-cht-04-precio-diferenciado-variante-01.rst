.. meta::
   :artefacto: FR-CHT-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cht-04-01:

FR-CHT-04.01: Configurar precio diferenciado por variante
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-04.01
   * - **Nombre**
     - Configurar precio diferenciado por variante
   * - **UC Origen**
     - UC-CHT 04 PRECIO DIFERENCIADO VARIANTE
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE persistir el precio diferenciado de la variante CUANDO el admin lo configura.

**Descripcion:**

``ProductVariant.price_override = nuevo_precio``

Si ``price_override`` es null: la variante usa el precio base del producto.
Si ``price_override`` no es null: ese precio se usa en lugar del precio base.

``effective_price() = price_override if price_override is not None else product.price``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Precio diferenciado mayor al base
   DADO producto con precio base 100 y variante Grande
   CUANDO el admin fija price_override=150 en Grande
   ENTONCES Grande muestra 150 y las otras variantes muestran 100

   Escenario: Eliminar el precio diferenciado
   DADO variante con price_override=150
   CUANDO el admin lo elimina (null)
   ENTONCES la variante vuelve a usar el precio base del producto


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El price_override puede ser menor al precio base (variante economica) o mayor (variante premium).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT 04 PRECIO DIFERENCIADO VARIANTE
   * - **Depende de**
     - FR-CHT-03.01 (variante existente)
   * - **Requerido por**
     - FR-CHT-01.01 (la ficha muestra el nuevo precio)
   * - **Test**
     - TST-FR-CHT-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CHT 04 PRECIO DIFERENCIADO VARIANTE

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rpt-02-ver-reporte-productos
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rpt-02-02-calcular-ranking-productos
   fr-rpt-02-ver-reporte-productos-01

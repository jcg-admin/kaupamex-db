.. meta::
   :artefacto: FR-AUTH-06.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-06.05: Registrar auditoria y confirmar actualizacion
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-06.05
   * - **Nombre**
     - Registrar los campos modificados en auditoria y confirmar al usuario
   * - **UC Origen**
     - UC-AUTH-06: Editar Perfil
   * - **Paso UC**
     - Pasos 10 y 11 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — ProfileChangeLog)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Auditoria + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar los campos modificados en el log de auditoria
   y confirmar la actualizacion al usuario CUANDO los cambios han sido
   persistidos exitosamente.

**Descripcion:**

El registro de auditoria de cambios de perfil captura:

- Los campos que cambiaron (no sus valores — privacidad)
- El timestamp del cambio
- La IP desde la que se realizaron los cambios

El sistema crea un registro ``ProfileChangeLog`` con los siguientes
datos: referencia al ``User`` modificado, la lista de nombres de
campos que cambiaron (``changed_fields``), la dirección IP de la
solicitud —obtenida de ``HTTP_X_FORWARDED_FOR`` o ``REMOTE_ADDR``
si el encabezado proxy no está presente— y el timestamp del momento
del cambio.

Los valores anteriores y nuevos NO se guardan en el log publico
(por privacidad del usuario). Solo se registra QUE cambio, no
el valor anterior ni el nuevo.

Respuesta de confirmacion (HTTP 200):

.. code-block:: json

   {
     "mensaje": "Tu perfil fue actualizado exitosamente.",
     "updated_fields": ["first_name", "phone"],
     "profile": { "...datos actualizados del perfil..." }
   }

La respuesta incluye el perfil actualizado para que el frontend
no necesite hacer una segunda llamada a FR-AUTH-05.02.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Auditoria con campos correctos
   DADO actualizacion de first_name y phone
   CUANDO se registra en el log
   ENTONCES ProfileChangeLog tiene changed_fields=["first_name", "phone"]
   Y NO tiene los valores anteriores ni los nuevos (solo los nombres)

   Escenario 2: Confirmacion incluye perfil actualizado
   DADO actualizacion exitosa
   CUANDO se retorna la respuesta
   ENTONCES HTTP 200 con el perfil completo actualizado
   Y el frontend no necesita hacer GET al perfil de nuevo

   Escenario 3: Fallo en auditoria no revierte el guardado
   DADO error al insertar en ProfileChangeLog
   CUANDO falla el INSERT
   ENTONCES los cambios del perfil permanecen guardados
   Y el usuario recibe la confirmacion de exito de todas formas
   Y el fallo se registra en django.log nivel ERROR

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel en ProfileChangeLog)
- **RNF aplicables:** RNF-PROC-002 (auditoria de cambios en datos de usuario)
- **Notas:** La privacidad del usuario es prioritaria — el log
  registra QUE campos cambiaron pero no los valores. Esto permite
  detectar cambios masivos sospechosos sin exponer el contenido.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-06: Editar Perfil
   * - **Depende de**
     - FR-AUTH-06.01 (cambios persistidos en la BD)
   * - **Requerido por**
     - Ninguno — es el ultimo paso del flujo principal de UC-AUTH-06
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-06.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 10 y 11 de UC-AUTH-06
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Bloque JSON conservado — es el contrato de la respuesta HTTP.

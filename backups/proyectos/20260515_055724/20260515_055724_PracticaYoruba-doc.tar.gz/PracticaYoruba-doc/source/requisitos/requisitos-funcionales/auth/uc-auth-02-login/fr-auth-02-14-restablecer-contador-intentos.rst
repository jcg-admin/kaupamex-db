.. meta::
   :artefacto: FR-AUTH-02.14
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-14:

======================================================
FR-AUTH-02.14: Restablecer contador de intentos fallidos
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.14
   * - **Nombre**
     - Resetear a cero el contador de intentos fallidos de la IP tras login exitoso
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 19 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — via Django cache framework)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE restablecer a cero el contador de intentos fallidos
   de la IP de origen CUANDO el acceso fue exitoso.

**Descripcion:**

Tras un acceso exitoso, el sistema elimina del Servicio de Cache
el registro del contador de intentos fallidos asociado al origen
de la solicitud. Eliminar el registro es equivalente a ponerlo en
cero: cuando el Servicio de Rate Limiting consulta el contador de
un origen que no tiene registro activo, lo interpreta como cero.

El restablecimiento aplica al origen de la solicitud, no al usuario.
Si el mismo usuario inicia sesión desde un origen diferente, el
contador de ese otro origen no se ve afectado.

**Limitación conocida y aceptada:**

El FR-AUTH-02.01 verifica el contador al inicio de cada solicitud
de login. Este FR lo restablece al final de un login exitoso. Un
actor malicioso que consiga alternar intentos fallidos con accesos
exitosos —usando credenciales válidas obtenidas previamente para
restablecer el contador periódicamente— puede evadir el bloqueo por
origen. Esta situación queda registrada en auditoría (FR-AUTH-02.13)
pero no es bloqueada automáticamente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Contador reseteado tras login exitoso
   DADO IP con 3 intentos fallidos previos
   CUANDO el login es exitoso
   ENTONCES el contador de la IP vuelve a 0
   Y el siguiente intento fallido (si hubiera) empieza desde 1

   Escenario 2: Contador de otra IP no se ve afectado
   DADO IP-A con 3 intentos fallidos y IP-B con 2 intentos fallidos
   CUANDO IP-A hace login exitoso
   ENTONCES solo el contador de IP-A se resetea
   Y el contador de IP-B permanece en 2

   Escenario 3: Login exitoso en IP sin intentos previos
   DADO IP sin intentos fallidos registrados
   CUANDO hace login exitoso
   ENTONCES el cache.delete es un no-op (no hay nada que borrar)
   Y no se genera ningun error

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — este FR es parte del
  ciclo de vida del contador definido en BR-015)
- **Notas:** El restablecimiento es por IP, no por usuario.
  Si el mismo usuario inicia sesion desde otra IP, el contador
  de esa IP no se resetea.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.13 (auditoria del acceso registrada)
   * - **Requerido por**
     - FR-AUTH-02.15 (retornar tokens y datos al cliente)
   * - **BR**
     - BR-015
   * - **Test**
     - TST-FR-AUTH-02.14 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 19 de UC-AUTH-02

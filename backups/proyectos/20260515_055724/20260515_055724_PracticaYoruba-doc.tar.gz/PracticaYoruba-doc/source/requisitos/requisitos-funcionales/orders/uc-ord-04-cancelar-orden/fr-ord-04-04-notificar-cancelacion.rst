.. meta::
   :artefacto: FR-ORD-04.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-04.04: Notificar la cancelacion al usuario y confirmar
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-04.04
   * - **Nombre**
     - Enviar email de confirmacion de cancelacion y retornar el estado actualizado
   * - **UC Origen**
     - UC-ORD-04: Cancelar Orden
   * - **Paso UC**
     - Pasos 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + notificaciones
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Comunicacion + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar un email de confirmacion de cancelacion al
   usuario y retornar el estado actualizado de la orden CUANDO la
   cancelacion ha sido ejecutada exitosamente.

**Descripcion:**

El email de cancelacion se encola de forma asincrona (no bloquea
la respuesta HTTP). Usa la plantilla ``orden_cancelada.html`` con:

- Numero de orden
- Items cancelados con sus precios snapshot
- Total que fue o sera reembolsado (si habia pago)
- Tiempo estimado de reembolso (si aplica)
- Instrucciones de soporte

La respuesta HTTP 200 incluye el estado actualizado de la orden
para que el frontend no necesite hacer un GET adicional.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email de cancelacion encolado
   DADO cancelacion exitosa
   CUANDO se encola el email
   ENTONCES el Procesador Periodico procesara el email en <= 5 minutos
   Y el usuario recibe la confirmacion en su bandeja de entrada

   Escenario 2: Fallo del servicio de email — cancelacion persiste
   DADO fallo al encolar el email de cancelacion
   CUANDO el sistema detecta el fallo
   ENTONCES la cancelacion sigue siendo valida (no se revierte)
   Y el administrador ve el email pendiente en el panel de emails fallidos

   Escenario 3: Respuesta HTTP inmediata sin esperar el email
   DADO cancelacion que desencadena el envio de email
   CUANDO el usuario recibe la respuesta HTTP
   ENTONCES el status_code es 200 con la orden cancelada
   Y el email llega unos minutos despues (asincrono)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-003 (backoff exponencial para reintento
  del email si el primer intento falla)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-04: Cancelar Orden
   * - **Depende de**
     - FR-ORD-04.03 (cancelacion ejecutada)
   * - **Relacionado con**
     - UC-NOT-02 (email de estado de orden)
   * - **Test**
     - TST-FR-ORD-04.04 (pendiente — mock del Procesador Periodico)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 7-8 de UC-ORD-04

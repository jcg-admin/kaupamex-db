.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inv-05-importar-productos-csv
===========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inv-05-02-procesar-csv-y-crear-borradores
   fr-inv-05-importar-productos-csv-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-06-ver-historial-pagos
========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-06-01-retornar-historial-movimientos
   fr-pay-06-02-listar-historial-pagos

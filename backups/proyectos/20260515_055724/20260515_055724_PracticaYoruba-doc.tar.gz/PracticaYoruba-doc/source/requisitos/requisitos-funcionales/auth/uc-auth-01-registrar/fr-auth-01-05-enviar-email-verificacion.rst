.. meta::
   :artefacto: FR-AUTH-01.05
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-01-05:

===================================================
FR-AUTH-01.05: Enviar email de verificacion
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-01.05
   * - **Nombre**
     - Generar token y enviar email de verificacion de cuenta
   * - **UC Origen**
     - UC-AUTH-01: Registrar cuenta
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar un token firmado y enviarlo por email
   CUANDO la cuenta es creada con exito.

**Descripcion:**

Proceso:

1. Se genera un token firmado con HMAC-SHA256 que contiene
   ``user_id`` + ``email`` + ``timestamp`` de expiracion
2. El token tiene una validez de **24 horas**
3. Se encola el envio de email usando UC-INC-03 con la plantilla
   ``email_verificacion``
4. El email contiene exactamente un enlace de verificacion:
   ``https://ojayoruba.com/verificar-email/?token=<TOKEN>``
5. Si el servicio de email no esta disponible, el envio se encola
   para reintento via UC-SYS-04. La cuenta queda creada de todas
   formas.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO cuenta nueva creada con is_active=False
   CUANDO se envia el email
   ENTONCES el comprador recibe el enlace en su correo

   Escenario 1: Token de un solo uso
   DADO token de verificacion enviado
   CUANDO el comprador hace clic y verifica exitosamente
   ENTONCES el token queda invalidado
   Y un segundo clic en el mismo enlace retorna error de token expirado

   Escenario 2: Token expirado
   DADO token generado hace mas de 24 horas
   CUANDO el comprador intenta usarlo
   ENTONCES se informa que el enlace expiro
   Y se ofrece la opcion de solicitar uno nuevo

   Escenario 3: Email no disponible al crear cuenta
   DADO proveedor de email no responde al momento de registro
   CUANDO se crea la cuenta
   ENTONCES la cuenta se crea igualmente con is_active=False
   Y el envio se encola para reintento (UC-SYS-04)
   Y el comprador ve mensaje de que el email llegara en unos minutos

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **Notas:** El rate limiting de reenvio de verificacion (max 3 por hora)
  se aplica en UC-AUTH-10, no en este FR.
  Este FR solo maneja el envio inicial al registrarse.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-01: Registrar cuenta
   * - **Depende de**
     - FR-AUTH-01.04 (cuenta creada)
   * - **Requerido por**
     - FR-AUTH-10.01 (verificar email con el token recibido)
   * - **Include**
     - UC-INC-03 (enviar email con plantilla)
   * - **RNF**
     - RNF-AVAIL-003 (backoff exponencial en reintentos)
   * - **Test**
     - TST-FR-AUTH-01.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-01

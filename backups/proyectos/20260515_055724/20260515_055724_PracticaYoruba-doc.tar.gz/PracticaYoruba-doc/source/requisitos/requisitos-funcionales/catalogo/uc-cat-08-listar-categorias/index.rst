.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-08-listar-categorias
======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-08-02-servir-arbol-categorias-con-cache
   fr-cat-08-listar-categorias-01-retornar-arbol-de-categorias-a

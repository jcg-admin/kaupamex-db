.. meta::
   :artefacto: FR-CART-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-02-01:

===================================================
FR-CART-02.01: Recuperar el carrito activo
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-02.01
   * - **Nombre**
     - Obtener o crear el carrito activo del visitante o comprador
   * - **UC Origen**
     - UC-CART-02: Ver carrito
   * - **Paso UC**
     - Pasos 2-3 del flujo principal
   * - **Modulo**
     - MOD-005 CART via UC-INC-02
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar el carrito activo del actor
   CUANDO solicita ver su carrito, creando uno vacio si no existe.

**Descripcion:**

Logica de recuperacion (patron definido en UC-INC-02):

- **Visitante anonimo**: busca carrito por ``session_key``
  de la sesion Django. Si no existe crea uno nuevo.
- **Comprador autenticado**: busca ``Cart`` por ``user_id``.
  Si no existe crea uno nuevo asociado al usuario.

El carrito retornado incluye:

- Lista de items con: ``variant_id``, ``product_name``,
  ``variant_label``, ``image_url`` (imagen primaria del producto),
  ``unit_price``, ``quantity``, ``subtotal_item``
- Items cuyo producto fue desactivado se marcan con
  ``is_available: false`` pero NO se eliminan automaticamente
- Subtotales calculados por ``FR-CART-01.03``

----

3. Criterio de Aceptacion
--------------------------

::

   DADO cualquier actor (anonimo o autenticado)
   CUANDO solicita GET /api/v1/cart/
   ENTONCES recibe su carrito activo

   Escenario 1: Carrito con items
   DADO comprador con 3 items en su carrito
   CUANDO consulta
   ENTONCES los 3 items aparecen con precio, cantidad e imagen

   Escenario 2: Carrito vacio
   DADO comprador sin carrito previo
   CUANDO consulta
   ENTONCES respuesta 200 con items: [] y totales en 0

   Escenario 3: Item con producto desactivado
   DADO item en carrito cuyo producto fue desactivado
   CUANDO se recupera el carrito
   ENTONCES el item aparece con is_available: false
   Y un mensaje sugiere eliminarlo del carrito

   Escenario 4: Aislamiento de carritos
   DADO comprador A con carrito propio
   CUANDO consulta GET /api/v1/cart/
   ENTONCES solo ve SU carrito, nunca el de otro comprador

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion para anonimos),
  BR-004 (carrito sin login permitido)
- **Notas:** El carrito de un visitante anonimo se vincula a la cuenta
  del comprador al hacer login (FR-CART-06.01).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-02: Ver carrito
   * - **Depende de**
     - Ninguno (punto de entrada)
   * - **Requerido por**
     - FR-CART-02.02 (calcular totales del carrito recuperado)
   * - **Include**
     - UC-INC-02 (recuperar carrito de sesion)
   * - **BR**
     - BR-003, BR-004
   * - **RNF**
     - RNF-SEC-003 (aislamiento)
   * - **Test**
     - TST-FR-CART-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-02

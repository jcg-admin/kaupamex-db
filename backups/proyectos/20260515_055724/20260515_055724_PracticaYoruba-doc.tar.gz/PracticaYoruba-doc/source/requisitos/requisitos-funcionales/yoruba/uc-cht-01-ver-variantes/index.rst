.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cht-01-ver-variantes
==================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cht-01-02-recuperar-variantes-activas
   fr-cht-01-ver-variantes-01

.. meta::
   :artefacto: FR-AUTH-01.04
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-01-04:

=================================================
FR-AUTH-01.04: Crear la cuenta en estado inactivo
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-01.04
   * - **Nombre**
     - Persistir la nueva cuenta con is_active=False
   * - **UC Origen**
     - UC-AUTH-01: Registrar cuenta
   * - **Paso UC**
     - Paso 4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear el registro de usuario con ``is_active=False``
   CUANDO los datos son validos y unicos.

**Descripcion:**

Proceso de creacion:

1. ``User.objects.create_user(username, email, password)``
   — Django hashea la password automaticamente (nunca texto plano)
2. Se establece ``is_active = False`` — la cuenta no puede iniciar
   sesion hasta verificar el email
3. Se establece ``date_joined = now()``
4. La operacion es atomica — si falla el envio del email (FR-AUTH-01.05)
   la cuenta queda creada de todas formas y el usuario puede solicitar
   reenvio desde el login

----

3. Criterio de Aceptacion
--------------------------

::

   DADO datos validos y unicos
   CUANDO el sistema crea el usuario
   ENTONCES existe en BD con is_active=False

   Escenario 1: Password nunca en texto plano
   DADO cualquier password ingresada
   CUANDO se almacena
   ENTONCES User.password contiene el hash (empieza con "pbkdf2_sha256$")
   Y el texto plano no existe en ningun campo de la BD

   Escenario 2: Cuenta inactiva no puede iniciar sesion
   DADO cuenta recien creada con is_active=False
   CUANDO intenta hacer login
   ENTONCES el sistema rechaza con mensaje de email no verificado

   Escenario 3: date_joined correcto
   DADO cuenta creada
   CUANDO se inspecciona
   ENTONCES date_joined es el momento exacto de la creacion

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — el ID se asigna
  automaticamente por la base de datos)
- **Notas:** Django usa el algoritmo de hash con SHA-256 para hashear passwords
  por defecto. No se usa ninguna otra libreria de hashing.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-01: Registrar cuenta
   * - **Depende de**
     - FR-AUTH-01.03 (unicidad verificada)
   * - **Requerido por**
     - FR-AUTH-01.05 (enviar email de verificacion)
   * - **BR**
     - BR-013
   * - **Test**
     - TST-FR-AUTH-01.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-01

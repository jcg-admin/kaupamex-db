.. meta::
   :artefacto: FR-NEW-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-new-02-02:

===========================================================================
FR-NEW-02.02: Desuscribir inmediatamente por token sin requerir sesión
===========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-02.02
   * - **Nombre**
     - Identificar al suscriptor por el token del enlace, marcarlo como
       UNSUBSCRIBED de forma inmediata y registrar el motivo si lo indica
   * - **UC Origen**
     - UC-NEW-02: Desuscribirse del Newsletter
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE localizar al suscriptor por el token único del
   enlace de desuscripción, marcarlo como ``UNSUBSCRIBED`` de forma
   inmediata y presentar la confirmación con la opción de revertir
   el cambio si fue accidental, sin requerir ningún tipo de
   autenticación.

**Descripcion:**

La desuscripción se activa desde el enlace que acompaña a cada
email de newsletter. El enlace contiene un token único por suscriptor
que permite identificarlo sin necesidad de que tenga sesión activa.

El sistema distingue tres situaciones al procesar el token:

- **Token válido y suscriptor activo.** El estado del suscriptor
  pasa a ``UNSUBSCRIBED`` de forma inmediata. El cambio entra en
  vigor antes de la siguiente campaña que se encole. Si el suscriptor
  indicó un motivo de desuscripción (Alt. C del UC), éste se registra
  junto al evento para que el admin pueda analizar tendencias.

- **Token válido pero suscriptor ya desuscrito (Alt. B).** El sistema
  muestra la misma pantalla de confirmación de desuscripción sin
  generar ningún error. Esto cubre el caso del doble clic o del
  uso repetido del mismo enlace. El suscriptor ve que su solicitud
  fue atendida.

- **Token inválido o que no existe (EX-01).** El sistema informa al
  suscriptor que el enlace no es válido y le ofrece acceder al sitio
  para gestionar sus preferencias.

Tras la desuscripción, la pantalla de confirmación ofrece siempre
la opción de volver a suscribirse por si el clic fue accidental. Si
el suscriptor elige revertirlo, se inicia el flujo de UC-NEW-01 desde
el paso 6 (doble opt-in de nuevo, sin activación automática).

El token de desuscripción no caduca — a diferencia del token de
confirmación de suscripción, este debe funcionar siempre para
garantizar que el suscriptor pueda salir de la lista en cualquier
momento, incluso desde un email antiguo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Desuscripción exitosa desde el enlace del email
   DADO suscriptor activo con token "tok_abc123" en su email
   CUANDO accede a /newsletter/unsubscribe/?token=tok_abc123
   ENTONCES el estado del suscriptor pasa a UNSUBSCRIBED de inmediato
   Y la pantalla muestra "Te dimos de baja de nuestra lista"
   Y se ofrece el enlace "¿Fue un error? Vuelve a suscribirte"

   Escenario 2: Doble clic en el enlace — comportamiento silencioso
   DADO suscriptor que ya estaba UNSUBSCRIBED y usa el mismo enlace
   CUANDO accede de nuevo a /newsletter/unsubscribe/?token=tok_abc123
   ENTONCES el sistema muestra la misma pantalla de confirmación
   Y no genera error ni registro duplicado de desuscripción

   Escenario 3: Desuscripción con motivo opcional registrado
   DADO suscriptor que selecciona "Demasiado frecuente" antes de confirmar
   CUANDO envía el formulario con el motivo
   ENTONCES el estado pasa a UNSUBSCRIBED
   Y el motivo queda registrado junto al evento para análisis del admin

   Escenario 4: Token inválido — aviso sin exponer datos
   DADO enlace con un token que no existe en el sistema
   CUANDO el suscriptor intenta usarlo
   ENTONCES el sistema muestra "Este enlace no es válido"
   Y ofrece acceder al sitio para gestionar las preferencias
   Y no revela si el token perteneció a otro suscriptor (EX-02)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-010 (la desuscripción no requiere autenticación;
  el token del enlace es la única credencial necesaria)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 300ms — la operación debe
  ser perceptiblemente inmediata para el suscriptor), RNF-SEC-003
  (el sistema no revela a quién pertenecía un token inválido, igual
  que el patrón de aislamiento aplicado en órdenes y perfiles)
- **Notas:** Los tokens de desuscripción no tienen fecha de expiración.
  El motivo de desuscripción es un campo opcional que el suscriptor
  puede ignorar; la desuscripción ocurre con o sin motivo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW-02: Desuscribirse del Newsletter
   * - **Depende de**
     - FR-NEW-01.02 (el token de desuscripción se crea al registrar
       la suscripción)
   * - **Requerido por**
     - FR-NEW-03.02 (el admin puede ver el estado UNSUBSCRIBED
       en la gestión de suscriptores)
   * - **Relacionado con**
     - FR-NEW-04.02 (al encolar una campaña se excluye a los
       suscriptores con estado UNSUBSCRIBED)
   * - **Test**
     - TST-FR-NEW-02.02 (pendiente — verificar que el doble uso
       del mismo token no crea un segundo registro de desuscripción;
       verificar que el token inválido no revela la existencia de
       otros suscriptores)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: tres situaciones documentadas en prosa,
       4 escenarios BDD con datos concretos, motivo opcional, token
       sin caducidad, trazabilidad completa

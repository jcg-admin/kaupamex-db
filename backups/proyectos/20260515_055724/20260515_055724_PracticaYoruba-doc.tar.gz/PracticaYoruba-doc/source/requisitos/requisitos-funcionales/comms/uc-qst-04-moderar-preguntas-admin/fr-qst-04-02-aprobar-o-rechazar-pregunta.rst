.. meta::
   :artefacto: FR-QST-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-qst-04-02:

=============================================================================
FR-QST-04.02: Moderar la pregunta, registrar la decisión y notificar al autor
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-04.02
   * - **Nombre**
     - Aprobar o rechazar la pregunta, registrar la decisión con el
       admin responsable y notificar al autor si dejó email
   * - **UC Origen**
     - UC-QST-04: Moderar Preguntas (Admin)
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la pregunta según la decisión
   del admin, registrar la acción en auditoría con el motivo cuando
   se rechaza, y notificar al autor de forma asíncrona si proporcionó
   email CUANDO el admin modera una pregunta de la cola.

**Descripcion:**

La cola de moderación agrupa las preguntas con estado
``PENDING_MODERATION`` ordenadas de más antigua a más reciente,
de modo que el equipo atiende las preguntas en el orden en que
llegaron. El sistema muestra el producto asociado a cada pregunta
para que el admin tenga contexto sin necesidad de navegar a la ficha.

El admin tiene dos decisiones posibles:

**Aprobar.** La pregunta pasa a estado ``PENDING_ANSWER``, lo que
la hace visible en la cola de respuestas del UC-QST-03. La pregunta
no es pública todavía en este momento: solo pasa a ser visible para
cualquier visitante cuando el admin la responda.

**Rechazar.** El motivo de rechazo es obligatorio para que quede
constancia de la razón. Los motivos habituales son: contenido
inapropiado, pregunta en idioma no soportado, duplicado de una
pregunta ya respondida, o datos personales en el texto. La pregunta
pasa a estado ``REJECTED`` y no será visible en ningún momento.

En ambos casos el sistema crea un registro en el historial de
moderación con la decisión, el admin responsable y el momento exacto.
Si el autor dejó su email, el sistema encola un aviso asíncrono
informándole del resultado; el aviso no bloquea la respuesta al admin.

**Alt. C — Edición del texto antes de aprobar:**

El admin puede corregir errores ortográficos o reformular la pregunta
para que sea más clara antes de aprobarla. El texto original se
conserva en el historial de moderación; el texto publicado es el
editado. Esta capacidad está sujeta a los mismos permisos que la
moderación general.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Pregunta aprobada — pasa a cola de respuestas
   DADO pregunta "¿Esta sopera incluye los accesorios de consagración?"
   en estado PENDING_MODERATION
   CUANDO el admin la aprueba
   ENTONCES QuestionAnswer.status = PENDING_ANSWER
   Y la pregunta aparece en la cola de UC-QST-03
   Y todavía no es visible para los visitantes de la ficha del producto

   Escenario 2: Pregunta rechazada — motivo registrado
   DADO pregunta con lenguaje ofensivo en el texto
   CUANDO el admin la rechaza con motivo "contenido inapropiado"
   ENTONCES QuestionAnswer.status = REJECTED
   Y el registro de moderación guarda el motivo y el admin responsable
   Y la pregunta no será visible en ningún momento

   Escenario 3: Edición del texto antes de aprobar
   DADO pregunta con nombre propio del autor en el texto que conviene
   eliminar por privacidad
   CUANDO el admin edita el texto y aprueba
   ENTONCES la versión publicada (PENDING_ANSWER) tiene el texto editado
   Y el historial de moderación conserva el texto original
   Y ambos textos tienen la fecha y el admin responsable

   Escenario 4: Cola vacía al intentar moderar — mensaje claro
   DADO admin que accede a la cola de moderación cuando otro admin
   ya procesó la última pregunta
   CUANDO el sistema consulta las preguntas PENDING_MODERATION
   ENTONCES HTTP 200 con items=[] y el mensaje
   "No hay preguntas pendientes de moderación en este momento"

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 300ms por operación de
  moderación), RNF-PROC-002 (auditoría obligatoria: admin, decisión,
  motivo y timestamp)
- **Notas:** El motivo de rechazo es obligatorio cuando la decisión
  es rechazar; no se admite el campo vacío. Para la aprobación no
  se requiere motivo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST-04: Moderar Preguntas
   * - **Depende de**
     - FR-QST-01.02 (las preguntas llegan a PENDING_MODERATION
       desde el formulario del visitante)
   * - **Requerido por**
     - FR-QST-03.02 (solo las preguntas PENDING_ANSWER pueden
       ser respondidas por el admin)
   * - **Incluye**
     - UC-INC-03 (notificación al autor si dejó email)
   * - **Test**
     - TST-FR-QST-04.02 (pendiente — verificar que el rechazo
       sin motivo es rechazado por el sistema; verificar que la
       notificación no se encola si el autor no dejó email)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: ordenamiento de la cola, dos decisiones
       en prosa detallada, edición con doble texto, EX-02 cola vacía,
       4 escenarios BDD, trazabilidad completa

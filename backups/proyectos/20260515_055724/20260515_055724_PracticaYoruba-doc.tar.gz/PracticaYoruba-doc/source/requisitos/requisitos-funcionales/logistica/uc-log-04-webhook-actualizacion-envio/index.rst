.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-04-webhook-actualizacion-envio
================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-04-02-procesar-evento-courier
   fr-log-04-webhook-actualizacion-envio-01

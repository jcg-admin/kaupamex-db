.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-02-ver-carrito
=================================

**4 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-02-01-recuperar-carrito-activo
   fr-cart-02-02-calcular-totales
   fr-cart-02-03-verificar-disponibilidad-items
   fr-cart-02-04-presentar-vista-y-nfr

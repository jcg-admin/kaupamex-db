.. meta::
   :artefacto: FR-CART-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-06-01:

==============================================
FR-CART-06.01: Fusionar carritos al sincronizar
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-06.01
   * - **Nombre**
     - Fusionar carrito de sesion con carrito de cuenta al hacer login
   * - **UC Origen**
     - UC-CART-06: Sincronizar carrito
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-005 CART — metodo Cart.merge()
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE fusionar el carrito de sesion con el carrito
   de la cuenta CUANDO el comprador inicia sesion teniendo ambos.

**Descripcion:**

Algoritmo de fusion idempotente (``Cart.merge(session_cart)``):

Para cada CartItem del carrito de sesion:

1. Busca si existe un CartItem con la misma variante en el carrito de cuenta
2. Si existe: ``account_item.quantity += session_item.quantity``
   (se suman las cantidades, no se reemplaza)
3. Si no existe: el item de sesion se mueve al carrito de cuenta
   cambiando su FK ``cart`` al carrito de cuenta

Tras la fusion:

- El carrito de sesion queda vacio y se marca para eliminacion
- El voucher del carrito de sesion tiene prioridad sobre el
  de la cuenta (el mas reciente gana)
- La fusion es atomica (transaccion)

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador con carrito de sesion y carrito de cuenta
   CUANDO inicia sesion
   ENTONCES los items se fusionan correctamente

   Escenario 1: Items distintos en ambos carritos
   DADO sesion: [producto A x1] y cuenta: [producto B x2]
   CUANDO se fusionan
   ENTONCES resultado: [producto A x1, producto B x2]
   Y el carrito de sesion queda vacio

   Escenario 2: Mismo producto en ambos carritos
   DADO sesion: [producto A x1] y cuenta: [producto A x2]
   CUANDO se fusionan
   ENTONCES resultado: [producto A x3]
   Y no hay items duplicados

   Escenario 3: Fusion idempotente
   DADO error en la primera fusion dejando estado inconsistente
   CUANDO se reintenta la fusion
   ENTONCES el resultado final es el mismo que una fusion exitosa
   Y no se duplican cantidades

   Escenario 4: Voucher en ambos carritos
   DADO sesion con voucher VERANO20 y cuenta con voucher PROMO10
   CUANDO se fusionan
   ENTONCES el carrito resultante tiene VERANO20 (el de sesion gana)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003, BR-004
- **Notas:** La fusion suma cantidades pero no verifica stock en este
  momento. La verificacion de stock ocurre al agregar al carrito
  individualmente y al hacer checkout.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-06: Sincronizar carrito
   * - **Depende de**
     - FR-CART-05.01 (carrito de sesion identificado)
   * - **Requerido por**
     - FR-CART-02.01 (carrito unificado disponible para consulta)
   * - **Test**
     - TST-FR-CART-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-06

.. meta::
   :artefacto: FR-CHT-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cht-04-02:

=================================================================================
FR-CHT-04.02: Configurar y eliminar el precio diferenciado de una variante
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-04.02
   * - **Nombre**
     - Validar y persistir el precio diferenciado de la variante, permitir
       su eliminación para que vuelva al precio base del producto, y reflejar
       el precio correcto en la ficha al seleccionar la variante
   * - **UC Origen**
     - UC-CHT-04: Precio Diferenciado de Variante
   * - **Paso UC**
     - Pasos 5, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que el precio diferenciado de la variante
   es un valor mayor que cero, persistirlo vinculado a esa variante
   específica, y hacer que la ficha del producto muestre ese precio
   cuando el visitante selecciona la variante CUANDO el admin configura
   el precio diferenciado.

**Descripcion:**

Algunos productos tienen presentaciones de distinto tamaño o capacidad
cuyo precio varía respecto al precio base. Por ejemplo, una sopera en
tamaño Pequeña puede costar $650 y en tamaño Grande $1200, siendo el
precio base del producto $850 para la Mediana. El precio diferenciado
permite reflejar esta realidad sin crear productos separados en el
catálogo.

**Validación del precio (paso 5).**
El precio diferenciado debe ser un valor numérico positivo, expresado
sin IVA (BR-001). El sistema rechaza valores negativos y también el
cero, porque un precio de cero tiene un significado especial —indica
que la variante no tiene costo adicional respecto al precio base, pero
eso se configura de otra forma— y debe quedar sin precio diferenciado
en lugar de tener un precio de cero.

**Eliminación del precio diferenciado (Alt. A).**
Cuando el admin elimina el precio diferenciado de una variante, esa
variante vuelve automáticamente a usar el precio base del producto.
No se requiere ninguna otra acción. En la ficha del producto, el
visitante verá el precio base al seleccionar esa variante.

**Precio inferior al base permitido (Alt. B).**
El sistema permite que el precio diferenciado sea menor al precio
base del producto. Esto puede corresponder a una variante más pequeña
que tiene un precio menor, lo cual es completamente válido. La
interfaz del visitante lo muestra claramente como precio de esa
variante específica.

**Conflicto con voucher activo (EX-02).**
Si un voucher de porcentaje está activo y el precio diferenciado de
la variante resulta ser menor al precio que daría el voucher aplicado
al precio base, el sistema aplica siempre el precio más bajo al
comprador. No se bloquea la configuración del precio diferenciado
por esta razón.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Precio diferenciado configurado — visible al seleccionar la variante
   DADO variante "Grande" de "Sopera de Yemoja" que hasta ahora usaba
   el precio base de $850
   CUANDO el admin configura el precio diferenciado de $1200
   ENTONCES el precio queda vinculado a la variante Grande
   Y cuando el visitante selecciona Grande en la ficha, el precio
   mostrado cambia de $850 a $1200 de forma inmediata
   Y cuando elige Mediana, vuelve a mostrar $850 (precio base)

   Escenario 2: Precio diferenciado eliminado — vuelve al precio base
   DADO variante "Grande" con precio diferenciado de $1200 configurado
   CUANDO el admin elimina el precio diferenciado de esa variante
   ENTONCES la variante Grande vuelve a mostrar $850 (precio base)
   Y el cambio es inmediato en la siguiente carga de la ficha

   Escenario 3: Precio diferenciado menor al precio base — configuración válida
   DADO precio base del producto de $850 y variante "Pequeña"
   CUANDO el admin configura $650 como precio de "Pequeña" (Alt. B)
   ENTONCES el sistema acepta la configuración sin error
   Y el visitante ve $650 al seleccionar Pequeña en la ficha
   Y no hay ningún mensaje de alerta por ser inferior al base

   Escenario 4: Precio negativo — rechazado con error específico
   DADO admin que ingresa -50 como precio diferenciado
   CUANDO el sistema valida el valor
   ENTONCES HTTP 400 con {"errors": {"price":
   "El precio diferenciado debe ser un valor mayor que cero."}}
   Y ningún cambio se persiste

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (el precio diferenciado se expresa sin
  IVA, igual que el precio base del producto; el IVA se calcula en
  el checkout)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 300ms para el guardado)
- **Notas:** El precio diferenciado coexiste con los descuentos de
  campaña del módulo DASHBOARD. Si hay un descuento de porcentaje
  activo para el producto, se aplica sobre el precio diferenciado
  de la variante seleccionada, no sobre el precio base.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT-04: Precio Diferenciado de Variante
   * - **Depende de**
     - FR-CHT-03.02 (la variante debe existir antes de configurar
       su precio)
   * - **Requerido por**
     - FR-CHT-01.02 (la ficha del producto incluye el precio de la
       variante en la respuesta para actualización inmediata en el
       cliente), FR-CHT-02.02 (el servidor valida el precio de la
       variante al agregar al carrito)
   * - **Test**
     - TST-FR-CHT-04.02 (pendiente — verificar que eliminar el precio
       diferenciado hace que la variante use el precio base;
       verificar que un precio negativo es rechazado)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — detalles de implementación expuestos,
       secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: cero rechazado, eliminación vuelve al
       base, precio menor al base permitido, EX-02 voucher, 4 escenarios
       BDD con datos concretos

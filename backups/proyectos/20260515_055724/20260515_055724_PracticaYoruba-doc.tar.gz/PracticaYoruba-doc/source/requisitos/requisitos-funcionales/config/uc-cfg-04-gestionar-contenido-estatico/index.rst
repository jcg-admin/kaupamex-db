.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cfg-04-gestionar-contenido-estatico
=================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cfg-04-02-editar-paginas-estaticas
   fr-cfg-04-gestionar-contenido-estatico-01

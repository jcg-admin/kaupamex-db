.. meta::
   :artefacto: FR-CAT-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-03.02: Normalizar el termino y ejecutar la busqueda de texto completo
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-03.02
   * - **Nombre**
     - Normalizar el termino de busqueda y buscar en nombre, descripcion y categoria
   * - **UC Origen**
     - UC-CAT-03: Buscar Productos
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE normalizar el termino de busqueda, ejecutar la
   busqueda de texto completo sobre los campos indexados y ordenar
   los resultados por relevancia CUANDO el visitante confirma la busqueda.

**Descripcion:**

**Normalizacion del termino (paso 5):**

El sistema elimina los espacios externos del término recibido y
normaliza los espacios internos (múltiples espacios consecutivos se
reducen a uno). Si el término resultante tiene menos de 2 caracteres,
el sistema rechaza la solicitud con ``TERMINO_MUY_CORTO`` sin ejecutar
ninguna consulta al repositorio. El término se trunca a 100 caracteres
si supera ese límite. Los caracteres especiales del idioma Yoruba
(tonos, diacríticos) se preservan sin transliteración — el motor de
búsqueda del repositorio los indexa correctamente.

**Busqueda de texto completo (paso 6):**

El sistema filtra productos con ``Product.is_active = True`` y
``Product.is_published = True``, y aplica la búsqueda sobre tres
campos indexados: ``Product.name``, ``Product.short_description``
y ``Category.name`` de la categoría asociada al producto. La
búsqueda es insensible a mayúsculas. Los resultados se ordenan por
nombre de producto.

Si el motor de búsqueda de texto completo no está disponible (EX-01),
el sistema degrada la búsqueda a coincidencia sobre ``Product.name``
únicamente, sin ranking de relevancia.

**Paginacion (paso 8):** igual que UC-CAT-01, max 20 por pagina.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Busqueda con termino valido — resultados encontrados
   DADO termino "Yemoja" con 3 productos que lo contienen en nombre o descripcion
   CUANDO se ejecuta la busqueda
   ENTONCES HTTP 200 con 3 productos paginados
   Y cada producto tiene highlighted_term con el termino marcado en el nombre

   Escenario 2: Termino muy corto — rechazo antes de buscar
   DADO termino "Y" (1 caracter)
   CUANDO el sistema normaliza
   ENTONCES HTTP 400 con {"codigo_error": "TERMINO_MUY_CORTO",
   "mensaje": "Ingresa al menos 2 caracteres para buscar."}
   Y no se ejecuta ninguna consulta al repositorio

   Escenario 3: Sin resultados — sugerencias de navegacion
   DADO termino "productoxyz" sin coincidencias
   CUANDO se ejecuta la busqueda
   ENTONCES HTTP 200 con total_results=0
   Y la respuesta incluye sugerencias de accion para el frontend

   Escenario 4: Motor de busqueda degradado — busqueda basica
   DADO fallo en el indice de busqueda de texto completo
   CUANDO el sistema detecta el fallo
   ENTONCES degrada a busqueda por nombre exacto (icontains)
   Y retorna resultados parciales con aviso de busqueda degradada

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms para la busqueda
  incluyendo la normalizacion y la consulta al repositorio)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-03: Buscar Productos
   * - **Depende de**
     - FR-CAT-03.01 (termino recibido del visitante)
   * - **Requerido por**
     - FR-CAT-03.03 (presentar resultados al visitante)
   * - **Test**
     - TST-FR-CAT-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5-8 de UC-CAT-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminados 2 bloques code-block Python.
       Logica de normalizacion, campos de busqueda y degradacion preservadas.

.. meta::
   :artefacto: FR-AUTH-03.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-03-03:

====================================================
FR-AUTH-03.03: Registrar el cierre de sesion en auditoria
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.03
   * - **Nombre**
     - Crear registro de auditoria con tipo CIERRE_SESION tras el logout exitoso
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — AccessAuditLog)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Auditoria

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear un registro de auditoria del cierre de sesion
   CUANDO el refresh token ha sido invalidado exitosamente.

**Descripcion:**

El registro captura:

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Campo
     - Valor
   * - ``user_id``
     - ID del usuario que cerro sesion (extraido del payload del token)
   * - ``event_type``
     - ``CIERRE_SESION`` (o ``CIERRE_SESION_MASIVO`` si es Alt. C)
   * - ``result``
     - ``EXITOSO``
   * - ``ip_address``
     - IP de origen del request de logout
   * - ``jti``
     - JWT ID del refresh token invalidado (trazabilidad)
   * - ``timestamp``
     - ``timezone.now()`` en UTC

Este registro permite:

- Detectar logouts inesperados (posible robo de sesion)
- Correlacionar el inicio y cierre de sesion por jti
- Detectar patrones de cierre masivo (Alt. C) que podrian indicar
  que el usuario sospecha que su cuenta fue comprometida

El fallo en el registro de auditoria NO impide que el logout
sea exitoso — el token ya fue invalidado en FR-AUTH-03.01.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Registro de auditoria creado correctamente
   DADO logout exitoso con token invalidado
   CUANDO se crea el registro en el paso 5
   ENTONCES existe un AccessAuditLog con:
   - event_type = CIERRE_SESION
   - jti = ID del token invalidado
   - ip_address = IP del request
   - timestamp = momento del logout

   Escenario 2: Cierre masivo registrado diferenciado (Alt. C)
   DADO usuario que selecciona cerrar sesion en todos los dispositivos
   CUANDO se invalidan todos los refresh tokens
   ENTONCES el registro tiene event_type = CIERRE_SESION_MASIVO
   Y indica cuantos tokens fueron invalidados

   Escenario 3: Fallo de auditoria no bloquea el logout
   DADO error al insertar en AccessAuditLog
   CUANDO falla el INSERT
   ENTONCES el logout se considera exitoso de todas formas
   Y el token ya fue invalidado en FR-AUTH-03.01
   Y el fallo se registra en django.log nivel ERROR

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — created_at automatico)
- **RNF aplicables:** RNF-PROC-002 (auditoria de operaciones criticas)
- **Notas:** El fallo de auditoria es aceptable porque la seguridad
  (token invalidado) tiene prioridad sobre el registro. Un logout
  donde falla la auditoria es mejor que uno donde el token no se
  invalida por esperar a que la auditoria funcione.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Depende de**
     - FR-AUTH-03.01 (token invalidado en la blacklist)
   * - **Requerido por**
     - FR-AUTH-03.04 (confirmar al usuario que la sesion cerro)
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-03.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 5 de UC-AUTH-03

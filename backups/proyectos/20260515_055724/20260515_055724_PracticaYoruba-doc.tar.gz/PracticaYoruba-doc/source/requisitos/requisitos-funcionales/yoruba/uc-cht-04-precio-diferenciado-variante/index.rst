.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cht-04-precio-diferenciado-variante
=================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cht-04-02-gestionar-precio-variante
   fr-cht-04-precio-diferenciado-variante-01

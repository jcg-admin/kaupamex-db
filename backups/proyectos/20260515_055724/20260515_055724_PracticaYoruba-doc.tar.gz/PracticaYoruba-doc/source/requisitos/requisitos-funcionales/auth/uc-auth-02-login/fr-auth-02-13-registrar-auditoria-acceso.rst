.. meta::
   :artefacto: FR-AUTH-02.13
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-13:

======================================================
FR-AUTH-02.13: Registrar el acceso exitoso en auditoria
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.13
   * - **Nombre**
     - Crear registro de auditoria con identificador, origen y resultado EXITOSO
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 18 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — AccessAuditLog)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Auditoria

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear un registro de auditoria completo
   CUANDO el acceso es exitoso.

**Descripcion:**

El registro de auditoria captura:

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Campo
     - Valor
   * - ``user_id``
     - ID del usuario que accedio
   * - ``identificador``
     - El email o username usado (normalizado)
   * - ``ip_address``
     - IP de origen del request (via ``X-Forwarded-For`` o ``REMOTE_ADDR``)
   * - ``user_agent``
     - User-Agent del request (primeros 200 chars)
   * - ``event_type``
     - ``ACCESO_EXITOSO``
   * - ``result``
     - ``EXITOSO``
   * - ``timestamp``
     - ``timezone.now()`` en UTC
   * - ``jti``
     - JWT ID del access token emitido (para trazabilidad)

**Campos que NUNCA aparecen en el registro:**

- La contraseña ingresada (ni su hash)
- El access token completo
- El refresh token

El registro de auditoria tambien se crea para accesos FALLIDOS,
con ``event_type`` diferente segun el motivo del fallo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Registro de auditoria creado tras acceso exitoso
   DADO autenticacion completamente exitosa
   CUANDO se ejecuta el paso 18
   ENTONCES existe un registro AccessAuditLog con:
   - event_type = ACCESO_EXITOSO
   - ip_address = IP del request
   - timestamp = momento del acceso (UTC)
   - contraseña = ausente (nunca guardada)

   Escenario 2: IP de origen correcta con proxy
   DADO request que pasa por un proxy (Apache mod_proxy)
   CUANDO se captura la IP de origen
   ENTONCES se usa el header X-Forwarded-For si esta presente
   Y se toma la primera IP de la lista (la mas cercana al cliente)

   Escenario 3: Fallo en auditoria no bloquea el acceso
   DADO error al crear el registro de auditoria
   CUANDO falla el INSERT en AccessAuditLog
   ENTONCES el login ya completado sigue siendo valido
   Y los tokens ya emitidos son validos
   Y el fallo se registra en el log del servidor para revision

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — el modelo
  AccessAuditLog hereda ``created_at`` automatico)
- **RNF aplicables:** RNF-PROC-002 (auditoria de operaciones criticas)
- **Notas:** El acceso al historial de auditoria es exclusivo para
  el administrador. El usuario normal solo ve su ``last_login``,
  no el log de auditoria completo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.12 (last_login actualizado)
   * - **Requerido por**
     - FR-AUTH-02.14 (restablecer contador de intentos)
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-02.13 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 18 de UC-AUTH-02

.. meta::
   :artefacto: FR-LOG-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-02-01:

FR-LOG-02.01: Registrar numero de rastreo en la guia
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-02.01
   * - **Nombre**
     - Registrar numero de rastreo en la guia
   * - **UC Origen**
     - UC-LOG 02 REGISTRAR NUMERO RASTREO
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el tracking_number de la guia y notificar al comprador CUANDO el admin lo registra.

**Descripcion:**

``ShipmentGuide.tracking_number = tracking_number``
``ShipmentGuide.tracking_url`` se construye si el courier tiene URL base configurada:
``courier.tracking_url_template.format(tracking=tracking_number)``
Tras actualizar: encola notificacion al comprador con el numero y la URL de rastreo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Tracking registrado exitosamente
   DADO guia sin tracking y admin que ingresa '1Z999AA10123456784'
   CUANDO se guarda
   ENTONCES tracking_number queda en la guia
   Y el comprador recibe email con el numero y el enlace de rastreo

   Escenario: Tracking actualizado por correccion
   DADO tracking incorrecto que el courier corrijo
   CUANDO el admin actualiza
   ENTONCES el nuevo tracking reemplaza al anterior
   Y el comprador recibe nueva notificacion con el numero correcto


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La URL de rastreo se construye automaticamente si el courier tiene template configurado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 02 REGISTRAR NUMERO RASTREO
   * - **Depende de**
     - FR-LOG-01.01 (guia creada)
   * - **Requerido por**
     - FR-LOG-03.01 (el comprador puede rastrear)
   * - **Test**
     - TST-FR-LOG-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 02 REGISTRAR NUMERO RASTREO

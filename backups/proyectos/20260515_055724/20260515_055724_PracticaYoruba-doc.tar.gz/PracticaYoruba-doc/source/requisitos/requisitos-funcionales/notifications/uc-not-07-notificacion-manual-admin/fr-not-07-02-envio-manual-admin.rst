.. meta::
   :artefacto: FR-NOT-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-07-02:

================================================================================
FR-NOT-07.02: Encolar la notificación manual del admin con registro de auditoría
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-07.02
   * - **Nombre**
     - Mostrar el número de destinatarios antes de confirmar, encolar el
       email individualizado a cada destinatario y registrar el envío en
       auditoría con el admin responsable
   * - **UC Origen**
     - UC-NOT-07: Notificación Manual (Admin)
   * - **Paso UC**
     - Pasos 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE mostrar el número de destinatarios que recibirán
   la notificación antes de que el admin confirme el envío, encolar
   el email de forma asíncrona e individualizada a cada destinatario,
   y registrar el envío en auditoría con el admin responsable y el
   timestamp CUANDO el admin confirma la notificación manual.

**Descripcion:**

La notificación manual sirve para situaciones que no tienen un evento
automático: avisar a los compradores de un producto con un defecto
detectado, comunicar un cambio de política, o responder de forma
proactiva a una incidencia puntual.

Antes de encolar el sistema muestra cuántos destinatarios recibirán
el email según el criterio elegido (Alt. C). El admin puede revisar
y cancelar si el número no es el esperado. Si el segmento resulta
estar vacío (EX-02), el sistema informa que no hay destinatarios y
cancela el envío sin crear ningún registro.

Una vez que el admin confirma, el sistema encola un email individual
para cada destinatario. El envío es masivo en el sentido de que
puede haber muchos destinatarios, pero cada email es individual —
el asunto y el cuerpo pueden incluir el nombre del destinatario u
otros datos personalizados si el admin usó marcadores en el texto.

El sistema respeta las preferencias de notificación del destinatario.
Si un usuario desactivó las notificaciones manuales del admin, el
email no se encola para ese usuario específico. Sin embargo, si el
motivo de la notificación es crítico para la seguridad, la
notificación puede marcarse como no omitible, en cuyo caso las
preferencias se ignoran.

Cada envío queda en auditoría con: el admin que lo inició, el
asunto y el cuerpo redactados, el criterio del segmento, el número
de destinatarios y el momento del envío. Este registro es inmutable
una vez creado.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Vista previa del número de destinatarios antes de confirmar
   DADO admin que selecciona como segmento todos los compradores del
   producto "Sopera de Yemoja" (47 compradores)
   CUANDO revisa la vista previa antes de confirmar
   ENTONCES el sistema muestra "Esta notificación se enviará a 47 compradores"
   Y el admin puede confirmar o cancelar

   Escenario 2: Email encolado de forma individualizada
   DADO admin que confirma el envío al segmento de 47 compradores
   CUANDO el sistema procesa la confirmación
   ENTONCES HTTP 202 retorna inmediatamente al admin
   Y se crean 47 registros en la cola de envío, uno por destinatario
   Y el registro de auditoría incluye el admin, el asunto y el segmento

   Escenario 3: Segmento vacío — envío cancelado antes de procesar
   DADO admin que selecciona un criterio de segmento sin resultados (EX-02)
   CUANDO el sistema verifica el segmento
   ENTONCES HTTP 400 con {"codigo_error": "SEGMENTO_VACIO",
   "mensaje": "No hay destinatarios para el criterio seleccionado.
   Ajusta el segmento e intenta de nuevo."}
   Y no se crea ningún registro en la cola ni en auditoría

   Escenario 4: Destinatario con preferencia de notificaciones manuales desactivada
   DADO 47 compradores en el segmento, 3 con notificaciones manuales desactivadas
   CUANDO el sistema encola los emails
   ENTONCES se encolan 44 emails (excluyendo los 3 con preferencia inactiva)
   Y el registro de auditoría refleja: total_segment=47, queued=44, skipped=3

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoría obligatoria: admin,
  asunto, cuerpo, segmento, total de destinatarios y timestamp),
  RNF-AVAIL-003 (reintentos con espera progresiva via FR-SYS-04.02
  para los envíos individuales que fallen)
- **Notas:** El registro de auditoría es inmutable. El admin no puede
  modificar ni eliminar el historial de notificaciones manuales
  enviadas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-07: Notificación Manual (Admin)
   * - **Depende de**
     - FR-NOT-06.02 (preferencias del destinatario que pueden
       excluirlo del envío)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla, uno por destinatario)
   * - **Relacionado con**
     - FR-SYS-04.02 (gestión de reintentos para los emails
       individuales que fallen)
   * - **Test**
     - TST-FR-NOT-07.02 (pendiente — verificar que el registro de
       auditoría refleja correctamente queued vs skipped; verificar
       que un segmento vacío no crea ningún registro)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: vista previa del número de destinatarios,
       envío individual por destinatario, auditoría con queued vs
       skipped, EX-02 de segmento vacío, 4 escenarios BDD

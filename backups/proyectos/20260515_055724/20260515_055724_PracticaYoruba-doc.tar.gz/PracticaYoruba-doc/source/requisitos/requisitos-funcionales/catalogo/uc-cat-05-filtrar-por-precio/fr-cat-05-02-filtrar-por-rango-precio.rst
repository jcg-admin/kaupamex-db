.. meta::
   :artefacto: FR-CAT-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-05.02: Filtrar productos por rango de precio con IVA calculado
======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-05.02
   * - **Nombre**
     - Aplicar filtro de rango de precio usando el precio base sin IVA como criterio
   * - **UC Origen**
     - UC-CAT-05: Filtrar por Precio
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE filtrar los productos cuyo precio base sin IVA
   esta dentro del rango especificado CUANDO el visitante aplica
   un filtro de precio.

**Descripcion:**

El filtro de precio opera sobre ``Product.base_price`` (precio sin IVA,
BR-001). Si la interfaz muestra precios con IVA y el visitante ingresa
valores con IVA incluido, el sistema convierte los límites a precio
base dividiendo por ``(1 + SiteSettings.iva_rate)`` antes de filtrar,
manteniendo consistencia con el catálogo.

El sistema filtra productos con ``Product.is_active = True`` y
``Product.is_published = True`` cuyo ``Product.base_price`` esté dentro
del rango recibido. Si solo se proporciona ``price_min``, el filtro es
unilateral por abajo (``≥``). Si solo se proporciona ``price_max``, el
filtro es unilateral por arriba (``≤``). Si no se proporciona ninguno,
el filtro de precio no se aplica.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Rango de precio aplicado correctamente
   DADO price_min=200, price_max=800 (precio base sin IVA)
   CUANDO se filtra
   ENTONCES todos los productos tienen 200 <= base_price <= 800
   Y los precios mostrados incluyen el IVA correspondiente

   Escenario 2: Solo precio minimo
   DADO price_min=500 sin price_max
   CUANDO se filtra
   ENTONCES todos los productos tienen base_price >= 500
   Y no hay limite superior

   Escenario 3: Rango que no incluye ningun producto — estado vacio
   DADO price_min=99999 price_max=999999 sin productos en ese rango
   CUANDO se filtra
   ENTONCES HTTP 200 con total_results=0
   Y se sugiere ampliar el rango de precio

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (el precio base es sin IVA; el IVA es
  del 16% configurado en SiteSettings)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-05: Filtrar por Precio
   * - **Depende de**
     - FR-CAT-01.02 (catalogo base disponible)
   * - **Test**
     - TST-FR-CAT-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-CAT-05

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-02-login
===========================

**24 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-02-01-verificar-bloqueo
   fr-auth-02-02-autenticar-credenciales
   fr-auth-02-03-emitir-tokens-jwt
   fr-auth-02-04-presentar-formulario-login
   fr-auth-02-05-validar-formato-identificador-tiempo-real
   fr-auth-02-06-validar-formato-final-y-bloquear-boton
   fr-auth-02-07-normalizar-identificador
   fr-auth-02-08-buscar-identificador-repositorio
   fr-auth-02-09-verificar-email-confirmado
   fr-auth-02-10-verificar-cuenta-activa
   fr-auth-02-11-emitir-refresh-token
   fr-auth-02-12-registrar-acceso-en-perfil
   fr-auth-02-13-registrar-auditoria-acceso
   fr-auth-02-14-restablecer-contador-intentos
   fr-auth-02-15-retornar-credenciales-y-datos-usuario
   fr-auth-02-16-exc-limite-de-intentos
   fr-auth-02-17-exc-repositorio-no-disponible
   fr-auth-02-18-exc-canal-no-seguro
   fr-auth-02-19-exc-solicitud-invalida
   fr-auth-02-20-exc-error-al-emitir-credenciales
   fr-auth-02-21-nfr-performance-login
   fr-auth-02-22-nfr-seguridad-login
   fr-auth-02-23-nfr-confiabilidad-login
   fr-auth-02-24-nfr-usabilidad-login

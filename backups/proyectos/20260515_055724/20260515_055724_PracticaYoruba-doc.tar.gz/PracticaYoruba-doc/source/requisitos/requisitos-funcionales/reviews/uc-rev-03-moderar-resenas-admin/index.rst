.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rev-03-moderar-resenas-admin
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rev-03-02-aprobar-o-rechazar-resena
   fr-rev-03-moderar-resenas-admin-01

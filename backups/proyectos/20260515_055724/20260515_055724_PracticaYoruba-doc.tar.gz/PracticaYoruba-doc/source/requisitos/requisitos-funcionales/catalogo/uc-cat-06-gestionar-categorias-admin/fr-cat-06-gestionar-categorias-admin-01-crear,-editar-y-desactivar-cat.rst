.. meta::
   :artefacto: FR-CAT-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-06-01:

FR-CAT-06.01: Crear, editar y desactivar categorias
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-06.01
   * - **Nombre**
     - Crear, editar y desactivar categorias
   * - **UC Origen**
     - UC-CAT 06 GESTIONAR CATEGORIAS ADMIN
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos / Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE persistir los cambios de la categoria CUANDO el administrador los ejecuta.

**Descripcion:**

Operaciones disponibles:

- **Crear**: ``POST /api/v1/admin/catalogue/categories/``
- **Editar**: ``PUT /api/v1/admin/catalogue/categories/{slug}/``
- **Desactivar**: soft delete con ``is_active=False``

Al desactivar una categoria con subcategorias: las subcategorias se desactivan en cascada.
Al desactivar una categoria con productos activos: los productos se marcan sin categoria visible.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Crear categoria hija
   DADO admin que crea categoria 'Collares Oshun' como hija de 'Oshun'
   CUANDO se crea
   ENTONCES aparece en el arbol de categorias bajo 'Oshun'

   Escenario: Desactivar categoria con subcategorias
   DADO categoria con 2 subcategorias activas
   CUANDO se desactiva
   ENTONCES las 2 subcategorias tambien quedan inactivas
   Y los productos de esas subcategorias dejan de aparecer en el catalogo


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** N/A

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 06 GESTIONAR CATEGORIAS ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-CAT-08.01 (arbol actualizado tras la gestion)
   * - **Test**
     - TST-FR-CAT-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 06 GESTIONAR CATEGORIAS ADMIN

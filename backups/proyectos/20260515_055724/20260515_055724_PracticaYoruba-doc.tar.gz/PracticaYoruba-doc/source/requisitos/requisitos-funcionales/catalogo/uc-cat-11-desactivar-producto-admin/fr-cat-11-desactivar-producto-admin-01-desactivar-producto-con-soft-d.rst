.. meta::
   :artefacto: FR-CAT-11.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-11-01:

FR-CAT-11.01: Desactivar producto con soft delete
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-11.01
   * - **Nombre**
     - Desactivar producto con soft delete
   * - **UC Origen**
     - UC-CAT 11 DESACTIVAR PRODUCTO ADMIN
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos / Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE marcar el producto como inactivo CUANDO el admin lo desactiva.

**Descripcion:**

``Product.is_active = False``

El producto desaparece del catalogo publico de inmediato.
Las ordenes existentes con ese producto NO se ven afectadas (snapshot BR-005).
Los CartItems con ese producto se marcan como ``is_available=False`` al cargar el carrito.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Desactivar con ordenes activas
   DADO producto con ordenes en PENDING_PAYMENT
   CUANDO el admin desactiva
   ENTONCES el producto desaparece del catalogo
   Y las ordenes activas no se modifican
   Y los CartItems de otros compradores se marcan sin disponibilidad

   Escenario: Reactivar producto
   DADO producto desactivado
   CUANDO el admin lo reactiva
   ENTONCES is_active=True y vuelve al catalogo


----

4. Reglas y Restricciones
--------------------------

- **BR-005**

- **Notas:** N/A

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 11 DESACTIVAR PRODUCTO ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-CART-02.01 (los carritos reflejan la indisponibilidad)
   * - **Test**
     - TST-FR-CAT-11.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 11 DESACTIVAR PRODUCTO ADMIN

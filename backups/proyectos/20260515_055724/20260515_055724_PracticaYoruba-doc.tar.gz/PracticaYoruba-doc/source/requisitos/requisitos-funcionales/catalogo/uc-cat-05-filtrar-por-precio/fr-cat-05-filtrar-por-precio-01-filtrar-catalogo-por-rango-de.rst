.. meta::
   :artefacto: FR-CAT-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-05-01:

FR-CAT-05.01: Filtrar catalogo por rango de precio
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-05.01
   * - **Nombre**
     - Filtrar catalogo por rango de precio
   * - **UC Origen**
     - UC-CAT 05 FILTRAR POR PRECIO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar productos dentro del rango de precio CUANDO se aplica el filtro.

**Descripcion:**

Los precios en el filtro incluyen IVA (precio visible para el comprador).
``Product.objects.filter(price__gte=min_neto, price__lte=max_neto, is_active=True)``
donde ``price_neto = price_with_tax / (1 + iva_rate)``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Rango valido con resultados
   DADO min_price=100 y max_price=500
   CUANDO se filtra
   ENTONCES solo productos cuyo precio con IVA esta en ese rango

   Escenario: Rango invalido — min mayor que max
   DADO min_price=500 y max_price=100
   CUANDO se envia
   ENTONCES error 422: RANGO_PRECIO_INVALIDO


----

4. Reglas y Restricciones
--------------------------

- **BR-001 (precio sin IVA en BD — el filtro convierte)**
- **BR-002 (IVA en checkout)**

- **Notas:** El filtro convierte los precios del visitante (con IVA) a precios de BD (sin IVA) antes de filtrar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 05 FILTRAR POR PRECIO
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-CAT-02.01
   * - **Test**
     - TST-FR-CAT-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 05 FILTRAR POR PRECIO

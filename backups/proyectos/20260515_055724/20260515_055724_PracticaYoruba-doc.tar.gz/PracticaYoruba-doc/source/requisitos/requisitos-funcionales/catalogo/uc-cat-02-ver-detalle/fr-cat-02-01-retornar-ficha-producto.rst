.. meta::
   :artefacto: FR-CAT-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-02-01:

FR-CAT-02.01: Retornar la ficha completa del producto
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-02.01
   * - **Nombre**
     - Retornar la ficha completa del producto
   * - **UC Origen**
     - UC-CAT-02: Ver detalle del producto
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE + MOD-003 CHARTSIZE + MOD-012 REVIEW
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la ficha completa del producto CUANDO el visitante accede al detalle.

**Descripcion:**

La ficha incluye:

- Datos del producto: ``name``, ``description``, ``sku``, ``price_with_tax``
- Galeria de imagenes: lista ordenada de ``image_url`` y ``alt_text``
- Categoria con su jerarquia completa
- Variantes disponibles (delegado en MOD-CHARTSIZE)
- Promedio de calificacion y cantidad de resenas aprobadas
- Productos relacionados (hasta 6, misma categoria)
- Si el comprador tiene el producto en wishlist: ``in_wishlist: true``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Producto con variantes
   DADO producto con variantes de tamano
   CUANDO se accede a la ficha
   ENTONCES la respuesta incluye variants[] con stock y precio de cada una

   Escenario: Producto desactivado
   DADO slug de producto con is_active = False
   CUANDO se accede
   ENTONCES error 404 (no se revelan productos inactivos)

   Escenario: Comprador con wishlist
   DADO comprador autenticado con el producto en su wishlist
   CUANDO accede a la ficha
   ENTONCES in_wishlist = true
   Y el icono de wishlist aparece marcado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PERF-001 (< 400ms P95)`
- **Notas:** La ficha incluye los datos de variantes, resenas y relacionados en una sola llamada para minimizar round-trips.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-02: Ver detalle del producto
   * - **Depende de**
     - FR-CAT-01.01 (producto listado en catalogo)
   * - **Requerido por**
     - FR-CART-01.01 (agregar al carrito desde la ficha)
   * - **Test**
     - TST-FR-CAT-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT-02

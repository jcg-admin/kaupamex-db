.. meta::
   :artefacto: FR-SYS-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-sys-01-01:

FR-SYS-01.01: Cancelar ordenes con timeout de pago vencido
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-01.01
   * - **Nombre**
     - Cancelar ordenes con timeout de pago vencido
   * - **UC Origen**
     - UC-SYS 01 CANCELAR ORDEN TIMEOUT
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-006 ORDER + MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cancelar las ordenes en PENDING_PAYMENT cuyo tiempo de pago vencio CUANDO el Actor Tiempo lo dispara.

**Descripcion:**

Tarea periodica (cada 5 minutos):

1. Busca ordenes con:
   ``Order.status=PENDING_PAYMENT AND created_at < now() - timedelta(minutes=SiteSettings.order_timeout_minutes)``
2. Para cada orden encontrada:
   - ``Order.status = CANCELLED_TIMEOUT``
   - Restaura el stock de cada OrderItem (UC-INV-03)
3. Notifica al comprador que la reserva expiro (UC-INC-03)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Orden expirada cancelada
   DADO orden en PENDING_PAYMENT creada hace 35 minutos con timeout=30
   CUANDO la tarea se ejecuta
   ENTONCES Order.status=CANCELLED_TIMEOUT
   Y el stock se restaura

   Escenario: Idempotencia — orden ya cancelada
   DADO orden ya en CANCELLED_TIMEOUT
   CUANDO la tarea la encuentra de nuevo en un ciclo posterior
   ENTONCES no se modifica nada


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002 (idempotencia)`
- **Notas:** La tarea se ejecuta cada 5 minutos. El timeout real puede ser hasta 5 minutos mayor al configurado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS 01 CANCELAR ORDEN TIMEOUT
   * - **Depende de**
     - Actor Tiempo (tarea periodica)
   * - **Requerido por**
     - FR-INV-03.01 (stock restaurado)
   * - **Test**
     - TST-FR-SYS-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-SYS 01 CANCELAR ORDEN TIMEOUT

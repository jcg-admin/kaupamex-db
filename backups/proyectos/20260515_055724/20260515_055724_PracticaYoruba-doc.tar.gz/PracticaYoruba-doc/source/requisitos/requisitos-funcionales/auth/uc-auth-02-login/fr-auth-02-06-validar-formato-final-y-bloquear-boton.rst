.. meta::
   :artefacto: FR-AUTH-02.06
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-06:

===========================================================
FR-AUTH-02.06: Validar formato final y bloquear el boton
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.06
   * - **Nombre**
     - Validacion final del formulario antes de enviar al servidor
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 8 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (validacion en cliente antes del POST)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion — Frontend

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE ejecutar la validacion final de todos los campos,
   deshabilitar el boton de envio y mostrar un indicador de
   procesamiento CUANDO el visitante hace submit del formulario.

**Descripcion:**

Este paso ocurre al hacer clic en "Iniciar sesion" o al presionar
Enter en cualquier campo del formulario.

Validaciones de formato en el submit:

1. ``identificador`` no esta vacio
2. ``identificador`` tiene formato valido (email o username)
3. ``contraseña`` no esta vacia
4. ``contraseña`` tiene longitud >= 1 caracter

Si alguna validacion falla:

- Se resaltan en rojo los campos con error
- Se muestra el mensaje de error bajo cada campo
- El formulario NO se envia al servidor
- El boton permanece habilitado para corregir

Si todas las validaciones pasan:

- El boton "Iniciar sesion" se deshabilita (``disabled=true``)
- El texto del boton cambia a "Verificando..."
- Aparece un spinner dentro del boton
- Se ejecuta el POST al servidor (paso 9 en adelante)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Formulario valido — boton se deshabilita
   DADO formulario con identificador y contraseña con formato correcto
   CUANDO el visitante hace clic en "Iniciar sesion"
   ENTONCES el boton se deshabilita inmediatamente
   Y el texto cambia a "Verificando..." con spinner
   Y se envia el POST /api/v1/auth/login/ al servidor

   Escenario 2: Formulario invalido — no se envia
   DADO formulario con el campo contraseña vacio
   CUANDO el visitante hace clic en "Iniciar sesion"
   ENTONCES el campo contraseña se marca en rojo
   Y aparece el mensaje "La contraseña es obligatoria"
   Y el formulario NO envia el POST al servidor
   Y el boton permanece habilitado para corregir

   Escenario 3: Doble clic no genera dos requests
   DADO boton habilitado antes del submit
   CUANDO el visitante hace doble clic rapidamente
   ENTONCES solo se envia un unico POST al servidor
   Y el segundo clic no tiene efecto (boton ya deshabilitado)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna — validacion de formato en cliente
- **RNF aplicables:** RNF-USAB-001 (mensajes de error claros),
  RNF-USAB-002 (indicador de progreso durante el procesamiento)
- **Notas:** La deshabilitacion del boton previene envios duplicados.
  Si el servidor retorna un error, el boton vuelve a habilitarse
  para permitir que el visitante corrija y reintente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.05 (formato del identificador ya validado en tiempo real)
   * - **Requerido por**
     - FR-AUTH-02.01 (el servidor verifica el bloqueo de IP)
   * - **Test**
     - TST-FR-AUTH-02.06 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 8 de UC-AUTH-02

.. meta::
   :artefacto: FR-CAT-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-03-01:

FR-CAT-03.01: Buscar productos por texto con relevancia
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-03.01
   * - **Nombre**
     - Buscar productos por texto con relevancia
   * - **UC Origen**
     - UC-CAT-03: Buscar productos
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE buscar productos cuyo nombre o descripcion contengan el termino CUANDO el visitante realiza una busqueda.

**Descripcion:**

Busqueda con Django ORM:

``Product.objects.filter(
    Q(name__icontains=query) | Q(description__icontains=query),
    is_active=True
).order_by('-is_featured', 'name')``

Si la busqueda retorna 0 resultados se sugieren productos populares
o se informa que no hay coincidencias.
Busqueda minima: 2 caracteres. Maxima: 100 caracteres.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Busqueda con resultados
   DADO termino 'collar Oshun'
   CUANDO se busca
   ENTONCES aparecen productos con 'collar' u 'Oshun' en nombre o descripcion
   Y los destacados (is_featured=True) aparecen primero

   Escenario: Busqueda sin resultados
   DADO termino sin coincidencias 'xxxx'
   CUANDO se busca
   ENTONCES results: [] con sugerencia de ver productos populares

   Escenario: Busqueda demasiado corta
   DADO query de 1 caracter
   CUANDO se envia
   ENTONCES error 422: BUSQUEDA_DEMASIADO_CORTA


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PERF-001`
- **Notas:** La busqueda es case-insensitive y no requiere coincidencia exacta (icontains).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-03: Buscar productos
   * - **Depende de**
     - Ninguno — punto de entrada de busqueda
   * - **Requerido por**
     - FR-CAT-03-EXT.01 (filtros avanzados sobre los resultados)
   * - **Test**
     - TST-FR-CAT-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT-03

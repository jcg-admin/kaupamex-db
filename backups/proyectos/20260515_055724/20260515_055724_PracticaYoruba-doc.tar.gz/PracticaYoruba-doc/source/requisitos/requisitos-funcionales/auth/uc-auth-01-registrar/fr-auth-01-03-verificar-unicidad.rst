.. meta::
   :artefacto: FR-AUTH-01.03
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-01-03:

================================================
FR-AUTH-01.03: Verificar unicidad en el sistema
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-01.03
   * - **Nombre**
     - Verificar que username y email no existan ya en el sistema
   * - **UC Origen**
     - UC-AUTH-01: Registrar cuenta
   * - **Paso UC**
     - Paso 3 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el username y el email no esten
   registrados previamente CUANDO el formato de los datos es valido.

**Descripcion:**

Comportamiento de verificacion:

1. Busca ``User.objects.filter(username__iexact=username)``
2. Busca ``User.objects.filter(email__iexact=email)``
3. Si alguno existe, retorna el error correspondiente al campo
4. El mensaje de error **no** revela que el username/email esta
   registrado con otro usuario — usa mensajes genericos para
   prevenir enumeracion de usuarios

Mensaje de error intencionalmente ambiguo:
``"Los datos ingresados no estan disponibles. Prueba con otros."``

----

3. Criterio de Aceptacion
--------------------------

::

   DADO datos de formato valido
   CUANDO el sistema verifica unicidad
   ENTONCES solo procede si username Y email son unicos

   Escenario 1: Username ya existe
   DADO username = "juanito" ya registrado
   CUANDO se verifica unicidad
   ENTONCES se muestra mensaje generico de no disponibilidad
   Y no se revela que "juanito" existe (prevencion de enumeracion)

   Escenario 2: Email ya existe
   DADO email = "juan@example.com" ya registrado
   CUANDO se verifica unicidad
   ENTONCES se muestra mensaje generico de no disponibilidad

   Escenario 3: Username y email unicos
   DADO username y email no existentes
   CUANDO se verifica
   ENTONCES no hay conflicto de unicidad
   Y el proceso continua a FR-AUTH-01.04

   Escenario 4: Case-insensitive
   DADO username = "JUANITO" y existe "juanito"
   CUANDO se verifica
   ENTONCES se detecta el conflicto (case-insensitive)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-010 (guest-friendly — el comprador puede
  crear cuenta en cualquier momento)
- **Notas:** La verificacion es case-insensitive para username y email.
  La normalizacion a minusculas del email ocurre antes de guardar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-01: Registrar cuenta
   * - **Depende de**
     - FR-AUTH-01.02 (validacion de formato exitosa)
   * - **Requerido por**
     - FR-AUTH-01.04 (crear cuenta)
   * - **RNF**
     - RNF-SEC-003 (aislamiento datos usuario)
   * - **Test**
     - TST-FR-AUTH-01.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-01

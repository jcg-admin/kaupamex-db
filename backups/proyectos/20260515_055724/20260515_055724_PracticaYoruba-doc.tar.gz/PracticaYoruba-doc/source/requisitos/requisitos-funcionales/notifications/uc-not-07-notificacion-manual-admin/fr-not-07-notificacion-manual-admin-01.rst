.. meta::
   :artefacto: FR-NOT-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-07-01:

FR-NOT-07.01: Enviar notificacion manual a compradores
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-07.01
   * - **Nombre**
     - Enviar notificacion manual a compradores
   * - **UC Origen**
     - UC-NOT 07 NOTIFICACION MANUAL ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar el email personalizado a los compradores del segmento CUANDO el admin lo dispara.

**Descripcion:**

El admin define:

- Segmento: todos / filtro por producto / filtro por fecha de orden
- Asunto y cuerpo del email (texto o HTML)
- Vista previa antes de confirmar

El sistema muestra cuantos compradores seran notificados antes de confirmar.
El envio es masivo pero individualizado — un email por comprador.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Envio masivo a segmento
   DADO admin que segmenta compradores de Orula en los ultimos 30 dias
   CUANDO confirma el envio
   ENTONCES cada comprador del segmento recibe su email individual

   Escenario: Segmento vacio
   DADO criterio de segmento que no arroja compradores
   CUANDO se aplica
   ENTONCES error 422: SEGMENTO_VACIO — no se puede enviar sin destinatarios


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El envio masivo usa la cola de emails para no bloquear al admin esperando.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 07 NOTIFICACION MANUAL ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 07 NOTIFICACION MANUAL ADMIN

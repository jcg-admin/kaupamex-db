.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-wish-02-ver-lista-deseos
======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-wish-02-02-mostrar-lista-con-precios-actuales
   fr-wish-02-ver-lista-deseos-01

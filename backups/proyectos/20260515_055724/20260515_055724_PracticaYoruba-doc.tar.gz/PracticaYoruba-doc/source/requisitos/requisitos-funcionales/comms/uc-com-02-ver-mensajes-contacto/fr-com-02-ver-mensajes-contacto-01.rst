.. meta::
   :artefacto: FR-COM-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-com-02-01:

FR-COM-02.01: Listar mensajes de contacto para el admin
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-02.01
   * - **Nombre**
     - Listar mensajes de contacto para el admin
   * - **UC Origen**
     - UC-COM 02 VER MENSAJES CONTACTO
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-014 CONTACT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista paginada de mensajes de contacto CUANDO el admin la consulta.

**Descripcion:**

Lista paginada con filtros: ``?status=NUEVO``, ``?status=RESPONDIDO``.
Ordenamiento: mas recientes primero.
Contador de mensajes sin leer visible en el panel.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Bandeja con mensajes nuevos
   DADO 5 mensajes nuevos y 10 respondidos
   CUANDO el admin consulta
   ENTONCES los 5 nuevos aparecen primero con indicador de no leido

   Escenario: Marcar como leido
   DADO mensaje en estado NUEVO
   CUANDO el admin lo abre
   ENTONCES status cambia a LEIDO automaticamente


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** Solo administradores pueden ver los mensajes de contacto.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM 02 VER MENSAJES CONTACTO
   * - **Depende de**
     - FR-COM-01.01 (mensaje creado)
   * - **Requerido por**
     - FR-COM-03.01 (responder el mensaje)
   * - **Test**
     - TST-FR-COM-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-COM 02 VER MENSAJES CONTACTO

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rev-01-dejar-resena
=================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rev-01-02-validar-y-crear-resena-pendiente
   fr-rev-01-dejar-resena-01

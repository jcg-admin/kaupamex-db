.. meta::
   :artefacto: FR-CART-01.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-01-03:

===================================================
FR-CART-01.03: Retornar carrito con totales
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-01.03
   * - **Nombre**
     - Calcular y retornar el estado completo del carrito actualizado
   * - **UC Origen**
     - UC-CART-01: Agregar producto al carrito
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Calculo

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular y retornar el carrito completo con
   todos sus totales CUANDO se agrega un item exitosamente.

**Descripcion:**

Calculo de totales del carrito:

- ``subtotal`` = suma de ``item.unit_price * item.quantity`` para cada item
- ``discount`` = descuento del voucher aplicado (si hay)
  calculado por ``Voucher.calculate_discount(subtotal)``
- ``shipping_cost`` = costo del metodo de envio seleccionado
  (0 si el subtotal supera el umbral de envio gratis de SiteSettings)
- ``tax`` = ``(subtotal - discount) * SiteSettings.iva_rate``
  (si el precio ya incluye IVA, tax = 0 y se desglosa)
- ``total`` = ``subtotal - discount + shipping_cost``

Todos los montos se retornan en la moneda configurada en SiteSettings.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO item agregado exitosamente al carrito
   CUANDO se calculan los totales
   ENTONCES la respuesta incluye todos los montos correctos

   Escenario 1: Carrito sin voucher ni envio
   DADO carrito con 2 items de $50 c/u y sin voucher
   CUANDO se calculan totales
   ENTONCES subtotal = 100, discount = 0, shipping_cost = 0
   Y total = 100

   Escenario 2: Con voucher de porcentaje
   DADO voucher de 10% activo y subtotal = 100
   CUANDO se calculan totales
   ENTONCES discount = 10, total = 90

   Escenario 3: Envio gratis por umbral
   DADO SiteSettings.free_shipping_threshold = 500
   Y subtotal = 600
   CUANDO se calculan totales
   ENTONCES shipping_cost = 0 (envio gratis aplicado automaticamente)

   Escenario 4: Respuesta completa de la API
   DADO cualquier carrito
   CUANDO se retorna
   ENTONCES la respuesta incluye items[], subtotal, discount,
   shipping_cost, total y total_items (cantidad de unidades)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio sin IVA — el IVA se agrega en
  checkout), BR-002 (IVA en checkout)
- **Notas:** SiteSettings.iva_rate se lee en tiempo real en cada calculo.
  Si el admin cambia la tasa de IVA el carrito la refleja de inmediato.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-01: Agregar producto al carrito
   * - **Depende de**
     - FR-CART-01.02 (item guardado en el carrito)
   * - **Requerido por**
     - FR-ORD-01.01 (el checkout parte del carrito con sus totales)
   * - **BR**
     - BR-001, BR-002
   * - **Test**
     - TST-FR-CART-01.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-sys-01-cancelar-orden-timeout
===========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-sys-01-02-cancelar-ordenes-expiradas
   fr-sys-01-cancelar-orden-timeout-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-wish-03-mover-wishlist-carrito
============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-wish-03-02-mover-al-carrito
   fr-wish-03-mover-wishlist-carrito-01

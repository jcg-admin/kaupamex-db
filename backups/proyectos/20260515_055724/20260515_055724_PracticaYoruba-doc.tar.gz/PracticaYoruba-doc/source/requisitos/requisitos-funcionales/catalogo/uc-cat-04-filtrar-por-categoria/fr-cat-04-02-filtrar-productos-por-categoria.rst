.. meta::
   :artefacto: FR-CAT-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-04.02: Filtrar productos por categoria y subcategorias
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-04.02
   * - **Nombre**
     - Aplicar filtro de categoria incluyendo todas sus subcategorias activas
   * - **UC Origen**
     - UC-CAT-04: Filtrar por Categoria
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar todos los productos activos de la
   categoria seleccionada y sus subcategorias CUANDO el visitante
   aplica un filtro de categoria.

**Descripcion:**

La categoría tiene una estructura de árbol. El filtro incluye la
categoría seleccionada y todos sus descendientes. El sistema obtiene
el identificador de la ``Category`` solicitada, recupera todos sus
nodos descendientes en el árbol (incluyendo la propia categoría), y
filtra los productos cuyo ``Product.category_id`` coincida con
alguno de esos identificadores, restringiendo además a productos con
``Product.is_active = True`` y ``Product.is_published = True``.
Los resultados se ordenan según el parámetro recibido, con
``-Product.created_at`` como ordenamiento por defecto.

La respuesta incluye la ruta de navegacion (breadcrumb):
``Inicio > Catalogo > Soperas > Sopera de Yemoja``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Categoria padre incluye subcategorias
   DADO categoria "Soperas" con subcategorias "Soperas grandes" y "Soperas medianas"
   CUANDO el visitante filtra por "Soperas"
   ENTONCES los resultados incluyen productos de las 3 categorias
   Y el breadcrumb muestra la categoria activa

   Escenario 2: Categoria hoja sin subcategorias
   DADO categoria "Soperas grandes" sin hijos
   CUANDO se filtra
   ENTONCES solo aparecen productos de esa categoria exacta

   Escenario 3: Categoria sin productos publicados — estado vacio
   DADO categoria con productos pero todos despublicados
   CUANDO se filtra
   ENTONCES HTTP 200 con total_results=0 y sugerencia de ver el catalogo completo

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms incluyendo la
  consulta del arbol de categorias)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-04: Filtrar por Categoria
   * - **Depende de**
     - FR-CAT-08.02 (estructura de categorias disponible)
   * - **Requerido por**
     - Ninguno — el resultado se presenta al visitante directamente
   * - **Test**
     - TST-FR-CAT-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-ORD-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-05.02: Actualizar la direccion de entrega antes del envio
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-05.02
   * - **Nombre**
     - Modificar OrderAddress solo cuando la orden no ha sido enviada
   * - **UC Origen**
     - UC-ORD-05: Editar Direccion de Orden
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar la direccion de entrega de la orden
   solo cuando la orden no ha sido enviada CUANDO el usuario solicita
   un cambio de direccion.

**Descripcion:**

Estados que permiten editar la direccion:

- PENDING_PAYMENT
- PAYMENT_CONFIRMED
- IN_PREPARATION

Estados que NO permiten editar (la guia de envio ya fue creada):

- SHIPPED, DELIVERED, CANCELLED

Si ``Order.status`` no está en la lista de estados editables
(``PENDING_PAYMENT``, ``PAYMENT_CONFIRMED``, ``IN_PREPARATION``),
el sistema rechaza la operación con ``DIRECCION_NO_EDITABLE``.
En caso contrario, actualiza todos los campos de ``OrderAddress``
con los nuevos valores y persiste el registro.

Nota: el snapshot de OrderAddress es modificable hasta que se
crea la guia de envio. Una vez que LOGISTICS crea la guia,
la direccion queda fija porque ya fue enviada al courier.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cambio de direccion en orden IN_PREPARATION
   DADO orden en preparacion que aun no tiene guia de envio
   CUANDO el usuario cambia la calle de entrega
   ENTONCES OrderAddress.street_address se actualiza
   Y el admin ve la nueva direccion en el panel

   Escenario 2: Orden SHIPPED — sin cambio posible
   DADO orden en estado SHIPPED con guia de envio generada
   CUANDO el usuario intenta cambiar la direccion
   ENTONCES HTTP 400 con {"codigo_error": "DIRECCION_NO_EDITABLE",
   "mensaje": "Tu orden ya fue enviada. Contacta soporte para redireccion."}

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 se aplica con excepcion en OrderAddress:
  la direccion puede editarse antes del envio. Una vez creada la
  guia de envio (LOGISTICS), queda inmutable.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-05: Editar Direccion
   * - **Relacionado con**
     - FR-LOG-01.01 (la guia de envio fija la direccion)
   * - **Test**
     - TST-FR-ORD-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-ORD-05

.. meta::
   :artefacto: FR-CART-06.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-06-03:

============================================================
FR-CART-06.03: Presentar el carrito fusionado, excepciones y NFR
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-06.03
   * - **Nombre**
     - Retornar el carrito fusionado con avisos de ajuste y restricciones tecnicas
   * - **UC Origen**
     - UC-CART-06: Sincronizar Carrito tras Login
   * - **Paso UC**
     - Paso 7 del flujo principal + PARTE 5 + PARTE 6
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion + NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE presentar el carrito fusionado al usuario con
   los avisos de ajuste cuando corresponda, y manejar los fallos
   de concurrencia de forma idempotente.

**Descripcion:**

**Paso 7 — Carrito fusionado:**

La respuesta del login (FR-AUTH-02.15) se enriquece o se hace una
segunda llamada para mostrar el carrito fusionado:

.. code-block:: json

   {
     "carrito": {
       "items": [...],
       "subtotal": 1250.00,
       "items_count": 4
     },
     "ajustes": [
       {
         "product": "Sopera de Yemoja",
         "ajustado_a": 3,
         "razon": "Solo quedan 3 unidades disponibles."
       }
     ],
     "mensaje": "Tu carrito fue sincronizado. Revisa los ajustes de cantidad."
   }

Si no hubo ajustes: ``"ajustes": []`` y sin mensaje especial.

**EX-01 — Error en la fusion:**

Si ``CartMergeService.merge()`` lanza una excepcion:

- El carrito del usuario autenticado queda sin modificar
- El carrito anonimo de sesion NO se elimina
- El login es exitoso (el error de fusion es independiente)
- La respuesta del login incluye un aviso: ``"cart_sync": "fallido"``
- El usuario puede reintentar la sincronizacion manualmente

**EX-02 — Concurrencia:**

Dos dispositivos del mismo usuario hacen login con carrito anónimo
al mismo tiempo. La fusión aplica ``SELECT FOR UPDATE`` sobre el
``SavedCart`` del usuario, serializando los accesos concurrentes.
El resultado de la segunda fusión toma como base el carrito ya
fusionado por la primera. El resultado final es correcto.

**NFRs:**

- P95 <= 500ms — la fusion procesa en memoria con verificaciones de stock
- Atomicidad: la fusion usa ``@transaction.atomic`` — si falla, rollback
- No perdida de items: el carrito del usuario nunca pierde items por la fusion
- Transparencia: el usuario percibe su carrito como siempre presente

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Fusion transparente sin ajustes
   DADO login con carrito anonimo compatible con el del usuario
   CUANDO la fusion completa exitosamente
   ENTONCES la respuesta incluye el carrito fusionado completo
   Y ajustes = [] (sin informacion extra)
   Y el usuario ve todos sus items sin necesitar accion

   Escenario 2: Fusion con ajustes informados
   DADO fusion que ajusto 2 items por falta de stock
   CUANDO la respuesta llega al cliente
   ENTONCES ajustes lista los 2 items ajustados con la cantidad final
   Y el usuario sabe que necesita revisar las cantidades

   Escenario 3: EX-01 — fusion falla, login exitoso igual
   DADO error de BD durante la fusion
   CUANDO falla CartMergeService.merge()
   ENTONCES el login es exitoso (tokens retornados)
   Y la respuesta incluye "cart_sync": "fallido"
   Y el carrito anonimo sigue en sesion (no se perdio)
   Y el usuario puede intentar la sincronizacion manualmente

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-001, RNF-AVAIL-002 (idempotencia)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-06: Sincronizar Carrito tras Login
   * - **Depende de**
     - FR-CART-06.02 (fusion ejecutada)
   * - **Requerido por**
     - Ninguno — ultimo paso del Sistema en UC-CART-06
   * - **Test**
     - TST-FR-CART-06.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 7 + PARTE 5 y 6 de UC-CART-06

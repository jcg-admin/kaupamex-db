.. meta::
   :artefacto: FR-PAY-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-02-01:

FR-PAY-02.01: Crear orden en PayPal y obtener URL de aprobacion
===============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-02.01
   * - **Nombre**
     - Crear orden en PayPal y obtener URL de aprobacion
   * - **UC Origen**
     - UC-PAY-02: Pago con PayPal
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-007 PAYMENT + Gateway PayPal
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Integracion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear una orden en PayPal y retornar la URL de aprobacion CUANDO el comprador selecciona PayPal.

**Descripcion:**

Proceso:

1. Construye la orden PayPal con ``purchase_units`` desde OrderItems
2. ``POST /v2/checkout/orders`` a la API de PayPal con el Bearer token
3. PayPal retorna ``order_id`` y el enlace ``approve`` (URL de redireccion)
4. Crea ``Payment(order, gateway=PAYPAL, gateway_payment_id=paypal_order_id, status=PENDING)``
5. Retorna la URL ``approve`` al frontend

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Orden PayPal creada
   DADO orden en PENDING_PAYMENT
   CUANDO se crea la orden en PayPal
   ENTONCES PayPal retorna order_id y approve URL
   Y el comprador es redirigido a PayPal para aprobar

   Escenario: Token de PayPal vencido
   DADO access_token de PayPal expirado
   CUANDO se intenta crear la orden
   ENTONCES el sistema renueva el token automaticamente
   Y reintenta la creacion sin que el comprador lo note


----

4. Reglas y Restricciones
--------------------------

- **BR-007 (PayPal es MVP secundario)**

- :ref:`RNF-SEC-002 (cifrado de credenciales)`
- **Notas:** El client_id y client_secret de PayPal se descifran en memoria. El token de acceso se cachea con su TTL.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-02: Pago con PayPal
   * - **Depende de**
     - FR-ORD-01.02 (orden creada en PENDING_PAYMENT)
   * - **Requerido por**
     - FR-PAY-04.01 (webhook PayPal confirma el pago)
   * - **Test**
     - TST-FR-PAY-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-02

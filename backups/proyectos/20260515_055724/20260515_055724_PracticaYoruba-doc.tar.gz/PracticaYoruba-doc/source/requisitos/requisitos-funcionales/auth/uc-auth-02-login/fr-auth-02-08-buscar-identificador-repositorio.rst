.. meta::
   :artefacto: FR-AUTH-02.08
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-08:

============================================================
FR-AUTH-02.08: Buscar el identificador en el repositorio
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.08
   * - **Nombre**
     - Buscar el identificador normalizado en el repositorio de usuarios
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 11 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — UserRepository)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE buscar el identificador normalizado en el repositorio
   de usuarios y retornar el resultado CUANDO el formato ha sido
   validado correctamente.

**Descripcion:**

El identificador puede ser el ``email`` o el ``username`` del usuario.
El sistema determina cuál campo consultar por la presencia del
carácter ``@``: si el identificador lo contiene, se busca por
``User.email`` con comparación insensible a mayúsculas; si no,
se busca por ``User.username`` con la misma comparación. Ambos
campos son únicos en el repositorio de usuarios (modelo ``User``
en MOD-001 ACCOUNTS).

Si el usuario no existe en el repositorio:

1. El sistema incrementa el contador de intentos fallidos del
   origen de la solicitud, de la misma forma que en FR-AUTH-02.01
   — el contador es compartido entre todos los pasos de validación.
2. Retorna HTTP 401 con el mensaje genérico de credenciales inválidas,
   sin revelar si el identificador existe o no — esto previene la
   enumeración de usuarios registrados.
3. Registra el intento en auditoría con tipo ``FALLO_ID_NO_ENCONTRADO``.

Si el usuario existe, el resultado se propaga al paso siguiente del
flujo (FR-AUTH-02.09 — verificar email confirmado).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Identificador encontrado como email
   DADO identificador "juan@ejemplo.com" que existe en el sistema
   CUANDO se busca en el repositorio
   ENTONCES se encuentra el usuario correspondiente
   Y el proceso continua al paso siguiente (verificar email confirmado)

   Escenario 2: Identificador encontrado como username
   DADO identificador "juanito123" que existe como username
   CUANDO se busca
   ENTONCES se encuentra el usuario sin importar el case del username
   Y el proceso continua

   Escenario 3: Identificador NO existe — respuesta generica
   DADO identificador "nadie@ejemplo.com" que NO existe
   CUANDO se busca
   ENTONCES se retorna HTTP 401
   Y el body es {"codigo_error": "CREDENCIALES_INVALIDAS",
   "mensaje": "Identificador o contraseña incorrectos"}
   Y el mensaje es IDENTICO al de contraseña incorrecta (no diferencia ambos)
   Y el contador de intentos de la IP incrementa en 1

   Escenario 4: Repositorio no disponible — EX-02
   DADO error de conexion a la base de datos
   CUANDO se intenta buscar
   ENTONCES se retorna HTTP 500 con {"codigo_error": "ERROR_SISTEMA"}
   Y el error se registra en el log del servidor
   Y el contador de intentos NO incrementa (no fue un intento malicioso)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — el contador se incrementa
  en este paso si el identificador no existe)
- **Notas:** La busqueda es ``iexact`` (case-insensitive). El usuario
  "JUAN@test.com" y "juan@test.com" son el mismo. Esto es coherente
  con la normalizacion de FR-AUTH-02.07.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.07 (identificador normalizado)
   * - **Requerido por**
     - FR-AUTH-02.09 (verificar que el email del usuario fue confirmado)
   * - **BR**
     - BR-015
   * - **Test**
     - TST-FR-AUTH-02.08 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 11 de UC-AUTH-02

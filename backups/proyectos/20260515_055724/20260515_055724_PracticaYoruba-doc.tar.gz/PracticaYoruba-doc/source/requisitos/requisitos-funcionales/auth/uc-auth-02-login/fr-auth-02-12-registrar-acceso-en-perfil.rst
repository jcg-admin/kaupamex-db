.. meta::
   :artefacto: FR-AUTH-02.12
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-12:

====================================================
FR-AUTH-02.12: Registrar fecha del acceso en el perfil
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.12
   * - **Nombre**
     - Actualizar el campo last_login del usuario con el timestamp del acceso
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 17 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — campo heredado de AbstractBaseUser)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el campo ``last_login`` del usuario
   con el timestamp del acceso exitoso CUANDO ambos tokens han sido
   emitidos correctamente.

**Descripcion:**

Al completarse el acceso exitoso, el sistema actualiza el campo
``User.last_login`` con el timestamp exacto del momento del acceso.
La actualización es atómica y afecta solo ese campo, sin modificar
``updated_at`` ni disparar lógica adicional sobre el registro del
usuario.

El campo ``User.last_login`` tiene los siguientes usos:

- Mostrar «Último acceso» en el perfil del usuario (UC-AUTH-05).
- Identificar cuentas sin actividad durante un período prolongado.
- Auditoría de seguridad de accesos por usuario.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: last_login actualizado correctamente
   DADO usuario que hace login exitoso
   CUANDO se procesa el paso 17
   ENTONCES User.last_login = timestamp actual (UTC)
   Y la diferencia entre last_login y now() es < 1 segundo

   Escenario 2: Fallo en la actualizacion no bloquea el login
   DADO error temporal en la BD al actualizar last_login
   CUANDO falla el UPDATE
   ENTONCES el login continua exitosamente
   Y los tokens ya emitidos son validos
   Y el error se registra en el log del servidor
   (Este paso no es critico — un fallo no debe impedir el acceso)

   Escenario 3: last_login visible en el perfil
   DADO usuario que hizo login hace 5 minutos
   CUANDO consulta GET /api/v1/auth/profile/
   ENTONCES last_login muestra el timestamp del login de hace 5 minutos

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — pero last_login
  es del AbstractBaseUser de Django, no del AbstractBaseModel del proyecto)
- **Notas:** El campo ``last_login`` es en timezone UTC.
  La conversion a timezone local es responsabilidad del frontend.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.11 (refresh token emitido)
   * - **Requerido por**
     - FR-AUTH-02.13 (registrar en auditoria)
   * - **Test**
     - TST-FR-AUTH-02.12 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 17 de UC-AUTH-02

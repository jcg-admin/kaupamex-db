.. meta::
   :artefacto: FR-AUTH-03.07
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-03.07: NFR Performance y Seguridad del logout
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.07
   * - **Nombre**
     - Restricciones de performance y seguridad especificas del endpoint de logout
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - Secciones 6.1 y 6.2 — Performance y Seguridad
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint POST /api/v1/auth/logout/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico

----

2. Especificacion
-----------------

**Declaracion:**

   El endpoint de logout DEBE responder en menos de 200ms P95 y cumplir
   los requisitos de seguridad de revocacion efectiva CUANDO procesa
   solicitudes de cierre de sesion.

**Descripcion:**

Performance (seccion 6.1):

- **P95:** menor a 200ms — el logout es mas rapido que el login porque
  no hay comparacion de contraseña. Solo es un INSERT en la blacklist
  mas el UPDATE de ``last_logout`` del perfil.
- **Disponibilidad:** el endpoint funciona aunque el servicio de auditoria
  no este disponible (EX-01 de FR-AUTH-03.05)

Seguridad (seccion 6.2):

- **Revocacion efectiva:** el token en la blacklist no puede usarse
  en ``POST /api/v1/auth/refresh/`` — devuelve 401 ``token_not_valid``
- **Limpieza del cliente:** el 200 OK instruye al cliente a eliminar
  sus tokens aunque la revocacion en servidor falle (degradacion graceful)
- **Registro de auditoria:** todo cierre queda en AccessAuditLog
- **Idempotencia:** multiples logouts con el mismo token retornan 200
  sin error (el token ya esta en blacklist — no es un problema)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Logout rapido bajo carga normal
   DADO 100 usuarios haciendo logout simultaneamente
   CUANDO se mide el tiempo de respuesta
   ENTONCES P95 <= 200ms
   Y ninguna solicitud retorna 5xx

   Escenario 2: Token revocado no puede renovar sesion
   DADO refresh token que fue invalidado via logout
   CUANDO se intenta usar en POST /api/v1/auth/refresh/
   ENTONCES respuesta HTTP 401 con "Token is blacklisted"
   Y el usuario no puede obtener un nuevo access token

   Escenario 3: Logout idempotente
   DADO el mismo refresh token usado 3 veces en logout
   CUANDO se procesan los 3 requests
   ENTONCES los 3 retornan 200 OK
   Y no se genera ningun error de "token ya en blacklist"

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-002

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Secciones UC**
     - 6.1 Performance, 6.2 Seguridad
   * - **RNF del sistema**
     - RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-002
   * - **Test**
     - TST-FR-AUTH-03.07 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de las secciones 6.1 y 6.2 de UC-AUTH-03

.. meta::
   :artefacto: FR-INC-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inc-02-01:

FR-INC-02.01: Recuperar o crear el carrito activo del actor
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-02.01
   * - **Nombre**
     - Recuperar o crear el carrito activo del actor
   * - **UC Origen**
     - UC-INC 02 RECUPERAR CARRITO SESION
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el carrito activo al UC incluidor CUANDO se necesita el carrito.

**Descripcion:**

Logica de resolucion:

- **Visitante anonimo**: ``Cart.objects.get_or_create(session_key=request.session.session_key)``
- **Comprador autenticado**: ``Cart.objects.get_or_create(user=request.user)``

Si el carrito no existe: se crea uno vacio y se retorna.
El UC incluidor recibe el objeto Cart para operar sobre el.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Visitante con carrito de sesion existente
   DADO visitante con session_key que ya tiene un Cart
   CUANDO se recupera
   ENTONCES retorna el Cart existente con sus items

   Escenario: Comprador sin carrito aun
   DADO comprador autenticado sin carrito previo
   CUANDO se recupera
   ENTONCES se crea un Cart vacio y se retorna


----

4. Reglas y Restricciones
--------------------------

- **BR-003 (carrito en sesion)**
- **BR-004 (carrito sin login)**

- **Notas:** N/A

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC 02 RECUPERAR CARRITO SESION
   * - **Depende de**
     - Session key o JWT del actor
   * - **Requerido por**
     - UC-CART-01, UC-CART-02, UC-CART-03, UC-CART-04, UC-CART-05, UC-ORD-01
   * - **Test**
     - TST-FR-INC-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INC 02 RECUPERAR CARRITO SESION

.. meta::
   :artefacto: FR-CART-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-02-02:

=================================================
FR-CART-02.02: Calcular desglose de totales
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-02.02
   * - **Nombre**
     - Calcular subtotal, descuento, envio, IVA y total del carrito
   * - **UC Origen**
     - UC-CART-02: Ver carrito
   * - **Paso UC**
     - Paso 4 del flujo principal
   * - **Modulo**
     - MOD-005 CART + MOD-004 VOUCHER + MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Calculo

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular y presentar el desglose completo
   de montos del carrito CUANDO el actor consulta su carrito.

**Descripcion:**

Desglose de montos (BR-001, BR-002):

.. list-table::
   :widths: 25 75
   :header-rows: 1

   * - Campo
     - Formula
   * - ``subtotal``
     - suma(item.unit_price * item.quantity)
   * - ``discount``
     - voucher.calculate_discount(subtotal) si hay voucher, sino 0
   * - ``subtotal_neto``
     - subtotal - discount
   * - ``shipping_cost``
     - 0 si subtotal_neto >= SiteSettings.free_shipping_threshold,
       sino costo del metodo de envio seleccionado
   * - ``tax``
     - se informa el IVA incluido: subtotal_neto * iva / (1 + iva)
   * - ``total``
     - subtotal_neto + shipping_cost

Adicionalmente se muestra cuanto falta para alcanzar el envio gratis
si el umbral esta configurado y no se ha alcanzado.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO carrito con items
   CUANDO se calculan los totales
   ENTONCES el desglose es aritmeticamente correcto

   Escenario 1: Umbral de envio gratis no alcanzado
   DADO SiteSettings.free_shipping_threshold = 500 y subtotal = 300
   CUANDO se calculan totales
   ENTONCES shipping_cost = costo del metodo seleccionado
   Y se muestra "Te faltan $200 para envio gratis"

   Escenario 2: Umbral de envio gratis alcanzado
   DADO subtotal_neto = 600 y umbral = 500
   CUANDO se calculan totales
   ENTONCES shipping_cost = 0
   Y se muestra el badge de envio gratis

   Escenario 3: Voucher de envio gratis
   DADO voucher de tipo FREE_SHIPPING aplicado
   CUANDO se calculan totales
   ENTONCES shipping_cost = 0 independiente del subtotal
   Y el ahorro de envio se muestra desglosado

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio sin IVA), BR-002 (IVA en checkout),
  BR-012 (un solo descuento por producto)
- **Notas:** Los precios de los items en el carrito ya incluyen IVA
  (BR-002 se aplica en la visualizacion del catalogo).
  El desglose de IVA es informativo, no lo agrega de nuevo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-02: Ver carrito
   * - **Depende de**
     - FR-CART-02.01 (carrito recuperado con sus items)
   * - **Requerido por**
     - FR-ORD-01.02 (el checkout usa estos totales como base)
   * - **BR**
     - BR-001, BR-002, BR-012
   * - **Test**
     - TST-FR-CART-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-02
   * - 1.1.0
     - 2026-05-05
     - Verificacion de nombres canonicos. Sin codigo Python. Nombres de modelos correctos.

.. meta::
   :artefacto: FR-AUTH-02.19
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-19:

==========================================================
FR-AUTH-02.19: EX-04 — Rechazar solicitud con datos invalidos
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.19
   * - **Nombre**
     - EX-04: Retornar 400 con detalle de campos invalidos o faltantes
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - EX-04 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS (serializer de DRF — validacion de request)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar HTTP 400 con el detalle de cada campo
   invalido CUANDO el body del request tiene campos faltantes,
   tipos incorrectos o formato invalido.

**Descripcion:**

Esta excepcion se activa antes de cualquier logica de negocio,
en la capa del serializer de Django REST Framework.

Casos que activan esta excepcion:

- Body del POST vacio o sin ``Content-Type: application/json``
- Campo ``identificador`` ausente del body
- Campo ``password`` ausente del body
- Campo ``identificador`` con tipo que no es string
- Body que no es JSON valido (malformado)

Respuesta estandar:

.. code-block:: json

   HTTP 400 Bad Request
   {
     "codigo_error": "DATOS_INVALIDOS",
     "mensaje": "Los datos enviados tienen errores.",
     "detalles": {
       "identificador": ["Este campo es obligatorio."],
       "password": ["Este campo es obligatorio."]
     }
   }

A diferencia de EX-01 (limite de intentos), en este caso el
contador de intentos fallidos NO se incrementa — la solicitud
ni siquiera es un intento de autenticacion legitimo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Body completamente vacio
   DADO POST /api/v1/auth/login/ con body {}
   CUANDO el serializer valida
   ENTONCES HTTP 400 con detalles de ambos campos faltantes
   Y el body incluye "identificador": ["Este campo es obligatorio."]
   Y el body incluye "password": ["Este campo es obligatorio."]

   Escenario 2: Body no es JSON valido
   DADO POST con Content-Type: application/json pero body "esto no es json"
   CUANDO el parser lo intenta leer
   ENTONCES HTTP 400 con {"codigo_error": "DATOS_INVALIDOS",
   "mensaje": "El cuerpo de la solicitud no es JSON valido."}

   Escenario 3: Content-Type incorrecto
   DADO POST con Content-Type: text/plain
   CUANDO DRF intenta parsear
   ENTONCES HTTP 415 Unsupported Media Type
   Y el body indica que solo se acepta application/json

   Escenario 4: Contador de intentos NO incrementa
   DADO solicitud con body invalido (EX-04)
   CUANDO el sistema retorna el 400
   ENTONCES el contador de intentos de la IP NO cambia
   Y la solicitud invalida no "consume" intentos del rate limiter

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-USAB-001 (mensajes de error comprensibles
  con detalle por campo — los desarrolladores del frontend necesitan
  saber exactamente que campo es invalido)
- **Notas:** Esta excepcion tambien aplica si un atacante intenta
  enviar tipos de datos incorrectos (ej: ``{"identificador": 123}``).
  DRF lo rechaza con 400 antes de procesar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Detectado en**
     - LoginSerializer.is_valid() — antes de FR-AUTH-02.01
   * - **Requerido por**
     - El cliente frontend corrige los campos y reintenta
   * - **RNF**
     - RNF-USAB-001
   * - **Test**
     - TST-FR-AUTH-02.19 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-04 de UC-AUTH-02

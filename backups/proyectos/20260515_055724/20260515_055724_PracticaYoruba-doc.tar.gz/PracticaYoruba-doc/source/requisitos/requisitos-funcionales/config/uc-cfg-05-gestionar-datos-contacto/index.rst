.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cfg-05-gestionar-datos-contacto
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cfg-05-02-actualizar-datos-contacto
   fr-cfg-05-gestionar-datos-contacto-01

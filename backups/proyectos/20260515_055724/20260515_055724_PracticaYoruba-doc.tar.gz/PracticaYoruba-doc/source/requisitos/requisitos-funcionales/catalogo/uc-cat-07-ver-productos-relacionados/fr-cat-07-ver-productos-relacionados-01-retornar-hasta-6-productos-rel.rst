.. meta::
   :artefacto: FR-CAT-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-07-01:

FR-CAT-07.01: Retornar hasta 6 productos relacionados
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-07.01
   * - **Nombre**
     - Retornar hasta 6 productos relacionados
   * - **UC Origen**
     - UC-CAT 07 VER PRODUCTOS RELACIONADOS
   * - **Paso UC**
     - Paso 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar hasta 6 productos de la misma categoria CUANDO se carga la ficha del producto.

**Descripcion:**

``Product.objects.filter(category=product.category, is_active=True).exclude(pk=product.pk)[:6]``
Ordenamiento: ``-is_featured, -created_at``.
Si la categoria no tiene suficientes productos: se retornan los disponibles (puede ser 0).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Productos relacionados disponibles
   DADO producto de categoria 'Collares Oshun'
   CUANDO se cargan los relacionados
   ENTONCES hasta 6 productos de 'Collares Oshun' sin incluir el actual

   Escenario: Sin productos relacionados
   DADO producto de categoria con un solo producto activo
   CUANDO se cargan relacionados
   ENTONCES lista vacia — la seccion no se muestra al visitante


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Los relacionados se retornan junto con la ficha en FR-CAT-02.01 para evitar una llamada extra.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 07 VER PRODUCTOS RELACIONADOS
   * - **Depende de**
     - FR-CAT-02.01 (ficha del producto cargada)
   * - **Requerido por**
     - FR-CART-01.01 (agregar desde relacionados)
   * - **Test**
     - TST-FR-CAT-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 07 VER PRODUCTOS RELACIONADOS

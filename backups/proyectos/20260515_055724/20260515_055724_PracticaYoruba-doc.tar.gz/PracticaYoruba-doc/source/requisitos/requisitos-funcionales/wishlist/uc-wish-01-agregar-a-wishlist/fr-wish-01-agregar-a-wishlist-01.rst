.. meta::
   :artefacto: FR-WISH-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-wish-01-01:

FR-WISH-01.01: Agregar producto a la lista de deseos
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-01.01
   * - **Nombre**
     - Agregar producto a la lista de deseos
   * - **UC Origen**
     - UC-WISH 01 AGREGAR A WISHLIST
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-011 WISHLIST
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear el WishlistItem CUANDO el comprador agrega un producto.

**Descripcion:**

Verifica que el producto/variante esta activo.
Verifica que no supera el limite de la lista (configurable en SiteSettings).
Guarda ``price_at_add = variant.effective_price()`` para detectar bajas de precio.
Unique together: ``(user, variant)`` o ``(user, product)`` si no hay variante.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Agregado exitosamente
   DADO comprador y producto activo con variante
   CUANDO agrega a wishlist
   ENTONCES WishlistItem creado con price_at_add=precio_actual

   Escenario: Producto ya en la lista
   DADO producto ya en la wishlist del comprador
   CUANDO intenta agregarlo de nuevo
   ENTONCES error 409: PRODUCTO_YA_EN_WISHLIST

   Escenario: Limite de lista alcanzado
   DADO comprador con la lista llena
   CUANDO intenta agregar otro
   ENTONCES error 422: LIMITE_LISTA_ALCANZADO con el maximo permitido


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El limite de la lista es configurable por el admin en SiteSettings.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH 01 AGREGAR A WISHLIST
   * - **Depende de**
     - FR-AUTH-02.03 (comprador autenticado)
   * - **Requerido por**
     - FR-WISH-02.01 (ver la lista)
   * - **Test**
     - TST-FR-WISH-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-WISH 01 AGREGAR A WISHLIST

.. meta::
   :artefacto: FR-AUTH-08.06
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-08-06:

===========================================================
FR-AUTH-08.06: Excepciones y NFR del cambio de contraseña
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.06
   * - **Nombre**
     - EX-01/EX-02 y restricciones tecnicas del endpoint de cambio de contraseña
   * - **UC Origen**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Paso UC**
     - PARTE 5 y PARTE 6
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint POST /api/v1/auth/change-password/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El endpoint de cambio de contraseña DEBE manejar los fallos del
   repositorio de forma atomica y cumplir los requisitos de seguridad
   de no exponer contraseñas en ninguna capa del sistema.

**Descripcion:**

**EX-01 — Error al guardar (repositorio falla):**

Si el guardado falla (error del repositorio o error de integridad):

- El rollback de la transaccion garantiza que la contraseña vieja
  sigue siendo la valida
- HTTP 500 con mensaje generico
- La contraseña anterior nunca fue reemplazada (atomicidad)

**EX-02 — Error al invalidar sesiones:**

Si la invalidacion de tokens en blacklist falla DESPUES de guardar
la nueva contraseña:

- La nueva contraseña ya esta almacenada — no se revierte
- Las sesiones antiguas expiraran por su tiempo natural (7 dias)
- HTTP 200 con advertencia: ``"warning": "sessions_not_invalidated"``
- El cambio de contraseña es exitoso aunque las sesiones no se
  hayan invalidado inmediatamente

**Performance (6.1):** P95 <= 800ms — incluye dos comparaciones de
contraseña con el algoritmo de hash de contraseñas (~200ms cada una: verificar actual + verificar diferente).

**Seguridad (6.2):**

- Contraseña actual verificada en tiempo constante (FR-AUTH-08.01)
- Nueva contraseña diferente a la actual (FR-AUTH-08.04)
- Ninguna contraseña aparece en logs, respuestas de error ni en el
  campo ``detail`` de las excepciones de DRF
- Invalidacion de otras sesiones como medida de seguridad proactiva

**Confiabilidad (6.3):** atomicidad — guardar nueva contraseña e
invalidar sesiones en ``@transaction.atomic``. Si falla el guardado,
ninguna sesion se invalida.

**Usabilidad (6.4):** los tres campos son claramente diferenciados
con etiquetas: "Contraseña actual", "Nueva contraseña", "Confirmar
nueva contraseña". El indicador de fortaleza orienta sin bloquear.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Error al guardar — contraseña anterior intacta
   DADO OperationalError en user.set_password() + user.save()
   CUANDO falla el guardado
   ENTONCES rollback completo — la contraseña anterior sigue siendo valida
   Y el usuario puede seguir usando su contraseña anterior
   Y recibe HTTP 500 con mensaje generico

   Escenario 2: Ningun log contiene contraseñas
   DADO cambio de contraseña (exitoso o fallido)
   CUANDO se revisan todos los logs del servidor
   ENTONCES ninguna contraseña (actual ni nueva) aparece en texto plano
   Y los logs de Django no tienen el campo "password" en ningun nivel

   Escenario 3: P95 <= 800ms con dos bcrypt
   DADO endpoint bajo carga normal
   CUANDO se mide el tiempo del endpoint completo
   ENTONCES P95 <= 800ms incluyendo verificar_actual (~200ms) +
   verificar_diferente (~200ms) + guardar + invalidar sesiones

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-002, RNF-SEC-001

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Secciones**
     - PARTE 5 (EX-01, EX-02) y PARTE 6
   * - **RNF del sistema**
     - RNF-PERF-002, RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-08.06 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de PARTE 5 y 6 de UC-AUTH-08

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pro-01-crear-voucher-admin
========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pro-01-02-validar-y-persistir-voucher
   fr-pro-01-crear-voucher-admin-01

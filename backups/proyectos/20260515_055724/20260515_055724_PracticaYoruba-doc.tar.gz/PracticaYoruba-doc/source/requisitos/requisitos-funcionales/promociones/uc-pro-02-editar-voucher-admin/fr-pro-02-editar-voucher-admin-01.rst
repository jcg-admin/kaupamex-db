.. meta::
   :artefacto: FR-PRO-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pro-02-01:

FR-PRO-02.01: Editar reglas de un voucher existente
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-02.01
   * - **Nombre**
     - Editar reglas de un voucher existente
   * - **UC Origen**
     - UC-PRO 02 EDITAR VOUCHER ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar los campos editables del voucher CUANDO el admin los modifica.

**Descripcion:**

Campos editables: ``max_uses``, ``valid_from``, ``valid_until``, ``min_order_value``, ``is_active``.
Campo NO editable: ``voucher_type`` — inmutable por integridad del historial.
Los cambios se aplican inmediatamente en UC-CART-04.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Extension de vigencia
   DADO voucher que expira manana
   CUANDO el admin extiende valid_until en 7 dias
   ENTONCES el voucher es valido 7 dias mas desde hoy

   Escenario: Intento de cambiar tipo de voucher
   DADO voucher FIXED que el admin quiere cambiar a PERCENTAGE
   CUANDO se intenta
   ENTONCES error 422: TIPO_VOUCHER_INMUTABLE


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** Los cambios son inmediatos — no hay periodo de gracia para que los cambios entren en efecto.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO 02 EDITAR VOUCHER ADMIN
   * - **Depende de**
     - Voucher existente
   * - **Requerido por**
     - FR-CART-04.01 (refleja los nuevos limites)
   * - **Test**
     - TST-FR-PRO-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PRO 02 EDITAR VOUCHER ADMIN

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — CART
==============================

**16 FRs** escritos uno por uno.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-cart-01-agregar-producto
     - 3
   * - uc-cart-02-ver-carrito
     - 2
   * - uc-cart-03-eliminar-item
     - 3
   * - uc-cart-04-aplicar-cupon
     - 2
   * - uc-cart-05-guardar-carrito
     - 3
   * - uc-cart-06-sincronizar-carrito
     - 3

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-cart-01-agregar-producto/index
   uc-cart-02-ver-carrito/index
   uc-cart-03-eliminar-item/index
   uc-cart-04-aplicar-cupon/index
   uc-cart-05-guardar-carrito/index
   uc-cart-06-sincronizar-carrito/index

.. meta::
   :artefacto: FR-PAY-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-02.02: Crear orden de pago en PayPal y redirigir al comprador
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-02.02
   * - **Nombre**
     - Crear orden en el Gateway de Pago PayPal y retornar la URL de aprobacion
   * - **UC Origen**
     - UC-PAY-02: Pago con PayPal
   * - **Paso UC**
     - Pasos 2, 3, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la orden de pago en el Gateway de Pago PayPal
   usando el Strategy Pattern y retornar la URL de aprobacion al
   comprador CUANDO selecciona PayPal como metodo de pago.

**Descripcion:**

El Strategy Pattern (BR-006, BR-007) permite que el mismo flujo
de checkout soporte múltiples gateways.

El sistema descifra en memoria las credenciales
``SiteSettings.paypal_client_id`` y ``SiteSettings.paypal_client_secret``
(RNF-SEC-002) e inicializa el cliente de PayPal. Crea una orden PayPal
con intent ``CAPTURE``, el importe total en MXN (``OrderValue.total``),
``reference_id = Order.order_number`` y las URLs de retorno y
cancelación. El gateway retorna el identificador de la orden PayPal y
el enlace de aprobación (``rel = 'approve'``) al que se redirige al
comprador. La captura del pago ocurre en UC-PAY-04 (webhook).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Orden PayPal creada y comprador redirigido
   DADO orden en PENDING_PAYMENT seleccionando PayPal
   CUANDO el sistema crea la orden en el gateway
   ENTONCES se crea Payment con gateway_payment_id del gateway PayPal
   Y el comprador es redirigido a la URL de aprobacion de PayPal

   Escenario 2: Gateway no disponible
   DADO fallo de conectividad con el Gateway de Pago PayPal
   CUANDO el sistema intenta crear la orden
   ENTONCES HTTP 503 con mensaje claro de indisponibilidad
   Y la orden sigue en PENDING_PAYMENT

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-006 (Strategy Pattern para gateways),
  BR-007 (multiples gateways), BR-009 (credenciales en servidor)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-02: Pago con PayPal
   * - **Depende de**
     - FR-ORD-01.03 (la orden fue creada)
   * - **Requerido por**
     - FR-PAY-04.01 (webhook de confirmacion de PayPal)
   * - **Test**
     - TST-FR-PAY-02.02 (pendiente — mock del cliente PayPal)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-3 y 5-6 de UC-PAY-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

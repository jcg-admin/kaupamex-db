.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-qst-02-ver-preguntas
==================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-qst-02-02-recuperar-preguntas-respondidas
   fr-qst-02-ver-preguntas-01

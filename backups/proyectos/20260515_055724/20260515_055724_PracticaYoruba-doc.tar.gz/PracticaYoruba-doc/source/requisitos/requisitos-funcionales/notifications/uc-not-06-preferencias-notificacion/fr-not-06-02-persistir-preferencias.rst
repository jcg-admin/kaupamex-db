.. meta::
   :artefacto: FR-NOT-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-06-02:

=============================================================================
FR-NOT-06.02: Persistir las preferencias de notificación por tipo de email
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-06.02
   * - **Nombre**
     - Mostrar el estado actual de cada tipo de notificación, proteger
       los tipos obligatorios de la desactivación y persistir los cambios
       que el usuario realice
   * - **UC Origen**
     - UC-NOT-06: Preferencias de Notificación
   * - **Paso UC**
     - Pasos 2, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE presentar el estado actual de cada tipo de
   notificación diferenciando los tipos obligatorios de los
   opcionales, y persistir los cambios que el usuario realice
   sobre los tipos opcionales CUANDO accede a la sección de
   preferencias de notificación de su perfil.

**Descripcion:**

Las preferencias de notificación tienen dos categorías con
comportamientos distintos:

**Notificaciones obligatorias.** Son las que el sistema siempre
envía independientemente de las preferencias del usuario porque
están vinculadas a la seguridad o a la transparencia del servicio.
El usuario las ve en la interfaz pero el control de activación
está bloqueado. Los tipos obligatorios son: confirmación de orden,
cambio de contraseña y alertas de seguridad de la cuenta.

**Notificaciones opcionales.** Son las que el usuario puede
activar o desactivar libremente a nivel individual. Si desactiva
un tipo, el Sistema de Notificaciones omitirá ese email para ese
usuario incluso cuando el evento correspondiente ocurra. Los tipos
opcionales incluyen: avisos de cambio de estado de la orden,
actualizaciones del envío, confirmación de reembolso, respuestas
a preguntas y campañas de newsletter.

El sistema ofrece además la opción de desactivar todos los tipos
opcionales con una sola acción (Alt. C), útil para usuarios que
quieren reducir al mínimo los emails sin tener que desactivar
cada tipo por separado. La reactivación también puede hacerse en
bloque (Alt. B).

Si el usuario intenta desactivar un tipo obligatorio mediante
petición directa a la API (EX-02), el sistema rechaza la acción
con un mensaje que explica por qué ese tipo no puede desactivarse.
Los controles de la interfaz ya impiden visualmente el intento,
pero la protección existe también en el servidor.

Las preferencias persisten por usuario. Cuando el Sistema de
Notificaciones va a encolar un email, consulta estas preferencias
como primer paso (UC-INC-03) antes de generar ningún contenido.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Usuario desactiva avisos de cambio de estado de orden
   DADO usuario con la preferencia ORDER_STATUS_UPDATE activa por defecto
   CUANDO desactiva ese tipo en el panel de preferencias
   ENTONCES la preferencia queda persistida como inactiva para ese usuario
   Y el siguiente cambio de estado de su orden no genera ningún email
   Y la confirmación de orden sigue funcionando (es obligatoria)

   Escenario 2: Usuario intenta desactivar la confirmación de orden — rechazado
   DADO usuario que intenta desactivar ORDER_CONFIRMATION via la API
   CUANDO el sistema verifica el tipo (EX-02)
   ENTONCES HTTP 400 con {"codigo_error": "NOTIFICACION_OBLIGATORIA",
   "mensaje": "La confirmación de orden no puede desactivarse porque
   es necesaria para el correcto seguimiento de tu pedido."}
   Y la preferencia no cambia

   Escenario 3: Usuario desactiva todos los tipos opcionales de una vez
   DADO usuario que activa la opción "desactivar todo" (Alt. C)
   CUANDO el sistema procesa la acción
   ENTONCES todos los tipos opcionales quedan inactivos
   Y los tipos obligatorios siguen activos sin cambio
   Y el usuario puede reactivar tipos individuales en cualquier momento

   Escenario 4: Estado actual mostrado correctamente al abrir preferencias
   DADO usuario que lleva 3 tipos desactivados desde la semana anterior
   CUANDO abre la sección de preferencias
   ENTONCES el panel muestra el estado real de cada tipo:
   los 3 desactivados aparecen como inactivos
   Y los obligatorios aparecen activos con el control bloqueado

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 600ms para cargar y
  guardar preferencias)
- **Notas:** Las preferencias por defecto al crear la cuenta tienen
  todos los tipos opcionales activos. El usuario parte de recibir
  todo y decide qué suprimir.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-06: Preferencias de Notificación
   * - **Requerido por**
     - FR-NOT-01.02, FR-NOT-02.02, FR-NOT-03.02, FR-NOT-04.02,
       FR-NOT-05.02 y FR-NOT-07.02 (todos consultan estas
       preferencias antes de encolar)
   * - **Incluido en**
     - UC-INC-03 (consulta las preferencias como primer paso)
   * - **Test**
     - TST-FR-NOT-06.02 (pendiente — verificar que la protección
       del servidor rechaza la desactivación de tipos obligatorios
       aunque la petición llegue directamente a la API sin pasar
       por la interfaz)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido incorrecto: escenarios
       de encolar email en un FR de gestión de preferencias)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: diferencia obligatorio/opcional,
       protección en servidor, desactivar todo, 4 escenarios BDD
       correctos para un FR de tipo Datos

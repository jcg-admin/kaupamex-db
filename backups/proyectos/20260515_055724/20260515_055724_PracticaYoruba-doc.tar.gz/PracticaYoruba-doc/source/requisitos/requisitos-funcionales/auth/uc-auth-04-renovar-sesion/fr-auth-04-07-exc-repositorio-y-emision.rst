.. meta::
   :artefacto: FR-AUTH-04.07
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-04.07: EX-01 y EX-02 — Repositorio no disponible o fallo en emision
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.07
   * - **Nombre**
     - EX-01/EX-02: Rechazar renovacion de forma segura ante fallos internos
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - EX-01 y EX-02 — Excepciones del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Confiabilidad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE rechazar la renovacion de forma segura ante fallos
   del repositorio o en la emision CUANDO ocurren errores internos.

**Descripcion:**

**EX-01 — Repositorio no disponible:**

La BD no responde al verificar el token en la blacklist (pasos 3-5).

Comportamiento conservador: ante la duda, RECHAZAR. No se puede
saber si el token fue revocado si no se puede consultar la BD.

.. code-block:: json

   HTTP 503
   {"codigo_error": "ERROR_SISTEMA",
    "mensaje": "El servicio esta temporalmente no disponible."}

El cliente puede reintentar en unos momentos. El token del usuario
sigue siendo valido (su exp no cambio).

**EX-02 — Error al emitir nuevas credenciales:**

Las verificaciones pasaron pero falla la generacion del nuevo par.

Comportamiento: el token USADO NO se invalida (porque la emision
del nuevo fallo). El cliente puede reintentar con el mismo refresh token.

.. code-block:: json

   HTTP 500
   {"codigo_error": "ERROR_SISTEMA",
    "mensaje": "Ocurrio un error interno. Intenta de nuevo."}

Esta es la diferencia clave con EX-01 del login: aqui el token
original NO se invalida porque aun no se emitio el nuevo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: BD no disponible — fallo seguro (EX-01)
   DADO OperationalError al consultar la blacklist
   CUANDO el sistema no puede verificar si el token fue revocado
   ENTONCES retorna HTTP 503 (no 401, porque no es culpa del usuario)
   Y el token del usuario sigue siendo el mismo (no se invalido)
   Y el cliente puede reintentar cuando el servicio se recupere

   Escenario 2: Emision falla — token original preservado (EX-02)
   DADO fallo en TokenBackend.make_token al generar el nuevo par
   CUANDO el sistema no puede emitir las nuevas credenciales
   ENTONCES retorna HTTP 500
   Y el refresh token ORIGINAL no fue invalidado (la transaccion no ocurrio)
   Y el cliente puede reintentar con el mismo refresh token

   Escenario 3: Atomicidad en EX-02
   DADO fallo que ocurre entre invalidar el viejo y emitir el nuevo
   CUANDO hay un error a mitad de la operacion
   ENTONCES la transaccion hace rollback completo
   Y el refresh token viejo sigue siendo valido
   Y el usuario puede reintentar la renovacion

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-001 (disponibilidad), RNF-AVAIL-002
  (atomicidad — la invalidacion y emision son atomicas)
- **Notas:** La atomicidad (EX-02) es posible porque
  el Servicio de Autenticacion envuelve la rotacion en una
  transaccion de BD. Si falla cualquier parte, hace rollback.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Detectado en**
     - FR-AUTH-04.02 a FR-AUTH-04.05
   * - **RNF**
     - RNF-AVAIL-001, RNF-AVAIL-002
   * - **Test**
     - TST-FR-AUTH-04.07 (pendiente — mock de error del repositorio y error del Servicio de Autenticacion)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-01 y EX-02 de UC-AUTH-04

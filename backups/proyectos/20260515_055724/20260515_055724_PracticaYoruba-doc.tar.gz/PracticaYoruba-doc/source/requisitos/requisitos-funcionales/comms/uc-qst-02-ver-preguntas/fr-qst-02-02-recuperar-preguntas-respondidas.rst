.. meta::
   :artefacto: FR-QST-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-qst-02-02:

==========================================================================
FR-QST-02.02: Recuperar las preguntas respondidas con búsqueda y degrada
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-02.02
   * - **Nombre**
     - Retornar las preguntas aprobadas del producto ordenadas por
       relevancia, con filtrado por término de búsqueda y degradación
       silenciosa si el servicio no responde
   * - **UC Origen**
     - UC-QST-02: Ver Preguntas y Respuestas de un Producto
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal; Alt. B (búsqueda); EX-02
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar únicamente las preguntas con estado
   ``ANSWERED`` del producto solicitado, ordenadas por relevancia
   o fecha según el parámetro del visitante, con soporte para filtrar
   por término de búsqueda dentro del texto de la pregunta y de la
   respuesta, y degradar silenciosamente si el servicio no está
   disponible.

**Descripcion:**

La sección de preguntas forma parte de la ficha del producto
(FR-CAT-02.02). Solo son visibles para el visitante las preguntas
que el equipo respondió y aprobó. Las que están en estado
``PENDING_MODERATION``, ``PENDING_ANSWER`` o ``REJECTED`` no
aparecen en ningún caso.

**Ordenamiento disponible:**

El visitante puede elegir entre dos criterios de ordenamiento. Por
fecha descendente, que coloca las preguntas más recientes primero y
es útil cuando el producto ha cambiado y las preguntas nuevas reflejan
el estado actual. Por relevancia, que prioriza las preguntas que más
visitantes encontraron útiles según los votos de utilidad; este es el
ordenamiento predeterminado porque maximiza el valor para el mayor
número de visitantes.

**Búsqueda dentro de las preguntas (Alt. B):**

Cuando el visitante escribe un término en el buscador de la sección,
el sistema filtra las preguntas ``ANSWERED`` del producto mostrando
solo las que contienen ese término en el texto de la pregunta o en
el texto de la respuesta. El término buscado se destaca visualmente
en los resultados para que el visitante localice la información
rápidamente. Si la búsqueda no devuelve resultados, el sistema
muestra el estado vacío con el acceso directo a UC-QST-01 para que
el visitante pueda hacer su pregunta.

**Degradación silenciosa (EX-02):**

Si el repositorio de preguntas no responde dentro del tiempo máximo
de espera, la sección de preguntas se oculta de la respuesta de la
ficha del producto sin que el resto de la ficha se vea afectado. El
visitante ve el producto completo con sus imágenes, precio y botón
de compra; simplemente no aparece la sección de preguntas. Esto
prioriza el flujo de compra sobre la funcionalidad informativa.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Preguntas respondidas retornadas con ordenamiento por relevancia
   DADO producto "Sopera de Yemoja" con 5 preguntas:
   3 con status=ANSWERED y 2 con status=PENDING_MODERATION
   CUANDO GET /api/v1/catalogue/products/sopera-de-yemoja/questions/
   ENTONCES HTTP 200 con las 3 preguntas ANSWERED
   Y ordenadas por relevancia descendente por defecto
   Y las 2 pendientes no aparecen en ningún campo de la respuesta

   Escenario 2: Búsqueda por término — resultados filtrados
   DADO producto con 8 preguntas respondidas
   CUANDO GET /questions/?q=ceremonia
   ENTONCES solo aparecen las preguntas cuyo texto o respuesta
   contiene "ceremonia"
   Y el término buscado aparece destacado en el texto de los resultados

   Escenario 3: Búsqueda sin resultados — CTA de preguntar
   DADO búsqueda con término que no aparece en ninguna pregunta del producto
   CUANDO el sistema procesa el filtro
   ENTONCES HTTP 200 con items=[] para esa búsqueda
   Y la respuesta incluye un enlace directo a UC-QST-01 para hacer
   la pregunta que no encontró

   Escenario 4: Sin preguntas respondidas — estado vacío con CTA
   DADO producto nuevo sin ninguna pregunta respondida aún
   CUANDO se solicita la sección de preguntas
   ENTONCES HTTP 200 con items=[]
   Y la respuesta incluye el mensaje "Sé el primero en preguntar"
   con acceso directo al formulario de UC-QST-01

   Escenario 5: Servicio de preguntas no disponible — degradación silenciosa
   DADO repositorio de preguntas que no responde en el tiempo límite
   CUANDO se carga la ficha del producto
   ENTONCES la ficha se retorna completa sin la sección de preguntas
   Y el visitante puede agregar al carrito y proceder normalmente
   Y no se muestra ningún mensaje de error relacionado con las preguntas

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 300ms para la carga de
  preguntas, que es una sección secundaria de la ficha del producto)
- **Notas:** El ordenamiento predeterminado es por relevancia. Un
  cambio a ordenamiento por fecha se realiza mediante parámetro de
  consulta y no modifica ninguna preferencia persistida del visitante.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST-02: Ver Preguntas y Respuestas
   * - **Depende de**
     - FR-QST-03.02 (las preguntas deben haber sido respondidas
       por el admin para aparecer aquí) y FR-QST-04.02 (las
       preguntas deben haber pasado la moderación)
   * - **Requerido por**
     - FR-CAT-02.02 (la ficha del producto incluye esta sección)
   * - **Test**
     - TST-FR-QST-02.02 (pendiente — verificar que status
       PENDING_MODERATION no aparece en ningún campo de la respuesta;
       verificar la degradación silenciosa mockeando un timeout
       del repositorio)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: ordenamiento por relevancia vs fecha,
       búsqueda con término destacado, degradación silenciosa EX-02,
       5 escenarios BDD, trazabilidad completa

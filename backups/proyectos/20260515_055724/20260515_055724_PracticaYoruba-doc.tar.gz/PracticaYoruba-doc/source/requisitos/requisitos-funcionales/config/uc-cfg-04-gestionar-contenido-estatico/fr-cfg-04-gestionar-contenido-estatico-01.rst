.. meta::
   :artefacto: FR-CFG-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cfg-04-01:

FR-CFG-04.01: Editar y publicar paginas estaticas
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-04.01
   * - **Nombre**
     - Editar y publicar paginas estaticas
   * - **UC Origen**
     - UC-CFG 04 GESTIONAR CONTENIDO ESTATICO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE guardar el contenido HTML de la pagina estatica CUANDO el admin lo edita.

**Descripcion:**

Paginas gestionadas: ABOUT, TERMS, PRIVACY, FAQ.

``StaticPage.content_html = contenido``
``StaticPage.updated_by = admin``
``StaticPage.updated_at = now()``

El historial de versiones permite revertir a versiones anteriores.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Publicacion exitosa
   DADO admin que edita la pagina de Terminos
   CUANDO guarda con publicar=True
   ENTONCES el nuevo contenido aparece en /terminos/ de inmediato

   Escenario: Guardar como borrador
   DADO admin que no quiere publicar aun
   CUANDO guarda con publicar=False
   ENTONCES el contenido queda en estado BORRADOR
   Y la pagina publica muestra el contenido anterior


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El historial de versiones permite auditar quien cambio que y cuando.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG 04 GESTIONAR CONTENIDO ESTATICO
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-CFG-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CFG 04 GESTIONAR CONTENIDO ESTATICO

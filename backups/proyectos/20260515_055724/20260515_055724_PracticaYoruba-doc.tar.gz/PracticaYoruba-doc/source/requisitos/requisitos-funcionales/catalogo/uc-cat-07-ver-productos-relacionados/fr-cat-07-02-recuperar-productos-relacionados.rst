.. meta::
   :artefacto: FR-CAT-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-07.02: Recuperar productos relacionados de la misma categoria
=====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-07.02
   * - **Nombre**
     - Obtener hasta 4 productos activos de la misma categoria excluyendo el actual
   * - **UC Origen**
     - UC-CAT-07: Ver Productos Relacionados
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar hasta 4 productos activos de la misma
   categoria del producto actual, excluyendo el producto visto,
   ordenados por novedad CUANDO se carga la ficha de un producto.

**Descripcion:**

Los productos relacionados se incluyen en la respuesta de
FR-CAT-02.02 (la ficha del producto). El sistema recupera hasta
4 productos con ``Product.is_active = True`` y
``Product.is_published = True`` que pertenezcan a la misma
``Product.category`` que el producto actual, excluyendo el propio
producto, ordenados por ``-Product.created_at`` (los más recientes
primero).

Si la categoria tiene menos de 4 productos disponibles, se retornan
los que existan. Si no hay productos relacionados, el campo
``related_products`` es una lista vacia ``[]`` — no es un error.

Los relacionados se incluyen en el cache de la ficha del producto.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: 4 relacionados disponibles
   DADO producto en categoria "Soperas" con 6 otros productos activos
   CUANDO se carga la ficha
   ENTONCES related_products tiene exactamente 4 productos
   Y el producto actual no esta en la lista

   Escenario 2: Menos de 4 relacionados
   DADO producto en categoria con solo 2 otros productos
   CUANDO se carga la ficha
   ENTONCES related_products tiene 2 productos (los disponibles)

   Escenario 3: Sin relacionados
   DADO producto unico en su categoria
   CUANDO se carga la ficha
   ENTONCES related_products = []
   Y no hay seccion de relacionados en el frontend

----

4. Reglas y Restricciones
--------------------------

- **Notas:** Los productos relacionados se calculan con la misma
  consulta al repositorio que la ficha del producto. No genera
  una segunda query si se usa prefetch_related correctamente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-07: Ver Productos Relacionados
   * - **Depende de**
     - FR-CAT-02.02 (la ficha del producto que los incluye)
   * - **Test**
     - TST-FR-CAT-07.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-3 de UC-CAT-07

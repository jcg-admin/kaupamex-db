.. meta::
   :artefacto: FR-PAY-03.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-03.03: Verificar firma del webhook y procesar el evento de pago
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-03.03
   * - **Nombre**
     - Verificar la autenticidad del webhook, consultar el estado del pago y actualizar la orden
   * - **UC Origen**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Paso UC**
     - Pasos 3, 6, 7, 8 y 9 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la firma criptografica del webhook del
   Gateway de Pago, consultar el estado del pago directamente en el
   gateway y actualizar la orden de forma idempotente CUANDO recibe
   una notificacion de pago.

**Descripcion:**

**Verificacion de firma (paso 3, RNF-SEC-005):**

El sistema extrae los encabezados ``X-Signature`` y ``X-Request-Id``
del webhook. Construye el manifiesto con el ``data.id`` del payload y
el ``X-Request-Id``, calcula el HMAC-SHA256 usando la clave secreta
``SiteSettings.mp_webhook_secret`` (descifrada en memoria), y compara
el resultado con la firma del encabezado usando comparación en tiempo
constante. Si no coinciden, rechaza el webhook.

**Idempotencia (RNF-AVAIL-002):**

El sistema responde HTTP 200 al gateway inmediatamente (paso 4) para
evitar reintentos del gateway, y procesa el evento de forma asíncrona.
Si existe un ``Payment`` con ese ``gateway_payment_id`` y
``status = 'APPROVED'``, el procesamiento concluye sin modificar
ningún registro. En caso contrario, el sistema consulta el estado del
pago directamente en el gateway (no confía únicamente en el webhook)
y actualiza ``Payment.status`` y ``Order.status`` según el resultado.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Webhook aprobado — orden actualizada
   DADO webhook de pago aprobado con firma valida
   CUANDO el sistema lo procesa
   ENTONCES Payment.status = APPROVED y Order.status = PAYMENT_CONFIRMED
   Y la notificacion de confirmacion se encola al comprador

   Escenario 2: Firma invalida — rechazado silenciosamente
   DADO webhook con firma incorrecta (posible ataque)
   CUANDO el sistema verifica la firma
   ENTONCES HTTP 401 y no se procesa el evento
   Y se registra en el log de auditoria el intento fallido

   Escenario 3: Webhook duplicado — idempotente
   DADO gateway que reintenta el mismo webhook dos veces
   CUANDO el segundo llega despues de que el primero fue procesado
   ENTONCES el segundo retorna HTTP 200 sin modificar la orden
   Y Payment.status sigue siendo APPROVED (no cambia)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-005 (verificacion de firma obligatoria),
  RNF-AVAIL-002 (idempotencia — Payment.gateway_payment_id unique)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Depende de**
     - FR-PAY-01.02 (Payment con preference_id ya existe)
   * - **Requerido por**
     - FR-ORD-07.02 (la orden transiciona a PAYMENT_CONFIRMED)
   * - **Test**
     - TST-FR-PAY-03.03 (pendiente — mock del gateway y del header X-Signature)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3 y 6-9 de UC-PAY-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

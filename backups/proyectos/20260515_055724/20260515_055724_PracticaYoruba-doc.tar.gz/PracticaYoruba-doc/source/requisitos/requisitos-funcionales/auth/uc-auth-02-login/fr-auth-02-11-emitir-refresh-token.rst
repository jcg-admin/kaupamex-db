.. meta::
   :artefacto: FR-AUTH-02.11
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-11:

==============================================
FR-AUTH-02.11: Emitir refresh token
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.11
   * - **Nombre**
     - Generar el refresh token con vida larga e invalidacion por uso
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 16 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar el refresh token con el tiempo de vida
   configurado CUANDO la autenticacion de credenciales es exitosa
   y el access token ya fue emitido.

**Descripcion:**

El refresh token complementa al access token (FR-AUTH-02.03):

- **Tiempo de vida normal:** 7 dias (el tiempo de vida configurado del token de renovacion)
- **Tiempo de vida con "Recordarme":** ``SiteSettings.remember_me_days``
  (default: 30 dias) — se activa si el visitante marco la casilla del
  paso 6 del flujo principal

Propiedades del refresh token:

- Firmado con HS256 usando ``la clave de firma del Servicio de Autenticacion``
- Payload: solo ``user_id``, ``token_type: refresh``, ``jti`` (ID unico), ``exp``
- NO contiene datos del usuario (nombre, email, rol) — el access token los tiene
- El ``jti`` (JWT ID) se registra en la tabla el repositorio de sesiones activas
  de el Servicio de Autenticacion

Comportamiento de rotacion (la rotacion de tokens activa en la configuracion):

- Al usar el refresh token para renovar la sesion (FR-AUTH-04.01),
  el refresh token actual se invalida y se emite uno nuevo
- Esto significa que un refresh token robado es detectado cuando el
  dueno legitimo intenta renovar su sesion

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Refresh token con vida normal
   DADO autenticacion exitosa sin "Recordarme" activado
   CUANDO se emite el refresh token
   ENTONCES su exp = now() + 7 dias
   Y esta registrado en outstanding_tokens

   Escenario 2: Refresh token con "Recordarme" activado
   DADO autenticacion exitosa con casilla "Recordarme" marcada
   CUANDO se emite el refresh token
   ENTONCES su exp = now() + SiteSettings.remember_me_days
   Y el usuario no necesita re-autenticarse por ese periodo

   Escenario 3: Refresh token invalido al ser usado una vez
   DADO refresh token valido
   CUANDO se usa en POST /api/v1/auth/refresh/
   ENTONCES se emite un NUEVO par de tokens
   Y el refresh token original queda en la blacklist
   Y si alguien intenta reusar el token original, recibe 401

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-SEC-001 (JWT con rotacion y blacklist)
- **Notas:** El refresh token no debe almacenarse en localStorage
  del navegador. Debe usarse en una cookie HttpOnly o en memoria.
  Esto es responsabilidad del cliente, no del servidor.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.03 (access token ya emitido exitosamente)
   * - **Requerido por**
     - FR-AUTH-02.12 (registrar fecha del acceso exitoso)
   * - **Relacionado con**
     - FR-AUTH-04.01 (rotacion del refresh token en renovacion)
   * - **RNF**
     - RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-02.11 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 16 de UC-AUTH-02

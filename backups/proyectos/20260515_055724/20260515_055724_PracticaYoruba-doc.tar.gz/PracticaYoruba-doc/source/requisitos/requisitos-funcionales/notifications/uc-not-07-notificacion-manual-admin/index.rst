.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-07-notificacion-manual-admin
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-07-02-envio-manual-admin
   fr-not-07-notificacion-manual-admin-01

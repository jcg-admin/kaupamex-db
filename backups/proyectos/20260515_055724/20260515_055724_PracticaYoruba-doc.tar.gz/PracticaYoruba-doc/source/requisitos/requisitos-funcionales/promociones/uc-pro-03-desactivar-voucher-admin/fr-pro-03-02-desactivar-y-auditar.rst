.. meta::
   :artefacto: FR-PRO-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PRO-03.02: Desactivar el voucher inmediatamente y registrar en auditoria
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-03.02
   * - **Nombre**
     - Cambiar is_active=False del voucher y registrar el motivo en auditoria
   * - **UC Origen**
     - UC-PRO-03: Desactivar Voucher (Admin)
   * - **Paso UC**
     - Pasos 2, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE desactivar el voucher de forma inmediata y
   registrar la desactivacion en auditoria CUANDO el admin confirma
   la operacion.

**Descripcion:**

**Descripcion:**

El sistema establece ``Voucher.is_active = False``, registra
``Voucher.deactivated_at`` y ``Voucher.deactivated_by``, y crea
un ``VoucherChangeLog`` con el motivo de la desactivación y la
referencia al administrador. La desactivación es inmediata: los
carritos que tenían el voucher aplicado ven el descuento eliminado
en el siguiente GET al carrito (FR-CART-02.04 valida el voucher
en cada carga).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Voucher desactivado inmediatamente
   DADO voucher activo con 30 usos
   CUANDO el admin lo desactiva
   ENTONCES Voucher.is_active = False inmediatamente
   Y en el proximo GET al carrito, el descuento no aplica
   Y VoucherChangeLog registra la desactivacion

   Escenario 2: Carrito con el voucher desactivado — aviso al visitante
   DADO visitante que tenia el voucher aplicado en su carrito
   CUANDO el admin desactiva el voucher y el visitante recarga el carrito
   ENTONCES FR-CART-02.04 detecta que el voucher no es valido
   Y el carrito se muestra sin el descuento con un aviso

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria de desactivacion)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO-03: Desactivar Voucher
   * - **Relacionado con**
     - UC-SYS-02 (desactivacion automatica de vouchers expirados)
   * - **Test**
     - TST-FR-PRO-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 4 y 5 de UC-PRO-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

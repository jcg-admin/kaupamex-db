.. meta::
   :artefacto: FR-ORD-04.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-04.03: Validar estado de la orden y ejecutar la cancelacion
==================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-04.03
   * - **Nombre**
     - Verificar que la orden puede cancelarse y ejecutar la transicion de estado
   * - **UC Origen**
     - UC-ORD-04: Cancelar Orden
   * - **Paso UC**
     - Pasos 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden esta en un estado que
   permite la cancelacion y ejecutar la transicion a CANCELLED
   restaurando el stock CUANDO el usuario confirma la cancelacion.

**Descripcion:**

Solo se pueden cancelar órdenes en estados pre-envío. El usuario
solo puede cancelar órdenes con ``Order.status`` igual a
``PENDING_PAYMENT`` o ``PAYMENT_CONFIRMED``. Los estados
``IN_PREPARATION``, ``SHIPPED`` y ``DELIVERED`` no son cancelables
por el usuario.

En una transacción atómica el sistema:

1. Valida que ``Order.status`` sea cancelable; si no → ``CANCELACION_NO_PERMITIDA``.
2. Actualiza ``Order.status = 'CANCELLED'``, registra
   ``Order.cancellation_reason`` y ``Order.cancelled_at``.
3. Para cada ``OrderItem`` restaura el ``ProductVariant.stock``
   sumando la cantidad del item, y crea un registro
   ``StockMovement`` de tipo ``CANCELLATION`` con cantidad positiva
   y ``reference = Order.order_number``.

Si el pago ya fue procesado (estado PAYMENT_CONFIRMED), se
desencadena el reembolso automaticamente (FR-PAY-06.01 o
FR-PAY-07.01 segun el gateway usado).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cancelacion exitosa en estado PENDING_PAYMENT
   DADO orden en PENDING_PAYMENT que el usuario quiere cancelar
   CUANDO confirma la cancelacion
   ENTONCES order.status = CANCELLED
   Y el stock de cada item se restaura
   Y se crea StockMovement CANCELLATION por cada item

   Escenario 2: Orden en SHIPPED — no cancelable por el usuario
   DADO orden en estado SHIPPED
   CUANDO el usuario intenta cancelar
   ENTONCES HTTP 400 con {"codigo_error": "CANCELACION_NO_PERMITIDA",
   "mensaje": "Esta orden ya fue enviada y no puede cancelarse aqui.
   Contacta soporte para iniciar una devolucion."}

   Escenario 3: Cancelacion con pago previo — reembolso automatico
   DADO orden en PAYMENT_CONFIRMED (pago procesado)
   CUANDO se cancela
   ENTONCES order.status = CANCELLED Y stock restaurado
   Y se desencadena el reembolso via FR-PAY-06.01 o FR-PAY-07.01

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (cancelled_at es el created_at del
  registro de cancelacion — via AbstractBaseModel)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-04: Cancelar Orden
   * - **Depende de**
     - FR-ORD-04.02 (orden verificada como propia del usuario)
   * - **Requerido por**
     - FR-PAY-06.01 (reembolso si habia pago previo)
   * - **Relacionado con**
     - FR-INV-03.01 (restaurar stock)
   * - **Test**
     - TST-FR-ORD-04.03 (pendiente — verificar que el stock se restaura
       atomicamente con el cambio de estado)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-6 de UC-ORD-04

.. meta::
   :artefacto: FR-QST-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-qst-04-01:

FR-QST-04.01: Aprobar o rechazar preguntas en moderacion
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-04.01
   * - **Nombre**
     - Aprobar o rechazar preguntas en moderacion
   * - **UC Origen**
     - UC-QST 04 MODERAR PREGUNTAS ADMIN
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la pregunta CUANDO el admin la modera.

**Descripcion:**

Acciones:

- **APROBAR sin responder**: la pregunta pasa a estado APPROVED (visible pero sin respuesta aun)
- **RECHAZAR**: ``Question.status=REJECTED`` — no visible al publico
- **RESPONDER directamente**: va a FR-QST-03.01

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Pregunta rechazada por spam
   DADO pregunta de spam
   CUANDO el admin rechaza
   ENTONCES Question.status=REJECTED
   Y no aparece en la ficha del producto

   Escenario: Pregunta aprobada pendiente de respuesta
   DADO pregunta legitima que el admin aprueba
   CUANDO se aprueba
   ENTONCES Question.status=APPROVED (visible en la ficha)
   Y la respuesta puede agregarse mas adelante


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El admin puede aprobar primero y responder despues si necesita tiempo para investigar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST 04 MODERAR PREGUNTAS ADMIN
   * - **Depende de**
     - FR-QST-01.01 (pregunta en moderacion)
   * - **Requerido por**
     - FR-QST-02.01 o FR-QST-03.01
   * - **Test**
     - TST-FR-QST-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-QST 04 MODERAR PREGUNTAS ADMIN

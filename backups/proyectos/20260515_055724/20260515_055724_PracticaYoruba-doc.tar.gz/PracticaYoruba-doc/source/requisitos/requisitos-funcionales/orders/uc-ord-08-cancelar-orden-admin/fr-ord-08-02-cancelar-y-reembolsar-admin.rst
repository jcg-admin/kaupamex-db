.. meta::
   :artefacto: FR-ORD-08.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-08.02: Cancelacion administrativa con restauracion de stock y reembolso
===============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-08.02
   * - **Nombre**
     - El admin cancela una orden en cualquier estado pre-entrega y desencadena el reembolso
   * - **UC Origen**
     - UC-ORD-08: Cancelar Orden (Admin)
   * - **Paso UC**
     - Pasos 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El admin DEBE poder cancelar una orden en cualquier estado previo
   a la entrega, con restauracion de stock y reembolso automatico
   si el pago ya fue procesado.

**Descripcion:**

El admin puede cancelar en mas estados que el usuario:

- Estados cancelables por admin: todos excepto DELIVERED

La cancelación administrativa registra el motivo y quién la ejecutó.
En una transacción atómica:

1. Si ``Order.status = 'DELIVERED'`` → ``ORDEN_ENTREGADA_NO_CANCELABLE``.
2. El sistema registra el estado previo, establece
   ``Order.status = 'CANCELLED'``, ``Order.cancellation_reason``,
   ``Order.cancelled_by_admin`` y ``Order.cancelled_at``.
3. Restaura el stock de cada item de la orden.
4. Si el estado previo era ``PAYMENT_CONFIRMED``, ``IN_PREPARATION``
   o ``SHIPPED``, encola el reembolso de forma asíncrona.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Admin cancela orden en IN_PREPARATION
   DADO orden en preparacion por un proveedor con stock incorrecto
   CUANDO el admin cancela con razon "stock insuficiente en proveedor"
   ENTONCES order.status = CANCELLED
   Y el stock de los items se restaura
   Y se inicia el reembolso si habia pago

   Escenario 2: Orden DELIVERED — no cancelable por admin
   DADO orden ya entregada
   CUANDO el admin intenta cancelar
   ENTONCES HTTP 400 con ORDEN_ENTREGADA_NO_CANCELABLE
   Y se sugiere iniciar una devolucion (UC-RET-01)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria — cancelled_by_admin
  registra quien cancelo y por que)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-08: Cancelar Orden Admin
   * - **Relacionado con**
     - FR-PAY-06.01 o FR-PAY-07.01 (reembolso segun gateway)
   * - **Test**
     - TST-FR-ORD-08.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-6 de UC-ORD-08

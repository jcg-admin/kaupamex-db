.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-05-editar-direccion-orden
===========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-05-01-actualizar-direccion-envio
   fr-ord-05-02-actualizar-direccion-pre-envio

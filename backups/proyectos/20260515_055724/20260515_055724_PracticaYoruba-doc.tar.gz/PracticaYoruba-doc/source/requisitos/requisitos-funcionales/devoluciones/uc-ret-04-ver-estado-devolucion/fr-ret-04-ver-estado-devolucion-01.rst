.. meta::
   :artefacto: FR-RET-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ret-04-01:

FR-RET-04.01: Retornar estado y historial de la devolucion
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-04.01
   * - **Nombre**
     - Retornar estado y historial de la devolucion
   * - **UC Origen**
     - UC-RET 04 VER ESTADO DEVOLUCION
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-010 RETURNS via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el estado actual y el historial de la solicitud CUANDO el comprador la consulta.

**Descripcion:**

Datos retornados:

- ``status`` actual con descripcion legible
- Historial cronologico de cambios de estado
- Datos del reembolso asociado si status=APPROVED o RECEIVED
- Motivo de rechazo si status=REJECTED

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Solicitud aprobada con reembolso en curso
   DADO solicitud con status=APPROVED y Refund.status=PENDING
   CUANDO el comprador consulta
   ENTONCES ve el estado APROBADA y el reembolso en proceso con el plazo estimado

   Escenario: Solicitud rechazada
   DADO solicitud con status=REJECTED
   CUANDO el comprador consulta
   ENTONCES ve el motivo del rechazo claramente


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El historial permite al comprador entender en que punto del proceso esta.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET 04 VER ESTADO DEVOLUCION
   * - **Depende de**
     - Propiedad verificada via INC-01
   * - **Requerido por**
     - Ninguno — consulta
   * - **Include**
     - UC-INC-01
   * - **Test**
     - TST-FR-RET-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RET 04 VER ESTADO DEVOLUCION

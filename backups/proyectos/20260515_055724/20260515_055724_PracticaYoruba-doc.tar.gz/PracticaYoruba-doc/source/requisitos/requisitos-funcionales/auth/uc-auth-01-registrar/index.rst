.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-01-registrar
===============================

**5 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-01-01-presentar-formulario-registro
   fr-auth-01-02-validar-datos-registro
   fr-auth-01-03-verificar-unicidad
   fr-auth-01-04-crear-cuenta-inactiva
   fr-auth-01-05-enviar-email-verificacion

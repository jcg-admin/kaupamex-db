.. meta::
   :artefacto: FR-AUTH-05.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-05.04: Excepciones y NFR del endpoint de perfil
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-05.04
   * - **Nombre**
     - EX-01/EX-02 y restricciones tecnicas del endpoint de ver perfil
   * - **UC Origen**
     - UC-AUTH-05: Ver Perfil
   * - **Paso UC**
     - PARTE 5 (excepciones) y PARTE 6 (NFRs)
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint GET /api/v1/auth/profile/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El endpoint de perfil DEBE rechazar solicitudes sin autenticacion,
   manejar errores del repositorio de forma controlada y cumplir
   los requisitos de calidad de las secciones 6.1 a 6.4.

**Descripcion:**

**EX-01 — Sin autenticacion:**

El middleware de el Servicio de Autenticacion verifica el JWT antes de llegar al view.
Si el token esta ausente, expirado o invalido:

.. code-block:: json

   HTTP 401
   {"codigo_error": "AUTENTICACION_REQUERIDA",
    "mensaje": "Inicia sesion para acceder a tu perfil.",
    "redirect": "/login/"}

**EX-02 — Error al recuperar perfil (BD no disponible):**

.. code-block:: json

   HTTP 500
   {"codigo_error": "ERROR_SISTEMA",
    "mensaje": "No pudimos cargar tu perfil. Intenta de nuevo."}

**Performance (6.1):** P95 <= 300ms. La consulta es simple (1 SELECT
por PK + 1 EXISTS para direcciones). Si supera 300ms revisar indices.

**Seguridad (6.2):**

- Solo el propio usuario puede ver su perfil. El endpoint no acepta
  un ``user_id`` en la URL — siempre usa ``request.user`` del JWT.
- ``password`` nunca aparece en la respuesta.

**Confiabilidad (6.3):** los datos mostrados son siempre frescos
de la BD — no hay cache del perfil (cambia con cada edicion).

**Usabilidad (6.4):** las ``quick_actions`` en la respuesta permiten
al frontend construir el menu de acciones sin hardcodear URLs.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Sin JWT — redireccion al login
   DADO GET /api/v1/auth/profile/ sin header Authorization
   CUANDO el middleware verifica la autenticacion
   ENTONCES HTTP 401 con codigo AUTENTICACION_REQUERIDA
   Y el cliente redirige al login

   Escenario 2: Solo el propio perfil es accesible
   DADO intentar GET /api/v1/auth/profile/?user_id=99 con JWT del usuario 1
   CUANDO el sistema procesa la solicitud
   ENTONCES siempre retorna el perfil del usuario 1 (del JWT)
   Y el parametro user_id es ignorado completamente

   Escenario 3: Password ausente en la respuesta
   DADO cualquier consulta de perfil
   CUANDO se retorna la respuesta
   ENTONCES el campo "password" esta ausente
   Y no hay ninguna representacion de la contraseña en el JSON

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-001, RNF-SEC-003

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-05: Ver Perfil
   * - **Secciones**
     - PARTE 5 (EX-01, EX-02), PARTE 6 (6.1 a 6.4)
   * - **RNF del sistema**
     - RNF-PERF-001, RNF-SEC-003
   * - **Test**
     - TST-FR-AUTH-05.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de PARTE 5 y 6 de UC-AUTH-05

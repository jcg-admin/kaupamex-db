.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — YORUBA
================================

**4 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-cht-01-ver-variantes
     - 1
   * - uc-cht-02-seleccionar-variante
     - 1
   * - uc-cht-03-gestionar-variantes-admin
     - 1
   * - uc-cht-04-precio-diferenciado-variante
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-cht-01-ver-variantes/index
   uc-cht-02-seleccionar-variante/index
   uc-cht-03-gestionar-variantes-admin/index
   uc-cht-04-precio-diferenciado-variante/index

.. meta::
   :artefacto: FR-REV-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-REV-02.02: Recuperar resenas aprobadas con calificacion promedio y desglose
===============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-02.02
   * - **Nombre**
     - Retornar resenas aprobadas del producto con promedio y desglose por estrellas
   * - **UC Origen**
     - UC-REV-02: Ver Resenas de Producto
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las resenas aprobadas del producto con
   el promedio de calificacion y el desglose por numero de estrellas
   CUANDO se solicitan las resenas de un producto.

**Descripcion:**

**Descripcion:**

El sistema recupera todos los ``Review`` con ``product_id`` igual
al solicitado y ``Review.status = 'APPROVED'``, con carga anticipada
del ``User`` autor. Calcula estadísticas agregadas: promedio de
``Review.rating``, conteo total y conteo por valor (1 a 5 estrellas).
Aplica el ordenamiento solicitado: ``-Review.created_at`` para
``sort = 'recent'``, o ``-Review.helpful_count`` para
``sort = 'helpful'``. Pagina los resultados a 10 por página. El
nombre del autor se muestra como nombre de pila e inicial del apellido
para proteger la privacidad.

El nombre del comprador se muestra como nombre de pila + inicial del
apellido (ej: "Juan P.") para proteger su privacidad.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto con 8 resenas aprobadas
   DADO producto con 8 resenas aprobadas (avg=4.5)
   CUANDO se solicitan
   ENTONCES HTTP 200 con average_rating=4.5, total_reviews=8
   Y desglose por estrellas correcto

   Escenario 2: Solo resenas APPROVED visibles
   DADO producto con 5 resenas: 3 aprobadas, 2 pendientes
   CUANDO se solicitan
   ENTONCES HTTP 200 con total_reviews=3 (solo las aprobadas)

   Escenario 3: Privacidad del comprador
   DADO resena de "Juan Perez"
   CUANDO aparece en la lista publica
   ENTONCES el nombre visible es "Juan P." (inicial del apellido)

----

4. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV-02: Ver Resenas
   * - **Depende de**
     - FR-REV-03.01 (resenas aprobadas por el admin)
   * - **Relacionado con**
     - FR-CAT-02.02 (la ficha del producto incluye estas resenas)
   * - **Test**
     - TST-FR-REV-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-REV-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

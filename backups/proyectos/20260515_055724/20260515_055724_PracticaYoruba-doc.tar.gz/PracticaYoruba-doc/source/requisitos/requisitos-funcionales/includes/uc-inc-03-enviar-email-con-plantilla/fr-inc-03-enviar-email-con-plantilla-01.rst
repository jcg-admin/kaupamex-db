.. meta::
   :artefacto: FR-INC-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inc-03-01:

FR-INC-03.01: Encolar email con plantilla y contexto
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-03.01
   * - **Nombre**
     - Encolar email con plantilla y contexto
   * - **UC Origen**
     - UC-INC 03 ENVIAR EMAIL CON PLANTILLA
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-001 ACCOUNTS — servicio de email
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE encolar el email con la plantilla y el contexto CUANDO un UC lo invoca.

**Descripcion:**

El UC incluidor provee:

- ``template_name``: nombre de la plantilla (ej: ``confirmacion_orden``)
- ``context``: diccionario con variables de la plantilla
- ``to_email``: email del destinatario
- ``subject``: asunto del email

El sistema:

1. Renderiza la plantilla con el contexto
2. Crea el registro de email con ``status=PENDING``
3. Encola el envio con el Procesador Asincrono
4. Retorna OK al UC incluidor sin esperar la confirmacion del envio

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email encolado exitosamente
   DADO UC-NOT-01 que invoca el include con plantilla confirmacion_orden
   CUANDO se encola
   ENTONCES el registro queda con status=PENDING
   Y el UC incluidor continua sin esperar

   Escenario: Proveedor de email no disponible
   DADO proveedor de email temporalmente no disponible
   CUANDO la tarea de Celery intenta enviar
   ENTONCES el email queda con status=FAILED
   Y UC-SYS-04 lo reintentara con backoff


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-003`
- **Notas:** El envio es siempre asincrono — ningun UC espera la confirmacion del proveedor de email.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC 03 ENVIAR EMAIL CON PLANTILLA
   * - **Depende de**
     - Invocacion de un UC incluidor
   * - **Requerido por**
     - UC-NOT-01..07, UC-SYS-04, UC-COM-03, UC-QST-03, UC-NEW-04
   * - **Test**
     - TST-FR-INC-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INC 03 ENVIAR EMAIL CON PLANTILLA

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — INCLUDES
==================================

**3 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-inc-01-verificar-propiedad-orden
     - 1
   * - uc-inc-02-recuperar-carrito-sesion
     - 1
   * - uc-inc-03-enviar-email-con-plantilla
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-inc-01-verificar-propiedad-orden/index
   uc-inc-02-recuperar-carrito-sesion/index
   uc-inc-03-enviar-email-con-plantilla/index

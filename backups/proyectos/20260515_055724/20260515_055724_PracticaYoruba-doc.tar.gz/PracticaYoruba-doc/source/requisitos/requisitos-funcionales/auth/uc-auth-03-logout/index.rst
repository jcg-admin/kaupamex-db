.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-03-logout
============================

**8 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-03-01-invalidar-refresh-token
   fr-auth-03-02-recibir-y-validar-refresh-token
   fr-auth-03-03-registrar-auditoria-cierre
   fr-auth-03-04-confirmar-y-redirigir
   fr-auth-03-05-exc-error-al-revocar
   fr-auth-03-06-exc-sin-credenciales
   fr-auth-03-07-nfr-performance-seguridad
   fr-auth-03-08-nfr-confiabilidad-usabilidad

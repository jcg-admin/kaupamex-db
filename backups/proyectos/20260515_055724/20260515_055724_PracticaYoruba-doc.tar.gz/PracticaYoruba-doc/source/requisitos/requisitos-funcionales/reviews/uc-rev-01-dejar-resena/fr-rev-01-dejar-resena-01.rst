.. meta::
   :artefacto: FR-REV-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rev-01-01:

FR-REV-01.01: Crear resena verificada de producto
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-01.01
   * - **Nombre**
     - Crear resena verificada de producto
   * - **UC Origen**
     - UC-REV 01 DEJAR RESENA
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la resena con status=PENDING CUANDO el comprador que recibio el producto la envia.

**Descripcion:**

Verificacion de elegibilidad:

- El comprador tiene una orden con ese producto en estado DELIVERED
- No existe ya una resena aprobada del comprador para ese producto y esa orden

``unique_together: (product, order, user)``

Campos: ``rating`` (1-5), ``title`` (opcional), ``body`` (opcional), imagenes (max 5).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Resena exitosa
   DADO comprador con orden DELIVERED que incluye el producto
   CUANDO crea la resena con rating=5
   ENTONCES Review.status=PENDING — va a moderacion

   Escenario: Comprador sin compra verificada
   DADO comprador sin orden DELIVERED del producto
   CUANDO intenta dejar resena
   ENTONCES error 422: COMPRA_NO_VERIFICADA


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** Solo compradores verificados pueden dejar resenas. Previene spam.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV 01 DEJAR RESENA
   * - **Depende de**
     - FR-LOG-05.01 (orden en estado DELIVERED)
   * - **Requerido por**
     - FR-REV-03.01 (moderacion de la resena)
   * - **Test**
     - TST-FR-REV-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-REV 01 DEJAR RESENA

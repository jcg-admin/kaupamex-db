.. meta::
   :artefacto: FR-CART-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-04-02:

================================================
FR-CART-04.02: Aplicar el descuento al carrito
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-04.02
   * - **Nombre**
     - Vincular el voucher al carrito y calcular el descuento
   * - **UC Origen**
     - UC-CART-04: Aplicar cupon de descuento
   * - **Paso UC**
     - Pasos 4-5 del flujo principal
   * - **Modulo**
     - MOD-005 CART + MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE vincular el voucher al carrito y calcular
   el descuento CUANDO el voucher pasa todas las validaciones.

**Descripcion:**

Proceso de aplicacion:

1. ``Cart.voucher = voucher`` (FK)
2. Calcula ``descuento = voucher.calculate_discount(subtotal)``:

   - **FIXED**: ``min(discount_value, subtotal)``
   - **PERCENTAGE**: ``subtotal * (discount_pct / 100)``
     con limite ``max_discount`` si aplica
   - **FREE_SHIPPING**: ``Cart.shipping_cost = 0``

3. Retorna el carrito completo con totales recalculados

El ``uses_count`` del voucher NO incrementa aqui. Incrementa en
``VoucherUsage`` cuando la orden es creada (UC-ORD-01).
Esto permite que un comprador agregue y quite el voucher sin
consumir usos del limite.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO voucher validado exitosamente
   CUANDO se aplica al carrito
   ENTONCES el descuento aparece en los totales

   Escenario 1: Voucher FIXED de $50
   DADO subtotal = 200 y voucher FIXED discount_value = 50
   CUANDO se aplica
   ENTONCES discount = 50, total = 150

   Escenario 2: Voucher PERCENTAGE 15% con max_discount = 100
   DADO subtotal = 1000 y voucher 15% con max = 100
   CUANDO se aplica
   ENTONCES discount = min(150, 100) = 100, total = 900

   Escenario 3: Voucher FREE_SHIPPING
   DADO shipping_cost = 80 y voucher FREE_SHIPPING
   CUANDO se aplica
   ENTONCES shipping_cost = 0, total se reduce en 80

   Escenario 4: Reemplazar voucher existente
   DADO carrito con voucher A activo
   CUANDO se aplica voucher B (diferente)
   ENTONCES voucher A es reemplazado por B
   Y los totales reflejan el descuento de B

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-012 (un solo descuento — no se pueden
  acumular dos vouchers)
- **Notas:** El voucher puede quedar invalido entre el momento de
  aplicarlo y el checkout (expira o se agota). Esto se re-verifica
  en UC-ORD-01 antes de crear la orden.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-04: Aplicar cupon de descuento
   * - **Depende de**
     - FR-CART-04.01 (voucher validado)
   * - **Requerido por**
     - FR-ORD-01.02 (checkout re-verifica el voucher)
   * - **BR**
     - BR-012
   * - **Test**
     - TST-FR-CART-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-04

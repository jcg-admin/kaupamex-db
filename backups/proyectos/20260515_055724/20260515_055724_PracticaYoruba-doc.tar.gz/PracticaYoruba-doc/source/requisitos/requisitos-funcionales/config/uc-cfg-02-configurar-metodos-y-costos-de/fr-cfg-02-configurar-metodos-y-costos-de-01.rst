.. meta::
   :artefacto: FR-CFG-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cfg-02-01:

FR-CFG-02.01: Configurar metodos de envio y costos
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-02.01
   * - **Nombre**
     - Configurar metodos de envio y costos
   * - **UC Origen**
     - UC-CFG 02 CONFIGURAR METODOS Y COSTOS DE
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear o actualizar el ShippingMethod CUANDO el admin lo configura.

**Descripcion:**

Campos del ShippingMethod:

- ``name``, ``slug`` (generado), ``is_active``
- ``base_cost``: costo base del envio
- ``free_above``: monto a partir del cual el envio es gratis (puede ser null)
- ``estimated_days_min`` y ``estimated_days_max``
- ``coverage_zones``: lista de estados/regiones cubiertas (JSON)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Crear metodo de envio express
   DADO admin que crea 'DHL Express' con costo 150 y 1-2 dias
   CUANDO se crea
   ENTONCES disponible en el checkout para ordenes con cobertura

   Escenario: Desactivar metodo con ordenes activas
   DADO metodo con ordenes en PENDING_PAYMENT
   CUANDO el admin lo desactiva
   ENTONCES is_active=False
   Y el metodo no aparece en nuevos checkouts
   Y las ordenes activas no se afectan


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** Los costos de envio se calculan en tiempo real — no hay cache.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG 02 CONFIGURAR METODOS Y COSTOS DE
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-ORD-01.01 (el checkout usa los metodos activos)
   * - **Test**
     - TST-FR-CFG-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CFG 02 CONFIGURAR METODOS Y COSTOS DE

.. meta::
   :artefacto: FR-AUTH-03.06
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-03.06: EX-02 y EX-03 — Logout sin credenciales o con token expirado
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.06
   * - **Nombre**
     - EX-02/EX-03: Proceder con logout aunque no haya token valido
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - EX-02 y EX-03 — Excepciones del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Usabilidad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE tratar el logout como exitoso aunque el token
   este ausente o ya haya expirado CUANDO el usuario solicita
   cerrar sesion en esas condiciones.

**Descripcion:**

Ambas excepciones comparten el mismo comportamiento desde la
perspectiva del usuario — el logout es exitoso sin mensajes de error:

- **EX-02 (sin credenciales):** El body del POST no incluye el campo
  ``refresh`` o esta vacio. El sistema no puede invalidar nada en
  la blacklist (no hay token que invalidar). Retorna 200 OK, limpia
  el estado del cliente, registra ``CIERRE_SESION_SIN_TOKEN``.

- **EX-03 (token expirado):** El token existe pero su ``exp`` ya paso.
  el Servicio de Autenticacion lo rechazaria normalmente con 401.
  En el contexto del logout, el sistema verifica si el token es
  estructuralmente valido aunque este expirado.

  - Si es valido estructuralmente: lo agrega a la blacklist de todas formas
    (para prevenir uso antes del exp por reversion de reloj)
  - Si no es valido: procede sin invalidacion


En ambos casos: 200 OK, limpiar cliente, sin mensaje de error al usuario.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Logout sin token en el body
   DADO POST /api/v1/auth/logout/ con body {}
   CUANDO el sistema procesa el logout
   ENTONCES retorna 200 OK con mensaje de sesion cerrada
   Y el cliente limpia su estado de todas formas
   Y el registro dice CIERRE_SESION_SIN_TOKEN

   Escenario 2: Logout con token expirado hace 2 horas
   DADO refresh token cuyo exp fue hace 2 horas
   CUANDO el usuario hace logout
   ENTONCES el sistema retorna 200 OK (no 401)
   Y la sesion del usuario queda limpia del lado del cliente

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-USAB-001 (el usuario no debe ver errores
  al hacer logout, independientemente del estado del token)
- **Notas:** El principio aqui es: el logout SIEMPRE debe ser posible.
  Un usuario que quiere salir de su cuenta no debe encontrar barreras
  tecnicas para hacerlo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Detectado en**
     - FR-AUTH-03.02 (al validar el token recibido)
   * - **RNF**
     - RNF-USAB-001
   * - **Test**
     - TST-FR-AUTH-03.06 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-02 y EX-03 de UC-AUTH-03

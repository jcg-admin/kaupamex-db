.. meta::
   :artefacto: FR-CART-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-05-02:

==========================================================
FR-CART-05.02: Persistir el carrito de sesion en la cuenta del usuario
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-05.02
   * - **Nombre**
     - Guardar en BD el contenido del carrito de sesion asociado al usuario autenticado
   * - **UC Origen**
     - UC-CART-05: Guardar Carrito para Despues
   * - **Paso UC**
     - Paso 3 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart — SavedCart model)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE persistir el contenido actual del carrito de sesion
   en la cuenta del usuario autenticado CUANDO el usuario solicita
   guardarlo para mas tarde.

**Descripcion:**

El guardado toma el contenido de ``session['cart']`` y lo persiste
en el modelo ``SavedCart`` en una transacción atómica. Si el carrito
de sesión está vacío, la operación se rechaza.

Si ya existe un registro ``SavedCart`` para el usuario, el sistema
elimina los ``SavedCartItem`` existentes y crea los nuevos en una
transaccion atomica, actualizando ``SavedCart.saved_at``. Si no
existe, crea un nuevo registro ``SavedCart`` con el usuario y luego
crea un ``SavedCartItem`` por cada producto del carrito de sesion.

Cada ``SavedCartItem`` almacena ``product_id``, ``quantity`` y
``price_at_save`` como campos relacionales tipados — con FK a
``catalogue_product`` que garantiza integridad referencial.
Ver :doc:`/arquitectura-tecnica/modelos/modelo-cart`.

El carrito de sesion NO se elimina tras el guardado — el usuario
puede seguir comprando con el carrito actual Y tener uno guardado.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Carrito guardado exitosamente en la cuenta
   DADO usuario autenticado con carrito de sesion con 2 items
   CUANDO solicita guardar
   ENTONCES SavedCart con user=request.user creado en BD
   Y SavedCartItem creados con los productos del carrito de sesion
   Y el carrito de sesion permanece intacto (sigue disponible)

   Escenario 2: Reemplazar carrito guardado previo
   DADO usuario con SavedCart existente de hace 3 dias
   CUANDO guarda el carrito actual (con accion "reemplazar")
   ENTONCES el SavedCart existente se actualiza con el nuevo contenido
   Y saved_at = timestamp actual
   Y el carrito antiguo no existe mas

   Escenario 3: Carrito vacio — no se puede guardar
   DADO usuario con carrito de sesion vacio
   CUANDO intenta guardar
   ENTONCES HTTP 400 con {"codigo_error": "CARRITO_VACIO",
   "mensaje": "Agrega productos al carrito antes de guardarlo."}

   Escenario 4: Carrito de sesion intacto tras el guardado
   DADO carrito de sesion con 3 items guardado exitosamente
   CUANDO el usuario navega al catalogo y vuelve al carrito
   ENTONCES el carrito de sesion sigue teniendo los 3 items
   Y el carrito guardado es una copia independiente

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion es la fuente de datos),
  BR-010 (guest-friendly — el guardado requiere autenticacion pero
  el carrito de sesion existe para visitantes anonimos)
- **RNF aplicables:** RNF-SEC-003 (aislamiento — el SavedCart.user
  garantiza que solo el propietario accede a su carrito guardado)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-05: Guardar Carrito para Despues
   * - **Depende de**
     - FR-CART-02.01 (carrito de sesion con items — el contenido existe)
   * - **Requerido por**
     - FR-CART-05.03 (confirmar al usuario que el guardado fue exitoso)
   * - **BR**
     - BR-003, BR-010
   * - **Test**
     - TST-FR-CART-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 3 de UC-CART-05

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-03-ext-buscar-filtros-avanzados
=================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-03-ext-01-aplicar-filtros-avanzados
   fr-cat-03-ext-02-aplicar-filtros-and

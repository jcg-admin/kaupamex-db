.. meta::
   :artefacto: FR-AUTH-02.02
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-02-02:

===============================================
FR-AUTH-02.02: Autenticar credenciales
===============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.02
   * - **Nombre**
     - Verificar username/email y password contra la base de datos
   * - **UC Origen**
     - UC-AUTH-02: Iniciar sesion
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Autenticacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar las credenciales contra la base de datos
   y registrar el intento CUANDO la IP no esta bloqueada.

**Descripcion:**

Proceso de autenticacion:

1. Busca el usuario por ``username`` o por ``email`` (el campo
   identificador acepta ambos formatos)
2. Si no existe: incrementa el contador de intentos fallidos de la IP
   y retorna error generico (sin revelar si el usuario existe)
3. Si existe pero ``is_active=False``: retorna error de cuenta
   inactiva con instruccion de revisar el email de verificacion
4. Si existe y activo: verifica la password con
   ``user.check_password(raw_password)``
5. Si la password es incorrecta: incrementa el contador de intentos
   fallidos y retorna error generico
6. Si todo es correcto: procede a FR-AUTH-02.03

El mensaje de error para usuario-no-existe y password-incorrecta
es identico para prevenir enumeracion de usuarios.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO IP no bloqueada y credenciales enviadas
   CUANDO el sistema autentica
   ENTONCES el resultado es exitoso o fallido con mensaje correcto

   Escenario 1: Credenciales correctas
   DADO username y password validos para un usuario activo
   CUANDO se autentica
   ENTONCES la autenticacion es exitosa
   Y el proceso continua a FR-AUTH-02.03

   Escenario 2: Usuario no existe
   DADO username que no existe en el sistema
   CUANDO se autentica
   ENTONCES se retorna 401 con mensaje generico
   Y el contador de intentos fallidos de la IP incrementa en 1
   Y NO se revela que el usuario no existe

   Escenario 3: Password incorrecta
   DADO username existente pero password incorrecta
   CUANDO se autentica
   ENTONCES se retorna 401 con el MISMO mensaje generico del escenario 2
   Y el contador de intentos fallidos incrementa en 1

   Escenario 4: Cuenta inactiva (email no verificado)
   DADO usuario existente con is_active=False
   CUANDO se autentica
   ENTONCES se retorna 401 con mensaje especifico de cuenta inactiva
   Y se incluye instruccion de revisar el email de verificacion
   Y el contador de intentos NO incrementa (no es un intento malicioso)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting), BR-013 (modelo base)
- **Notas:** El identificador acepta tanto username como email para
  mayor comodidad. Se normaliza a minusculas antes de la busqueda.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar sesion
   * - **Depende de**
     - FR-AUTH-02.01 (IP no bloqueada)
   * - **Requerido por**
     - FR-AUTH-02.03 (emitir tokens JWT)
   * - **RNF**
     - RNF-SEC-001 (JWT), RNF-SEC-004 (rate limiting)
   * - **Test**
     - TST-FR-AUTH-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-02

.. meta::
   :artefacto: FR-CAT-08.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-08-01:

FR-CAT-08.01: Retornar arbol de categorias activas
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-08.01
   * - **Nombre**
     - Retornar arbol de categorias activas
   * - **UC Origen**
     - UC-CAT 08 LISTAR CATEGORIAS
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el arbol completo de categorias activas CUANDO se solicita.

**Descripcion:**

Estructura jerarquica: ``[{id, name, slug, children: [...], product_count}]``
Solo categorias con ``is_active=True``.
``product_count``: numero de productos activos directos e indirectos de cada categoria.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Arbol completo
   DADO 3 categorias raiz con subcategorias
   CUANDO se solicita GET /api/v1/catalogue/categories/
   ENTONCES la respuesta es el arbol completo con product_count en cada nodo

   Escenario: Sin categorias activas
   DADO sistema sin categorias activas
   CUANDO se solicita
   ENTONCES lista vacia []


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El arbol de categorias puede cachearse — cambia poco y se usa en cada carga del catalogo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 08 LISTAR CATEGORIAS
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-CAT-01.01 (el visitante filtra por categoria desde el listado)
   * - **Test**
     - TST-FR-CAT-08.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 08 LISTAR CATEGORIAS

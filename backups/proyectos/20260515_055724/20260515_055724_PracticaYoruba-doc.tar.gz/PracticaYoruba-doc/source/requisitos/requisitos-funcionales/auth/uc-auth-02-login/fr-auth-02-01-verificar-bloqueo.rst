.. meta::
   :artefacto: FR-AUTH-02.01
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-02-01:

==================================================
FR-AUTH-02.01: Verificar bloqueo por intentos
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.01
   * - **Nombre**
     - Verificar si la IP esta bloqueada por exceso de intentos fallidos
   * - **UC Origen**
     - UC-AUTH-02: Iniciar sesion
   * - **Paso UC**
     - Paso 1 del flujo principal (antes de validar credenciales)
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Seguridad

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar si la IP del solicitante esta temporalmente
   bloqueada CUANDO recibe una solicitud de login.

**Descripcion:**

Reglas de bloqueo (BR-015 rate limiting):

- Maximo **5 intentos fallidos** por IP en una ventana de **15 minutos**
- Al superar el limite: bloqueo temporal de **15 minutos** adicionales
- El contador se almacena en cache (Django cache framework)
- El bloqueo es por IP, no por usuario — protege cuentas existentes
  y previene enumeracion de usuarios
- El tiempo restante del bloqueo se informa en la respuesta

----

3. Criterio de Aceptacion
--------------------------

::

   DADO una solicitud de login
   CUANDO llega al endpoint
   ENTONCES se verifica el estado de bloqueo de la IP primero

   Escenario 1: IP no bloqueada
   DADO IP con menos de 5 intentos fallidos en los ultimos 15 minutos
   CUANDO se verifica
   ENTONCES no hay bloqueo activo
   Y el proceso continua a FR-AUTH-02.02

   Escenario 2: IP bloqueada
   DADO IP con 5+ intentos fallidos
   CUANDO se verifica
   ENTONCES se retorna 429 Too Many Requests
   Y la respuesta incluye Retry-After con los segundos restantes
   Y no se verifica username ni password (ni se revela si existen)

   Escenario 3: Bloqueo expira
   DADO IP bloqueada cuyo tiempo de 15 minutos expiro
   CUANDO intenta de nuevo
   ENTONCES el sistema acepta el intento como si fuera el primero
   Y el contador se reinicia a 0

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting)
- **RNF aplicables:** RNF-SEC-004 (rate limiting endpoints criticos)
- **Notas:** El bloqueo por IP no discrimina entre usuarios distintos
  desde la misma IP. En entornos corporativos (NAT) puede afectar
  a multiples usuarios. Esto es una decision de seguridad aceptada.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar sesion
   * - **Depende de**
     - Ninguno (es el primer paso del login)
   * - **Requerido por**
     - FR-AUTH-02.02 (autenticar credenciales)
   * - **BR**
     - BR-015
   * - **RNF**
     - RNF-SEC-004
   * - **Test**
     - TST-FR-AUTH-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-02

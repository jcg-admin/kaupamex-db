.. meta::
   :artefacto: FR-RPT-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rpt-01-01:

FR-RPT-01.01: Calcular metricas de ventas del periodo
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-01.01
   * - **Nombre**
     - Calcular metricas de ventas del periodo
   * - **UC Origen**
     - UC-RPT 01 VER REPORTE VENTAS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular y retornar las metricas de ventas CUANDO el admin consulta el reporte.

**Descripcion:**

Calculo sobre ordenes con status=DELIVERED o PAYMENT_CONFIRMED en el periodo:

``Order.objects.filter(status__in=['DELIVERED','PAYMENT_CONFIRMED'],
  created_at__range=[desde, hasta]).aggregate(
  total_revenue=Sum('ordervalue__total'),
  total_orders=Count('id'),
  avg_ticket=Avg('ordervalue__total'))``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reporte del mes con comparativa
   DADO admin que consulta el reporte del mes actual
   CUANDO se calcula
   ENTONCES ve total_revenue, total_orders, avg_ticket
   Y la variacion porcentual vs el mismo mes del año anterior

   Escenario: Periodo sin ventas
   DADO periodo con cero ordenes
   CUANDO se calcula
   ENTONCES todos los valores en 0 — no es un error


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El reporte se calcula en tiempo real sobre las ordenes de BD.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT 01 VER REPORTE VENTAS
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-RPT-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RPT 01 VER REPORTE VENTAS

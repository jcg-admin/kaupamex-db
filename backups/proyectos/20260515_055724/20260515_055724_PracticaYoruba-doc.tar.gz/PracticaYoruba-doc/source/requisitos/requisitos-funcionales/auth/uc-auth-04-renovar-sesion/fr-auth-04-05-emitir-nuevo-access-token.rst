.. meta::
   :artefacto: FR-AUTH-04.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-04-05:

====================================================
FR-AUTH-04.05: Emitir nuevo access token tras la renovacion
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.05
   * - **Nombre**
     - Generar nuevo access token con los datos actuales del usuario
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Paso 6 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE emitir un nuevo access token con los datos actuales
   del usuario CUANDO todas las verificaciones previas han pasado.

**Descripcion:**

El nuevo access token se genera con los datos del usuario al momento
de la renovación, no con los del login original. Su contenido incluye:
el tipo de token, la fecha de expiración (15 minutos desde la emisión),
la fecha de emisión, un identificador único de token, y los datos del
usuario: ``User.id``, ``User.username`` y ``User.is_staff``.

Ventaja de usar datos actuales: si el administrador modificó el campo
``User.is_staff`` del usuario entre el login y la renovación, el nuevo
access token refleja el valor actual. El usuario no necesita
re-autenticarse para que el cambio surta efecto — basta con que su
access token expire y se renueve.

El nuevo access token tiene siempre 15 minutos de vida,
independientemente de cuánto tiempo de vida le quede al refresh token.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nuevo access token emitido correctamente
   DADO todas las verificaciones previas exitosas
   CUANDO se emite el nuevo access token
   ENTONCES el token es un JWT valido firmado con HS256
   Y su exp = now() + 15 minutos
   Y su jti es un UUID unico (diferente al del token anterior)

   Escenario 2: Cambio de rol reflejado en el nuevo access token
   DADO usuario con is_staff=False que fue promovido a staff entre renovaciones
   CUANDO se renueva la sesion
   ENTONCES el nuevo access token tiene is_staff = True
   Y el frontend detecta el cambio y muestra el menu de admin

   Escenario 3: Access token anterior invalido tras emision del nuevo
   DADO access token anterior (aun dentro de sus 15 minutos)
   CUANDO se emite el nuevo access token
   ENTONCES el access token anterior SIGUE SIENDO VALIDO hasta su exp
   (limitacion conocida del JWT stateless — no hay blacklist de access tokens)
   Y el nuevo access token tambien es valido
   Y ambos pueden usarse hasta que el anterior expire

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (JWT con 15 minutos de vida)
- **Notas:** La superposicion de access tokens (el viejo y el nuevo
  ambos validos) es una limitacion aceptada del diseno JWT. La ventana
  maxima es de 15 minutos. En APIs tipicas de usuario final, esto
  no representa un riesgo significativo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Depende de**
     - FR-AUTH-04.04 (cuenta activa verificada)
   * - **Requerido por**
     - FR-AUTH-04.01 (que tambien invalida el refresh token usado y emite el nuevo)
   * - **Test**
     - TST-FR-AUTH-04.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 6 de UC-AUTH-04

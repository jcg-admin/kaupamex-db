.. meta::
   :artefacto: FR-AUTH-08.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-08-05:

===========================================================
FR-AUTH-08.05: Registrar auditoria del cambio y confirmar al usuario
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.05
   * - **Nombre**
     - Crear registro de auditoria y confirmar que la contraseña fue cambiada
   * - **UC Origen**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Paso UC**
     - Pasos 13, 14 y 15 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (AccessAuditLog + respuesta del endpoint)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Auditoria + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar el cambio de contraseña en auditoria
   e informar al usuario que el cambio fue exitoso y que sus otras
   sesiones han sido cerradas CUANDO la nueva contraseña ha sido
   almacenada y las sesiones invalidadas.

**Descripcion:**

**Registro de auditoria (paso 13):**

El sistema crea un registro ``AccessAuditLog`` con los campos:
referencia al ``User``, tipo de evento ``CAMBIO_CONTRASENA``,
dirección IP del cliente, resultado ``EXITOSO`` y timestamp del
momento. Ni la contraseña anterior ni la nueva se registran en
ningún campo del log.

**Confirmacion al usuario (pasos 14 y 15):**

El sistema retorna HTTP 200 informando:

1. Que la contraseña fue cambiada exitosamente
2. Que todas las sesiones en otros dispositivos han sido cerradas
3. Que el usuario necesita volver a iniciar sesion en esos dispositivos

.. code-block:: json

   {
     "mensaje": "Tu contraseña fue cambiada exitosamente.",
     "sesiones_cerradas": true,
     "info": "Tus otras sesiones activas han sido cerradas por seguridad."
   }

La sesion actual permanece activa. El usuario no necesita volver
a iniciar sesion en el dispositivo donde hizo el cambio.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Auditoria registrada sin contraseñas
   DADO cambio de contraseña exitoso
   CUANDO se crea el registro en AccessAuditLog
   ENTONCES event_type = CAMBIO_CONTRASENA
   Y ninguna contraseña (anterior ni nueva) aparece en el registro
   Y ip_address = IP del request

   Escenario 2: Confirmacion informa sobre otras sesiones
   DADO usuario con sesiones activas en 3 dispositivos
   CUANDO cambia la contraseña desde el dispositivo A
   ENTONCES la respuesta 200 incluye sesiones_cerradas: true
   Y el usuario en los dispositivos B y C necesitan re-autenticarse
   Y la sesion del dispositivo A sigue activa

   Escenario 3: Fallo de auditoria no revierte el cambio
   DADO error al insertar en AccessAuditLog
   CUANDO falla el INSERT
   ENTONCES la nueva contraseña ya esta almacenada (no se revierte)
   Y el fallo queda en django.log nivel ERROR
   Y el usuario recibe la confirmacion de exito

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (created_at automatico en AccessAuditLog)
- **RNF aplicables:** RNF-PROC-002 (auditoria de cambios de credenciales)
- **Notas:** Mantener la sesion actual activa es una decision de UX —
  no tiene sentido desconectar al usuario en el mismo dispositivo donde
  acaba de cambiar su contraseña con exito. Solo se invalidan las
  sesiones de otros dispositivos.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Depende de**
     - FR-AUTH-08.02 (contraseña almacenada y otras sesiones invalidadas)
   * - **Requerido por**
     - Ninguno — ultimo paso del flujo principal
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-08.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 13-15 de UC-AUTH-08
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Bloque JSON conservado — contrato de respuesta HTTP.

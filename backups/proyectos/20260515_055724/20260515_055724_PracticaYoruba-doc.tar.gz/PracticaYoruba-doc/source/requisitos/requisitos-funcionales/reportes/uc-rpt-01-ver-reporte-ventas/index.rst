.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rpt-01-ver-reporte-ventas
=======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rpt-01-02-calcular-reporte-ventas
   fr-rpt-01-ver-reporte-ventas-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — DEVOLUCIONES
======================================

**4 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-ret-01-solicitar-devolucion
     - 1
   * - uc-ret-02-revisar-solicitud-devolucion
     - 1
   * - uc-ret-03-registrar-recepcion-devolucion
     - 1
   * - uc-ret-04-ver-estado-devolucion
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-ret-01-solicitar-devolucion/index
   uc-ret-02-revisar-solicitud-devolucion/index
   uc-ret-03-registrar-recepcion-devolucion/index
   uc-ret-04-ver-estado-devolucion/index

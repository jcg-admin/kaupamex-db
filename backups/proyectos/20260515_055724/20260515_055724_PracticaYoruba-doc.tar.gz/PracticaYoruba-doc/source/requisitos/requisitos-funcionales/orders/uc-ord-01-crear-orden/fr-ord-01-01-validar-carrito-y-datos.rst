.. meta::
   :artefacto: FR-ORD-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-01-01:

====================================================
FR-ORD-01.01: Validar carrito y datos de checkout
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01.01
   * - **Nombre**
     - Verificar que el carrito, la direccion y el metodo de envio son validos
   * - **UC Origen**
     - UC-ORD-01: Crear orden desde carrito (Checkout)
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-005 CART + MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que todos los prerequisitos del checkout
   son validos CUANDO el actor inicia el proceso de creacion de orden.

**Descripcion:**

Validaciones pre-checkout en orden:

1. El carrito no esta vacio (al menos 1 CartItem)
2. Todos los items tienen stock suficiente en este momento
   (re-verificacion — el stock pudo cambiar desde que se agrego)
3. La direccion de envio seleccionada existe y pertenece al actor
   (o es una direccion nueva valida para invitados)
4. El metodo de envio seleccionado esta activo en SiteSettings
   y tiene cobertura para la zona de la direccion
5. Si hay voucher en el carrito: re-valida que sigue vigente
   y que el subtotal supera el minimo (puede haber cambiado)

Cualquier falla retorna un error descriptivo indicando que elemento
requiere accion del actor antes de continuar.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO actor con carrito y datos de checkout
   CUANDO inicia el checkout
   ENTONCES se validan todos los prerequisitos

   Escenario 1: Stock insuficiente al iniciar checkout
   DADO item en carrito cuyo stock bajo a 0 mientras navegaba
   CUANDO inicia checkout
   ENTONCES error 409: STOCK_INSUFICIENTE_CHECKOUT
   Y se identifica cual item tiene el problema
   Y el actor puede eliminarlo o esperar

   Escenario 2: Metodo de envio desactivado
   DADO metodo de envio seleccionado que fue desactivado
   CUANDO inicia checkout
   ENTONCES error 422: METODO_ENVIO_NO_DISPONIBLE
   Y se presenta la lista de metodos disponibles actualmente

   Escenario 3: Voucher expirado entre carrito y checkout
   DADO voucher en el carrito que expiro en las ultimas horas
   CUANDO inicia checkout
   ENTONCES error 422: VOUCHER_EXPIRADO_EN_CHECKOUT
   Y se ofrece continuar sin el voucher o agregar otro codigo

   Escenario 4: Todos los datos validos
   DADO carrito con stock, direccion valida y metodo activo
   CUANDO se valida
   ENTONCES todos los checks pasan
   Y el proceso continua a FR-ORD-01.02

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion), BR-004 (carrito sin login)
- **Notas:** Esta re-validacion es necesaria porque pueden pasar horas
  o dias entre que el actor agrego los items y cuando hace checkout.
  El stock puede haber cambiado, los metodos pueden haberse desactivado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01: Crear orden desde carrito
   * - **Depende de**
     - FR-CART-02.01 (carrito activo recuperado)
   * - **Requerido por**
     - FR-ORD-01.02 (capturar snapshot de la orden)
   * - **Include**
     - UC-INC-02 (recuperar carrito de sesion)
   * - **Test**
     - TST-FR-ORD-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-01

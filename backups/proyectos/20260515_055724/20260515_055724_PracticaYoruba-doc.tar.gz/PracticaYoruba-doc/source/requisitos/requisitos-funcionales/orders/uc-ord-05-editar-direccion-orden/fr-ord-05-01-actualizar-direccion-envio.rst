.. meta::
   :artefacto: FR-ORD-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-ORD-05.01: Actualizar la direccion de envio
===============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-05.01
   * - **Nombre**
     - Reemplazar la OrderAddress de una orden pendiente de pago
   * - **UC Origen**
     - UC-ORD-05: Editar direccion de orden
   * - **Paso UC**
     - Pasos 3-5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE reemplazar la OrderAddress de la orden con
   la nueva direccion CUANDO la orden esta en PENDING_PAYMENT.

**Descripcion:**

Solo es posible cuando el estado es ``PENDING_PAYMENT``.
Una vez que la orden pasa a ``PAYMENT_CONFIRMED`` la direccion
es definitiva y no se puede cambiar desde la cuenta del comprador
(requiere atencion del admin via UC-ORD-07).

El reemplazo crea una nueva ``OrderAddress`` con los datos
de la nueva direccion. La anterior queda en el historial.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO orden en PENDING_PAYMENT
   CUANDO el comprador cambia la direccion
   ENTONCES la OrderAddress se actualiza

   Escenario 1: Cambio exitoso a direccion guardada
   DADO comprador con orden PENDING_PAYMENT y 2 direcciones en perfil
   CUANDO selecciona la segunda direccion
   ENTONCES OrderAddress refleja la nueva direccion

   Escenario 2: Orden ya con pago confirmado
   DADO orden en PAYMENT_CONFIRMED
   CUANDO se intenta cambiar la direccion
   ENTONCES error 422: NO_SE_PUEDE_EDITAR_EN_ESTE_ESTADO

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (el snapshot nuevo sustituye al anterior)
- **Notas:** El cambio de direccion puede cambiar el costo de envio
  si la nueva zona tiene una tarifa diferente. Los totales se recalculan.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-05: Editar direccion de orden
   * - **Depende de**
     - FR-ORD-02.01 (propiedad verificada)
   * - **Requerido por**
     - FR-PAY-01.01 (el pago se procesa con la direccion definitiva)
   * - **Include**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-ORD-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-05

.. meta::
   :artefacto: FR-ORD-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-07-01:

==========================================================
FR-ORD-07.01: Cambiar estado de orden a IN_PREPARATION
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-07.01
   * - **Nombre**
     - Transicionar la orden de PAYMENT_CONFIRMED a IN_PREPARATION
   * - **UC Origen**
     - UC-ORD-07: Procesar orden (Admin)
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER (apps.orders)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la orden a IN_PREPARATION
   CUANDO el administrador la toma para procesar.

**Descripcion:**

Transicion de estado valida:
``PAYMENT_CONFIRMED`` → ``IN_PREPARATION``

Solo esta transicion es valida para este UC. Una orden en otro
estado retorna error indicando la transicion no permitida.

Al transicionar:

- ``Order.status = IN_PREPARATION``
- ``Order.processed_by = admin_user`` (FK, nullable)
- ``Order.processed_at = now()``
- Notificacion al comprador via UC-NOT sobre actualizacion de estado

Efecto de seguridad: al llegar a IN_PREPARATION el comprador
ya no puede cancelar la orden desde su cuenta.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO admin con orden en PAYMENT_CONFIRMED
   CUANDO hace POST /api/v1/admin/orders/{number}/process/
   ENTONCES el estado cambia a IN_PREPARATION

   Escenario 1: Transicion exitosa
   DADO orden en PAYMENT_CONFIRMED
   CUANDO el admin procesa
   ENTONCES status = IN_PREPARATION
   Y el comprador recibe notificacion de su orden en preparacion

   Escenario 2: Orden en estado incorrecto
   DADO orden en SHIPPED (ya fue enviada)
   CUANDO el admin intenta procesarla
   ENTONCES error 422: TRANSICION_INVALIDA
   Y se informa el estado actual de la orden

   Escenario 3: Dos admins procesando la misma orden
   DADO dos admins intentando procesar la misma orden simultaneamente
   CUANDO el primero lo hace
   ENTONCES el segundo recibe error: LA_ORDEN_YA_FUE_PROCESADA

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF:** RNF-PROC-002 (auditoria — quien proceso y cuando)
- **Notas:** Un admin puede agregar una nota interna opcional al procesar
  la orden. La nota queda en el historial interno, no visible al comprador.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-07: Procesar orden (Admin)
   * - **Depende de**
     - Orden en estado PAYMENT_CONFIRMED
   * - **Requerido por**
     - Siguiente paso del admin: crear guia de envio (UC-LOG-01)
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-ORD-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-07

.. meta::
   :artefacto: FR-CART-02.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-02-04:

===========================================================
FR-CART-02.04: Presentar la vista completa del carrito y NFR
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-02.04
   * - **Nombre**
     - Retornar la estructura completa del carrito con totales, avisos y restricciones tecnicas
   * - **UC Origen**
     - UC-CART-02: Ver Carrito
   * - **Paso UC**
     - Paso 5 del flujo principal + PARTE 5 + PARTE 6
   * - **Modulo**
     - MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion + NFR Tecnico

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la estructura completa del carrito con
   todos los items, sus estados de disponibilidad, el desglose
   de precios y las acciones disponibles CUANDO el calculo de
   totales ha sido completado.

**Descripcion:**

Respuesta HTTP 200 con la estructura completa:

.. code-block:: json

   {
     "estado": "con_items",
     "items": [
       {
         "key": "product_42_variant_3",
         "product_id": 42,
         "variant_id": 3,
         "name": "Sopera de Yemoja",
         "variant_name": "Grande",
         "imagen_url": "https://cdn.ojayoruba.com/products/42.jpg",
         "unit_price": 850.00,
         "quantity": 2,
         "item_subtotal": 1700.00,
         "availability": "AVAILABLE",
         "max_available": null
       }
     ],
     "subtotal": 1700.00,
     "voucher": null,
     "descuento": 0.00,
     "items_count": 2,
     "tiene_items_bloqueantes": false,
     "acciones": {
       "checkout_habilitado": true,
       "url_checkout": "/api/v1/checkout/",
       "url_catalogo": "/catalogo/"
     }
   }

El campo ``tiene_items_bloqueantes`` es ``true`` cuando algun item
tiene ``availability`` de ``OUT_OF_STOCK`` o ``REDUCED_STOCK`` con
cantidad mayor al stock disponible. En ese caso ``checkout_habilitado``
es ``false``.

**EX-01 — Sistema de carrito no disponible:**
Si la sesion no puede ser leida, HTTP 503 con mensaje generico.

**EX-03 — Precio desactualizado:**
Si el precio del producto cambio en el repositorio desde que fue
agregado al carrito, la respuesta incluye un aviso:

.. code-block:: json

   {
     "avisos": [
       {
         "tipo": "precio_actualizado",
         "producto": "Sopera de Yemoja",
         "precio_anterior": 800.00,
         "precio_actual": 850.00
       }
     ]
   }

El precio en el carrito se actualiza al precio actual del repositorio.

**NFR — Performance:** GET /api/v1/cart/ debe responder en P95 <= 400ms
incluyendo la verificacion de stock de todos los items (consulta con IN).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Carrito normal retornado correctamente
   DADO carrito con 3 items, todos AVAILABLE
   CUANDO GET /api/v1/cart/
   ENTONCES HTTP 200 con los 3 items, subtotal correcto
   Y checkout_habilitado = true

   Escenario 2: Carrito con item bloqueante
   DADO item con REDUCED_STOCK (quantity > stock)
   CUANDO GET /api/v1/cart/
   ENTONCES tiene_items_bloqueantes = true
   Y checkout_habilitado = false
   Y el item muestra max_available = stock disponible

   Escenario 3: Precio actualizado automaticamente
   DADO item agregado cuando el precio era 800, ahora es 850
   CUANDO GET /api/v1/cart/
   ENTONCES el item muestra unit_price = 850
   Y la respuesta incluye aviso de tipo precio_actualizado
   Y el subtotal usa el precio actual

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio sin IVA en catalogo — el carrito
  muestra precios sin IVA; el IVA se calcula en checkout)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-02: Ver Carrito
   * - **Depende de**
     - FR-CART-02.03 (disponibilidad verificada),
       FR-CART-02.02 (subtotales calculados)
   * - **Requerido por**
     - FR-ORD-01.01 (el checkout usa el carrito verificado)
   * - **Test**
     - TST-FR-CART-02.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 5 + PARTE 5 y 6 de UC-CART-02

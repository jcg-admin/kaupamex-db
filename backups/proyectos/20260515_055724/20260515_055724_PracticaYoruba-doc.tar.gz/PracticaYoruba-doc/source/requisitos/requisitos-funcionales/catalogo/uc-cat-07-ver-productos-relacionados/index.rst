.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-07-ver-productos-relacionados
===============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-07-02-recuperar-productos-relacionados
   fr-cat-07-ver-productos-relacionados-01-retornar-hasta-6-productos-rel

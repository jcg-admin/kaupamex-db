.. meta::
   :artefacto: FR-AUTH-09.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-09-03:

==========================================================
FR-AUTH-09.03: Generar token HMAC y enviar email de recuperacion
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.03
   * - **Nombre**
     - Validar email, generar token de un solo uso y encolar el envio asincrono
   * - **UC Origen**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Paso UC**
     - Pasos 4, 5, 6, 7 y 8 del flujo principal (Fase 1)
   * - **Modulo**
     - MOD-001 ACCOUNTS (PasswordResetToken + cola de email asincrona)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Datos + Comunicacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato del email, buscar la cuenta
   de forma interna, generar el token si corresponde, encolar el
   envio y siempre retornar el mismo mensaje al usuario CUANDO
   recibe la solicitud de recuperacion de contraseña.

**Descripcion:**

**Paso 4 — Validacion de formato (servidor):**

Formato de email valido. Si no cumple formato → 400 con mensaje
tecnico (no el mensaje generico, porque la validacion de formato es
una ayuda al usuario, no una revelacion de existencia de cuenta).

**Pasos 5 y 6 — Busqueda interna y generacion del token:**

El sistema busca internamente un ``User`` activo cuyo email coincida
con el recibido (comparación sin distinción de mayúsculas). Esta
búsqueda es estrictamente interna y su resultado nunca se revela en
la respuesta. Si existe un usuario activo con ese email:

- Los ``PasswordResetToken`` previos del usuario que aún no han sido
  usados se marcan como expirados de inmediato, invalidándolos.
- El sistema genera un token de 256 bits de entropía y crea un nuevo
  registro ``PasswordResetToken`` almacenando el hash del token
  (nunca el token en texto claro), con expiración de 1 hora desde
  el momento de la creación.
- El envío del email de recuperación se encola de forma asíncrona,
  incluyendo el token en claro en el enlace del mensaje.

**Pasos 7 y 8 — Respuesta siempre identica:**

Independientemente de si el email existe o no:

.. code-block:: json

   HTTP 200
   {
     "mensaje": "Si el email esta registrado, recibiras un mensaje con instrucciones."
   }

El envio del email ocurre de forma asincrona — no bloquea la respuesta.

**Rate limiting (BR-015):** maximo 3 solicitudes de recuperacion
por hora por IP para prevenir abuso del servicio de email.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email registrado — token generado y email encolado
   DADO email "juan@ejemplo.com" que existe en el sistema
   CUANDO se solicita la recuperacion
   ENTONCES se genera un token HMAC con 256 bits de entropia
   Y los tokens previos del usuario quedan expirados
   Y el envio del email se encola en Celery (asincrono)
   Y la respuesta es HTTP 200 con el mensaje generico

   Escenario 2: Email no registrado — respuesta identica
   DADO email "nadie@ejemplo.com" que no existe
   CUANDO se solicita la recuperacion
   ENTONCES NO se genera ningun token ni se encola ningun envio
   Y la respuesta es HTTP 200 con el MISMO mensaje generico
   Y un observador externo no puede distinguir este caso del anterior

   Escenario 3: Tiempo de respuesta similar para ambos casos
   DADO 1000 solicitudes con email existente y 1000 con email inexistente
   CUANDO se miden los tiempos de respuesta
   ENTONCES la diferencia estadistica entre ambos grupos es < 50ms
   (timing attack no puede distinguir si el email existe)

   Escenario 4: Rate limiting aplicado
   DADO IP que hace 3 solicitudes en menos de 1 hora
   CUANDO hace la cuarta
   ENTONCES HTTP 429 con Retry-After
   Y las primeras 3 solicitudes se procesaron normalmente

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — max 3/hora para no
  saturar el servicio de email)
- **Notas:** El token se almacena hasheado en la BD (no en texto claro).
  El enlace en el email contiene el token en claro (un solo uso).
  Si alguien obtiene acceso a la BD, los tokens hasheados no sirven.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Depende de**
     - Ninguno — primer paso del Sistema
   * - **Requerido por**
     - FR-AUTH-09.04 (el usuario usa el enlace del email)
   * - **BR**
     - BR-015
   * - **Test**
     - TST-FR-AUTH-09.03 (pendiente — mock del envio de email)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-8 de UC-AUTH-09
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Bloque JSON conservado — contrato de respuesta HTTP.

.. meta::
   :artefacto: FR-SYS-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-sys-02-01:

FR-SYS-02.01: Desactivar vouchers que alcanzaron su fecha de vencimiento
========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-02.01
   * - **Nombre**
     - Desactivar vouchers que alcanzaron su fecha de vencimiento
   * - **UC Origen**
     - UC-SYS 02 DESACTIVAR VOUCHERS EXPIRADOS
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE desactivar los vouchers cuya valid_until vencio CUANDO el Actor Tiempo lo dispara.

**Descripcion:**

Tarea periodica (cada hora):

``Voucher.objects.filter(is_active=True, valid_until__lt=now()).update(is_active=False)``

La desactivacion masiva usa ``.update()`` para eficiencia — sin iterar uno por uno.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Vouchers expirados desactivados
   DADO 3 vouchers con valid_until de ayer
   CUANDO la tarea se ejecuta
   ENTONCES los 3 quedan con is_active=False en un solo UPDATE

   Escenario: Sin vouchers expirados
   DADO ninguna voucher expirada en este ciclo
   CUANDO la tarea se ejecuta
   ENTONCES no se modifica nada — la tarea termina sin efectos


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002`
- **Notas:** El bulk UPDATE es mas eficiente que iterar y guardar cada voucher individualmente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS 02 DESACTIVAR VOUCHERS EXPIRADOS
   * - **Depende de**
     - Actor Tiempo (tarea periodica)
   * - **Requerido por**
     - FR-CART-04.01 (el voucher ya no puede aplicarse)
   * - **Test**
     - TST-FR-SYS-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-SYS 02 DESACTIVAR VOUCHERS EXPIRADOS

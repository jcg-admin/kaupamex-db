.. meta::
   :artefacto: FR-INC-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INC-02.02: Recuperar el carrito de sesion o de cuenta segun autenticacion
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-02.02
   * - **Nombre**
     - Retornar el carrito correcto segun si el visitante esta autenticado o no
   * - **UC Origen**
     - UC-INC-02: Recuperar Carrito de Sesion (included)
   * - **Paso UC**
     - Pasos 1, 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta (reutilizable)

----

2. Especificacion
-----------------

**Declaracion:**

   El include DEBE retornar el carrito de la sesion activa si el
   visitante es anonimo, o el carrito de la cuenta si esta autenticado,
   creando uno vacio si no existe ninguno.

**Descripcion:**

**Descripcion:**

Si el usuario está autenticado, el sistema busca el ``SavedCart``
asociado al usuario. Si existe, retorna ``SavedCart.items``. Si no
existe, retorna el carrito de sesión ``session['cart']``. Si el usuario
no está autenticado, retorna directamente ``session['cart']``. En
cualquier caso, si el carrito resultante está vacío, retorna un
diccionario vacío. Este include abstrae la diferencia entre el carrito
de sesión (BR-004) y el carrito persistido en cuenta — los UCs que
necesitan el carrito no conocen esta distinción.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Visitante anonimo con carrito de sesion
   DADO visitante no autenticado con items en request.session['cart']
   CUANDO el include es invocado
   ENTONCES retorna el diccionario del carrito de sesion

   Escenario 2: Usuario autenticado con carrito en cuenta
   DADO comprador autenticado con SavedCart en BD
   CUANDO el include es invocado
   ENTONCES retorna los items del SavedCart de la BD

   Escenario 3: Sin carrito existente — retorna vacio
   DADO visitante sin ninguna sesion ni cuenta de carrito
   CUANDO el include es invocado
   ENTONCES retorna {} (diccionario vacio)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-004 (carrito disponible sin login — sesion),
  BR-003 (carrito en sesion Django para visitantes anonimos)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC-02: Recuperar Carrito de Sesion
   * - **Incluido por**
     - FR-CART-01.01, FR-CART-02.03, FR-ORD-01.02 y otros UCs de carrito
   * - **Test**
     - TST-FR-INC-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 1-5 de UC-INC-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

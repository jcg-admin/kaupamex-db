.. meta::
   :artefacto: FR-WISH-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-wish-03-01:

FR-WISH-03.01: Mover item de la wishlist al carrito
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-03.01
   * - **Nombre**
     - Mover item de la wishlist al carrito
   * - **UC Origen**
     - UC-WISH 03 MOVER WISHLIST CARRITO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-011 WISHLIST + MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE agregar el item al carrito y opcionalmente eliminarlo de la lista CUANDO el comprador lo mueve.

**Descripcion:**

1. Llama a FR-CART-01.01 (verificar stock) y FR-CART-01.02 (agregar item)
2. Si ``keep_in_list=False`` (default): elimina el WishlistItem
3. Si ``keep_in_list=True``: el item permanece en la wishlist
4. Retorna el carrito actualizado y si el item quedo o no en la lista

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Mover con eliminacion de lista
   DADO item disponible en wishlist
   CUANDO se mueve al carrito con keep_in_list=False
   ENTONCES el item aparece en el carrito
   Y desaparece de la wishlist

   Escenario: Mover item sin stock
   DADO item sin stock en wishlist
   CUANDO se intenta mover al carrito
   ENTONCES error 409: PRODUCTO_SIN_STOCK
   Y el item permanece en la wishlist


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La operacion delega en Cart.add_item — la logica de stock y duplicados la maneja el carrito.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH 03 MOVER WISHLIST CARRITO
   * - **Depende de**
     - FR-WISH-02.01 (item identificado en la lista)
   * - **Requerido por**
     - FR-CART-02.02 (totales del carrito actualizados)
   * - **Test**
     - TST-FR-WISH-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-WISH 03 MOVER WISHLIST CARRITO

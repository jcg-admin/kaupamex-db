.. meta::
   :artefacto: FR-CAT-10.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-10-01:

FR-CAT-10.01: Editar producto preservando snapshots de ordenes
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-10.01
   * - **Nombre**
     - Editar producto preservando snapshots de ordenes
   * - **UC Origen**
     - UC-CAT 10 EDITAR PRODUCTO ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos / Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar los campos del producto CUANDO el admin edita, sin afectar ordenes existentes.

**Descripcion:**

Cualquier campo del producto puede editarse.
Los cambios de precio NO afectan a las ordenes existentes porque usan snapshots (BR-005).
Si se cambia el sku: se verifica unicidad con el nuevo valor.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Cambio de precio
   DADO producto con ordenes historicas a precio 100
   CUANDO el admin cambia el precio a 120
   ENTONCES el catalogo muestra 120
   Y las ordenes historicas siguen mostrando 100 en sus OrderItems

   Escenario: SKU duplicado al editar
   DADO nuevo sku que ya existe en otro producto
   CUANDO se intenta guardar
   ENTONCES error 409: SKU_DUPLICADO


----

4. Reglas y Restricciones
--------------------------

- **BR-005 (snapshot inmutable de ordenes)**

- **Notas:** N/A

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 10 EDITAR PRODUCTO ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-CAT-01.01 (el catalogo refleja el cambio de inmediato)
   * - **Test**
     - TST-FR-CAT-10.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 10 EDITAR PRODUCTO ADMIN

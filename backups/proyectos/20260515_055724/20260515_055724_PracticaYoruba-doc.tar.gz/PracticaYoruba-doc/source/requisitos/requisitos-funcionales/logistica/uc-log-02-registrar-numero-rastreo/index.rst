.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-02-registrar-numero-rastreo
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-02-02-actualizar-tracking-y-notificar
   fr-log-02-registrar-numero-rastreo-01

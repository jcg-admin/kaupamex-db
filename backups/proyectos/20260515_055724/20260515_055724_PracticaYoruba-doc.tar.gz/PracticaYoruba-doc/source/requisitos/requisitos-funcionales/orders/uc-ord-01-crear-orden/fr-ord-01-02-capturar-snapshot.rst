.. meta::
   :artefacto: FR-ORD-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-01-02:

=======================================================
FR-ORD-01.02: Capturar snapshot inmutable de la orden
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01.02
   * - **Nombre**
     - Crear Order, OrderItem, OrderAddress y OrderValue con snapshot BR-005
   * - **UC Origen**
     - UC-ORD-01: Crear orden desde carrito
   * - **Paso UC**
     - Pasos 5-6 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER (apps.orders)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la orden con snapshot inmutable de todos
   los precios, la direccion y el metodo de envio CUANDO todas las
   validaciones del checkout son exitosas.

**Descripcion:**

Creacion atomica (dentro de una unica transaccion de BD):

**Order:**

- ``order_number`` = generado con formato ``PY-YYYYMMDD-XXXXXXXX``
- ``user`` = actor si autenticado, ``guest_email`` si es invitado
- ``status`` = ``PENDING_PAYMENT``
- ``voucher_code`` + ``voucher_discount`` = snapshot del voucher
  (aunque el voucher sea eliminado despues, la orden lo recuerda)

**OrderItem** (uno por cada CartItem):

- ``product_name`` = ``variant.product.name`` al momento del checkout
- ``variant_label`` = ``variant.option.label`` al momento del checkout
- ``sku`` = ``variant.sku`` al momento del checkout
- ``unit_price`` = precio con IVA al momento del checkout
- ``quantity`` = la del CartItem
- Estos campos son **inmutables** — BR-005

**OrderAddress** (snapshot de la direccion):

- Todos los campos de la direccion copiados al momento del checkout
- Inmutable — si el comprador edita su direccion guardada,
  la orden no cambia

**OrderValue:**

- ``subtotal``, ``discount``, ``shipping_cost``, ``tax``, ``total``
  calculados y fijados al momento del checkout

----

3. Criterio de Aceptacion
--------------------------

::

   DADO validaciones pre-checkout exitosas
   CUANDO se crea la orden
   ENTONCES todos los datos quedan inmutables en BD

   Escenario 1: Precio del producto sube despues del checkout
   DADO OrderItem con unit_price = 100 creado ayer
   CUANDO el admin sube el precio del producto a 120 hoy
   ENTONCES el OrderItem sigue mostrando 100
   Y el total de la orden no cambia

   Escenario 2: Comprador elimina su direccion despues del checkout
   DADO OrderAddress creado con la direccion del comprador
   CUANDO el comprador elimina esa direccion de su perfil
   ENTONCES la OrderAddress de la orden sigue intacta con la misma info

   Escenario 3: Numero de orden unico
   DADO multiples checkout simultaneos
   CUANDO se generan los numeros de orden
   ENTONCES cada order_number es unico en el sistema
   Y ninguna orden tiene el mismo numero que otra

   Escenario 4: Estado inicial PENDING_PAYMENT
   DADO orden recien creada
   CUANDO se inspecciona
   ENTONCES status = PENDING_PAYMENT
   Y el comprador es redirigido a la pantalla de pago

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (snapshots inmutables), BR-011 (orden de guest)
- **Notas:** La transaccion es atomica. Si cualquier parte falla
  (error al crear OrderItem, OrderAddress, etc.) se hace rollback
  completo. Nunca queda una orden parcialmente creada.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01: Crear orden desde carrito
   * - **Depende de**
     - FR-ORD-01.01 (validaciones pre-checkout exitosas)
   * - **Requerido por**
     - FR-ORD-01.03 (decrementar stock), FR-ORD-01.04 (vaciar carrito)
   * - **BR**
     - BR-005, BR-011
   * - **Test**
     - TST-FR-ORD-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-01

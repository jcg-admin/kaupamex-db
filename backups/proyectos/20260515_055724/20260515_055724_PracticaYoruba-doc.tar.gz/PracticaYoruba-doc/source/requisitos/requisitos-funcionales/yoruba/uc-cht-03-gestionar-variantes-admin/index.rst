.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cht-03-gestionar-variantes-admin
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cht-03-02-crud-variantes-producto
   fr-cht-03-gestionar-variantes-admin-01

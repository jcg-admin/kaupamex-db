.. meta::
   :artefacto: FR-CHT-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cht-02-01:

FR-CHT-02.01: Actualizar seleccion de variante en la UI
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-02.01
   * - **Nombre**
     - Actualizar seleccion de variante en la UI
   * - **UC Origen**
     - UC-CHT 02 SELECCIONAR VARIANTE
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el precio y stock de la variante seleccionada CUANDO el comprador la elige.

**Descripcion:**

Al cambiar la variante seleccionada en la ficha:

- Se retorna el ``effective_price`` de la variante seleccionada
- Se actualiza el indicador de disponibilidad (stock > 0)
- El boton de agregar al carrito se habilita/deshabilita segun el stock

Esta operacion puede ser completamente en el cliente si los datos de variantes ya estan en la respuesta de la ficha.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Seleccion de variante disponible
   DADO variante Mediano con stock=3 y precio 150
   CUANDO el comprador la selecciona
   ENTONCES el precio mostrado es 150 y el boton esta habilitado

   Escenario: Seleccion de variante sin stock
   DADO variante Grande con stock=0
   CUANDO el comprador la selecciona
   ENTONCES el precio se muestra pero el boton de compra esta deshabilitado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La seleccion de variante puede resolverse con los datos ya cargados en la ficha — sin round-trip al servidor.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT 02 SELECCIONAR VARIANTE
   * - **Depende de**
     - FR-CHT-01.01 (variantes cargadas)
   * - **Requerido por**
     - FR-CART-01.01 (agregar la variante seleccionada al carrito)
   * - **Test**
     - TST-FR-CHT-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CHT 02 SELECCIONAR VARIANTE

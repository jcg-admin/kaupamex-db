.. meta::
   :artefacto: FR-CHT-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cht-03-02:

==================================================================================
FR-CHT-03.02: Gestionar variantes del producto con unicidad y protección de órdenes
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-03.02
   * - **Nombre**
     - Crear, editar, reordenar y desactivar variantes validando unicidad
       de nombre, protegiendo las variantes con órdenes activas de la
       eliminación y haciendo los cambios disponibles de forma inmediata
   * - **UC Origen**
     - UC-CHT-03: Gestionar Variantes (Admin)
   * - **Paso UC**
     - Pasos 8, 9 y 10 del flujo principal
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que cada variante tiene un nombre único
   dentro del producto, proteger de la eliminación las variantes que
   aparecen en órdenes activas, persistir la configuración completa
   y hacer las variantes disponibles de forma inmediata en la ficha
   del producto CUANDO el admin guarda los cambios.

**Descripcion:**

Las variantes de un producto se gestionan en bloque: el admin define
el tipo de atributo —Tamaño, Presentación, Capacidad— y las opciones
que lo componen. Cada opción es una variante individual con su propio
stock y, opcionalmente, su propio precio (FR-CHT-04.02).

**Validación de unicidad (paso 8).**
Dos variantes del mismo producto no pueden tener el mismo nombre.
El sistema valida esta condición antes de persistir. Si el admin
intenta crear una variante con un nombre que ya existe en ese
producto, el sistema indica exactamente qué nombre está duplicado
y no guarda ningún cambio hasta que se corrija.

**Orden de presentación (paso 7 y Alt. C).**
El admin define el orden en que las variantes aparecen al visitante.
La primera variante en el orden es la que queda preseleccionada
por defecto cuando hay una única variante con stock disponible
(Alt. A de FR-CHT-01.02). El orden puede ajustarse en cualquier
momento y el efecto es inmediato.

**Desactivación de variante (Alt. A).**
Cuando una variante deja de ofrecerse, el admin la desactiva. La
variante desactivada aparece en el selector de la ficha como no
disponible pero no desaparece del todo, para que el visitante
entienda que existe esa presentación aunque no esté en stock en
este momento. El stock de la variante desactivada pasa a cero.

**Protección de variantes con órdenes activas (EX-02).**
Una variante que aparece en órdenes en proceso no puede eliminarse
definitivamente; solo puede desactivarse. Esta protección garantiza
que el admin puede seguir gestionando esas órdenes —cambiar su
estado, gestionar la devolución— sin que la referencia a la variante
desaparezca del repositorio.

Cuando una nueva variante se agrega a un producto que ya tiene
variantes configuradas (Alt. B), queda disponible para los visitantes
de forma inmediata. Las órdenes existentes con otras variantes no se
ven afectadas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nueva variante creada y disponible de inmediato
   DADO admin que agrega la variante "Grande" con stock inicial=10
   al producto "Sopera de Yemoja"
   CUANDO guarda la configuración
   ENTONCES la variante aparece en la ficha del producto en el siguiente acceso
   Y el selector de la ficha muestra Pequeña, Mediana y Grande según el orden

   Escenario 2: Nombre duplicado en el mismo producto — error específico
   DADO producto que ya tiene la variante "Grande" configurada
   CUANDO el admin intenta crear otra variante llamada también "Grande"
   ENTONCES HTTP 400 con {"errors": {"name": "Este producto ya tiene
   una variante con el nombre Grande."}}
   Y ningún cambio se persiste hasta corregir el conflicto

   Escenario 3: Intento de eliminar variante con órdenes activas (EX-02)
   DADO variante "Mediana" que aparece en 2 órdenes en estado IN_PREPARATION
   CUANDO el admin intenta eliminarla definitivamente
   ENTONCES HTTP 400 con {"codigo_error": "VARIANTE_CON_ORDENES",
   "mensaje": "Esta variante tiene órdenes en proceso y no puede
   eliminarse. Puedes desactivarla para que no acepte nuevas selecciones."}

   Escenario 4: Desactivación de variante — visible como no disponible
   DADO variante "Grande" que el admin desactiva porque se agotó
   CUANDO el visitante carga la ficha del producto
   ENTONCES "Grande" aparece en el selector con indicador de no disponible
   Y no puede seleccionarse para agregar al carrito
   Y las variantes activas siguen funcionando con normalidad

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (las órdenes existentes conservan la
  referencia a la variante en el snapshot del OrderItem; el cambio
  o desactivación de la variante no afecta a las órdenes pasadas)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 600ms para el guardado
  de la configuración completa de variantes)
- **Notas:** El efecto de los cambios es inmediato porque FR-CHT-01.02
  lee las variantes activas del repositorio en cada carga de la ficha
  del producto, sin cache de larga duración.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT-03: Gestionar Variantes (Admin)
   * - **Requerido por**
     - FR-CHT-01.02 (las variantes configuradas aquí son las que
       se presentan al visitante)
   * - **Relacionado con**
     - FR-CHT-04.02 (el precio diferenciado de cada variante
       se configura desde este mismo flujo)
   * - **Test**
     - TST-FR-CHT-03.02 (pendiente — verificar que la desactivación
       hace la variante no seleccionable pero visible; verificar que
       una variante con órdenes activas no puede eliminarse pero sí
       desactivarse)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — detalles de implementación expuestos,
       secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: unicidad, orden de presentación, desactivación
       vs eliminación, EX-02 protección de órdenes, 4 escenarios BDD

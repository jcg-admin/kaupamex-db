.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-new-04-enviar-campana-newsletter
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-new-04-02-encolar-campana-newsletter
   fr-new-04-enviar-campana-newsletter-01

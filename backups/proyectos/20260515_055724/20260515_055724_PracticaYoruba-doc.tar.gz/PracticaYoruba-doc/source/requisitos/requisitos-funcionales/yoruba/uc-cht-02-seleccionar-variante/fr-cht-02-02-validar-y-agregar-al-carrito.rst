.. meta::
   :artefacto: FR-CHT-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cht-02-02:

==================================================================================
FR-CHT-02.02: Validar la selección de variante y agregar al carrito con precio
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-02.02
   * - **Nombre**
     - Verificar que el visitante seleccionó una variante, validar el
       stock y el precio de esa variante en el servidor, y agregar el
       item al carrito con la referencia a la variante y su precio vigente
   * - **UC Origen**
     - UC-CHT-02: Seleccionar Variante y Agregar al Carrito
   * - **Paso UC**
     - Pasos 2, 3, 4, 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-003 CHARTSIZE + MOD-005 CART
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validación + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el visitante seleccionó una variante
   antes de agregar, validar en el servidor que esa variante tiene
   stock disponible y que su precio es el vigente, y agregar el
   item al carrito con la referencia específica a la variante y el
   precio validado CUANDO el visitante solicita agregar el producto.

**Descripcion:**

El flujo de validación ocurre íntegramente en el servidor. El precio
que el visitante vio en pantalla (calculado en el cliente por
FR-CHT-01.02) se descarta; el sistema obtiene el precio vigente
de la variante directamente del repositorio al momento de agregar.
Esto evita que una manipulación del cliente resulte en un precio
incorrecto en el carrito.

Las validaciones se ejecutan en este orden:

1. **Variante seleccionada.** Si el visitante intentó agregar sin
   elegir variante (Alt. B), el sistema rechaza la acción con un
   mensaje que le indica que debe seleccionar primero. No se accede
   al inventario ni al precio hasta que haya una variante elegida.

2. **Stock disponible (paso 3).** El sistema consulta el stock actual
   de esa variante específica. Si el stock cayó a cero entre que el
   visitante cargó la ficha y el momento en que hizo clic (EX-01),
   el sistema lo informa con el mensaje de variante no disponible.
   El carrito no se modifica.

3. **Precio vigente (paso 4).** El sistema obtiene el precio de la
   variante del repositorio. Si la variante tiene precio diferenciado
   configurado, ese es el precio que se registra en el carrito. Si
   no, se usa el precio base del producto.

4. **Registro en el carrito (paso 5).** El item se registra en el
   carrito con la identificación del producto, la identificación de
   la variante, el nombre de la variante, el precio validado y la
   cantidad indicada por el visitante. Esto garantiza que al revisar
   el carrito (FR-CAT-02.03) el sistema consulta el stock de la
   variante correcta.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Variante con stock agregada con precio validado en servidor
   DADO visitante que selecciona la variante "Grande" del producto
   "Sopera de Yemoja" que tiene stock=5 y precio diferenciado=$1200
   CUANDO hace clic en agregar al carrito
   ENTONCES el item en el carrito identifica la variante "Grande"
   Y el precio registrado en el carrito es $1200 (obtenido del servidor)
   Y el carrito muestra "Sopera de Yemoja — Grande" con precio $1200

   Escenario 2: Intento sin variante seleccionada — error claro (Alt. B)
   DADO visitante que hace clic en agregar sin elegir ninguna variante
   CUANDO el sistema verifica la selección
   ENTONCES HTTP 400 con {"codigo_error": "VARIANTE_NO_SELECCIONADA",
   "mensaje": "Selecciona una presentación antes de agregar al carrito."}
   Y el selector de variantes se resalta visualmente en la interfaz

   Escenario 3: Variante agotada entre la vista y el clic (EX-01)
   DADO variante "Mediana" que tenía stock cuando el visitante cargó
   la ficha pero fue comprada por otro usuario antes de que este
   hiciera clic en agregar
   CUANDO el sistema verifica el stock en tiempo real
   ENTONCES HTTP 409 con {"codigo_error": "VARIANTE_SIN_STOCK",
   "mensaje": "La presentación Mediana ya no está disponible.
   Elige otra presentación."}
   Y el carrito no se modifica

   Escenario 4: Cambio de variante de un item ya en el carrito (Alt. C)
   DADO comprador que tiene "Sopera — Grande" en el carrito y quiere
   cambiarlo a "Sopera — Mediana"
   CUANDO selecciona la variante Mediana y solicita el cambio
   ENTONCES el item en el carrito se actualiza a la variante Mediana
   Y el precio del carrito refleja el precio de Mediana
   Y el sistema verifica el stock de Mediana antes de confirmar el cambio

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 300ms para la validación
  completa y el registro en el carrito), RNF-SEC-003 (el precio de
  la variante siempre se obtiene del servidor; el precio que el
  cliente envía en la petición se descarta)
- **Notas:** La validación de stock es de solo lectura en este punto.
  El stock no se decrementa al agregar al carrito; el decremento
  real ocurre en el checkout (FR-ORD-01.02). La verificación en
  tiempo real al agregar es una comprobación de disponibilidad, no
  una reserva.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT-02: Seleccionar Variante y Agregar al Carrito
   * - **Depende de**
     - FR-CHT-01.02 (las variantes disponibles fueron presentadas
       al visitante antes de la selección)
   * - **Requerido por**
     - FR-CART-02.03 (la verificación de disponibilidad del carrito
       consulta el stock por variante específica)
   * - **Test**
     - TST-FR-CHT-02.02 (pendiente — verificar que el precio del
       cliente se descarta y se usa el del repositorio; verificar
       que el stock de la variante incorrecta no se consulta)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — detalles de implementación expuestos,
       secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: validación en servidor, precio del cliente
       descartado, cuatro validaciones en orden, Alt. B y C, EX-01
       de race condition, 4 escenarios BDD

.. meta::
   :artefacto: FR-CAT-09.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-09.02: Validar campos e imagenes y persistir el nuevo producto
=====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-09.02
   * - **Nombre**
     - Validar los datos del nuevo producto, procesar imagenes y guardar en el repositorio
   * - **UC Origen**
     - UC-CAT-09: Crear Producto (Admin)
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar todos los campos del producto, procesar
   las imagenes subidas y persistir el producto en el repositorio
   CUANDO el admin solicita guardar un nuevo producto.

**Descripcion:**

Campos obligatorios y sus validaciones:

.. list-table::
   :widths: 20 20 60
   :header-rows: 1

   * - Campo
     - Obligatorio
     - Validacion
   * - name
     - SI
     - 3-200 chars. No duplicado en la misma categoria.
   * - base_price
     - SI
     - Decimal > 0. Precio sin IVA (BR-001).
   * - category
     - SI
     - Debe existir y estar activa.
   * - sku
     - SI
     - Unico en todo el catalogo. Solo alfanumerico y guiones.
   * - description
     - NO
     - Max 5000 chars.
   * - images
     - NO
     - Min 1 imagen recomendada. Max 8. JPEG/PNG/WebP, max 5MB c/u.

El producto se crea con ``is_published=False`` por defecto.
El admin debe publicarlo explicitamente cuando este listo.

Tras la creacion exitosa: el sistema invalida el cache del catalogo
si habia paginas cacheadas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto creado correctamente
   DADO admin que completa todos los campos obligatorios con datos validos
   CUANDO guarda
   ENTONCES el producto existe en el repositorio con is_published=False
   Y el admin ve la ficha del producto recien creado

   Escenario 2: SKU duplicado — error especifico
   DADO admin que usa un SKU ya existente "YOR-042"
   CUANDO guarda
   ENTONCES HTTP 400 con {"detalles": {"sku": ["Este SKU ya esta en uso."]}}

   Escenario 3: Imagen invalida — datos textuales guardados igual
   DADO admin que sube una imagen con formato no soportado (.bmp)
   CUANDO intenta guardar con datos textuales validos
   ENTONCES los datos del producto se guardan
   Y HTTP 400 indica que la imagen no es valida pero el producto si
   O se puede guardar sin imagen y agregarla despues

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (base_price es sin IVA),
  BR-013 (AbstractBaseModel — created_at automatico)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-09: Crear Producto
   * - **Requerido por**
     - FR-CAT-01.02 (el producto aparecera en el catalogo tras publicarse)
   * - **RNF**
     - RNF-PROC-003 (migracion de datos — el campo SKU es unique, no destructivo)
   * - **Test**
     - TST-FR-CAT-09.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-CAT-09
   * - 1.1.0
     - 2026-05-05
     - Verificacion de nombres canonicos. Sin codigo Python. Nombres de modelos correctos.

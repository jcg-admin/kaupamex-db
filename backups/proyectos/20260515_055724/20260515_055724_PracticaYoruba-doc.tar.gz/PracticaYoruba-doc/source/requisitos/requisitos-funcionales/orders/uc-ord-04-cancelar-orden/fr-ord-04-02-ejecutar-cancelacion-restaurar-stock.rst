.. meta::
   :artefacto: FR-ORD-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-04-02:

==========================================================
FR-ORD-04.02: Ejecutar cancelacion y restaurar stock
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-04.02
   * - **Nombre**
     - Cancelar la orden, restaurar stock e iniciar reembolso si aplica
   * - **UC Origen**
     - UC-ORD-04: Cancelar orden
   * - **Paso UC**
     - Pasos 4-6 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-009 INVENTORY + MOD-007 PAYMENT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la orden a CANCELLED,
   restaurar el stock decrementado e iniciar el reembolso si
   existia un pago CUANDO la cancelacion es elegible.

**Descripcion:**

Proceso atomico (una transaccion):

1. ``Order.status = CANCELLED`` con ``cancelled_at = now()``
2. Por cada OrderItem: restaura el stock en MOD-INVENTORY
   (``StockMovement.create(CANCELLATION, +quantity)`` via UC-INV-03)
3. Si ``Order.status`` era ``PAYMENT_CONFIRMED`` y existe un ``Payment``
   aprobado: encola el proceso de reembolso en MOD-PAYMENT
4. Envia notificacion al comprador (UC-NOT via INC-03)

El reembolso se inicia de forma asincrona — la orden queda cancelada
de inmediato aunque el reembolso tarde dias en acreditarse.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO orden elegible para cancelacion
   CUANDO se ejecuta la cancelacion
   ENTONCES el estado cambia y los efectos secundarios ocurren

   Escenario 1: Cancelacion exitosa de PENDING_PAYMENT
   DADO orden en PENDING_PAYMENT (sin pago)
   CUANDO se cancela
   ENTONCES Order.status = CANCELLED
   Y el stock de cada item se restaura
   Y no se inicia reembolso (no habia pago)

   Escenario 2: Cancelacion con pago — reembolso iniciado
   DADO orden en PAYMENT_CONFIRMED con Payment aprobado
   CUANDO se cancela
   ENTONCES Order.status = CANCELLED
   Y el stock se restaura
   Y se inicia el proceso de reembolso en el gateway
   Y el comprador recibe email con el estado del reembolso

   Escenario 3: Fallo en restauracion de stock
   DADO error al restaurar el stock durante la cancelacion
   CUANDO falla la transaccion
   ENTONCES rollback: la orden no cambia de estado
   Y el sistema registra el error para revision manual

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (la restauracion usa las cantidades del
  OrderItem, que son inmutables — snapshot del checkout)
- **RNF:** RNF-PROC-002 (auditoria), RNF-AVAIL-002 (idempotencia)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-04: Cancelar orden
   * - **Depende de**
     - FR-ORD-04.01 (elegibilidad verificada)
   * - **Requerido por**
     - FR-PAY-07.01 (reembolso si habia pago)
   * - **BR**
     - BR-005
   * - **RNF**
     - RNF-PROC-002, RNF-AVAIL-002
   * - **Test**
     - TST-FR-ORD-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-04

.. meta::
   :artefacto: FR-AUTH-03.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-03-04:

================================================================
FR-AUTH-03.04: Confirmar el cierre y redirigir al area publica
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.04
   * - **Nombre**
     - Retornar 200, eliminar estado del cliente y redirigir al catalogo
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - Pasos 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (respuesta del endpoint + logica del cliente)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE confirmar el cierre de sesion, instruir al cliente
   para limpiar su estado y retornar la respuesta CUANDO la invalidacion
   del token y la auditoria han sido procesadas.

**Descripcion:**

Respuesta del servidor:

.. code-block:: http

   HTTP/1.1 200 OK
   Content-Type: application/json

   {
     "mensaje": "Sesion cerrada exitosamente.",
     "redirect": "/catalogo/"
   }

Acciones que el **cliente** debe ejecutar al recibir el 200:

1. Eliminar el access token de memoria (si estaba en memoria)
2. Eliminar el refresh token de donde este almacenado
3. Limpiar cualquier dato del usuario del store (Redux, Pinia, etc.)
4. Redirigir al usuario a la URL del campo ``redirect``
   (``/catalogo/`` por defecto)

El servidor no puede forzar la limpieza del cliente — es responsabilidad
del frontend. Si el frontend no limpia los tokens, el access token
seguira siendo valido por sus 15 minutos restantes (limitacion de JWT).
Sin embargo, el refresh token ya fue invalidado, por lo que no podra
obtener nuevos access tokens.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Logout exitoso — respuesta y redireccion
   DADO logout procesado correctamente
   CUANDO el servidor retorna la respuesta
   ENTONCES HTTP 200 con mensaje de exito y URL de redireccion
   Y el cliente elimina los tokens de su almacenamiento
   Y el usuario es redirigido a /catalogo/

   Escenario 2: Un clic sin confirmacion adicional
   DADO usuario que hace clic en el boton "Cerrar sesion"
   CUANDO se procesa el logout
   ENTONCES el logout ocurre sin pedir confirmacion adicional
   Y el usuario no ve dialogo de "¿Estas seguro?"
   (RNF de usabilidad: sin friccion innecesaria)

   Escenario 3: Acceso a endpoint protegido tras logout
   DADO usuario que hizo logout exitoso
   CUANDO intenta acceder a GET /api/v1/auth/profile/
   ENTONCES recibe HTTP 401 Unauthorized
   (el access token puede seguir siendo valido 15 min — limitacion JWT
   pero no puede renovarse porque el refresh esta en blacklist)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-USAB-001 (confirmacion visible sin friccion),
  RNF-SEC-001 (el refresh token invalidado impide la renovacion)
- **Notas:** La redireccion al catalogo puede configurarse. Si el usuario
  esta en el admin panel, redirige al login de admin. El campo ``redirect``
  en la respuesta permite que el frontend use la URL correcta.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Depende de**
     - FR-AUTH-03.03 (auditoria registrada)
   * - **Requerido por**
     - Ninguno — es el ultimo paso del flujo de logout
   * - **Test**
     - TST-FR-AUTH-03.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 6, 7 y 8 de UC-AUTH-03

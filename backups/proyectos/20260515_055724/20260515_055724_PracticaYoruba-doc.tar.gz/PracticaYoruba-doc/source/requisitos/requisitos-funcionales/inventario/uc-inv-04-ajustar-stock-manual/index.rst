.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inv-04-ajustar-stock-manual
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inv-04-02-ajustar-con-auditoria
   fr-inv-04-ajustar-stock-manual-01

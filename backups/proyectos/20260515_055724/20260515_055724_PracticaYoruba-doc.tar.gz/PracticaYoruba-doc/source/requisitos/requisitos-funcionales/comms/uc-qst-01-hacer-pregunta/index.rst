.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-qst-01-hacer-pregunta
===================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-qst-01-02-validar-y-registrar-pregunta
   fr-qst-01-hacer-pregunta-01

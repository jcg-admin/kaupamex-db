.. meta::
   :artefacto: FR-LOG-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-05-01:

FR-LOG-05.01: Confirmar entrega y actualizar estados
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-05.01
   * - **Nombre**
     - Confirmar entrega y actualizar estados
   * - **UC Origen**
     - UC-LOG 05 CONFIRMAR ENTREGA
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE marcar la orden como DELIVERED y habilitar la resena CUANDO se confirma la entrega.

**Descripcion:**

``Order.status = DELIVERED``
``ShipmentGuide.status = DELIVERED``
``ShipmentGuide.delivered_at = fecha_entrega``

La entrega puede confirmarse por:

- Webhook automatico del courier (FR-LOG-04.01)
- Confirmacion manual del admin en UC-LOG-05

Tras confirmar: el comprador puede dejar una resena (UC-REV-01).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Confirmacion automatica via webhook
   DADO webhook de entrega del courier
   CUANDO se procesa
   ENTONCES Order.status=DELIVERED, ShipmentGuide.delivered_at=fecha del courier

   Escenario: Confirmacion manual con fecha retroactiva
   DADO admin que confirma entrega ocurrida hace 2 dias
   CUANDO ingresa la fecha correcta
   ENTONCES delivered_at = fecha ingresada por el admin
   Y created_at del registro sigue siendo hoy


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** La fecha de entrega del courier y la fecha de registro pueden diferir. Ambas se guardan.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 05 CONFIRMAR ENTREGA
   * - **Depende de**
     - ShipmentGuide creada
   * - **Requerido por**
     - FR-REV-01.01 (resena habilitada tras entrega)
   * - **Test**
     - TST-FR-LOG-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 05 CONFIRMAR ENTREGA

.. meta::
   :artefacto: FR-WISH-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-WISH-02.02: Mostrar la lista con precios actuales e indicador de precio reducido
====================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-02.02
   * - **Nombre**
     - Recuperar los items de la lista con precio actual y disponibilidad, destacando bajadas de precio
   * - **UC Origen**
     - UC-WISH-02: Ver Lista de Deseos
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-011 WISHLIST
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista de deseos del comprador con el
   precio actual de cada producto, la disponibilidad en stock y un
   indicador cuando el precio bajo desde que fue agregado.

**Descripcion:**

**Descripcion:**

El sistema recupera todos los ``WishlistItem`` del usuario con carga
anticipada del ``Product`` y la variante, ordenados por
``-WishlistItem.created_at``. Para cada item calcula: el precio
actual (``Product.base_price``), si bajó respecto al
``WishlistItem.price_at_add``, el porcentaje de reducción si aplica,
y la disponibilidad (``IN_STOCK`` si el producto tiene stock en alguna
variante, ``OUT_OF_STOCK`` en caso contrario).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto con precio reducido desde que se agrego
   DADO item agregado cuando el precio era 1000 y ahora cuesta 850
   CUANDO el comprador ve la lista
   ENTONCES price_dropped=true y price_drop_pct=15.0
   Y el frontend muestra la etiqueta de precio reducido

   Escenario 2: Producto sin stock — indicado claramente
   DADO producto que se agoto
   CUANDO aparece en la lista
   ENTONCES availability=OUT_OF_STOCK
   Y el boton de agregar al carrito esta deshabilitado

   Escenario 3: Lista vacia — estado vacio
   DADO comprador sin items en la lista
   CUANDO accede
   ENTONCES HTTP 200 con items=[] y sugerencia de navegar el catalogo

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (solo items del usuario autenticado)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH-02: Ver Lista de Deseos
   * - **Test**
     - TST-FR-WISH-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-WISH-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

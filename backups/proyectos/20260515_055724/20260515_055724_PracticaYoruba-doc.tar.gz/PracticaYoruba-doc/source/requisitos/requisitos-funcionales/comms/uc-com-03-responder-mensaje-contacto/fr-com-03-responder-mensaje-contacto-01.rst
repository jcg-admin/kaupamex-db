.. meta::
   :artefacto: FR-COM-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-com-03-01:

FR-COM-03.01: Responder mensaje y cerrarlo
==========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-03.01
   * - **Nombre**
     - Responder mensaje y cerrarlo
   * - **UC Origen**
     - UC-COM 03 RESPONDER MENSAJE CONTACTO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-014 CONTACT via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar la respuesta por email y cerrar el mensaje CUANDO el admin responde.

**Descripcion:**

``Contact.status = RESPONDIDO``
``Contact.response = texto_respuesta``
Envia el texto por email al remitente via UC-INC-03.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Respuesta enviada exitosamente
   DADO admin que escribe la respuesta al mensaje de 'juan@example.com'
   CUANDO envía
   ENTONCES el email llega al visitante y Contact.status=RESPONDIDO

   Escenario: Email del remitente invalido
   DADO mensaje con email invalido
   CUANDO se intenta responder
   ENTONCES advertencia de email posiblemente invalido pero se permite enviar


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El admin puede editar el borrador de la respuesta antes de enviar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM 03 RESPONDER MENSAJE CONTACTO
   * - **Depende de**
     - FR-COM-02.01 (mensaje identificado)
   * - **Requerido por**
     - Ninguno — fin del flujo
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-COM-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-COM 03 RESPONDER MENSAJE CONTACTO

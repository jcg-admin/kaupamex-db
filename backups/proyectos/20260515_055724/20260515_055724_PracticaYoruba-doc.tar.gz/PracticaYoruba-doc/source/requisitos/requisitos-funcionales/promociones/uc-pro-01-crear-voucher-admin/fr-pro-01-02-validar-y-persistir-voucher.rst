.. meta::
   :artefacto: FR-PRO-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PRO-01.02: Validar unicidad del codigo y persistir el voucher activo
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-01.02
   * - **Nombre**
     - Verificar que el codigo es unico y crear el Voucher con el tipo poliformico correcto
   * - **UC Origen**
     - UC-PRO-01: Crear Voucher (Admin)
   * - **Paso UC**
     - Pasos 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el codigo del voucher es unico,
   crear el Voucher con el tipo correcto y confirmarlo como listo
   para uso CUANDO el admin guarda el nuevo voucher.

**Descripcion:**

El código del voucher es insensible a mayúsculas para el usuario
pero se almacena en mayúsculas.

El sistema normaliza el código a mayúsculas y verifica que no exista
otro ``Voucher`` con el mismo código (insensible a mayúsculas) →
``CODIGO_DUPLICADO``. Valida la coherencia del tipo y valor:
``PERCENTAGE`` requiere ``discount_value`` entre 0 y 100 exclusivos →
``PORCENTAJE_INVALIDO``; ``FIXED`` requiere ``discount_value > 0`` →
``MONTO_INVALIDO``. Si pasa las validaciones, crea el ``Voucher``
con ``is_active = True`` y la referencia al administrador creador.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Voucher de porcentaje creado
   DADO admin que crea BIENVENIDO20 de 20% con vigencia de 30 dias
   CUANDO guarda
   ENTONCES Voucher activo listo para UC-CART-04
   Y el codigo se almacena como "BIENVENIDO20" (mayusculas)

   Escenario 2: Codigo duplicado — error claro
   DADO codigo BIENVENIDO20 que ya existe
   CUANDO el admin intenta crear otro con el mismo codigo
   ENTONCES HTTP 409 con CODIGO_DUPLICADO

   Escenario 3: Voucher de envio gratis — sin monto de descuento
   DADO admin que crea voucher FREE_SHIPPING
   CUANDO guarda
   ENTONCES discount_value = 0 (no aplica)
   Y en checkout: el costo de envio se reduce a 0 con este voucher

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-008 (Voucher poliformico con Strategy Pattern —
  PERCENTAGE, FIXED y FREE_SHIPPING)
- **RNF aplicables:** RNF-PROC-002 (created_by para auditoria)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO-01: Crear Voucher
   * - **Requerido por**
     - FR-CART-04.03 (el voucher se valida en el carrito)
   * - **Test**
     - TST-FR-PRO-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-5 de UC-PRO-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

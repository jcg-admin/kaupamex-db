.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inc-03-enviar-email-con-plantilla
===============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inc-03-02-renderizar-y-encolar-email
   fr-inc-03-enviar-email-con-plantilla-01

.. meta::
   :artefacto: FR-AUTH-01.01
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-01-01:

================================================
FR-AUTH-01.01: Presentar formulario de registro
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-01.01
   * - **Nombre**
     - Presentar formulario de registro de nueva cuenta
   * - **UC Origen**
     - UC-AUTH-01: Registrar cuenta
   * - **Paso UC**
     - Paso 1 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE presentar el formulario de registro con todos sus
   campos CUANDO el visitante navega a la pagina de registro.

**Descripcion:**

El formulario incluye exactamente los siguientes campos:

- ``username`` — obligatorio, maximo 150 caracteres, solo letras, numeros
  y los simbolos ``@``, ``+``, ``-``, ``_``, ``.``
- ``email`` — obligatorio, formato email valido
- ``password`` — obligatorio, minimo 8 caracteres
- ``password_confirm`` — obligatorio, debe coincidir con ``password``

Ademas del formulario, la pagina presenta:

- Enlace a la pagina de inicio de sesion (UC-AUTH-02)
- Enlace a los Terminos y Condiciones (pagina estatica)
- Indicador de fortaleza de contrasena en tiempo real

----

3. Criterio de Aceptacion
--------------------------

::

   DADO un visitante no autenticado
   CUANDO navega a /registro/
   ENTONCES ve el formulario con los 4 campos obligatorios

   Escenario 1: Campos visibles y vacios
   DADO la pagina de registro recien cargada
   CUANDO se inspeccionan los campos
   ENTONCES username, email, password y password_confirm estan vacios
   Y cada campo tiene su label y placeholder correspondiente

   Escenario 2: Indicador de fortaleza
   DADO el campo password visible
   CUANDO el visitante escribe su contrasena
   ENTONCES el indicador muestra la fortaleza en tiempo real
   Y cambia de rojo a amarillo a verde segun la complejidad

   Escenario 3: Comprador ya autenticado
   DADO un comprador con sesion activa
   CUANDO intenta acceder a /registro/
   ENTONCES el sistema redirige al inicio (no muestra el formulario)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — todo modelo tiene ID)
- **Notas:** El formulario es la vista publica de mayor conversion.
  No solicitar informacion innecesaria en este paso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-01: Registrar cuenta
   * - **Depende de**
     - Ninguno (es el primer paso)
   * - **Requerido por**
     - FR-AUTH-01.02 (validar campos)
   * - **Test**
     - TST-FR-AUTH-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-01

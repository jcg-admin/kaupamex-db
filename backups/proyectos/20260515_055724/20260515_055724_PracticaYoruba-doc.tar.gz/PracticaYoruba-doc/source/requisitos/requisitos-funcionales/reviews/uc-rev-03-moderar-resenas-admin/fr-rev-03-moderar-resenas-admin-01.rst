.. meta::
   :artefacto: FR-REV-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rev-03-01:

FR-REV-03.01: Moderar resena — aprobar o rechazar
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-03.01
   * - **Nombre**
     - Moderar resena — aprobar o rechazar
   * - **UC Origen**
     - UC-REV 03 MODERAR RESENAS ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la resena CUANDO el admin la modera.

**Descripcion:**

Acciones posibles:

- **APROBAR**: ``Review.status=APPROVED`` — la resena aparece en UC-REV-02
- **RECHAZAR**: ``Review.status=REJECTED`` con ``rejected_reason`` obligatorio

Tras aprobar: el promedio de calificacion del producto se recalcula.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Aprobacion de resena legitima
   DADO resena con contenido apropiado
   CUANDO el admin aprueba
   ENTONCES aparece en la ficha del producto
   Y el promedio del producto se actualiza

   Escenario: Rechazo con motivo
   DADO resena con contenido inapropiado
   CUANDO el admin rechaza con motivo 'Contenido ofensivo'
   ENTONCES Review.status=REJECTED
   Y el comprador puede ser notificado del rechazo


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El promedio se recalcula con AVG(rating) sobre resenas APPROVED.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV 03 MODERAR RESENAS ADMIN
   * - **Depende de**
     - FR-REV-01.01 (resena creada en PENDING)
   * - **Requerido por**
     - FR-REV-02.01 (resena visible tras aprobar)
   * - **Test**
     - TST-FR-REV-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-REV 03 MODERAR RESENAS ADMIN

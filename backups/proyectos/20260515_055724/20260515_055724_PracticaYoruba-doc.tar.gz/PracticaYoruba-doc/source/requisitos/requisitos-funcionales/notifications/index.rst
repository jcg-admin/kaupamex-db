.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — NOTIFICATIONS
=======================================

**7 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-not-01-email-confirmacion-orden
     - 1
   * - uc-not-02-email-estado-orden
     - 1
   * - uc-not-03-email-actualizacion-envio
     - 1
   * - uc-not-04-email-devolucion-procesada
     - 1
   * - uc-not-05-email-reembolso
     - 1
   * - uc-not-06-preferencias-notificacion
     - 1
   * - uc-not-07-notificacion-manual-admin
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-not-01-email-confirmacion-orden/index
   uc-not-02-email-estado-orden/index
   uc-not-03-email-actualizacion-envio/index
   uc-not-04-email-devolucion-procesada/index
   uc-not-05-email-reembolso/index
   uc-not-06-preferencias-notificacion/index
   uc-not-07-notificacion-manual-admin/index

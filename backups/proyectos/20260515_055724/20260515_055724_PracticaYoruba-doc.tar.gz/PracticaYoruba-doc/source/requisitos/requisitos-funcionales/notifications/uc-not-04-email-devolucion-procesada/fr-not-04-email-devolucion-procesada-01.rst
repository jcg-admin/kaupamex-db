.. meta::
   :artefacto: FR-NOT-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-04-01:

FR-NOT-04.01: Enviar email de resultado de devolucion
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-04.01
   * - **Nombre**
     - Enviar email de resultado de devolucion
   * - **UC Origen**
     - UC-NOT 04 EMAIL DEVOLUCION PROCESADA
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE notificar al comprador del resultado de su devolucion CUANDO el admin decide.

**Descripcion:**

Plantillas segun la decision:

- Aprobada: plantilla ``devolucion_aprobada`` con instrucciones de envio del producto
- Rechazada: plantilla ``devolucion_rechazada`` con el motivo del rechazo
- Informacion requerida: plantilla ``devolucion_info_requerida``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email de devolucion aprobada
   DADO decision de admin: APROBAR
   CUANDO se notifica
   ENTONCES el comprador recibe email con instrucciones para enviar el producto devuelto

   Escenario: Email de devolucion rechazada
   DADO decision de admin: RECHAZAR con motivo
   CUANDO se notifica
   ENTONCES el email incluye el motivo y opciones de contacto para aclarar


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El email de aprobacion incluye el numero de guia de devolucion si el negocio lo proporciona.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 04 EMAIL DEVOLUCION PROCESADA
   * - **Depende de**
     - FR-RET-02.01 (decision del admin)
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 04 EMAIL DEVOLUCION PROCESADA

.. meta::
   :artefacto: FR-AUTH-02.09
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-09:

====================================================
FR-AUTH-02.09: Verificar que el email fue confirmado
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.09
   * - **Nombre**
     - Verificar que la cuenta del usuario tiene el email confirmado
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 12 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el usuario tiene el email confirmado
   CUANDO el identificador fue encontrado en el repositorio.

**Descripcion:**

La verificacion comprueba el campo ``User.is_active``.

Un usuario con ``is_active = False`` NO puede iniciar sesion,
independientemente de si la contraseña es correcta.
Este estado se establece al registrarse (FR-AUTH-01.04) y se cambia
a ``True`` cuando el usuario verifica su email (FR-AUTH-10.01).

Si el email NO ha sido confirmado (``is_active = False``):

1. El sistema retorna HTTP 401 con un mensaje DIFERENCIADO
   (a diferencia del caso de credenciales incorrectas, aqui SI se
   informa de la verificacion pendiente — el usuario ya existe y lo sabe)
2. El mensaje incluye la opcion de reenviar el email de verificacion
3. El contador de intentos fallidos NO incrementa (no es un intento
   malicioso sino un usuario legitimamente registrado)
4. Se registra en auditoria con tipo ``FALLO_EMAIL_NO_VERIFICADO``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email confirmado — continua el flujo
   DADO usuario con is_active = True
   CUANDO se verifica en el paso 12
   ENTONCES la verificacion pasa
   Y el proceso continua a FR-AUTH-02.10 (verificar cuenta activa)

   Escenario 2: Email NO confirmado — mensaje especifico
   DADO usuario recien registrado con is_active = False
   CUANDO intenta iniciar sesion
   ENTONCES respuesta HTTP 401 con:
   {"codigo_error": "EMAIL_NO_VERIFICADO",
    "mensaje": "Debes confirmar tu email antes de iniciar sesion.",
    "accion": "reenviar_verificacion",
    "url": "/api/v1/auth/resend-verification/"}
   Y el contador de intentos de la IP NO incrementa

   Escenario 3: Diferencia en el mensaje vs credenciales invalidas
   DADO usuario con email no verificado comparado con usuario inexistente
   CUANDO ambos intentan iniciar sesion
   ENTONCES el primer caso retorna EMAIL_NO_VERIFICADO (mas descriptivo)
   Y el segundo caso retorna CREDENCIALES_INVALIDAS (generico)
   Esta diferencia de mensajes es deliberada: el usuario registrado
   merece saber por que no puede entrar y como resolverlo

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **Notas:** La razon por la que aqui SI se diferencia el mensaje es
  que el usuario ya demostro que existe (fue encontrado en el
  repositorio). Darle una pista aqui no ayuda a un atacante a enumerar
  usuarios — el atacante ya sabe que el usuario existe desde el paso 11.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.08 (usuario encontrado en el repositorio)
   * - **Requerido por**
     - FR-AUTH-02.10 (verificar que la cuenta esta activa)
   * - **Relacionado con**
     - FR-AUTH-10.01 (el que activa is_active al verificar el email)
   * - **Test**
     - TST-FR-AUTH-02.09 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 12 de UC-AUTH-02

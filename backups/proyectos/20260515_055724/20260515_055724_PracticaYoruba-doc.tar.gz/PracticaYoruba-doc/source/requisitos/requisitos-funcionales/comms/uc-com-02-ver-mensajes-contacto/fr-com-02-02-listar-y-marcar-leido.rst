.. meta::
   :artefacto: FR-COM-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-04-30
   :fecha_actualizacion: 2026-05-03

.. _fr-com-02-02:

================================================================
FR-COM-02.02: Listar mensajes con filtros y marcar como leido
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-02.02
   * - **Nombre**
     - Retornar la bandeja de contacto paginada con filtros y marcar automaticamente como LEIDO al abrir
   * - **UC Origen**
     - UC-COM-02: Ver Mensajes de Contacto
   * - **Paso UC**
     - Pasos 2, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-014 CONTACT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la bandeja de mensajes de contacto
   paginada con filtros por estado y ordenamiento configurable,
   y marcar automaticamente el mensaje como LEIDO al acceder
   a su detalle CUANDO el admin lo solicita.

**Descripcion:**

**Listado de la bandeja (paso 2 y Alt. C):**

El listado acepta los siguientes parámetros opcionales, todos
acumulables:

- **Filtro por estado:** ``UNREAD``, ``READ`` o ``REPLIED``. Si se omite,
  devuelve todos los mensajes sin distinción de estado.
- **Filtro por fecha:** fecha de inicio y fecha de fin para acotar el
  rango. Ambos son independientes — se puede usar solo uno.
- **Ordenamiento:** por fecha descendente de forma predeterminada.
  El admin puede cambiar a fecha ascendente, por estado o por urgencia.

La respuesta siempre incluye el contador global de mensajes sin leer,
independientemente del filtro activo. Esto permite que el panel del
admin muestre la insignia de pendientes sin necesitar un segundo
endpoint exclusivo para ese dato.

**Detalle y marcado como leido (pasos 5 y 6):**

Cuando el admin accede al detalle de un mensaje, el sistema lo marca
automáticamente como ``READ`` si su estado era ``UNREAD``. La operación
es idempotente: si el admin abre el mismo mensaje más de una vez, solo
el primer acceso actualiza el estado; los siguientes no generan ninguna
escritura adicional.

El detalle incluye los archivos adjuntos si el visitante los acompañó
al enviar el formulario (Alt. C de UC-COM-01), presentados como
referencias al Servicio de Archivos donde están almacenados.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Bandeja con mensajes y contador de sin leer
   DADO 12 mensajes en total: 7 UNREAD, 3 READ, 2 REPLIED
   CUANDO GET /api/v1/admin/contact/
   ENTONCES HTTP 200 con los 12 mensajes paginados (20 por pagina)
   Y la respuesta incluye {"unread_count": 7}
   Y los mensajes estan ordenados del mas reciente al mas antiguo

   Escenario 2: Filtro por estado UNREAD
   DADO la misma bandeja de 12 mensajes
   CUANDO GET /api/v1/admin/contact/?status=UNREAD
   ENTONCES HTTP 200 con solo los 7 mensajes sin leer

   Escenario 3: Admin abre un mensaje — se marca como READ
   DADO mensaje con id=42 en estado UNREAD
   CUANDO GET /api/v1/admin/contact/42/
   ENTONCES HTTP 200 con el detalle completo del mensaje
   Y ContactMessage.status = READ y read_at = timestamp del acceso
   Y el contador unread_count se reduce en 1 en el proximo listado

   Escenario 4: Admin abre el mismo mensaje por segunda vez — idempotente
   DADO mensaje id=42 que ya esta en estado READ
   CUANDO GET /api/v1/admin/contact/42/
   ENTONCES HTTP 200 con el detalle del mensaje
   Y el status sigue siendo READ (sin escritura adicional)
   Y read_at no cambia

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms para el listado
  incluyendo el conteo de sin leer), RNF-SEC-003 (el endpoint
  requiere permisos de staff — ``IsAdminUser`` en DRF)
- **Notas:** El email del remitente solo es visible en la vista de
  detalle del admin. En el listado se muestra solo el nombre y el
  asunto.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM-02: Ver Mensajes de Contacto
   * - **Depende de**
     - FR-COM-01.02 (los mensajes existen en el repositorio)
   * - **Requerido por**
     - FR-COM-03.02 (el admin responde desde el detalle del mensaje)
   * - **Test**
     - TST-FR-COM-02.02 (pendiente — verificar idempotencia del
       marcado: dos GET consecutivos al mismo mensaje no duplican
       la escritura de read_at)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial
   * - 1.2.0
     - 2026-05-03
     - Eliminado código Python real; descripción reemplazada
       por prosa estructurada conforme al estándar de documentación

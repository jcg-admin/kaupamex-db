.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ret-01-solicitar-devolucion
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ret-01-02-validar-y-registrar-solicitud
   fr-ret-01-solicitar-devolucion-01

.. meta::
   :artefacto: FR-AUTH-02.10
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-10:

=================================================
FR-AUTH-02.10: Verificar que la cuenta esta activa
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.10
   * - **Nombre**
     - Verificar que la cuenta del usuario no esta suspendida
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 13 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la cuenta no esta suspendida
   ni en un estado que impida el acceso CUANDO el email
   del usuario ya fue confirmado.

**Descripcion:**

Esta verificacion distingue el campo ``is_active`` usado para
verificacion de email del estado de suspension del admin.

En el MVP, ambos estados se mapean al mismo campo ``User.is_active``,
pero la logica de negocio es diferente:

- ``is_active = False`` por registro sin verificar → FR-AUTH-02.09
- ``is_active = False`` por suspension del admin → este FR

Para distinguirlos, el sistema verifica si el usuario tiene
``email_verified_at`` (un campo de auditoria):

- Si ``is_active = False`` Y ``email_verified_at`` es NULL:
  el email no fue verificado → FR-AUTH-02.09 lo manejo primero
- Si ``is_active = False`` Y ``email_verified_at`` NO es NULL:
  la cuenta fue suspendida despues de verificarse → CUENTA_INACTIVA

Si la cuenta esta suspendida:

1. HTTP 401 con ``codigo_error: CUENTA_INACTIVA``
2. El mensaje informa del estado e incluye el contacto de soporte
3. El contador de intentos NO incrementa
4. Auditoria con tipo ``FALLO_CUENTA_INACTIVA``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cuenta activa — continua el flujo
   DADO usuario con cuenta activa y email verificado
   CUANDO se verifica el estado en el paso 13
   ENTONCES la verificacion pasa
   Y el proceso continua a FR-AUTH-02.02 (comparar contraseña)

   Escenario 2: Cuenta suspendida por admin
   DADO usuario con is_active=False y email_verified_at con fecha
   CUANDO intenta iniciar sesion
   ENTONCES HTTP 401 con {"codigo_error": "CUENTA_INACTIVA",
   "mensaje": "Tu cuenta esta suspendida. Contacta al soporte.",
   "soporte_email": "soporte@ojayoruba.com"}
   Y el contador de intentos NO incrementa

   Escenario 3: Consistencia entre verificaciones
   DADO usuario con email no verificado (is_active=False, email_verified=NULL)
   CUANDO llega al paso 13 (que no deberia porque el 12 lo detiene)
   ENTONCES el paso 13 actua como segunda linea de defensa
   Y retorna el mismo mensaje de EMAIL_NO_VERIFICADO del paso 12

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La suspension de cuentas es una operacion del admin
  que se realiza fuera del flujo normal de UC-AUTH-02. Este FR
  solo verifica el estado, no lo modifica.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.09 (email confirmado verificado)
   * - **Requerido por**
     - FR-AUTH-02.02 (comparar la contraseña con la almacenada)
   * - **Test**
     - TST-FR-AUTH-02.10 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 13 de UC-AUTH-02

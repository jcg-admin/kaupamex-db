.. meta::
   :artefacto: FR-CART-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-04-01:

==============================================
FR-CART-04.01: Validar el codigo de voucher
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-04.01
   * - **Nombre**
     - Verificar existencia, estado y elegibilidad del voucher
   * - **UC Origen**
     - UC-CART-04: Aplicar cupon de descuento
   * - **Paso UC**
     - Pasos 2-3 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER (apps.voucher)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el codigo ingresado contra todas las
   reglas del voucher CUANDO el actor lo aplica al carrito.

**Descripcion:**

Validaciones en orden secuencial (falla en la primera que no pasa):

1. El codigo existe en el sistema (case-insensitive)
2. ``Voucher.is_active = True``
3. La fecha actual esta dentro de ``[valid_from, valid_until]``
4. ``Voucher.uses_count < Voucher.max_uses`` (si max_uses no es null)
5. Si ``restricted_to_email`` tiene valor: el actor autenticado
   tiene ese email
6. El subtotal del carrito supera ``Voucher.min_order_value``

Cada validacion fallida retorna un codigo de error especifico para
que el frontend pueda mostrar el mensaje apropiado.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO actor con carrito activo que ingresa un codigo
   CUANDO se valida el voucher
   ENTONCES cada regla se verifica en orden

   Escenario 1: Codigo inexistente
   DADO codigo "NOEEXISTE123"
   CUANDO se valida
   ENTONCES error 404: VOUCHER_NO_ENCONTRADO

   Escenario 2: Voucher expirado
   DADO voucher con valid_until hace 3 dias
   CUANDO se valida
   ENTONCES error 422: VOUCHER_EXPIRADO

   Escenario 3: Usos agotados
   DADO voucher con max_uses = 100 y uses_count = 100
   CUANDO se valida
   ENTONCES error 422: VOUCHER_AGOTADO

   Escenario 4: Voucher personalizado para otro email
   DADO voucher con restricted_to_email = "otro@email.com"
   Y comprador autenticado con email diferente
   CUANDO se valida
   ENTONCES error 422: VOUCHER_NO_DISPONIBLE (mensaje generico)

   Escenario 5: Monto minimo no alcanzado
   DADO voucher con min_order_value = 200 y subtotal = 150
   CUANDO se valida
   ENTONCES error 422: MONTO_MINIMO_NO_ALCANZADO
   Y el mensaje indica que faltan $50 para poder usarlo

   Escenario 6: Voucher valido en todo
   DADO voucher que pasa todas las validaciones
   CUANDO se valida
   ENTONCES proceso continua a FR-CART-04.02

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-012 (un solo descuento por producto — si
  el producto ya tiene descuento de ProductDiscount, el voucher
  puede o no acumularse segun configuracion)
- **Notas:** El codigo se normaliza a MAYUSCULAS antes de buscar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-04: Aplicar cupon de descuento
   * - **Depende de**
     - FR-CART-02.01 (carrito activo recuperado)
   * - **Requerido por**
     - FR-CART-04.02 (aplicar el descuento al carrito)
   * - **BR**
     - BR-012
   * - **Test**
     - TST-FR-CART-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-04

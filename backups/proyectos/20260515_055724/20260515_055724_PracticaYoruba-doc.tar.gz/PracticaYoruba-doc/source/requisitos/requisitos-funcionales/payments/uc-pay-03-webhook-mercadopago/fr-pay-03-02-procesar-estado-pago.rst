.. meta::
   :artefacto: FR-PAY-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-03-02:

FR-PAY-03.02: Procesar estado del pago e idempotencia
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-03.02
   * - **Nombre**
     - Procesar estado del pago e idempotencia
   * - **UC Origen**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Paso UC**
     - Pasos 3-5
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el estado del pago de forma idempotente CUANDO la firma del webhook es valida.

**Descripcion:**

Proceso idempotente:

1. Extrae ``data.id`` (gateway_payment_id) del payload JSON
2. ``Payment.objects.get_or_create(gateway_payment_id=id, gateway=MERCADOPAGO)``
3. Si el Payment ya tiene el mismo status que el webhook: retorna 200 sin cambios (idempotencia)
4. Si el estado cambia a ``approved``:

   - ``Payment.status = APPROVED``
   - ``Order.status = PAYMENT_CONFIRMED``
   - Encola ``fr-not-01`` (email confirmacion de orden)
   - ``StockMovement`` ya ocurrio en checkout — no se vuelve a decrementar

5. Si el estado es ``rejected`` o ``cancelled``: ``Payment.status = FAILED``
6. Guarda ``raw_response = payload`` para debugging

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Pago aprobado — primera vez
   DADO webhook con status=approved para gateway_payment_id nuevo
   CUANDO se procesa
   ENTONCES Payment.status = APPROVED
   Y Order.status = PAYMENT_CONFIRMED
   Y se envia email de confirmacion al comprador

   Escenario: Webhook duplicado — idempotencia
   DADO webhook con el mismo gateway_payment_id ya procesado
   CUANDO llega de nuevo
   ENTONCES respuesta 200 sin modificar nada
   Y el estado de la orden no cambia

   Escenario: Pago rechazado
   DADO webhook con status=rejected
   CUANDO se procesa
   ENTONCES Payment.status = FAILED
   Y Order permanece en PENDING_PAYMENT
   Y el comprador puede reintentar el pago (UC-PAY-08)


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002 (idempotencia de webhooks)`
- **Notas:** El campo ``gateway_payment_id`` tiene ``unique=True`` en BD, garantia de nivel de base de datos contra duplicados.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Depende de**
     - FR-PAY-03.01 (firma verificada)
   * - **Requerido por**
     - FR-NOT-01.01 (email de confirmacion si pago aprobado)
   * - **Test**
     - TST-FR-PAY-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-03

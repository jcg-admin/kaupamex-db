.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-05-confirmar-entrega
======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-05-02-confirmar-entrega-y-notificar
   fr-log-05-confirmar-entrega-01

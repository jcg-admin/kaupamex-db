.. meta::
   :artefacto: FR-PAY-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-03-01:

FR-PAY-03.01: Verificar firma del webhook de MP
===============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-03.01
   * - **Nombre**
     - Verificar firma del webhook de MP
   * - **UC Origen**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Seguridad

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la firma criptografica del webhook CUANDO Mercado Pago envia una notificacion de pago.

**Descripcion:**

MP firma cada notificacion con HMAC-SHA256 usando el ``client_secret``.

Proceso de verificacion:

1. Lee el header ``x-signature`` del request
2. Extrae ``ts`` (timestamp) y ``v1`` (hash) del header
3. Construye el string a verificar: ``id:{payment_id};request-id:{request_id};ts:{ts}``
4. Calcula ``HMAC-SHA256(secret_key, string)``
5. Compara con ``v1`` del header (comparacion de tiempo constante para prevenir timing attacks)
6. Si no coincide: retorna 401 sin procesar el evento

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Firma valida
   DADO webhook con x-signature correcto
   CUANDO se verifica
   ENTONCES la firma es valida
   Y el proceso continua a FR-PAY-03.02

   Escenario: Firma invalida — webhook fraudulento
   DADO webhook sin x-signature o con hash incorrecto
   CUANDO se verifica
   ENTONCES respuesta 401
   Y el evento NO se procesa
   Y se registra el intento fallido con la IP origen


----

4. Reglas y Restricciones
--------------------------

- **BR-009 (credenciales solo en el servidor)**

- :ref:`RNF-SEC-005 (firma de webhooks)`
- **Notas:** La comparacion de firmas usa ``comparacion_en_tiempo_constante`` (tiempo constante) para prevenir ataques de timing.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-03: Webhook Mercado Pago
   * - **Depende de**
     - Llamada entrante del gateway MP
   * - **Requerido por**
     - FR-PAY-03.02 (procesar el estado del pago)
   * - **Test**
     - TST-FR-PAY-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-03

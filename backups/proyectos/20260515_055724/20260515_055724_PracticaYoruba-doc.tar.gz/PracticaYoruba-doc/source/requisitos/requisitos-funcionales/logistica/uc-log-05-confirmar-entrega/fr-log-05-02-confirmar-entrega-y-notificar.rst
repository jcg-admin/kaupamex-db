.. meta::
   :artefacto: FR-LOG-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-05.02: Confirmar entrega manual y transicionar la orden a DELIVERED
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-05.02
   * - **Nombre**
     - El admin confirma la entrega cuando el courier no tiene webhook, actualiza estados
   * - **UC Origen**
     - UC-LOG-05: Confirmar Entrega (Admin)
   * - **Paso UC**
     - Pasos 3, 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar la guia a DELIVERED, transicionar la
   orden a DELIVERED y notificar al comprador CUANDO el admin
   confirma manualmente la entrega.

**Descripcion:**

La confirmación manual es necesaria cuando el courier no tiene
webhook integrado (couriers locales o nuevos proveedores).

En una transacción atómica: el sistema establece
``ShipmentGuide.status = 'DELIVERED'``, registra
``ShipmentGuide.delivered_at`` con la fecha proporcionada o el
momento actual, y almacena la referencia al administrador en
``ShipmentGuide.confirmed_by``. Crea un ``ShipmentEvent`` con
estado ``'DELIVERED'`` y descripción que identifica la confirmación
manual. Actualiza ``Order.status = 'DELIVERED'`` y encola la
notificación al comprador de forma asíncrona.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Entrega confirmada manualmente
   DADO guia en SHIPPED de un courier sin webhook
   CUANDO el admin confirma la entrega
   ENTONCES ShipmentGuide.status = DELIVERED y Order.status = DELIVERED
   Y ShipmentEvent creado con la descripcion de confirmacion manual
   Y notificacion al comprador encolada (con opcion de dejar resena)

   Escenario 2: Guia ya marcada como entregada — error
   DADO guia que ya tiene status=DELIVERED
   CUANDO el admin intenta confirmar de nuevo
   ENTONCES HTTP 400 con "Esta guia ya fue marcada como entregada."

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria — confirmed_by registra
  quien confirmo la entrega y cuando)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-05: Confirmar Entrega
   * - **Depende de**
     - FR-LOG-01.02 (la guia existe en estado SHIPPED)
   * - **Test**
     - TST-FR-LOG-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-7 de UC-LOG-05
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

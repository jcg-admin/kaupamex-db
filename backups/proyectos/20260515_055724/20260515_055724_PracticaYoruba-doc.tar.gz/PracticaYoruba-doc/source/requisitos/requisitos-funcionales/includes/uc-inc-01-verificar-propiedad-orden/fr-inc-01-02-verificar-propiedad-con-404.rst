.. meta::
   :artefacto: FR-INC-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INC-01.02: Verificar propiedad retornando 404 para no revelar existencia
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-01.02
   * - **Nombre**
     - Verificar que la orden pertenece al usuario autenticado retornando 404 si no coincide
   * - **UC Origen**
     - UC-INC-01: Verificar Propiedad de Orden (included)
   * - **Paso UC**
     - Pasos 1, 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Validacion (reutilizable)

----

2. Especificacion
-----------------

**Declaracion:**

   El include DEBE verificar que la orden especificada pertenece al
   usuario autenticado y retornar 404 si no coincide o no existe,
   sin revelar si la orden existe para otro usuario.

**Descripcion:**

Este include es reutilizado por FR-ORD-02.02, FR-LOG-03.02,
FR-PAY-05.02, FR-RET-01.02, FR-WISH-03.02 y otros.

El patrón de implementación es siempre el mismo: el sistema busca
la ``Order`` filtrando simultáneamente por el identificador recibido
(clave primaria entera o ``Order.order_number`` alfanumérico) y
``Order.user = user``. Si no existe ningún registro que cumpla ambas
condiciones, lanza HTTP 404. El HTTP 404 es intencional — nunca HTTP
403 — porque si un atacante intenta acceder a la orden de otro
usuario, recibe el mismo error que si la orden no existiera, lo que
previene la enumeración de órdenes (RNF-SEC-003).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Orden propia — retornada exitosamente
   DADO usuario A que solicita su orden ORD-001
   CUANDO el include verifica la propiedad
   ENTONCES la orden es retornada al UC incluidor

   Escenario 2: Orden de otro usuario — 404
   DADO usuario B que solicita la orden ORD-001 de usuario A
   CUANDO el include verifica la propiedad
   ENTONCES Http404 — identico a si la orden no existiera

   Escenario 3: Orden inexistente — 404
   DADO numero de orden que no existe en la BD
   CUANDO el include verifica
   ENTONCES Http404 — identico al escenario 2

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — 404 nunca 403)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC-01: Verificar Propiedad de Orden
   * - **Incluido por**
     - FR-ORD-02.02, FR-LOG-03.02, FR-PAY-05.02, FR-RET-01.02,
       FR-WISH-03.02, FR-LOG-07.02, FR-RET-04.02
   * - **Test**
     - TST-FR-INC-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 1-4 de UC-INC-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-INV-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INV-02.02: Verificar si el stock cae bajo umbral tras el decremento y alertar
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-02.02
   * - **Nombre**
     - Post-decremento: verificar si el stock cae bajo el umbral minimo y encolar alerta
   * - **UC Origen**
     - UC-INV-02: Decrementar Stock
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar si el stock resultante del decremento
   cae bajo el umbral minimo y encolar la alerta al admin CUANDO el
   decremento ha sido ejecutado.

**Descripcion:**

Este paso ocurre DESPUÉS del decremento atómico (FR-ORD-01.02).

Si el nuevo ``ProductVariant.stock`` es menor o igual a
``SiteSettings.min_stock_threshold``, el sistema verifica si ya existe
un ``StockAlert`` para ese producto y variante creado en las últimas
24 horas. Si no existe, crea un nuevo ``StockAlert`` con el stock
actual y encola la notificación asíncrona al administrador. La
deduplicación de 24 horas evita inundar al admin con alertas cuando
el producto se vende rápidamente en ráfagas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Stock cae bajo umbral — alerta enviada una vez
   DADO producto con stock=6 que se vende (qty=2) con umbral=5
   CUANDO stock queda en 4 (< 5)
   ENTONCES se crea StockAlert y se encola la notificacion al admin
   Y si el mismo producto se vende de nuevo en las proximas 24h,
   NO se envia otra alerta (deduplicacion)

   Escenario 2: Stock sigue sobre umbral — sin alerta
   DADO producto con stock=20 que se vende (qty=2) con umbral=5
   CUANDO stock queda en 18
   ENTONCES no se crea ninguna alerta

----

4. Reglas y Restricciones
--------------------------

- **Relacionado con:** UC-SYS-03 (notificar stock minimo) que ejecuta
  el mismo tipo de alerta como proceso periodico

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV-02: Decrementar Stock
   * - **Depende de**
     - FR-ORD-01.02 (decremento ya ejecutado)
   * - **Test**
     - TST-FR-INV-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 5 de UC-INV-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-CART-03.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-03-03:

=============================================================
FR-CART-03.03: Presentar el carrito actualizado o el estado vacio
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-03.03
   * - **Nombre**
     - Retornar el carrito con los items restantes o la vista de carrito vacio
   * - **UC Origen**
     - UC-CART-03: Eliminar Item del Carrito
   * - **Paso UC**
     - Pasos 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el carrito actualizado con los items
   restantes o el estado de carrito vacio con acceso al catalogo
   CUANDO el item ha sido eliminado.

**Descripcion:**

El endpoint ``DELETE /api/v1/cart/items/{item_key}/`` retorna
siempre HTTP 200 (no 204) porque necesita devolver el estado
actualizado del carrito para que el frontend pueda actualizar la UI
sin hacer una segunda llamada.

**Caso con items restantes (paso 5):**

.. code-block:: json

   {
     "estado": "con_items",
     "items": [
       {
         "key": "product_42",
         "product_id": 42,
         "name": "Sopera de Yemoja",
         "quantity": 2,
         "unit_price": 850.00,
         "subtotal": 1700.00
       }
     ],
     "subtotal": 1700.00,
     "items_count": 1
   }

**Caso de carrito vacio (paso 6 / Alt. C):**

.. code-block:: json

   {
     "estado": "vacio",
     "items": [],
     "subtotal": 0.00,
     "items_count": 0,
     "cta": {
       "label": "Ir al catalogo",
       "url": "/catalogo/"
     }
   }

El campo ``cta`` (call-to-action) solo aparece cuando el carrito
esta vacio. Orienta al visitante a seguir comprando.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Carrito con items restantes
   DADO eliminacion exitosa de 1 de 3 items
   CUANDO se retorna la respuesta
   ENTONCES estado = "con_items" con 2 items en la lista
   Y subtotal = suma de los 2 items restantes
   Y items_count = 2

   Escenario 2: Carrito vacio tras eliminar el ultimo item
   DADO eliminacion del ultimo item del carrito
   CUANDO se retorna la respuesta
   ENTONCES estado = "vacio"
   Y items = [] y subtotal = 0.00
   Y cta.url = "/catalogo/" para seguir comprando

   Escenario 3: Precios en subtotal usan precio al momento del addedd
   DADO item agregado cuando el precio era 100 y ahora el precio es 120
   CUANDO el visitante elimina y el sistema recalcula
   ENTONCES el subtotal de los items restantes usa el precio snapshoteado
   Y el precio actual del catalogo no afecta el subtotal del carrito

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion), BR-004 (sin login)
- **RNF aplicables:** RNF-USAB-001 (el CTA de ir al catalogo cuando
  el carrito esta vacio es la accion natural a seguir)
- **Notas:** El precio en el carrito es el precio al momento de agregar
  el item (snapshot). Si el precio cambia en el catalogo, el carrito
  no se actualiza automaticamente hasta el checkout.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-03: Eliminar Item del Carrito
   * - **Depende de**
     - FR-CART-03.02 (item eliminado y subtotal recalculado)
   * - **Requerido por**
     - Ninguno — ultimo paso del Sistema en UC-CART-03
   * - **Test**
     - TST-FR-CART-03.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5 y 6 de UC-CART-03

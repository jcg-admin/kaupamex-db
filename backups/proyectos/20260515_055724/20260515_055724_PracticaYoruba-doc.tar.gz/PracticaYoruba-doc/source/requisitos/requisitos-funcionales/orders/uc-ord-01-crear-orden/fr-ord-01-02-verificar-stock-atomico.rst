.. meta::
   :artefacto: FR-ORD-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-01.02: Verificar y reservar stock de forma atomica antes de crear la orden
===================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01.02
   * - **Nombre**
     - Verificar disponibilidad transaccional de todos los items y decrementar stock atomicamente
   * - **UC Origen**
     - UC-ORD-01: Crear Orden (Checkout)
   * - **Paso UC**
     - Pasos 3 y 14 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-009 INVENTORY
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la disponibilidad de stock de todos los
   items del carrito y decrementar el stock de forma atomica CUANDO
   el visitante confirma el pedido, previniendo la sobreventa.

**Descripcion:**

La verificación y el decremento ocurren en una sola transacción
atómica con bloqueo de filas (``SELECT FOR UPDATE``) para prevenir
la sobreventa:

1. **Verificación:** para cada item del carrito el sistema bloquea
   el registro ``ProductVariant`` correspondiente. Si su
   ``ProductVariant.stock`` es inferior a la cantidad solicitada,
   el item se añade a la lista de items sin stock suficiente.

2. **Decisión:** si la lista de items sin stock no está vacía, el
   sistema lanza un error de stock insuficiente. La transacción
   hace rollback completo — ningún stock cambia.

3. **Decremento:** si todos los items tienen stock suficiente, el
   sistema decrementa ``ProductVariant.stock`` en la cantidad
   solicitada para cada item mediante actualización en bloque.
   Además crea un registro ``StockMovement`` con tipo ``SALE``,
   cantidad negativa y ``reference = None`` (se actualiza con el
   ``order_id`` tras crear la orden en la misma transacción).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Todos los items con stock — decremento atomico
   DADO carrito con producto A (qty=2, stock=5) y producto B (qty=1, stock=3)
   CUANDO se ejecuta la reserva
   ENTONCES product A stock queda en 3 y product B stock en 2 (atomico)
   Y se crea StockMovement SALE para cada item
   Y el proceso continua a FR-ORD-01.03 (crear la orden)

   Escenario 2: Un item sin stock — rollback total
   DADO carrito con producto A (qty=5, stock=3) y producto B (qty=1, stock=8)
   CUANDO se ejecuta la reserva
   ENTONCES se detecta que A no tiene stock suficiente
   Y NINGUN stock cambia (rollback atomico)
   Y HTTP 409 con la lista de items con problema

   Escenario 3: Prevencion de sobreventa — dos checkouts simultaneos
   DADO dos visitantes que intenta comprar el ultimo item (stock=1)
   CUANDO ambas transacciones ejecutan select_for_update()
   ENTONCES una transaccion bloquea la fila y procede
   Y la segunda espera y detecta stock=0 tras el decremento de la primera
   Y solo una orden se crea; la segunda recibe HTTP 409

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-002 (idempotencia — si el checkout
  falla DESPUES del decremento, el stock se restaura por el rollback
  de la transaccion)
- **Notas:** El ``StockMovement`` se crea con ``reference=None``
  inicialmente. Tras crear la orden (FR-ORD-01.03), se actualiza
  con el ``order_id`` en la misma transaccion.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01: Crear Orden
   * - **Depende de**
     - FR-CART-02.03 (stock pre-verificado en la vista del carrito)
   * - **Requerido por**
     - FR-ORD-01.03 (crear los snapshots de la orden)
   * - **Relacionado con**
     - FR-INV-02.01 (mismo mecanismo de decremento de stock)
   * - **Test**
     - TST-FR-ORD-01.02 (pendiente — test de concurrencia con
       threading o signal para simular dos checkouts simultaneos)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3 y 14 de UC-ORD-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Logica SELECT FOR UPDATE, rollback y StockMovement preservada.

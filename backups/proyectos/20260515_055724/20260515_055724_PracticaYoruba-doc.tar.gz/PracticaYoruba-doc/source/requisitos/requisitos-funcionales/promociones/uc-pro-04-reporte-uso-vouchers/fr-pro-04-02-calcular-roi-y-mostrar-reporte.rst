.. meta::
   :artefacto: FR-PRO-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PRO-04.02: Calcular uso y ROI estimado de los vouchers para el admin
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-04.02
   * - **Nombre**
     - Agregar metricas de uso de vouchers y calcular el total de descuentos otorgados
   * - **UC Origen**
     - UC-PRO-04: Reporte de Uso de Vouchers
   * - **Paso UC**
     - Pasos 2 y 5 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER + MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE agregar las metricas de uso de cada voucher y
   calcular el total de descuentos otorgados CUANDO el admin accede
   al reporte de vouchers.

**Descripcion:**

**Descripcion:**

El sistema agrega métricas por ``Voucher`` para las órdenes con
``status`` en ``['DELIVERED', 'SHIPPED']``: suma de
``OrderValue.voucher_discount`` (total de descuentos otorgados),
suma de ``OrderValue.total`` (ingresos generados con ese voucher) y
conteo de órdenes. Los resultados se ordenan por
``-Voucher.current_uses``.

El ROI estimado se calcula como
``total_revenue_with_voucher / total_discount_given``.
Si es mayor a 1, el voucher genera más ingresos de los que cuesta.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reporte con metricas de uso
   DADO voucher BIENVENIDO20 usado en 15 ordenes
   CUANDO el admin accede al reporte
   ENTONCES uses=15, total_discount=descuento_total en esas ordenes
   Y se puede ver el ROI del voucher

   Escenario 2: Vouchers sin uso — en el reporte con ceros
   DADO voucher recien creado sin usos
   CUANDO aparece en el reporte
   ENTONCES uses=0, total_discount=0 (no se omite del reporte)

----

4. Reglas y Restricciones
--------------------------

- **Notas:** El reporte solo cuenta ordenes en SHIPPED y DELIVERED
  — no se incluyen ordenes canceladas o pendientes de pago.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO-04: Reporte de Uso de Vouchers
   * - **Relacionado con**
     - MOD-013 REPORTS (mismo patron de aggregacion sin modelos propios)
   * - **Test**
     - TST-FR-PRO-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2 y 5 de UC-PRO-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-INV-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INV-04.02: Ajustar stock manualmente con validacion y registro de auditoria
===============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-04.02
   * - **Nombre**
     - Validar el ajuste manual, actualizar el stock y crear StockMovement MANUAL con el motivo
   * - **UC Origen**
     - UC-INV-04: Ajustar Stock Manual (Admin)
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que el ajuste no resulta en stock negativo,
   actualizar el stock y registrar el movimiento con el admin responsable
   y el motivo CUANDO el admin realiza un ajuste manual.

**Descripcion:**

En una transacción atómica con ``SELECT FOR UPDATE`` sobre el
``ProductVariant``: calcula el nuevo stock sumando el delta al valor
actual. Si el resultado es negativo, rechaza el ajuste. En caso
contrario, actualiza ``ProductVariant.stock`` y crea un
``StockMovement`` con tipo ``'MANUAL'``, el delta (positivo = entrada,
negativo = salida), referencia ``ADMIN:<admin_user_pk>`` y el motivo
del ajuste.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Ajuste positivo — entrada de mercancia
   DADO producto con stock=10 y ajuste delta=+20 por "recepcion de proveedor"
   CUANDO el admin guarda
   ENTONCES stock = 30
   Y StockMovement MANUAL con quantity=+20 y notes="recepcion de proveedor"

   Escenario 2: Ajuste negativo que resultaria en stock negativo
   DADO producto con stock=5 y ajuste delta=-10
   CUANDO el admin intenta guardar
   ENTONCES HTTP 400 con "El ajuste resultaria en stock negativo (-5)."
   Y el stock NO cambia

   Escenario 3: Auditoria completa del ajuste
   DADO ajuste manual realizado
   CUANDO el admin revisa el historial del producto
   ENTONCES StockMovement.reference = "ADMIN:{admin_pk}"
   Y el motivo del ajuste esta en StockMovement.notes

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria — quien, cuando y por que)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV-04: Ajustar Stock Manual
   * - **Test**
     - TST-FR-INV-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-6 de UC-INV-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

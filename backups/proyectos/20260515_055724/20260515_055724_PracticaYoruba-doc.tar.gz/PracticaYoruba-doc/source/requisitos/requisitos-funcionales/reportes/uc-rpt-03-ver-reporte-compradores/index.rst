.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rpt-03-ver-reporte-compradores
============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rpt-03-02-calcular-metricas-compradores
   fr-rpt-03-ver-reporte-compradores-01

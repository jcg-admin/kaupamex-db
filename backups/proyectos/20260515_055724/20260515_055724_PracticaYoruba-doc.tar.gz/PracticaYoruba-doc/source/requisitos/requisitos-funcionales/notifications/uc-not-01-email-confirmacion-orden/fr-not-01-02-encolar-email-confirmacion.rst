.. meta::
   :artefacto: FR-NOT-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-01-02:

=============================================================================
FR-NOT-01.02: Generar y encolar el email de confirmación de orden
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-01.02
   * - **Nombre**
     - Recuperar los datos de la orden, verificar preferencias, renderizar
       la plantilla de confirmación y encolar el email de forma asíncrona
   * - **UC Origen**
     - UC-NOT-01: Email de Confirmación de Orden
   * - **Paso UC**
     - Pasos 2 al 11 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El Sistema de Notificaciones DEBE recuperar los datos completos de
   la orden, verificar que el comprador acepta este tipo de email,
   renderizar la plantilla de confirmación y encolar el mensaje de
   forma asíncrona sin bloquear el flujo de creación de la orden
   CUANDO recibe el evento ``orden_creada``.

**Descripcion:**

Este UC es disparado por el evento que emite el Servicio de Órdenes
tras crear la orden exitosamente. El Sistema de Notificaciones actúa
de forma completamente independiente: la creación de la orden
(FR-ORD-01.03) no espera el resultado de este proceso.

La secuencia de acciones que ejecuta el Sistema de Notificaciones es:

1. **Recuperar datos completos de la orden.** Número de orden,
   nombre del comprador, lista de items con nombre, cantidad y precio
   unitario, subtotal, descuentos aplicados, IVA, costo de envío,
   total, dirección de entrega y método de envío seleccionado.

2. **Verificar email y preferencias.** Si el comprador no tiene email
   válido o ha desactivado las notificaciones de confirmación de
   orden (FR-NOT-06.02), el proceso termina aquí sin registrar
   ningún error. La orden no se ve afectada.

3. **Obtener la plantilla.** El Sistema de Notificaciones consulta
   primero el Servicio de Cache. Si la plantilla está disponible,
   la usa directamente; si no, la recupera del repositorio y la
   almacena en cache para los siguientes envíos.

4. **Renderizar el contenido.** La plantilla produce dos versiones:
   HTML con el diseño completo del email y texto plano como
   alternativa para clientes de correo que no admiten HTML. El
   contenido incluye un saludo personalizado con el nombre del
   comprador, el número de orden destacado, el desglose completo
   de precios y un enlace directo al detalle de la orden.

5. **Registrar el envío como pendiente.** Antes de encolar, el sistema
   crea el registro en el repositorio de notificaciones con estado
   ``PENDING`` para que el fallo pueda detectarse si el Procesador
   Asíncrono no lo procesa en el tiempo esperado.

6. **Encolar para envío asíncrono.** El mensaje se entrega al
   Procesador Asíncrono, que lo enviará al Servicio de Email Externo.
   Si el envío es aceptado, el estado del registro pasa a ``SENT``.
   Si falla, el Procesador reintenta con espera progresiva hasta
   agotar el número de intentos configurado, momento en que el estado
   pasa a ``FAILED`` para revisión del admin.

**Alt. C — Reenvío a petición del comprador o del admin:**

Si el comprador declara no haber recibido el email, puede solicitar
un reenvío desde el detalle de su orden. El sistema genera un nuevo
envío sin crear una nueva orden. Para prevenir el abuso, el sistema
limita a tres los reenvíos por orden en un período de 24 horas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email encolado correctamente tras crear la orden
   DADO orden ORD-20260504-00087 creada para "Carlos Méndez"
   con 2 items, total de $1824.80
   CUANDO el evento orden_creada llega al Sistema de Notificaciones
   ENTONCES el registro en el repositorio de notificaciones tiene
   status=PENDING con el contenido HTML y texto plano renderizados
   Y el Procesador Asíncrono lo procesa en menos de 30 segundos
   Y Carlos recibe el email con el número de orden destacado
   y el desglose de precios

   Escenario 2: Comprador sin email válido — proceso termina silenciosamente
   DADO orden de un comprador con email rebotado en registros previos
   CUANDO el Sistema de Notificaciones verifica el email en el paso 2
   ENTONCES no se crea ningún registro en el repositorio de notificaciones
   Y la orden sigue su flujo normal sin ningún error

   Escenario 3: Fallo en el Servicio de Email — reintento con espera progresiva
   DADO Servicio de Email Externo que rechaza el mensaje temporalmente
   CUANDO el Procesador Asíncrono detecta el fallo
   ENTONCES reintenta con espera progresiva hasta el número máximo
   de intentos configurado
   Y si agota los intentos, el registro queda con status=FAILED
   Y el admin puede ver los envíos fallidos en el panel

   Escenario 4: Reenvío solicitado por el comprador
   DADO comprador que no recibió el email de la orden ORD-20260504-00087
   CUANDO solicita el reenvío desde el detalle de su orden
   ENTONCES se crea un nuevo registro de envío sin modificar la orden
   Y si ya se hicieron 3 reenvíos en las últimas 24 horas
   el sistema rechaza la solicitud con un mensaje claro

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-002 (P95 <= 30 segundos desde el
  evento hasta que el email llega al Servicio de Email Externo),
  RNF-AVAIL-003 (el Procesador Asíncrono reintenta con espera
  progresiva — gestionado por FR-SYS-04.02)
- **Notas:** El proceso es completamente asíncrono. El Servicio de
  Órdenes emite el evento y continúa; no espera ninguna confirmación
  del Sistema de Notificaciones. Un fallo en el email nunca revierte
  ni bloquea la orden.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-01: Email de Confirmación de Orden
   * - **Disparado por**
     - FR-ORD-01.03 (la orden es creada con snapshots inmutables)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla)
   * - **Relacionado con**
     - FR-NOT-06.02 (preferencias del comprador que pueden suprimir
       el envío)
   * - **Relacionado con**
     - FR-SYS-04.02 (gestión de reintentos con espera progresiva
       para los envíos fallidos)
   * - **Test**
     - TST-FR-NOT-01.02 (pendiente — verificar que la creación de
       la orden no espera el resultado del email; verificar que el
       fallo del email no revierte la orden; verificar el límite
       de 3 reenvíos en 24 horas)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: 6 pasos del flujo en prosa, plantilla
       con cache, Alt. C de reenvío con límite de 3 por 24h,
       EX-02, 4 escenarios BDD con datos concretos

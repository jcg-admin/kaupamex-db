.. meta::
   :artefacto: FR-ORD-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-06.02: Cambiar metodo de envio y recalcular el total de la orden
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-06.02
   * - **Nombre**
     - Actualizar el costo de envio y el total de la orden cuando cambia el metodo de envio
   * - **UC Origen**
     - UC-ORD-06: Cambiar Metodo de Envio
   * - **Paso UC**
     - Pasos 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-008 LOGISTICS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el metodo de envio, recalcular el
   costo y actualizar el total de la orden CUANDO el usuario cambia
   el metodo de envio antes del envio.

**Descripcion:**

Solo posible en estados PENDING_PAYMENT, PAYMENT_CONFIRMED o
IN_PREPARATION (antes de crear la guia de envio).

El sistema recupera el ``ShippingMethod`` activo solicitado,
actualiza ``OrderValue.shipping_cost`` con su coste y recalcula
``OrderValue.total = OrderValue.subtotal_neto + OrderValue.iva_amount + ShippingMethod.cost``.
Persiste ``OrderValue`` con los nuevos valores y actualiza
``Order.shipping_method`` con la referencia al nuevo método.

Si el nuevo total es mayor que el pago ya realizado (raro),
se requiere un pago adicional — flujo gestionado por soporte.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cambio de express a estandar — total reducido
   DADO orden con envio express ($150) en estado PENDING_PAYMENT
   CUANDO el usuario cambia a envio estandar ($50)
   ENTONCES OrderValue.shipping_cost = 50
   Y OrderValue.total se reduce en 100
   Y el usuario ve el nuevo total en la ficha de la orden

   Escenario 2: Orden SHIPPED — sin cambio posible
   DADO orden ya enviada
   CUANDO el usuario intenta cambiar el metodo
   ENTONCES HTTP 400 con METODO_NO_EDITABLE

----

4. Reglas y Restricciones
--------------------------

- **Notas:** El costo de envio es parte del OrderValue (snapshot).
  Este es el unico campo del snapshot que se puede modificar antes
  del envio, ya que el metodo de envio es una decision del usuario
  pre-logistica.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-06: Cambiar Metodo de Envio
   * - **Test**
     - TST-FR-ORD-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-4 de UC-ORD-06

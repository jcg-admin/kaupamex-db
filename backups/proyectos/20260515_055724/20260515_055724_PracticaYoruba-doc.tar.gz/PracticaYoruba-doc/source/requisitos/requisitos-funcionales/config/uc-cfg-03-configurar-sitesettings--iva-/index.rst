.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cfg-03-configurar-sitesettings--iva-
==================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cfg-03-02-actualizar-parametros-globales
   fr-cfg-03-configurar-sitesettings--iva--01

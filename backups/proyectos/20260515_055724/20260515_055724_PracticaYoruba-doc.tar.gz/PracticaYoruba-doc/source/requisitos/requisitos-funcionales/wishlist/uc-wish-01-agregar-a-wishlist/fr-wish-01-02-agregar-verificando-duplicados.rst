.. meta::
   :artefacto: FR-WISH-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-WISH-01.02: Agregar producto a la lista verificando duplicados
=================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-01.02
   * - **Nombre**
     - Crear WishlistItem verificando que el producto no esta ya en la lista
   * - **UC Origen**
     - UC-WISH-01: Agregar a Lista de Deseos
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-011 WISHLIST
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el producto no esta ya en la lista
   del comprador y agregar el WishlistItem con la fecha de adicion
   CUANDO el comprador autenticado lo solicita.

**Descripcion:**

**Descripcion:**

El sistema verifica si ya existe un ``WishlistItem`` del usuario para
el mismo ``product_id`` y ``variant_id``. Si existe, retorna el item
existente sin crear uno nuevo (idempotente). Si no existe, crea un
nuevo ``WishlistItem`` con el ``User``, el ``product_id``, el
``variant_id`` y ``price_at_add = Product.base_price`` en el momento
de la adición. Este campo permite mostrar si el precio ha bajado
desde que se agregó a la lista.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto agregado exitosamente
   DADO comprador que agrega "Sopera de Yemoja" a su lista
   CUANDO POST /api/v1/wishlist/
   ENTONCES WishlistItem creado con price_at_add=precio_actual
   Y HTTP 201 con el item creado

   Escenario 2: Producto ya en la lista — idempotente
   DADO comprador que intenta agregar un producto ya en su lista
   CUANDO POST de nuevo
   ENTONCES HTTP 200 (no 201, no error) con el item existente

   Escenario 3: Visitante no autenticado — redirige al login
   DADO visitante anonimo que intenta agregar
   CUANDO el sistema verifica la autenticacion
   ENTONCES HTTP 401 con redirect al login

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (cada usuario solo ve su propia lista)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH-01: Agregar a Lista de Deseos
   * - **Test**
     - TST-FR-WISH-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-WISH-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

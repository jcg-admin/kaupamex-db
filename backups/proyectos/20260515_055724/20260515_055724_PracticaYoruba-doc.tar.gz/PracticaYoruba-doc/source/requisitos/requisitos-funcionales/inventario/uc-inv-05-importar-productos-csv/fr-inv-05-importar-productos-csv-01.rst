.. meta::
   :artefacto: FR-INV-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inv-05-01:

FR-INV-05.01: Importar y validar productos desde CSV
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-05.01
   * - **Nombre**
     - Importar y validar productos desde CSV
   * - **UC Origen**
     - UC-INV 05 IMPORTAR PRODUCTOS CSV
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE procesar cada fila del CSV y crear o actualizar productos CUANDO el admin importa.

**Descripcion:**

Formato del CSV (encabezado obligatorio):
``sku,nombre,descripcion,precio,categoria_id,stock_inicial``

Proceso fila por fila:

1. Valida el formato de los campos
2. Si el sku ya existe: actualiza el producto (precio, descripcion)
3. Si el sku no existe: crea el producto con stock_inicial
4. Cada error de fila se registra en el reporte sin detener el proceso

Al finalizar: retorna {creados, actualizados, fallidos, url_reporte_csv}

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Importacion exitosa
   DADO CSV con 100 filas validas
   CUANDO se importa
   ENTONCES 100 productos creados o actualizados
   Y reporte: {creados:100, actualizados:0, fallidos:0}

   Escenario: CSV con errores parciales
   DADO CSV con 95 filas validas y 5 con precio invalido
   CUANDO se importa
   ENTONCES 95 productos procesados y 5 errores en el reporte
   Y el reporte CSV descargable identifica las 5 filas con el error

   Escenario: Encabezado incorrecto
   DADO CSV con columnas en orden diferente
   CUANDO se valida el encabezado
   ENTONCES error 422: ENCABEZADO_CSV_INVALIDO con el formato esperado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** La importacion es tolerante a fallos por fila — un error no detiene el procesamiento de las demas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV 05 IMPORTAR PRODUCTOS CSV
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-INV-01.01 (el inventario refleja el stock importado)
   * - **Test**
     - TST-FR-INV-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INV 05 IMPORTAR PRODUCTOS CSV

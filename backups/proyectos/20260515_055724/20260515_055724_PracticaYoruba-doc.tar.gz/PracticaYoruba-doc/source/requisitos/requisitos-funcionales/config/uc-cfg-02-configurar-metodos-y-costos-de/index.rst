.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cfg-02-configurar-metodos-y-costos-de
===================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cfg-02-02-crud-metodos-envio
   fr-cfg-02-configurar-metodos-y-costos-de-01

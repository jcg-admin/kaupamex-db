.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-new-01-suscribirse
================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-new-01-02-registrar-suscripcion-con-confirmacion
   fr-new-01-suscribirse-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — CATALOGO
==================================

**12 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-cat-01-ver-catalogo
     - 1
   * - uc-cat-02-ver-detalle
     - 1
   * - uc-cat-03-buscar-productos
     - 1
   * - uc-cat-03-ext-buscar-filtros-avanzados
     - 1
   * - uc-cat-04-filtrar-por-categoria
     - 1
   * - uc-cat-05-filtrar-por-precio
     - 1
   * - uc-cat-06-gestionar-categorias-admin
     - 1
   * - uc-cat-07-ver-productos-relacionados
     - 1
   * - uc-cat-08-listar-categorias
     - 1
   * - uc-cat-09-crear-producto-admin
     - 1
   * - uc-cat-10-editar-producto-admin
     - 1
   * - uc-cat-11-desactivar-producto-admin
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-cat-01-ver-catalogo/index
   uc-cat-02-ver-detalle/index
   uc-cat-03-buscar-productos/index
   uc-cat-03-ext-buscar-filtros-avanzados/index
   uc-cat-04-filtrar-por-categoria/index
   uc-cat-05-filtrar-por-precio/index
   uc-cat-06-gestionar-categorias-admin/index
   uc-cat-07-ver-productos-relacionados/index
   uc-cat-08-listar-categorias/index
   uc-cat-09-crear-producto-admin/index
   uc-cat-10-editar-producto-admin/index
   uc-cat-11-desactivar-producto-admin/index

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — ORDERS
================================

**13 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-ord-01-crear-orden
     - 3
   * - uc-ord-01-ext-checkout-express
     - 1
   * - uc-ord-02-ver-detalle-orden
     - 1
   * - uc-ord-03-listar-ordenes
     - 1
   * - uc-ord-04-cancelar-orden
     - 2
   * - uc-ord-05-editar-direccion-orden
     - 1
   * - uc-ord-06-cambiar-metodo-envio
     - 1
   * - uc-ord-07-procesar-orden-admin
     - 1
   * - uc-ord-08-cancelar-orden-admin
     - 1
   * - uc-ord-09-buscar-orden-admin
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-ord-01-crear-orden/index
   uc-ord-01-ext-checkout-express/index
   uc-ord-02-ver-detalle-orden/index
   uc-ord-03-listar-ordenes/index
   uc-ord-04-cancelar-orden/index
   uc-ord-05-editar-direccion-orden/index
   uc-ord-06-cambiar-metodo-envio/index
   uc-ord-07-procesar-orden-admin/index
   uc-ord-08-cancelar-orden-admin/index
   uc-ord-09-buscar-orden-admin/index

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-wish-01-agregar-a-wishlist
========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-wish-01-02-agregar-verificando-duplicados
   fr-wish-01-agregar-a-wishlist-01

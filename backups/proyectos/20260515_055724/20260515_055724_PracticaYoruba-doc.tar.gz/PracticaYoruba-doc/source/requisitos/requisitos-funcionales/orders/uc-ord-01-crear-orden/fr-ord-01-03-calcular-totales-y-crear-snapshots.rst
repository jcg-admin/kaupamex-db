.. meta::
   :artefacto: FR-ORD-01.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-01.03: Calcular totales y crear los snapshots inmutables de la orden
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01.03
   * - **Nombre**
     - Calcular subtotal, IVA, descuentos y crear Order, OrderItems, OrderAddress, OrderValue
   * - **UC Origen**
     - UC-ORD-01: Crear Orden (Checkout)
   * - **Paso UC**
     - Pasos 10, 15, 16 y 17 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular el desglose completo de precios y crear
   los modelos de snapshot inmutables de la orden de forma atomica
   CUANDO el stock ha sido reservado exitosamente.

**Descripcion:**

**Calculo de totales (paso 10):**

Todos los cálculos siguen la fórmula de BR-002:

- ``subtotal_bruto``: suma de ``unit_price × quantity`` para cada item
  del carrito.
- ``product_discount``: suma de los descuentos de producto aplicados
  por DASHBOARD (MOD-018) a cada item.
- ``voucher_discount``: importe calculado del cupón almacenado en
  ``session['cart_voucher']``, o cero si no hay cupón activo.
- ``subtotal_neto = subtotal_bruto − product_discount − voucher_discount``.
- ``iva_amount = subtotal_neto × SiteSettings.iva_rate``, redondeado
  a dos decimales.
- ``shipping_cost``: coste del método de envío seleccionado.
- ``total = subtotal_neto + iva_amount + shipping_cost``.

**Creacion de snapshots (pasos 15 y 16) en una sola transaccion:**

En una transacción atómica el sistema crea cuatro registros:

- ``Order``: con referencia al ``User`` (nula si es invitado, BR-011),
  ``guest_email`` si aplica, estado ``PENDING_PAYMENT``, número de
  orden generado (formato ``ORD-YYYYMMDD-NNNNN``), y el código y
  descuento del voucher si estaba aplicado.
- ``OrderItem`` por cada item del carrito: snapshot de
  ``product_name``, ``variant_name``, ``unit_price`` y ``quantity``
  al momento del checkout (BR-005). El precio queda inmutable aunque
  el producto cambie de precio en el futuro.
- ``OrderAddress``: snapshot completo de los campos de la dirección
  de envío (BR-005).
- ``OrderValue``: snapshot de todos los valores calculados —
  ``subtotal_bruto``, ``product_discount``, ``voucher_discount``,
  ``subtotal_neto``, ``iva_rate``, ``iva_amount``,
  ``shipping_cost`` y ``total`` (BR-005).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Orden creada con snapshot inmutable
   DADO checkout con producto a $850 (qty=2), voucher 10%, IVA 16%, envio $50
   CUANDO se crea la orden
   ENTONCES subtotal_bruto = 1700, voucher_discount = 170,
   subtotal_neto = 1530, iva_amount = 244.80, total = 1824.80
   Y OrderItem.unit_price = 850 (snapshot inmutable)
   Y si el precio del producto sube manana, el OrderItem sigue en 850

   Escenario 2: Orden de invitado (sin cuenta)
   DADO visitante que elige "continuar sin registrarse" (BR-011)
   CUANDO se crea la orden
   ENTONCES Order.user = null y Order.guest_email = email ingresado
   Y la orden puede rastrearse por numero + email

   Escenario 3: Numero de orden unico y legible
   DADO cualquier nueva orden
   CUANDO se asigna el numero
   ENTONCES tiene formato ORD-YYYYMMDD-NNNNN (ej: ORD-20260503-00042)
   Y es unico en toda la BD (campo unique en el modelo)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-002 (formula de IVA: subtotal_neto * 0.16),
  BR-005 (snapshots inmutables — OrderItem, OrderAddress, OrderValue
  no se modifican despues de creados), BR-011 (orden de invitado)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01: Crear Orden
   * - **Depende de**
     - FR-ORD-01.02 (stock reservado)
   * - **Requerido por**
     - FR-ORD-01.01 (limpiar el carrito y redirigir al pago)
   * - **BR**
     - BR-002, BR-005, BR-011
   * - **Test**
     - TST-FR-ORD-01.03 (pendiente — verificar calculos de IVA y que
       los snapshots son inmutables tras edicion del producto)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 10, 15 y 16 de UC-ORD-01

.. meta::
   :artefacto: FR-NOT-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30T00:00:00

.. _fr-not-06-01:

FR-NOT-06.01: Gestionar preferencias de notificacion
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-06.01
   * - **Nombre**
     - Gestionar preferencias de notificacion
   * - **UC Origen**
     - UC-NOT 06 PREFERENCIAS NOTIFICACION
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar las preferencias de email CUANDO el comprador las modifica.

**Descripcion:**

Preferencias disponibles:

- **Obligatorias** (no desactivables): confirmacion_orden, cambio_contrasena
- **Opcionales**: actualizacion_estado, actualizacion_envio, newsletter, ofertas

Las preferencias se almacenan en ``UserNotificationPreference``
(tabla normalizada con FK a ``User`` y ``notification_type`` como
campo con choices). Cada preferencia es una fila independiente.
Ver :doc:`/arquitectura-tecnica/modelos/modelo-accounts`.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Desactivar notificaciones de envio
   DADO comprador que desactiva las notificaciones de actualizacion de envio
   CUANDO guarda las preferencias
   ENTONCES FR-NOT-03.01 omite los emails de ese comprador

   Escenario: Intento de desactivar notificacion obligatoria
   DADO comprador que intenta desactivar email de confirmacion
   CUANDO se envia la solicitud
   ENTONCES error 422: NOTIFICACION_OBLIGATORIA_NO_DESACTIVABLE


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** Las preferencias se aplican en tiempo real — el proximo email respeta los cambios.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 06 PREFERENCIAS NOTIFICACION
   * - **Depende de**
     - FR-AUTH-02.03 (comprador autenticado)
   * - **Requerido por**
     - Todos los FR-NOT que envian emails opcionales
   * - **Test**
     - TST-FR-NOT-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 06 PREFERENCIAS NOTIFICACION

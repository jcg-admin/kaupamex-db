.. meta::
   :artefacto: FR-CFG-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cfg-03-01:

FR-CFG-03.01: Actualizar configuracion global del sistema
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-03.01
   * - **Nombre**
     - Actualizar configuracion global del sistema
   * - **UC Origen**
     - UC-CFG 03 CONFIGURAR SITESETTINGS  IVA 
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el singleton SiteSettings CUANDO el admin modifica la configuracion.

**Descripcion:**

Campos editables:

- ``iva_rate``: tasa de IVA (0 a 1, ej: 0.16 para 16%)
- ``currency``: codigo ISO de la moneda (MXN, USD)
- ``order_timeout_minutes``: tiempo hasta cancelacion automatica
- ``max_return_days``: plazo de devolucion en dias
- ``free_shipping_threshold``: monto minimo para envio gratis

Al ser un singleton: solo un registro existe. ``get()`` o ``create_defaults()``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Cambio de IVA
   DADO admin que cambia iva_rate de 0.16 a 0.08
   CUANDO guarda
   ENTONCES el catalogo muestra los nuevos precios con IVA de inmediato

   Escenario: Cambio de timeout de orden
   DADO admin que cambia order_timeout_minutes de 30 a 60
   CUANDO guarda
   ENTONCES UC-SYS-01 usa el nuevo valor para las ordenes creadas desde ese momento


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Los cambios en SiteSettings tienen efecto inmediato en todos los calculos del sistema.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG 03 CONFIGURAR SITESETTINGS  IVA 
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Todos los modulos que consumen SiteSettings
   * - **Test**
     - TST-FR-CFG-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CFG 03 CONFIGURAR SITESETTINGS  IVA

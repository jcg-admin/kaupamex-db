.. meta::
   :artefacto: FR-AUTH-09.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-09.01: Generar y enviar token de recuperacion
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.01
   * - **Nombre**
     - Generar token firmado de recuperacion y enviarlo por email
   * - **UC Origen**
     - UC-AUTH-09: Recuperar contrasena
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar un token de recuperacion y enviarlo
   al email ingresado CUANDO el visitante solicita recuperar su
   contrasena, independientemente de si el email existe o no.

**Descripcion:**

Comportamiento critico de seguridad:

1. Si el email NO existe: se retorna 200 OK igualmente (sin revelar
   que el email no esta registrado — previene enumeracion)
2. Si el email SI existe: se genera token HMAC-SHA256 con
   ``user_id + email + timestamp``, validez 1 hora
3. Se encola el envio del email con el enlace de recuperacion
4. Rate limit: maximo 3 solicitudes por email en 1 hora (BR-015)

El endpoint siempre retorna el mismo mensaje:
``"Si ese email esta registrado, recibiras las instrucciones."``

----

3. Criterio de Aceptacion
--------------------------

::

   DADO visitante que solicita recuperacion
   CUANDO envia su email al endpoint
   ENTONCES recibe la misma respuesta sin importar si existe

   Escenario 1: Email existente
   DADO email registrado en el sistema
   CUANDO se solicita recuperacion
   ENTONCES respuesta 200 con mensaje generico
   Y el email recibe el enlace en los proximos minutos

   Escenario 2: Email no existente
   DADO email que no esta en el sistema
   CUANDO se solicita recuperacion
   ENTONCES MISMA respuesta 200 con MISMO mensaje generico
   Y no se envia ningun email (silencioso)

   Escenario 3: Rate limit alcanzado
   DADO 3 solicitudes en la ultima hora para el mismo email
   CUANDO se hace la 4a solicitud
   ENTONCES error 429 con Retry-After

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting)
- **RNF:** RNF-SEC-004 (rate limiting)
- **Notas:** El token de 1 hora es deliberadamente mas largo que
  los tokens de verificacion de registro (24h vs 1h). La recuperacion
  de contrasena es urgente y el usuario puede no revisar el email
  de inmediato.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar contrasena
   * - **Depende de**
     - Ninguno (no requiere sesion activa)
   * - **Requerido por**
     - FR-AUTH-09.02 (restablecer con el token recibido)
   * - **Include**
     - UC-INC-03 (envio del email)
   * - **Test**
     - TST-FR-AUTH-09.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-09

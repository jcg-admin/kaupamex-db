.. meta::
   :artefacto: FR-SRCH-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

FR-SRCH-03.01: Registrar historial de busqueda con upsert y limite de 20 entradas
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SRCH-03.01
   * - **Nombre**
     - Upsert de SearchHistory con trim automatico a 20 entradas por usuario
   * - **UC Origen**
     - UC-SRCH-03: Guardar Historial de Busquedas
   * - **Paso UC**
     - Pasos 1, 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE (``apps.catalogue``)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar el termino de busqueda del comprador
   autenticado de forma asincrona, actualizando ``searched_at`` si
   el termino ya existe (upsert), y eliminando las entradas mas
   antiguas si el total supera 20, CUANDO se ejecuta una busqueda
   exitosa via UC-SRCH-01.

**Descripcion:**

El registro es asincrono: se lanza en un hilo separado tras retornar
la respuesta de busqueda. Si el guardado falla, el error se registra
en log pero no se propaga al visitante.

El termino se guarda tal como llego a ``ProductSearchView`` (ya
normalizado por ``_normalize_query``). Si ``(user, term)`` ya existe
en ``SearchHistory``, se actualiza ``searched_at`` (``auto_now=True``
en el campo). Si no existe, se crea. Tras el upsert, si el total de
registros del usuario supera 20, se eliminan los mas antiguos
(por ``searched_at`` ASC) hasta dejar exactamente 20.

Solo se registra para compradores autenticados. Los visitantes
anonimos no tienen historial.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Termino nuevo — se crea registro
   DADO comprador autenticado sin historial previo
   CUANDO busca "collar oshun"
   ENTONCES SearchHistory contiene 1 registro con term="collar oshun"
   Y la respuesta de busqueda llega antes de que se confirme el guardado

   Escenario 2: Termino repetido — upsert actualiza searched_at
   DADO comprador que ya busco "collar oshun" hace 1 hora
   CUANDO busca "collar oshun" de nuevo
   ENTONCES SearchHistory tiene 1 registro (no duplicado)
   Y searched_at se actualiza al momento actual

   Escenario 3: Trim automatico al superar 20
   DADO comprador con 20 entradas en historial
   CUANDO busca un termino nuevo
   ENTONCES historial tiene 20 entradas (la mas antigua fue eliminada)

----

4. Reglas y Restricciones
--------------------------

- Solo para usuarios autenticados.
- Maximo 20 entradas por usuario.
- Asincrono: threading (sin Celery hasta Sprint 27).
- Fallo silencioso: el error se loguea, no se propaga.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SRCH-03
   * - **Test**
     - TST-FR-SRCH-03.01

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Derivado de UC-SRCH-03 pasos 1-3.
       Creado en Sprint 6 (H-S6-008).

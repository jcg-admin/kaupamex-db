.. meta::
   :artefacto: FR-CAT-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-01.02: Recuperar productos activos con cache y calcular precio final
===========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-01.02
   * - **Nombre**
     - Consultar productos publicados con cache, aplicar ordenamiento y calcular precios con descuentos
   * - **UC Origen**
     - UC-CAT-01: Ver Catalogo de Productos
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar los productos activos y publicados del
   repositorio usando el Servicio de Cache cuando este disponible,
   aplicar ordenamiento y paginacion, y calcular el precio final
   de cada producto incluyendo descuentos activos de DASHBOARD.

**Descripcion:**

La consulta base recupera solo productos ``Product.is_active = True`` y
``Product.is_published = True``, con carga anticipada de la categoría
asociada y los tamaños disponibles.

**Estrategia de cache:** El sistema construye una clave de cache que
incorpora el número de página, el criterio de ordenamiento y el
identificador de categoría. Si existe una entrada válida en
``DatabaseCache`` para esa clave (TTL de 5 minutos, BR-004), el
sistema retorna el resultado cacheado sin consultar el repositorio.
Si no existe entrada válida, ejecuta la consulta completa y almacena
el resultado en cache antes de retornarlo.

**Ordenamiento:** El sistema aplica el criterio de ordenamiento
recibido mapeando los valores aceptados a campos del modelo:
``novedades`` ordena por ``Product.created_at`` descendente,
``precio_asc`` por ``Product.base_price`` ascendente, ``precio_desc``
por ``Product.base_price`` descendente, y ``nombre`` por
``Product.name`` ascendente. Cualquier valor no reconocido aplica
el ordenamiento por defecto (``novedades``).

**Paginación:** El sistema divide el conjunto de resultados en páginas
del tamaño solicitado, con un máximo de 100 elementos por página
(RNF-PERF-003).

**Cálculo del precio final:** Para cada producto de la página, el
sistema busca un ``ProductDiscount`` activo cuya ventana temporal
incluya el momento actual (``valid_from`` ≤ ahora ≤ ``valid_until``).
Si existe, calcula ``final_price = Product.base_price × (1 − discount_pct / 100)``
y retorna también ``original_price = Product.base_price`` para que el
frontend pueda mostrar el precio tachado. Si no existe descuento,
``final_price = Product.base_price`` y ``original_price`` queda ausente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Catalogo servido desde cache
   DADO catalogo consultado hace 2 minutos (cache con 5 min de TTL)
   CUANDO el visitante accede de nuevo con los mismos parametros
   ENTONCES la respuesta se sirve desde el Servicio de Cache (P50 < 100ms)
   Y el repositorio no recibe ninguna consulta

   Escenario 2: Precio con descuento activo
   DADO producto con base_price=1000 y descuento activo de 15%
   CUANDO se calcula el precio final
   ENTONCES final_price = 850.00 y original_price = 1000.00
   Y el frontend muestra el precio tachado y el precio con descuento

   Escenario 3: Paginacion por defecto
   DADO catalogo con 47 productos y page_size=20
   CUANDO se solicita la pagina 1
   ENTONCES se retornan 20 productos
   Y la respuesta incluye total_pages=3, total_products=47, current_page=1

   Escenario 4: Parametro de ordenamiento invalido — valores por defecto
   DADO solicitud con sort=precio_raramente_usado (no reconocido)
   CUANDO el sistema procesa el parametro
   ENTONCES aplica el ordenamiento por defecto (novedades)
   Y no retorna error al visitante (Alt. E del UC)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio base sin IVA — el catalogo muestra
  precios sin IVA; el IVA se calcula en checkout)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms sin cache),
  RNF-PERF-003 (paginacion obligatoria, max 100 items/pagina)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-01: Ver Catalogo
   * - **Depende de**
     - Ninguno — primer paso del Sistema
   * - **Requerido por**
     - FR-CAT-01.01 (presentar el catalogo al visitante)
   * - **Relacionado con**
     - MOD-018 DASHBOARD (descuentos de producto aplicados aqui)
   * - **Test**
     - TST-FR-CAT-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-CAT-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Las 4 logicas (cache, ordenamiento, paginacion, precio final)
       preservadas integras con nombres canonicos del modelo.

.. meta::
   :artefacto: FR-RET-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ret-03-01:

FR-RET-03.01: Registrar recepcion fisica del producto
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-03.01
   * - **Nombre**
     - Registrar recepcion fisica del producto
   * - **UC Origen**
     - UC-RET 03 REGISTRAR RECEPCION DEVOLUCION
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar la recepcion del producto devuelto CUANDO el admin lo confirma.

**Descripcion:**

``ReturnRequest.received_at = now()``
``ReturnRequest.product_condition = estado_reportado``
``ReturnRequest.status = RECEIVED``

El estado del producto (BUENAS_CONDICIONES / DANADO / INCOMPLETO) se registra para auditoria interna.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Recepcion exitosa
   DADO solicitud en APPROVED con tracking de devolucion activo
   CUANDO el admin registra la recepcion del producto
   ENTONCES ReturnRequest.status=RECEIVED y received_at=now

   Escenario: Producto recibido en mal estado
   DADO producto devuelto con daños adicionales
   CUANDO el admin registra como DANADO
   ENTONCES el estado queda en BD para auditoria interna


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** La condicion del producto se guarda para disputes futuras con el comprador.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET 03 REGISTRAR RECEPCION DEVOLUCION
   * - **Depende de**
     - FR-RET-02.01 (solicitud aprobada)
   * - **Requerido por**
     - Ninguno — fin del ciclo fisico
   * - **Test**
     - TST-FR-RET-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RET 03 REGISTRAR RECEPCION DEVOLUCION

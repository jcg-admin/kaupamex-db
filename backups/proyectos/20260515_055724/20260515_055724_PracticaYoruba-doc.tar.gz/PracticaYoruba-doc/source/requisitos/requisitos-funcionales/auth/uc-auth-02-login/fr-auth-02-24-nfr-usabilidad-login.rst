.. meta::
   :artefacto: FR-AUTH-02.24
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-24:

==========================================================
FR-AUTH-02.24: NFR Usabilidad — Experiencia del formulario de login
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.24
   * - **Nombre**
     - Restricciones de usabilidad y accesibilidad del formulario de login
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Seccion 6.4 — Requisitos No Funcionales de Usabilidad
   * - **Modulo**
     - MOD-001 ACCOUNTS (formulario de login — capa de presentacion)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - NFR Tecnico — Usabilidad

----

2. Especificacion
-----------------

**Declaracion:**

   El formulario de login DEBE cumplir los estandares de usabilidad
   y accesibilidad definidos en la seccion 6.4 del UC-AUTH-02.

**Descripcion:**

Requisitos de usabilidad implementados en el formulario:

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Requerimiento
   * - Campos identificados
     - Labels visibles (no solo placeholders), asociados al campo
       con ``for``/``id``
   * - Retroalimentacion inmediata
     - Validacion en tiempo real (FR-AUTH-02.05) con indicacion
       visual verde/rojo. Sin esperar al submit para ver errores de formato.
   * - Visibilidad de contraseña
     - Toggle mostrar/ocultar con icono semantico (WCAG 2.1 AA)
   * - Prevencion de doble envio
     - Boton deshabilitado durante el procesamiento (FR-AUTH-02.06)
   * - Indicador de progreso
     - Spinner + texto "Verificando..." durante el POST al servidor
   * - Mensajes de error orientados a accion
     - Los errores dicen que hacer: "Verifica tu email antes de iniciar
       sesion" incluye un boton de reenvio, no solo el mensaje
   * - Accesibilidad WCAG 2.1 AA
     - Navegable por teclado, ratio de contraste >= 4.5:1,
       mensajes de error anunciados por lectores de pantalla
       (via ``aria-describedby``)
   * - Responsivo
     - Funciona en movil (320px) y escritorio (1440px)
       sin scroll horizontal

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Navegacion por teclado
   DADO formulario de login visible
   CUANDO el usuario navega solo con Tab y Enter
   ENTONCES puede completar el login sin usar el raton
   Y el orden de tabulacion es: identificador → contraseña →
   recordarme → boton → enlace recuperar → enlace registro

   Escenario 2: Error de contraseña anunciado por lector de pantalla
   DADO login fallido con contraseña incorrecta
   CUANDO el mensaje de error aparece
   ENTONCES el lector de pantalla anuncia el error automaticamente
   Y el mensaje incluye la accion correctiva posible

   Escenario 3: Formulario usable en movil (320px de ancho)
   DADO pantalla de 320px de ancho (iPhone SE)
   CUANDO se muestra el formulario de login
   ENTONCES todos los elementos son visibles sin scroll horizontal
   Y los campos tienen el tamanio minimo recomendado para touch (44px)

   Escenario 4: Ratio de contraste cumple WCAG 2.1 AA
   DADO el texto de labels y mensajes de error
   CUANDO se mide el contraste con el fondo
   ENTONCES el ratio es >= 4.5:1 para texto normal
   Y >= 3:1 para texto grande (> 18px o 14px bold)

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-USAB-001 (mensajes de error comprensibles),
  RNF-USAB-002 (retroalimentacion en operaciones largas)
- **Notas:** Los requisitos de WCAG 2.1 AA son la responsabilidad
  del equipo de frontend. Este FR los documenta como requisito
  derivado del UC, no como detalle de implementacion del backend.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Seccion UC**
     - 6.4 Usabilidad
   * - **RNF del sistema**
     - RNF-USAB-001, RNF-USAB-002
   * - **Test**
     - TST-FR-AUTH-02.24 (pendiente — test de accesibilidad con axe-core)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de la seccion 6.4 de UC-AUTH-02

.. meta::
   :artefacto: FR-AUTH-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-04-01:

=====================================================
FR-AUTH-04.01: Rotar tokens — emitir nuevo par
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.01
   * - **Nombre**
     - Verificar refresh token, invalidarlo y emitir nuevo par JWT
   * - **UC Origen**
     - UC-AUTH-04: Renovar sesion
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Autenticacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar el refresh token, invalidarlo e
   issuar un nuevo par de tokens CUANDO el access token expiro.

**Descripcion:**

Proceso de rotacion (token rotation):

1. Verifica la firma y expiracion del refresh token
2. Verifica que el refresh token NO este en la blacklist
3. Agrega el refresh token actual a la blacklist (invalida el anterior)
4. Emite un nuevo access token (15 min) y un nuevo refresh token (7 dias)
5. Retorna el nuevo par al cliente

La rotacion del refresh token en cada uso es una medida de seguridad:
si un refresh token robado se usa, el token legit del usuario queda
invalidado en el siguiente intento, alertando del robo.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO refresh token valido y no en blacklist
   CUANDO se llama a POST /api/v1/auth/refresh/
   ENTONCES se retorna nuevo access y refresh token

   Escenario 1: Rotacion exitosa
   DADO refresh token valido
   CUANDO se renueva
   ENTONCES respuesta 200 con {access: "nuevo...", refresh: "nuevo..."}
   Y el refresh token anterior queda en la blacklist

   Escenario 2: Refresh token expirado
   DADO refresh token con mas de 7 dias
   CUANDO se intenta renovar
   ENTONCES respuesta 401 "Token is expired"
   Y el usuario debe hacer login completo

   Escenario 3: Refresh token ya en blacklist
   DADO refresh token previamente invalidado
   CUANDO se intenta usar
   ENTONCES respuesta 401 "Token is blacklisted"

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** El cliente debe reemplazar AMBOS tokens (access y refresh)
  al recibir la respuesta. El refresh anterior ya no es valido.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar sesion
   * - **Depende de**
     - FR-AUTH-02.03 (token original emitido en login)
   * - **Requerido por**
     - Cualquier llamada autenticada posterior al vencimiento del access
   * - **RNF**
     - RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-04

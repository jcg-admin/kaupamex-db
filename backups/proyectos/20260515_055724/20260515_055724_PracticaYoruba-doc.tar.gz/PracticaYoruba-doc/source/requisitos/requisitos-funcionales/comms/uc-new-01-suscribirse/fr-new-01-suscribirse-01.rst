.. meta::
   :artefacto: FR-NEW-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-new-01-01:

FR-NEW-01.01: Crear suscripcion al newsletter
=============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-01.01
   * - **Nombre**
     - Crear suscripcion al newsletter
   * - **UC Origen**
     - UC-NEW 01 SUSCRIBIRSE
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la suscripcion CUANDO el visitante completa el formulario.

**Descripcion:**

Si el email ya esta suscrito: retorna OK sin crear duplicado (idempotente).
Rate limiting: max 3 intentos de suscripcion con el mismo email por hora.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Suscripcion nueva
   DADO email no suscrito
   CUANDO se suscribe
   ENTONCES Newsletter creado con is_active=True

   Escenario: Email ya suscrito — idempotente
   DADO email ya en la lista
   CUANDO intenta suscribirse de nuevo
   ENTONCES respuesta 200 OK sin crear duplicado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-004`
- **Notas:** La suscripcion es idempotente para que el footer pueda capturar sin verificar si ya esta suscrito.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW 01 SUSCRIBIRSE
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-NEW-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NEW 01 SUSCRIBIRSE

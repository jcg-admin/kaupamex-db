.. meta::
   :artefacto: FR-NOT-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-04-02:

==================================================================================
FR-NOT-04.02: Notificar al comprador la decisión sobre su solicitud de devolución
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-04.02
   * - **Nombre**
     - Seleccionar la plantilla según la decisión del admin (aprobada
       o rechazada), incluir el motivo o el estado del reembolso
       según corresponda, y encolar el email de forma asíncrona
   * - **UC Origen**
     - UC-NOT-04: Email de Devolución Procesada
   * - **Paso UC**
     - Pasos 2 al 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El Sistema de Notificaciones DEBE seleccionar la plantilla
   correspondiente a la decisión tomada sobre la devolución,
   incluir la información específica de esa decisión y encolar
   el email al comprador de forma asíncrona CUANDO FR-RET-02.02
   registra la aprobación o el rechazo de una solicitud de
   devolución.

**Descripcion:**

La decisión sobre una devolución puede ser una de dos, y cada una
genera un email con contenido y tono distintos:

**Devolución aprobada.**
El email comunica al comprador que su solicitud fue aceptada y que
el reembolso fue iniciado. Incluye el monto que recibirá, el método
de pago al que se procesará (el mismo con el que realizó la compra)
y el tiempo estimado que tarda el reembolso en hacerse visible en
su cuenta según el gateway utilizado. El tono del email es positivo
y resolutivo.

**Devolución rechazada (Alt. C).**
El email informa al comprador que su solicitud no pudo ser procesada
e incluye el motivo exacto que el admin registró al rechazarla. La
claridad en el motivo es importante para que el comprador entienda
la decisión y pueda actuar en consecuencia —por ejemplo, si el
rechazo fue por plazo vencido, el comprador sabe que no puede
reintentar.

En ambos casos, antes de encolar el sistema verifica que el
comprador tiene email válido y que no desactivó las notificaciones
de devoluciones. Si alguna verificación falla, el proceso termina
y queda registrado el motivo de la omisión.

**EX-02 — Email rechazado permanentemente por el proveedor:**
Si el Servicio de Email Externo rechaza el mensaje de forma
permanente —por ejemplo porque el dominio del destinatario tiene
lista negra activa— el sistema marca el envío como
``FAILED_PERMANENTLY`` sin programar reintentos. El Procesador
Asíncrono no reintentará para evitar la acumulación de rebotes
que podría degradar la reputación del remitente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Devolución aprobada — email con monto y tiempo de reembolso
   DADO solicitud de devolución aprobada por el admin
   Y el pago original fue realizado con Mercado Pago
   CUANDO el Sistema de Notificaciones recibe el evento
   ENTONCES el email informa "Tu devolución fue aprobada"
   Y muestra el monto del reembolso y el gateway al que se procesará
   Y indica "El reembolso aparecerá en tu cuenta en 3 a 5 días hábiles"

   Escenario 2: Devolución rechazada — email con el motivo del admin
   DADO solicitud rechazada con motivo "El producto muestra signos de uso"
   CUANDO el Sistema de Notificaciones recibe el evento (Alt. C)
   ENTONCES el email informa "Tu solicitud de devolución no fue aprobada"
   Y muestra el motivo exacto: "El producto muestra signos de uso"
   Y ofrece los datos de contacto del negocio para consultas adicionales

   Escenario 3: Email rechazado permanentemente por el proveedor
   DADO comprador con dominio de email en lista negra del proveedor
   CUANDO el Servicio de Email Externo rechaza el mensaje (EX-02)
   ENTONCES el registro queda como FAILED_PERMANENTLY
   Y el Procesador Asíncrono no programa ningún reintento
   Y el admin puede ver el fallo en el panel de notificaciones

   Escenario 4: Preferencia de notificaciones de devolución desactivada
   DADO comprador que desactivó los avisos de devoluciones en FR-NOT-06.02
   CUANDO el Sistema de Notificaciones verifica las preferencias
   ENTONCES no se encola ningún email
   Y el proceso registra "omitida por preferencia" en auditoría

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-003 (reintentos con espera progresiva
  para fallos temporales; sin reintentos para ``FAILED_PERMANENTLY``
  — gestionado por FR-SYS-04.02)
- **Notas:** El tiempo estimado de reembolso depende del gateway y
  se obtiene de la configuración del mismo, no se codifica en la
  plantilla.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-04: Email de Devolución Procesada
   * - **Disparado por**
     - FR-RET-02.02 (el admin aprueba o rechaza la solicitud)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla)
   * - **Relacionado con**
     - FR-NOT-06.02 (preferencias del comprador),
       FR-SYS-04.02 (gestión de reintentos con espera progresiva)
   * - **Test**
     - TST-FR-NOT-04.02 (pendiente — verificar que el email de
       rechazo incluye el motivo exacto del admin; verificar que
       FAILED_PERMANENTLY no genera reintento programado)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: dos plantillas según decisión, motivo
       del rechazo, tiempo de reembolso por gateway, EX-02 con
       FAILED_PERMANENTLY sin reintentos, 4 escenarios BDD

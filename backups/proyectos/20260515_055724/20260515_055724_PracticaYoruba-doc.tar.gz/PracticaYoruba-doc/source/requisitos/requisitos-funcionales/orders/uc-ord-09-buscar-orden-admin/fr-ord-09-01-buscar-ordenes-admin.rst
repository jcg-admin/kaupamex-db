.. meta::
   :artefacto: FR-ORD-09.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-ORD-09.01: Buscar ordenes con filtros (Admin)
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-09.01
   * - **Nombre**
     - Buscar ordenes con multiples criterios de filtrado
   * - **UC Origen**
     - UC-ORD-09: Buscar orden (Admin)
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER (apps.orders)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE buscar ordenes con los criterios del admin
   y retornar resultados paginados CUANDO se ejecuta la busqueda.

**Descripcion:**

Filtros disponibles (todos opcionales, se combinan como AND):

- ``order_number`` — busqueda exacta
- ``email`` — email del comprador o guest_email
- ``status`` — uno o varios estados
- ``date_from`` / ``date_to`` — rango de fecha de creacion
- ``min_total`` / ``max_total`` — rango de total de la orden

Al menos un criterio de busqueda es obligatorio para ejecutar.
Resultados paginados: 20 por pagina. Ordenamiento configurable.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO admin con criterios de busqueda
   CUANDO ejecuta GET /api/v1/admin/orders/?{filtros}
   ENTONCES recibe los resultados que coinciden

   Escenario 1: Busqueda por email del comprador
   DADO admin que busca ordenes de "juan@example.com"
   CUANDO filtra por ?email=juan@example.com
   ENTONCES solo aparecen las ordenes de ese comprador

   Escenario 2: Sin criterios — error
   DADO admin que hace GET sin ningun parametro de filtro
   CUANDO se procesa
   ENTONCES error 422: SE_REQUIERE_AL_MENOS_UN_CRITERIO

   Escenario 3: Exportar resultados a CSV
   DADO busqueda con resultados
   CUANDO el admin exporta
   ENTONCES descarga CSV con order_number, fecha, email, estado, total

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF:** RNF-SEC-003 (el admin solo ve ordenes segun sus permisos),
  RNF-PERF-003 (paginacion obligatoria)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-09: Buscar orden (Admin)
   * - **Depende de**
     - Autenticacion de admin
   * - **Requerido por**
     - Acciones admin sobre las ordenes encontradas
   * - **Test**
     - TST-FR-ORD-09.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-09

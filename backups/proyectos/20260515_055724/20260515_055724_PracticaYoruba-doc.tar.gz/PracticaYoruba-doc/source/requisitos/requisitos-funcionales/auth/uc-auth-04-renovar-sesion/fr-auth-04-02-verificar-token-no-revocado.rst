.. meta::
   :artefacto: FR-AUTH-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-04-02:

=============================================================
FR-AUTH-04.02: Verificar que el refresh token no fue revocado
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.02
   * - **Nombre**
     - Comprobar que el refresh token existe en sesiones activas registradas y no esta en blacklist
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Paso 3 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el refresh token esta en la tabla
   de tokens activos y no ha sido revocado CUANDO recibe una
   solicitud de renovacion de sesion.

**Descripcion:**

Verificacion en dos pasos:

1. **Existencia en sesiones activas registradas:** el token debe estar registrado
   en el repositorio de sesiones activas. Si no existe, fue emitido
   por otro sistema o es una falsificacion.

2. **Ausencia en sesiones revocadas:** el token NO debe estar en
   ``el repositorio de sesiones revocadas``. Si esta en blacklist, fue
   revocado por un logout previo (FR-AUTH-03.01).

el Servicio de Autenticacion ejecuta estas verificaciones
automaticamente cuando ``BLACKLIST_AFTER_ROTATION = True`` y la
app ``token_blacklist`` esta instalada.

Si el token fue revocado (esta en blacklist):

- HTTP 401 con ``codigo_error: SESION_REVOCADA``
- El cliente debe redirigir al usuario al login
- Posible indicador de seguridad: si un token revocado se intenta
  usar, puede significar que un token robado fue revocado por el
  dueño legitimo y el atacante intenta seguir usandolo

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token activo y no revocado — renovacion procede
   DADO refresh token que fue emitido por el sistema y no esta en blacklist
   CUANDO se verifica en el paso 3
   ENTONCES la verificacion pasa
   Y el proceso continua al paso 4 (verificar expiracion)

   Escenario 2: Token revocado por logout previo
   DADO refresh token que fue invalidado via FR-AUTH-03.01
   CUANDO se intenta usar para renovar
   ENTONCES HTTP 401 con {"codigo_error": "SESION_REVOCADA",
   "mensaje": "Tu sesion ha sido cerrada. Inicia sesion de nuevo."}
   Y el cliente redirige al usuario a la pagina de login

   Escenario 3: Token no emitido por el sistema (falsificado)
   DADO token JWT con firma valida pero jti no registrado en outstanding_tokens
   CUANDO se intenta usar para renovar
   ENTONCES HTTP 401 con "SESION_REVOCADA" (mismo mensaje — no revelamos detalles)
   Y el intento queda registrado en el log de auditoria

   Escenario 4: Detector de robo de sesion activo
   DADO refresh token que el usuario legitimo ya uso (y fue rotado)
   CUANDO un atacante intenta usar el token original
   ENTONCES HTTP 401 porque el token original esta en blacklist tras la rotacion
   Y el usuario legitimo con el nuevo token sigue autenticado

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (JWT con blacklist activa)
- **Notas:** La rotacion de tokens (FR-AUTH-04.01) genera una cadena:
  token-A → uso → blacklist + nuevo token-B → uso → blacklist + token-C...
  Un atacante con token-A no puede usarlo despues de que el dueño
  uso token-A para obtener token-B.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Depende de**
     - FR-AUTH-04.01 (token recibido y firma verificada)
   * - **Requerido por**
     - FR-AUTH-04.03 (verificar que el token no ha expirado)
   * - **RNF**
     - RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 3 de UC-AUTH-04

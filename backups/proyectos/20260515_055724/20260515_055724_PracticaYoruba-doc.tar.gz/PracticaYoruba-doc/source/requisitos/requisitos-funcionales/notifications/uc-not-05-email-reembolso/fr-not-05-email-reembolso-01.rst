.. meta::
   :artefacto: FR-NOT-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-not-05-01:

FR-NOT-05.01: Enviar email de confirmacion de reembolso
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-05.01
   * - **Nombre**
     - Enviar email de confirmacion de reembolso
   * - **UC Origen**
     - UC-NOT 05 EMAIL REEMBOLSO
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-001 via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE notificar al comprador cuando el reembolso fue iniciado y cuando se acredita.

**Descripcion:**

Dos momentos de notificacion:

1. Al iniciar el reembolso: ``reembolso_iniciado`` con monto y plazo estimado
2. Al confirmarlo via webhook del gateway: ``reembolso_completado`` con la fecha de acreditacion

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email de reembolso iniciado
   DADO reembolso creado en MOD-PAYMENT
   CUANDO se dispara la notificacion
   ENTONCES el comprador recibe el monto y que el reembolso tomara 3-10 dias habiles

   Escenario: Reembolso parcial
   DADO reembolso de solo algunos items
   CUANDO se notifica
   ENTONCES el email indica claramente el monto parcial y que items fueron reembolsados


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El plazo de acreditacion varia por gateway y tipo de tarjeta. Se indica un rango estimado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT 05 EMAIL REEMBOLSO
   * - **Depende de**
     - FR-PAY-07.01 (reembolso iniciado)
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NOT-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NOT 05 EMAIL REEMBOLSO

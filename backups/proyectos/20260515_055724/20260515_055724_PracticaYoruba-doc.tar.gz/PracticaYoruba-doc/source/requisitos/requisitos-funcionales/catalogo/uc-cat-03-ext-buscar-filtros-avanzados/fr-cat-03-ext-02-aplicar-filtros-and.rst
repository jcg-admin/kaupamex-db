.. meta::
   :artefacto: FR-CAT-03-EXT.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-03-EXT.02: Aplicar filtros avanzados como condicion AND sobre los resultados
====================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-03-EXT.02
   * - **Nombre**
     - Filtrar resultados de busqueda por categoria, rango de precio y disponibilidad (AND)
   * - **UC Origen**
     - UC-CAT-03-EXT: Buscar con Filtros Avanzados
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE aplicar los filtros activos como condicion AND
   sobre el conjunto de resultados de busqueda base CUANDO el
   visitante activa uno o mas filtros avanzados.

**Descripcion:**

Los filtros se acumulan como condiciones AND — cada filtro activo
reduce el conjunto de resultados:

- **Filtro de categoría:** si el parámetro ``category`` está presente,
  el sistema restringe los resultados a productos cuyo
  ``Product.category_id`` coincida con el valor recibido.

- **Filtro de rango de precio:** si ``price_min`` está presente, el
  sistema excluye productos con ``Product.base_price`` inferior al
  valor. Si ``price_max`` está presente, excluye productos con
  ``Product.base_price`` superior al valor. El precio comparado
  es el precio base sin IVA (BR-001).

- **Filtro de disponibilidad:** si el parámetro ``in_stock`` es
  ``true``, el sistema restringe los resultados a productos que
  tienen al menos un ``ProductVariant`` con ``stock > 0``,
  eliminando duplicados que pudieran surgir de la relación.

Los filtros activos se codifican en la URL como query params:
``?q=collar&category=5&price_min=100&price_max=500&in_stock=true``

Esto permite que el visitante comparta o guarde la URL de resultados
filtrados, y que el navegador pueda retroceder al estado anterior.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Filtro de categoria aplicado sobre busqueda
   DADO busqueda "collar" con categoria=5 (Orisha Yemoja)
   CUANDO se aplican los filtros
   ENTONCES los resultados contienen solo productos de la categoria 5
   Y el termino "collar" coincide en nombre o descripcion

   Escenario 2: Rango de precio aplicado
   DADO price_min=200, price_max=800
   CUANDO se filtra
   ENTONCES todos los productos retornados tienen base_price entre 200 y 800
   Y los precios se comparan sin IVA (BR-001)

   Escenario 3: Combinacion sin resultados — sugerencia de ampliar
   DADO filtros muy restrictivos que no dejan ningún resultado
   CUANDO el sistema aplica los filtros
   ENTONCES HTTP 200 con total_results=0
   Y la respuesta indica cuales filtros eliminar para ampliar
   Y el boton "limpiar filtros" regresa a los resultados base

   Escenario 4: URL con filtros activos — compartible
   DADO visitante con filtros aplicados
   CUANDO copia la URL del navegador
   ENTONCES la URL incluye todos los filtros como query params
   Y otro visitante que accede a esa URL ve los mismos resultados

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio filtrado es el precio base sin IVA)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-03-EXT: Buscar con Filtros Avanzados
   * - **Depende de**
     - FR-CAT-03.02 (conjunto de resultados base de la busqueda)
   * - **Requerido por**
     - Ninguno — el resultado es la lista filtrada que se presenta al visitante
   * - **Test**
     - TST-FR-CAT-03-EXT.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-6 de UC-CAT-03-EXT
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Los 3 filtros preservados con nombres canonicos del modelo.

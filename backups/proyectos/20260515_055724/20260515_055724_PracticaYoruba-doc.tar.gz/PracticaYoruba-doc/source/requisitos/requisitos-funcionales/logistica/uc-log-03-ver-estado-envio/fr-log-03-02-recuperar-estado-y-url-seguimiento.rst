.. meta::
   :artefacto: FR-LOG-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-03.02: Recuperar el estado del envio y el URL de seguimiento del courier
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-03.02
   * - **Nombre**
     - Retornar el estado de la guia, numero de rastreo, URL de seguimiento y fecha estimada
   * - **UC Origen**
     - UC-LOG-03: Ver Estado de Envio
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden pertenece al comprador y
   retornar el estado del envio con el URL de seguimiento del courier
   CUANDO el comprador consulta el estado de su envio.

**Descripcion:**

El sistema busca la ``Order`` por ``order_number`` y ``user``. Si no
existe → HTTP 404 (nunca HTTP 403, RNF-SEC-003). Si la orden no tiene
``ShipmentGuide`` asociada, retorna ``shipment_status = 'NOT_SHIPPED'``.
En caso contrario retorna: ``ShipmentGuide.status``,
``ShipmentGuide.tracking_number``, la URL de seguimiento construida como
``Courier.tracking_url_template.format(tracking=tracking_number)``
(o nula si aún no hay número de rastreo), ``Courier.name``,
``ShipmentGuide.estimated_delivery``, los ``ShipmentEvent`` ordenados
por ``-occurred_at``, y la bandera ``can_leave_review`` que es
verdadera si ``Order.status = 'DELIVERED'`` y ningún ``OrderItem``
tiene reseña asociada todavía.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Envio en transito con URL de seguimiento
   DADO orden con guia EN_TRANSITO y tracking_number=1234567890
   CUANDO el comprador consulta
   ENTONCES HTTP 200 con tracking_url del courier
   Y la lista de eventos del envio (si el courier los proveyo via webhook)

   Escenario 2: Orden aun no enviada
   DADO orden en PAYMENT_CONFIRMED sin guia creada
   CUANDO el comprador consulta
   ENTONCES HTTP 200 con shipment_status=NOT_SHIPPED

   Escenario 3: Envio entregado — opcion de resena disponible
   DADO orden en estado DELIVERED sin resenas previas
   CUANDO el comprador consulta
   ENTONCES can_leave_review = true
   Y el frontend muestra el boton de dejar resena

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — 404 para ordenes
  de otros usuarios, no 403)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-03: Ver Estado de Envio
   * - **Incluye**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **Relacionado con**
     - UC-REV-01 (resena disponible cuando can_leave_review=true)
   * - **Test**
     - TST-FR-LOG-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-LOG-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

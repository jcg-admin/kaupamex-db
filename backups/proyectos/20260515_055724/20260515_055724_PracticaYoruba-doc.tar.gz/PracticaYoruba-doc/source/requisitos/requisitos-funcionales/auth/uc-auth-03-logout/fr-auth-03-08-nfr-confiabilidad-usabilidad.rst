.. meta::
   :artefacto: FR-AUTH-03.08
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-03.08: NFR Confiabilidad y Usabilidad del logout
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.08
   * - **Nombre**
     - Garantizar que el usuario siempre queda desautenticado y el logout es visible
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - Secciones 6.3 y 6.4 — Confiabilidad y Usabilidad
   * - **Modulo**
     - MOD-001 ACCOUNTS + frontend
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico

----

2. Especificacion
-----------------

**Declaracion:**

   El logout DEBE garantizar que el usuario queda en estado no autenticado
   desde su perspectiva Y que el boton de cierre de sesion es siempre
   visible y accesible sin friccion.

**Descripcion:**

Confiabilidad (6.3):

- **Garantia para el usuario:** independientemente de lo que ocurra en el
  servidor (fallo en blacklist, fallo en auditoria), el usuario SIEMPRE
  queda en estado no autenticado desde su dispositivo.
  La limpieza del cliente (FR-AUTH-03.04) ocurre aunque el servidor
  retorne un error parcial.
- **Degradacion controlada:** si la BD de blacklist no responde, el
  logout es parcial pero el usuario no ve errores. El token expira
  en su tiempo natural.

Usabilidad (6.4):

- **Acceso visible:** el boton "Cerrar sesion" es visible en el menu
  de usuario en TODAS las paginas cuando el usuario esta autenticado.
  No requiere navegar a ninguna pagina especifica.
- **Un solo clic:** el logout ocurre con un click. Sin dialogo de
  confirmacion (la confirmacion agrega friccion sin beneficio real
  — el usuario puede volver a hacer login inmediatamente si fue un error).
- **Confirmacion inmediata:** tras el logout, el usuario ve un mensaje
  de confirmacion (toast o banner) antes de la redireccion.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Logout siempre funciona para el usuario
   DADO cualquier condicion del servidor (BD disponible o no)
   CUANDO el usuario hace clic en "Cerrar sesion"
   ENTONCES el usuario queda en estado no autenticado en su dispositivo
   Y no ve mensajes de error que le impidan salir de su cuenta

   Escenario 2: Boton de logout visible sin buscar
   DADO usuario autenticado en cualquier pagina del sistema
   CUANDO busca como cerrar sesion
   ENTONCES el boton esta visible en el menu de usuario
   Y no requiere mas de 2 clicks desde cualquier pagina

   Escenario 3: Sin dialogo de confirmacion innecesario
   DADO usuario que hace clic en "Cerrar sesion"
   CUANDO se hace clic
   ENTONCES el logout se procesa directamente sin "¿Estas seguro?"
   Y si el usuario quiere volver, puede hacer login inmediatamente

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-AVAIL-001, RNF-USAB-001

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Secciones UC**
     - 6.3 Confiabilidad, 6.4 Usabilidad
   * - **RNF del sistema**
     - RNF-AVAIL-001, RNF-USAB-001
   * - **Test**
     - TST-FR-AUTH-03.08 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de las secciones 6.3 y 6.4 de UC-AUTH-03

.. meta::
   :artefacto: FR-AUTH-02.07
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-07:

===================================================
FR-AUTH-02.07: Normalizar y validar el identificador
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.07
   * - **Nombre**
     - Normalizar el identificador a minusculas y validar su formato
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 10 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — capa de servicio en el servidor)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE normalizar el identificador a minusculas y validar
   que cumple las reglas del sistema CUANDO recibe el POST de login
   en el servidor.

**Descripcion:**

Este paso ocurre en el servidor, despues de la validacion de cliente
(FR-AUTH-02.06) y del check de rate limiting (FR-AUTH-02.01).

Normalizacion y validacion en el servidor:

1. ``identificador = identificador.strip()`` — elimina espacios al inicio y fin
2. ``identificador = identificador.lower()`` — convierte a minusculas
3. Si contiene ``@``: valida formato email (RFC 5322 basico)
4. Si no contiene ``@``: valida que cumple el patron de username de Django
   (``[\w.@+-]``, longitud 1-150)
5. Si falla alguna validacion: retorna HTTP 400 con
   ``codigo_error: DATOS_INVALIDOS`` y detalle del campo

Esta normalizacion es independiente de la del cliente — el servidor
no confía ciegamente en la validacion del cliente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email con mayusculas — normalizado correctamente
   DADO identificador "Usuario@EJEMPLO.COM" enviado en el POST
   CUANDO el servidor procesa el paso 10
   ENTONCES el sistema trabaja internamente con "usuario@ejemplo.com"
   Y la busqueda posterior usa el valor normalizado

   Escenario 2: Identificador con espacios al inicio — limpiado
   DADO identificador "  juan@test.com  " con espacios
   CUANDO el servidor normaliza
   ENTONCES trabaja con "juan@test.com" (sin espacios)
   Y la busqueda posterior funciona correctamente

   Escenario 3: Identificador invalido en el servidor
   DADO identificador "" (vacio, aunque el cliente lo bloqueo)
   CUANDO el servidor valida
   ENTONCES retorna HTTP 400
   Y el body incluye {"codigo_error": "DATOS_INVALIDOS",
   "detalles": {"identificador": "Este campo es obligatorio"}}

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La validacion en el servidor es la validacion de verdad —
  la del cliente es solo UX. Un cliente malicioso puede saltarse
  la validacion de cliente, pero no la del servidor.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.01 (IP no bloqueada — ya verificado)
   * - **Requerido por**
     - FR-AUTH-02.08 (buscar el identificador normalizado en el repositorio)
   * - **Test**
     - TST-FR-AUTH-02.07 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 10 de UC-AUTH-02

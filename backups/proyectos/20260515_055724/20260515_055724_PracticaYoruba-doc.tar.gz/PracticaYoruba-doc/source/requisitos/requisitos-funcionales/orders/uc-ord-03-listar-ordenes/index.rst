.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-03-listar-ordenes
===================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-03-01-listar-historial
   fr-ord-03-02-listar-ordenes-paginadas

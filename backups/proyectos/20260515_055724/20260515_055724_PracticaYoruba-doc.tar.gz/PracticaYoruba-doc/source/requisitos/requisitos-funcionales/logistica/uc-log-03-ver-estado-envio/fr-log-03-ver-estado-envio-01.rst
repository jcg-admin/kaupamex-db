.. meta::
   :artefacto: FR-LOG-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-03-01:

FR-LOG-03.01: Retornar estado del envio al comprador
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-03.01
   * - **Nombre**
     - Retornar estado del envio al comprador
   * - **UC Origen**
     - UC-LOG 03 VER ESTADO ENVIO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el estado y el historial de eventos del envio CUANDO el comprador lo consulta.

**Descripcion:**

Datos retornados:

- ``status``: PENDING / IN_TRANSIT / DELIVERED / etc.
- ``tracking_number`` y ``tracking_url``
- ``courier_name`` y ``service_type``
- ``estimated_delivery``
- ``events[]``: historial cronologico de actualizaciones del courier
- ``shipped_at``, ``delivered_at`` (si aplica)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Envio en transito con historial
   DADO orden SHIPPED con 3 eventos de courier
   CUANDO el comprador consulta el estado
   ENTONCES ve los 3 eventos en orden cronologico
   Y el estado actual es IN_TRANSIT

   Escenario: Envio entregado
   DADO orden DELIVERED
   CUANDO se consulta
   ENTONCES status=DELIVERED y delivered_at con la fecha de entrega
   Y aparece el CTA de dejar resena si no ha dejado una


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El estado se lee desde BD local. Los eventos llegan via webhooks de UC-LOG-04.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 03 VER ESTADO ENVIO
   * - **Depende de**
     - Propiedad verificada via INC-01
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-LOG-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 03 VER ESTADO ENVIO

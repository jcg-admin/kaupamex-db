.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — SISTEMA
=================================

**4 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-sys-01-cancelar-orden-timeout
     - 1
   * - uc-sys-02-desactivar-vouchers-expirados
     - 1
   * - uc-sys-03-notificar-stock-minimo
     - 1
   * - uc-sys-04-reenviar-emails-fallidos
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-sys-01-cancelar-orden-timeout/index
   uc-sys-02-desactivar-vouchers-expirados/index
   uc-sys-03-notificar-stock-minimo/index
   uc-sys-04-reenviar-emails-fallidos/index

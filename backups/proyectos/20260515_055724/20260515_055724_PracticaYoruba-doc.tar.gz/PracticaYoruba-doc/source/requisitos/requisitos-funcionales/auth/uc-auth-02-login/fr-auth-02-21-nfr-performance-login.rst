.. meta::
   :artefacto: FR-AUTH-02.21
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-21:

====================================================
FR-AUTH-02.21: NFR Performance — Tiempo de respuesta del login
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.21
   * - **Nombre**
     - Restriccion de performance especifica del endpoint de login
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Seccion 6.1 — Requisitos No Funcionales de Performance
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint POST /api/v1/auth/login/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico — Performance

----

2. Especificacion
-----------------

**Declaracion:**

   La implementacion del endpoint de login DEBE cumplir los tiempos
   de respuesta definidos en la seccion 6.1 del UC-AUTH-02.

**Descripcion:**

Metricas de performance especificas del login:

.. list-table::
   :widths: 30 40 30
   :header-rows: 1

   * - Metrica
     - Objetivo
     - Justificacion
   * - Tiempo de respuesta P50
     - <= 200ms
     - La comparacion el algoritmo de hash de contraseñas dura ~100-200ms intencionalmente
   * - Tiempo de respuesta P95
     - <= 500ms
     - Incluye validacion, busqueda en BD y firma JWT
   * - Tiempo de respuesta P99
     - <= 1000ms
     - Margen para picos de carga
   * - Capacidad concurrente
     - Sin degradacion al pico definido
     - Ver BReq-007 (SLO de disponibilidad)

**Nota critica sobre el tiempo de comparacion de contraseña:**

La comparacion segura de el algoritmo de hash de contraseñas dura intencionalmente
100-200ms para dificultar ataques de temporalizacion. Este tiempo
esta INCLUIDO en los objetivos anteriores, no se suma a ellos.
No se debe "optimizar" la comparacion de contraseña para bajar
los tiempos — eso comprometeria la seguridad.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Login exitoso bajo carga normal
   DADO 50 usuarios concurrentes haciendo login exitoso
   CUANDO se ejecuta la prueba de carga
   ENTONCES el P95 de latencia es <= 500ms
   Y el P50 es <= 200ms
   Y ningun request retorna 5xx

   Escenario 2: Login fallido no es mas rapido que el exitoso
   DADO intentos de login con credenciales incorrectas
   CUANDO se mide el tiempo de respuesta
   ENTONCES el tiempo de respuesta es similar al del login exitoso
   (la comparacion de contraseña se ejecuta siempre para prevenir
   ataques de temporalizacion que distinguen user-no-existe de
   contraseña-incorrecta)

   Escenario 3: Rate limiter no degrada el P95
   DADO endpoint con rate limiter activo
   CUANDO se evalua la performance del check de rate limit
   ENTONCES el check agrega <= 10ms al tiempo total
   (DatabaseCache es mas lento que LocMemCache pero cumple BR-014)

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-002 (tiempo de respuesta escritura)
- **Notas:** Si el P95 supera 500ms en produccion, revisar:
  1. Indices en la columna ``email`` de la tabla users
  2. Configuracion del pool de conexiones del repositorio
  3. Costo del hash de contraseña (iterciones de el algoritmo de hash)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Seccion UC**
     - 6.1 Performance
   * - **RNF del sistema**
     - RNF-PERF-002
   * - **BReq**
     - BReq-007 (disponibilidad y SLO)
   * - **Test**
     - TST-FR-AUTH-02.21 (pendiente — test de carga con locust)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de la seccion 6.1 de UC-AUTH-02

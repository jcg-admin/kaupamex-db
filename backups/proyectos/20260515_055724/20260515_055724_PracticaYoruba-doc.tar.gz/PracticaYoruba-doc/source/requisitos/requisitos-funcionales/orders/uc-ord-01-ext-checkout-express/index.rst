.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-01-ext-checkout-express
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-01-ext-01-detectar-elegibilidad-express
   fr-ord-01-ext-02-crear-orden-express

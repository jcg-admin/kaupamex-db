.. meta::
   :artefacto: FR-AUTH-04.06
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-04-06:

====================================================
FR-AUTH-04.06: Registrar el evento de renovacion en auditoria
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.06
   * - **Nombre**
     - Crear registro de auditoria del evento RENOVACION_SESION
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Paso 9 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — AccessAuditLog)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Auditoria

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear un registro de auditoria de la renovacion
   de sesion CUANDO las nuevas credenciales han sido emitidas y la
   rotacion completada.

**Descripcion:**

El registro de renovacion permite detectar patrones anormales:

- Renovaciones muy frecuentes desde una IP inusual (posible robo de token)
- Renovaciones desde multiples IPs para el mismo usuario en poco tiempo
- Renovaciones que ocurren despues de que el usuario deberia estar durmiendo

Campos del registro:

.. list-table::
   :widths: 30 70
   :header-rows: 1

   * - Campo
     - Valor
   * - ``user_id``
     - ID del usuario cuya sesion fue renovada
   * - ``event_type``
     - ``RENOVACION_SESION``
   * - ``ip_address``
     - IP de origen del request de renovacion
   * - ``jti_old``
     - JWT ID del refresh token que fue invalidado (el que se uso)
   * - ``jti_new``
     - JWT ID del nuevo refresh token emitido
   * - ``timestamp``
     - ``timezone.now()`` UTC

El par ``jti_old → jti_new`` permite reconstruir la cadena completa
de renovaciones de una sesion para analisis forense si fuera necesario.

Al igual que en el logout, el fallo en el registro de auditoria no
impide que la renovacion sea exitosa — las credenciales ya fueron emitidas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Registro de renovacion creado
   DADO renovacion completada exitosamente
   CUANDO se registra en el paso 9
   ENTONCES existe AccessAuditLog con:
   - event_type = RENOVACION_SESION
   - jti_old = jti del token que se invalido
   - jti_new = jti del nuevo refresh token
   - ip_address = IP del request

   Escenario 2: Cadena de renovaciones trazable
   DADO usuario con 5 renovaciones en la misma sesion
   CUANDO se revisa el log de auditoria
   ENTONCES cada renovacion tiene jti_old del registro anterior
   Y la cadena desde jti_new(login) hasta jti_new(ultima renovacion) es continua

   Escenario 3: Fallo de auditoria no afecta la sesion
   DADO error al insertar en AccessAuditLog
   CUANDO falla el registro
   ENTONCES las credenciales ya emitidas siguen siendo validas
   Y el error queda en django.log nivel ERROR para el administrador

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — created_at automatico)
- **RNF aplicables:** RNF-PROC-002 (auditoria de operaciones de sesion)
- **Notas:** Las renovaciones son eventos de alta frecuencia (cada
  15 minutos por usuario activo). El AccessAuditLog necesita una
  politica de retencion — no se guarda para siempre. Recomendacion:
  purgar registros de mas de 90 dias con una tarea periodica.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Depende de**
     - FR-AUTH-04.01 (rotacion completada — nuevo par emitido)
   * - **Requerido por**
     - Ninguno — es el ultimo paso del Sistema en UC-AUTH-04
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-04.06 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 9 de UC-AUTH-04

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — REPORTES
==================================

**4 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-rpt-01-ver-reporte-ventas
     - 1
   * - uc-rpt-02-ver-reporte-productos
     - 1
   * - uc-rpt-03-ver-reporte-compradores
     - 1
   * - uc-rpt-04-exportar-reporte
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-rpt-01-ver-reporte-ventas/index
   uc-rpt-02-ver-reporte-productos/index
   uc-rpt-03-ver-reporte-compradores/index
   uc-rpt-04-exportar-reporte/index

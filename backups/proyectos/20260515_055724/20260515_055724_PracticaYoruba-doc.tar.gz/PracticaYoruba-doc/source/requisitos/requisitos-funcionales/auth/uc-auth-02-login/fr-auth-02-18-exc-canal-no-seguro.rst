.. meta::
   :artefacto: FR-AUTH-02.18
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-18:

====================================================
FR-AUTH-02.18: EX-03 — Rechazar solicitud por canal no cifrado
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.18
   * - **Nombre**
     - EX-03: Rechazar y redirigir si la solicitud llega por HTTP plano
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - EX-03 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - Servidor Web + Configuracion de canal seguro
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Seguridad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE rechazar cualquier solicitud de login que llegue
   por HTTP sin cifrar y redirigir al canal seguro CUANDO la solicitud
   no usa HTTPS.

**Descripcion:**

La protección opera en dos capas secuenciales. Cualquier solicitud
que llegue por HTTP sin cifrar es interceptada antes de que la
contraseña sea procesada.

**Capa 1 — Servidor web (primer punto de contacto):**

Apache está configurado para redirigir con HTTP 301 toda solicitud
entrante por el puerto 80 hacia la misma URL en HTTPS. Esta
redirección ocurre antes de que Django reciba la solicitud, por lo
que la contraseña nunca llega a la capa de aplicación por canal
inseguro. Esta configuración está documentada en
:doc:`/devops/despliegue-produccion`.

**Capa 2 — Middleware de Django (segunda línea de defensa):**

Si alguna solicitud lograra pasar la capa del servidor web sin
cifrar, el middleware de seguridad de Django la rechaza con HTTP 301
hacia HTTPS. Esta capa aplica únicamente en producción; en desarrollo
local está desactivada para permitir trabajo con HTTP.

**Resultado para el cliente:**

El navegador sigue la redirección 301 automáticamente a HTTPS.
La contraseña nunca se transmite por canal inseguro porque la
redirección se produce antes de que el formulario sea enviado.
Las visitas posteriores al sitio tampoco llegan por HTTP gracias
a HSTS, que instruye al navegador a convertir automáticamente
a HTTPS sin necesidad de contactar al servidor.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Request HTTP redirigido a HTTPS por Apache
   DADO solicitud GET http://ojayoruba.com/login/
   CUANDO Apache recibe la solicitud
   ENTONCES retorna 301 Moved Permanently
   Y Location: https://ojayoruba.com/login/
   Y el cliente carga el formulario por HTTPS

   Escenario 2: POST HTTP directo al API rechazado
   DADO solicitud POST http://ojayoruba.com/api/v1/auth/login/ con credenciales
   CUANDO llega sin HTTPS
   ENTONCES Apache redirige con 301 (antes de que Django procese)
   Y el body con las credenciales no es procesado por el servidor
   Y la contraseña no queda en ningun log del servidor

   Escenario 3: HSTS previene request HTTP en visitas futuras
   DADO usuario que ya accedio al sitio por HTTPS
   CUANDO su navegador intenta acceder por HTTP en el futuro
   ENTONCES el navegador convierte automaticamente a HTTPS (HSTS)
   Y ni siquiera se hace el request HTTP al servidor

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-SEC-006 (HTTPS obligatorio con HSTS
  de 1 anio — este FR es la implementacion de ese RNF en login)
- **Notas:** En desarrollo local (``DEBUG = True``) la redireccion
  a HTTPS esta desactivada para permitir trabajo con HTTP. Solo
  aplica en produccion (``la configuracion del entorno de produccion``).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Detectado en**
     - Servidor Web (capa de transporte) o middleware
   * - **Requerido por**
     - Todas las solicitudes del sistema — transversal
   * - **RNF**
     - RNF-SEC-006
   * - **ADR relacionado**
     - ADR-001 (monolito con Apache — la redireccion es responsabilidad
       de Apache como servidor web)
   * - **Test**
     - TST-FR-AUTH-02.18 (pendiente — curl -I http://ojayoruba.com/)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-03 de UC-AUTH-02

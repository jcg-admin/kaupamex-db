.. meta::
   :artefacto: FR-PRO-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pro-01-01:

FR-PRO-01.01: Crear voucher con reglas de elegibilidad
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-01.01
   * - **Nombre**
     - Crear voucher con reglas de elegibilidad
   * - **UC Origen**
     - UC-PRO 01 CREAR VOUCHER ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear el voucher con todas sus reglas CUANDO el admin completa el formulario.

**Descripcion:**

El tipo de voucher define que campos son requeridos:

- **FIXED**: ``discount_value`` requerido
- **PERCENTAGE**: ``discount_pct`` requerido, ``max_discount`` opcional
- **FREE_SHIPPING**: sin campos de monto

El codigo se normaliza a MAYUSCULAS y debe ser unico.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Voucher de porcentaje creado
   DADO admin que crea VERANO20 de 20% con max_discount=100
   CUANDO se crea
   ENTONCES el voucher esta disponible para aplicarse en UC-CART-04

   Escenario: Codigo duplicado
   DADO codigo PROMO10 ya existente
   CUANDO el admin intenta crear otro con ese codigo
   ENTONCES error 409: CODIGO_DUPLICADO


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El tipo del voucher es inmutable una vez creado para preservar la integridad del historial.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO 01 CREAR VOUCHER ADMIN
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-CART-04.01 (el comprador puede aplicar el voucher)
   * - **Test**
     - TST-FR-PRO-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PRO 01 CREAR VOUCHER ADMIN

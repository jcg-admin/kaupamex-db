.. meta::
   :artefacto: FR-NEW-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-04-30
   :fecha_actualizacion: 2026-05-03

.. _fr-new-01-02:

=================================================================================
FR-NEW-01.02: Registrar la suscripcion al newsletter con doble opt-in
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-01.02
   * - **Nombre**
     - Validar el email, verificar unicidad, crear NewsletterSubscriber en PENDING
       y encolar el email de confirmacion de doble opt-in
   * - **UC Origen**
     - UC-NEW-01: Suscribirse al Newsletter
   * - **Paso UC**
     - Pasos 4, 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos + Comunicacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato del email, verificar que no
   esta ya suscrito, crear el registro de suscripcion en estado
   PENDING con un token de confirmacion unico y encolar el email
   de doble opt-in CUANDO el visitante solicita suscribirse.

**Descripcion:**

El doble opt-in protege la lista de emails no autorizados y
cumple con los requisitos de GDPR. Ninguna suscripción pasa a
activa sin que el destinatario haga clic en el enlace de confirmación.

El sistema distingue cuatro situaciones al recibir un email de suscripción:

- **Email nuevo.** Se crea el registro con estado ``PENDING`` y un
  token de confirmación generado con el mecanismo criptográficamente
  seguro del sistema. Se encola el email de confirmación via UC-INC-03.

- **Email ya activo (``ACTIVE``).** El sistema responde con éxito pero
  sin revelar que ese email ya estaba en la lista. Esta respuesta genérica
  impide que un actor externo enumere qué emails pertenecen a la lista.
  No se crea ningún registro nuevo.

- **Email pendiente de confirmación (``PENDING``).** El sistema reenvía el
  email de confirmación sin crear un registro duplicado. El token
  existente sigue siendo válido.

- **Email desuscrito (``UNSUBSCRIBED``).** El visitante puede volver a
  suscribirse. El registro se reactiva con un nuevo token y se encola
  el email de confirmación.

El campo ``origin`` registra desde dónde se suscribió el visitante
(footer, página dedicada, durante el checkout) para que el admin pueda
ver qué puntos del sitio generan más suscripciones, sin almacenar datos
personales adicionales.

**Alt. B — Confirmación del doble opt-in:**

Cuando el visitante hace clic en el enlace del email, el sistema
localiza el registro por el token, verifica que no hayan pasado más de
72 horas desde su creación, y activa la suscripción. Tras la
confirmación el token queda invalidado para que no pueda reutilizarse.
Si el token expiró o no existe, el sistema informa al visitante y le
ofrece suscribirse de nuevo para recibir un enlace fresco.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nueva suscripcion exitosa — doble opt-in pendiente
   DADO visitante que ingresa "visitante@ejemplo.com" en el footer
   CUANDO POST /api/v1/newsletter/subscribe/
   ENTONCES HTTP 200 con {"result": "PENDING_CONFIRMATION"}
   Y NewsletterSubscriber creado con status=PENDING y token de 32 chars
   Y email de confirmacion encolado con el enlace de activacion
   Y el visitante ve "Revisa tu email para confirmar tu suscripcion"

   Escenario 2: Email ya ACTIVE — respuesta generica
   DADO "visitante@ejemplo.com" que ya tiene suscripcion ACTIVE
   CUANDO POST con el mismo email
   ENTONCES HTTP 200 con {"result": "ALREADY_REGISTERED"}
   Y el sistema NO revela si ya estaba suscrito (privacidad)
   Y NO se crea ningun registro nuevo

   Escenario 3: Confirmacion del token — suscripcion activada
   DADO NewsletterSubscriber con status=PENDING y token="abc123..."
   CUANDO GET /api/v1/newsletter/confirm/?token=abc123...
   ENTONCES NewsletterSubscriber.status = ACTIVE
   Y confirmed_at registrado y confirmation_token vaciado
   Y el suscriptor recibe emails de campanas futuras (FR-NEW-04.02)

   Escenario 4: Token expirado — error claro
   DADO token creado hace mas de 72 horas
   CUANDO el visitante hace clic en el enlace tardio
   ENTONCES HTTP 400 con {"codigo_error": "TOKEN_INVALIDO_O_EXPIRADO",
   "mensaje": "El enlace expiro. Suscribete de nuevo para recibir un nuevo enlace."}

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-010 (no se requiere autenticacion para
  suscribirse — acceso publico)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms), RNF-SEC-006
  (el token de confirmación se genera con el mecanismo
  criptográficamente seguro del sistema, no con generadores de
  números pseudoaleatorios simples)
- **Notas:** La respuesta generica para emails ya suscritos evita
  que un actor malicioso pueda enumerar cuales emails estan en la
  lista de suscriptores.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW-01: Suscribirse al Newsletter
   * - **Incluye**
     - UC-INC-03 (encolar email de confirmacion con plantilla NEWSLETTER_CONFIRMATION)
   * - **Requerido por**
     - FR-NEW-04.02 (el suscriptor ACTIVE recibe campanas futuras)
   * - **Relacionado con**
     - FR-NEW-02.02 (el suscriptor puede desuscribirse desde el enlace del email)
   * - **Test**
     - TST-FR-NEW-01.02 (pendiente — verificar que el token se
       genera con el mecanismo criptográficamente seguro; verificar
       que dos POST con el mismo email ACTIVE no crean registros
       duplicados)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial
   * - 1.2.0
     - 2026-05-03
     - Eliminado código Python; descripción reemplazada por
       prosa con los cuatro casos de suscripción y la
       confirmación del doble opt-in

.. meta::
   :artefacto: FR-NEW-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-new-03-02:

=================================================================================
FR-NEW-03.02: Listar suscriptores con estadísticas, filtros y exportación CSV
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-03.02
   * - **Nombre**
     - Retornar el listado paginado de suscriptores con estadísticas
       globales, filtros por estado y capacidad de desuscripción manual
       con auditoría
   * - **UC Origen**
     - UC-NEW-03: Gestionar Suscriptores (Admin)
   * - **Paso UC**
     - Pasos 2, 4, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el listado paginado de suscriptores con
   estadísticas globales y filtros por estado, permitir la desuscripción
   manual con registro de auditoría, y generar la exportación en CSV
   con los datos mínimos exigidos por GDPR CUANDO el admin accede
   al panel de gestión de suscriptores.

**Descripcion:**

**Listado y estadísticas (pasos 2 y 4):**

La respuesta incluye siempre dos bloques: las estadísticas globales
del newsletter y la lista paginada de suscriptores con los filtros
activos.

Las estadísticas globales comprenden el total de suscriptores activos,
la fecha de la última suscripción confirmada y la tasa de desuscripción
del mes en curso. Estas métricas se calculan sobre el total de la lista,
sin importar el filtro que el admin tenga activo en ese momento.

Los filtros disponibles sobre el listado son: estado del suscriptor
(``ACTIVE``, ``PENDING``, ``UNSUBSCRIBED``), rango de fechas de
suscripción, y orden por fecha ascendente o descendente. Los filtros
son acumulables.

**Desuscripción manual con auditoría (pasos 6 y 7):**

Cuando el admin desuscribe a un suscriptor a petición del titular
—por ejemplo, porque el titular contactó por teléfono o en persona—
el sistema registra el evento con el motivo ``SOLICITUD_MANUAL`` y el
admin responsable. Este registro es obligatorio para demostrar
conformidad ante una solicitud de derecho de supresión bajo GDPR.

La desuscripción manual produce el mismo efecto que la realizada
por el propio suscriptor: el estado pasa a ``UNSUBSCRIBED`` de
forma inmediata y la cuenta queda excluida de las siguientes campañas.

**Exportación CSV (Alt. B y C):**

La exportación contiene únicamente los campos mínimos necesarios:
email y fecha de suscripción. No se incluyen datos personales
adicionales. El archivo se genera y entrega directamente al
navegador del admin sin almacenarse en el servidor.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Listado con estadísticas globales
   DADO lista con 1200 suscriptores activos, 45 pendientes y 80 desuscritos
   CUANDO el admin accede al panel sin filtros activos
   ENTONCES la respuesta incluye total_active=1200, last_subscribed=fecha
   Y monthly_unsub_rate calculado sobre el mes en curso
   Y los 1325 suscriptores paginados de 20 en 20

   Escenario 2: Filtro por estado PENDING
   DADO la misma lista
   CUANDO el admin filtra por estado=PENDING
   ENTONCES el listado muestra solo los 45 suscriptores pendientes
   Y las estadísticas globales siguen mostrando los totales sin filtro

   Escenario 3: Desuscripción manual por solicitud del titular
   DADO suscriptor "carlos@ejemplo.com" que llamó pidiendo ser removido
   CUANDO el admin lo desuscribe desde el panel con motivo SOLICITUD_MANUAL
   ENTONCES el estado del suscriptor pasa a UNSUBSCRIBED de inmediato
   Y el registro de auditoría guarda el admin responsable y el motivo
   Y el suscriptor queda excluido de la siguiente campaña

   Escenario 4: Exportación CSV con datos mínimos GDPR
   DADO admin que exporta la lista de suscriptores activos
   CUANDO descarga el archivo
   ENTONCES el CSV contiene solo las columnas email y fecha_suscripcion
   Y el archivo se descarga directamente sin quedar almacenado en el servidor

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms para el listado
  incluyendo el cálculo de estadísticas), RNF-SEC-003 (acceso
  restringido a admins con permisos de marketing)
- **Notas:** La exportación CSV no incluye nombre, IP ni ningún otro
  dato personal más allá del email y la fecha. Esta restricción deriva
  del principio de minimización de datos de GDPR y no es configurable
  por el admin.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW-03: Gestionar Suscriptores
   * - **Depende de**
     - FR-NEW-01.02 (los suscriptores existen en el repositorio),
       FR-NEW-02.02 (los desuscritos tienen el estado correcto)
   * - **Requerido por**
     - FR-NEW-04.02 (al enviar una campaña se consulta la lista
       de suscriptores ACTIVE generada por este FR)
   * - **Test**
     - TST-FR-NEW-03.02 (pendiente — verificar que el CSV no incluye
       columnas adicionales; verificar que la desuscripción manual
       crea el registro de auditoría con SOLICITUD_MANUAL)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: estadísticas, desuscripción manual con
       auditoría GDPR, exportación CSV con datos mínimos, 4 escenarios
       BDD, trazabilidad completa

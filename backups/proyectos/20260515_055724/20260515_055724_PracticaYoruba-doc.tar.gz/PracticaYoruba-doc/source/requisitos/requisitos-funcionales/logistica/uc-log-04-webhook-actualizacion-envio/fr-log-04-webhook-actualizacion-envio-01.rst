.. meta::
   :artefacto: FR-LOG-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-04-01:

FR-LOG-04.01: Procesar webhook de actualizacion del courier
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-04.01
   * - **Nombre**
     - Procesar webhook de actualizacion del courier
   * - **UC Origen**
     - UC-LOG 04 WEBHOOK ACTUALIZACION ENVIO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar el evento de envio e idempotente CUANDO el courier envia una actualizacion.

**Descripcion:**

El webhook del courier llega con:

- Identificador del envio en el sistema del courier
- Nuevo estado (en el formato del courier)
- Descripcion del evento
- Timestamp del evento

El sistema normaliza el estado del courier al enum interno de ``ShipmentStatus``.
Si el nuevo estado es DELIVERED: ejecuta FR-LOG-05.01 (confirmar entrega).
Idempotencia: verifica que el evento (courier_ref + timestamp) no fue procesado antes.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Actualizacion en transito
   DADO evento 'En camino a su destino' del courier
   CUANDO se procesa el webhook
   ENTONCES ShipmentEvent se crea con el estado y descripcion
   Y ShipmentGuide.status = IN_TRANSIT

   Escenario: Evento DELIVERED
   DADO evento de entrega exitosa del courier
   CUANDO se procesa
   ENTONCES ShipmentGuide.status = DELIVERED
   Y Order.status = DELIVERED
   Y se ejecuta la logica de entrega (FR-LOG-05.01)


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002 (idempotencia)`
- **Notas:** Cada courier tiene su propio formato — el normalizador es especifico por courier.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 04 WEBHOOK ACTUALIZACION ENVIO
   * - **Depende de**
     - Llamada entrante del courier
   * - **Requerido por**
     - FR-LOG-05.01 (si el evento es DELIVERED)
   * - **Test**
     - TST-FR-LOG-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 04 WEBHOOK ACTUALIZACION ENVIO

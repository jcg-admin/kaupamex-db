.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-01-ver-catalogo
=================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-01-01-listar-productos-activos
   fr-cat-01-02-recuperar-productos-paginados

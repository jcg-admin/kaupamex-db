.. meta::
   :artefacto: FR-SYS-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-sys-03-01:

FR-SYS-03.01: Notificar al admin sobre productos con stock bajo
===============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-03.01
   * - **Nombre**
     - Notificar al admin sobre productos con stock bajo
   * - **UC Origen**
     - UC-SYS 03 NOTIFICAR STOCK MINIMO
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-009 INVENTORY via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar una notificacion consolidada de productos con stock bajo CUANDO el Actor Tiempo lo dispara.

**Descripcion:**

Tarea periodica (cada hora):

1. Busca variantes con: ``0 < stock <= StockAlert.threshold AND StockAlert.is_active=True``
2. Agrupa las alertas para enviar un solo email consolidado al admin
3. Actualiza ``StockAlert.last_alerted_at = now()`` para prevenir spam
   (no se re-notifica si ``last_alerted_at > now() - 24h``)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Email de alerta consolidado
   DADO 5 variantes con stock bajo
   CUANDO la tarea detecta las alertas
   ENTONCES el admin recibe UN email con las 5 variantes listadas

   Escenario: Supresion de re-notificacion
   DADO variante que ya fue notificada hace 12 horas y sigue con stock bajo
   CUANDO la tarea se ejecuta
   ENTONCES NO se envia otro email (last_alerted_at < 24h)


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002`
- **Notas:** El email consolidado evita spam al admin cuando muchos productos caen bajo el umbral al mismo tiempo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS 03 NOTIFICAR STOCK MINIMO
   * - **Depende de**
     - Actor Tiempo (tarea periodica)
   * - **Requerido por**
     - FR-INV-01.01 (el admin ve el stock bajo en el panel)
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-SYS-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-SYS 03 NOTIFICAR STOCK MINIMO

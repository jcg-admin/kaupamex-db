.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-05-guardar-carrito
=====================================

**3 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-05-01-persistir-en-cuenta
   fr-cart-05-02-persistir-carrito-en-cuenta
   fr-cart-05-03-confirmar-guardado-y-nfr

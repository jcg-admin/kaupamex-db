.. meta::
   :artefacto: FR-RET-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-RET-01.02: Validar elegibilidad de la devolucion y registrar la solicitud
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-01.02
   * - **Nombre**
     - Verificar que la orden esta entregada y dentro del plazo, y crear ReturnRequest
   * - **UC Origen**
     - UC-RET-01: Solicitar Devolucion
   * - **Paso UC**
     - Pasos 2, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden esta en estado DELIVERED
   y que la solicitud esta dentro del plazo de devolucion configurado
   antes de crear el ReturnRequest CUANDO el comprador solicita devolver.

**Descripcion:**

El sistema valida dos condiciones en orden antes de crear la solicitud:

1. ``Order.status`` debe ser ``'DELIVERED'`` → ``ORDEN_NO_ENTREGADA``
   si no lo es.
2. El momento actual debe ser anterior a
   ``Order.delivered_at + SiteSettings.return_period_days`` días
   (valor por defecto 30) → ``PLAZO_VENCIDO`` con la fecha límite
   si ha expirado.

Si pasa las dos validaciones, el sistema crea un ``ReturnRequest``
con referencia a la ``Order``, el usuario que solicita, el motivo
y ``status = 'PENDING'``. Por cada item devuelto crea un
``ReturnItem`` con el ``OrderItem`` correspondiente y la cantidad.
Encola la notificación al equipo de soporte de forma asíncrona.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Solicitud dentro del plazo — registrada
   DADO orden entregada hace 10 dias con plazo de 30 dias
   CUANDO el comprador solicita devolucion
   ENTONCES ReturnRequest creado con status=PENDING
   Y el equipo de soporte es notificado

   Escenario 2: Plazo vencido — error con la fecha limite
   DADO orden entregada hace 45 dias con plazo de 30 dias
   CUANDO el comprador intenta solicitar devolucion
   ENTONCES HTTP 400 con {"codigo_error": "PLAZO_VENCIDO",
   "deadline": "2026-04-03"}

   Escenario 3: Orden no entregada — no aplica devolucion
   DADO orden en estado SHIPPED
   CUANDO el comprador intenta solicitar devolucion
   ENTONCES HTTP 400 con ORDEN_NO_ENTREGADA

----

4. Reglas y Restricciones
--------------------------

- **Notas:** El plazo de devolucion es configurable en SiteSettings
  (``return_period_days``). Default: 30 dias desde la entrega.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET-01: Solicitar Devolucion
   * - **Incluye**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **Requerido por**
     - FR-RET-02.01 (el admin revisa la solicitud)
   * - **Test**
     - TST-FR-RET-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 7 y 8 de UC-RET-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

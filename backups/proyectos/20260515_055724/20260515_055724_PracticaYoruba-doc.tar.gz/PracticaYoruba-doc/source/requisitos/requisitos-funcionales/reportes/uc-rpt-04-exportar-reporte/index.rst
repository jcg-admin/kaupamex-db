.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rpt-04-exportar-reporte
=====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rpt-04-02-generar-y-servir-archivo-exportacion
   fr-rpt-04-exportar-reporte-01

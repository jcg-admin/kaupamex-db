.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-qst-04-moderar-preguntas-admin
============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-qst-04-02-aprobar-o-rechazar-pregunta
   fr-qst-04-moderar-preguntas-admin-01

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — REVIEWS
=================================

**3 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-rev-01-dejar-resena
     - 1
   * - uc-rev-02-ver-resenas
     - 1
   * - uc-rev-03-moderar-resenas-admin
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-rev-01-dejar-resena/index
   uc-rev-02-ver-resenas/index
   uc-rev-03-moderar-resenas-admin/index

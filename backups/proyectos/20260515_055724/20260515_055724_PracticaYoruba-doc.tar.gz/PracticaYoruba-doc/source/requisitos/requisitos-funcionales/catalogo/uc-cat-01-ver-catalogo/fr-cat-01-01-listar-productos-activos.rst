.. meta::
   :artefacto: FR-CAT-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-01-01:

FR-CAT-01.01: Listar productos activos con paginacion y filtros
===============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-01.01
   * - **Nombre**
     - Listar productos activos con paginacion y filtros
   * - **UC Origen**
     - UC-CAT-01: Ver catalogo
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista paginada de productos activos CUANDO el visitante accede al catalogo.

**Descripcion:**

Filtros opcionales combinables (AND):

- ``category``: slug de la categoria
- ``min_price`` / ``max_price``: rango de precio con IVA
- ``in_stock``: solo productos con stock > 0
- ``featured``: solo productos destacados
- ``ordering``: ``-created_at`` (defecto), ``price``, ``-price``, ``name``

Cada item retorna: ``slug``, ``name``, ``category_name``,
``price_with_tax``, ``primary_image_url``, ``is_available``,
``avg_rating``, ``review_count``.

Paginacion: configurable en SiteSettings (default 20).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Catalogo sin filtros
   DADO visitante sin filtros
   CUANDO accede a GET /api/v1/catalogue/
   ENTONCES recibe los 20 productos mas recientes activos
   Y la respuesta incluye count, next, previous

   Escenario: Filtro por categoria y rango de precio
   DADO filtros ?category=orula&min_price=100&max_price=500
   CUANDO se aplican
   ENTONCES solo aparecen productos de Orula entre $100 y $500

   Escenario: Producto sin stock incluido con indicador
   DADO producto activo con stock = 0
   CUANDO aparece en el listado
   ENTONCES is_available = false
   Y el precio se muestra pero el CTA de agregar esta deshabilitado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PERF-001 (< 400ms P95)`
- :ref:`RNF-PERF-003 (paginacion obligatoria)`
- **Notas:** Los productos desactivados (is_active=False) nunca aparecen en el catalogo publico.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-01: Ver catalogo
   * - **Depende de**
     - Ninguno — punto de entrada del catalogo
   * - **Requerido por**
     - FR-CAT-02.01 (ver detalle desde el listado)
   * - **Test**
     - TST-FR-CAT-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT-01

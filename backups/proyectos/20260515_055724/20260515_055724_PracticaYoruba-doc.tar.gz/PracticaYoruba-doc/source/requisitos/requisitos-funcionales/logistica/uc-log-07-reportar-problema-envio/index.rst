.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-07-reportar-problema-envio
============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-07-02-registrar-reporte-y-notificar
   fr-log-07-reportar-problema-envio-01

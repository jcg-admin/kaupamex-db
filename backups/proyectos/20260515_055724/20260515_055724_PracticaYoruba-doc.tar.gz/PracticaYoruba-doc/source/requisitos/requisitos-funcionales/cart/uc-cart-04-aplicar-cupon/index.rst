.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-04-aplicar-cupon
===================================

**4 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-04-01-validar-voucher
   fr-cart-04-02-aplicar-descuento
   fr-cart-04-03-validar-cupon-completo
   fr-cart-04-04-persistir-cupon-y-confirmar

.. meta::
   :artefacto: FR-INC-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INC-03.02: Renderizar la plantilla y encolar el email en la cola de envio
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-03.02
   * - **Nombre**
     - Verificar preferencias del destinatario, renderizar HTML y texto plano, encolar
   * - **UC Origen**
     - UC-INC-03: Enviar Email con Plantilla (included)
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications — EmailQueue)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicacion (reutilizable)

----

2. Especificacion
-----------------

**Declaracion:**

   El include DEBE verificar las preferencias de notificacion del
   destinatario, renderizar la plantilla correspondiente al tipo de
   email y encolar el mensaje en la cola de envio CUANDO un UC
   necesita enviar una comunicacion.

**Descripcion:**

**Descripcion:**

Si el destinatario es un usuario registrado, el sistema verifica si
tiene una ``NotificationPreference`` para ese ``email_type`` con
``enabled = False``; en ese caso concluye sin crear ningún mensaje.
En caso contrario, recupera el ``EmailTemplate`` activo para el tipo
de email, renderiza el cuerpo HTML y el texto plano con el contexto
recibido, y crea un registro ``EmailQueue`` con el email del
destinatario, el asunto renderizado, ambos cuerpos, el tipo de email,
``status = 'PENDING'`` y ``retry_count = 0``. El envío real lo
realiza el procesador periódico (FR-SYS-04.02).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email encolado correctamente
   DADO UC-NOT-01 que necesita enviar confirmacion de orden
   CUANDO invoca el include con email_type=ORDER_CONFIRMATION
   ENTONCES EmailQueue.status = PENDING con el HTML renderizado
   Y el Procesador Periodico lo envia en el siguiente ciclo

   Escenario 2: Usuario con notificacion desactivada — email omitido
   DADO usuario que desactivo los emails de estado de orden
   CUANDO UC-NOT-02 invoca el include con ORDER_STATUS_UPDATE
   ENTONCES el include detecta la preferencia desactivada
   Y NO crea ningun registro en EmailQueue

   Escenario 3: Plantilla no encontrada — error con log
   DADO email_type invalido o sin plantilla activa
   CUANDO el include intenta obtener la plantilla
   ENTONCES EmailTemplate.DoesNotExist es capturada
   Y se registra en el log sin interrumpir el UC incluidor

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-003 (el include encola, no envia;
  el reintento con backoff lo gestiona FR-SYS-04.02)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC-03: Enviar Email con Plantilla
   * - **Incluido por**
     - UC-NOT-01 a UC-NOT-07, FR-LOG-01.02, FR-ORD-04.04,
       FR-RET-02.02 y muchos otros
   * - **Requerido por**
     - FR-SYS-04.02 (procesador de cola de emails)
   * - **Test**
     - TST-FR-INC-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-INC-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

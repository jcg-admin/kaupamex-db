.. meta::
   :artefacto: FR-REV-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-REV-03.02: Aprobar o rechazar la resena con registro de auditoria
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-03.02
   * - **Nombre**
     - Cambiar el estado de la resena, notificar al comprador y registrar en auditoria
   * - **UC Origen**
     - UC-REV-03: Moderar Resenas (Admin)
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el estado de la resena, notificar al
   comprador del resultado y registrar la moderacion en auditoria
   CUANDO el admin toma una decision de moderacion.

**Descripcion:**

**Descripcion:**

El sistema actualiza ``Review.status`` a ``'APPROVED'`` o
``'REJECTED'`` según la decisión, registra ``Review.moderated_by``,
``Review.moderation_reason`` y ``Review.moderated_at``. Encola la
notificación al comprador de forma asíncrona. Crea un
``ReviewModerationLog`` con la acción, el administrador y el motivo.
Si la decisión es aprobación, invalida la entrada del cache de detalle
del producto afectado.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Resena aprobada — visible en el producto
   DADO resena en PENDING_MODERATION
   CUANDO el admin la aprueba
   ENTONCES Review.status = APPROVED
   Y el cache de la ficha del producto se invalida
   Y la resena aparece en FR-REV-02.02

   Escenario 2: Resena rechazada — con motivo
   DADO resena con contenido inapropiado
   CUANDO el admin la rechaza con razon "lenguaje inapropiado"
   ENTONCES Review.status = REJECTED
   Y ReviewModerationLog creado con el motivo

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria de moderacion de contenido)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV-03: Moderar Resenas
   * - **Depende de**
     - FR-REV-01.02 (la resena fue creada en PENDING_MODERATION)
   * - **Requerido por**
     - FR-REV-02.02 (solo muestra resenas APPROVED)
   * - **Test**
     - TST-FR-REV-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5-8 de UC-REV-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-RET-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ret-02-01:

FR-RET-02.01: Revisar y decidir sobre la solicitud
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-02.01
   * - **Nombre**
     - Revisar y decidir sobre la solicitud
   * - **UC Origen**
     - UC-RET 02 REVISAR SOLICITUD DEVOLUCION
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cambiar el estado de la solicitud y ejecutar los efectos CUANDO el admin decide.

**Descripcion:**

Decisiones posibles:

- **APROBAR**: status=APPROVED, inicia reembolso en MOD-PAYMENT
- **RECHAZAR**: status=REJECTED con motivo obligatorio
- **SOLICITAR_INFO**: status=PENDING_INFO, notifica al comprador

Solo el admin con permisos de devoluciones puede decidir.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Aprobacion total
   DADO solicitud en PENDING_REVIEW
   CUANDO el admin aprueba
   ENTONCES status=APPROVED y se inicia el reembolso
   Y el comprador recibe instrucciones de como enviar el producto

   Escenario: Rechazo con motivo
   DADO solicitud en PENDING_REVIEW
   CUANDO el admin rechaza con motivo 'Producto sin defecto aparente'
   ENTONCES status=REJECTED y el comprador recibe el motivo por email


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El reembolso se inicia de forma asincrona — la solicitud queda APPROVED de inmediato.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET 02 REVISAR SOLICITUD DEVOLUCION
   * - **Depende de**
     - FR-RET-01.01 (solicitud creada)
   * - **Requerido por**
     - FR-RET-03.01 (recepcion del producto)
   * - **Test**
     - TST-FR-RET-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RET 02 REVISAR SOLICITUD DEVOLUCION

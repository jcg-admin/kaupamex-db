.. meta::
   :artefacto: FR-LOG-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-07.02: Registrar el reporte de problema y notificar al equipo de soporte
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-07.02
   * - **Nombre**
     - Validar el formulario de reporte, persistir el incidente y notificar al equipo
   * - **UC Origen**
     - UC-LOG-07: Reportar Problema de Envio
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formulario de reporte, crear el registro
   del incidente y notificar al equipo de soporte de forma asincrona
   CUANDO el comprador reporta un problema con su envio.

**Descripcion:**

**Descripcion:**

Si la ``Order`` no tiene ``ShipmentGuide`` asociada →
``SIN_GUIA_DE_ENVIO``. En caso contrario, el sistema crea un
``ShipmentIncident`` con referencia a la ``ShipmentGuide``, al
usuario que reporta, el tipo de problema
(``LOST``, ``DAMAGED``, ``DELAYED`` o ``WRONG_ADDRESS``),
la descripción truncada a 1000 caracteres y estado ``'OPEN'``.
Encola la notificación al equipo de soporte de forma asíncrona.

Tipos de problema disponibles: LOST (paquete perdido), DAMAGED
(paquete danahado), DELAYED (retraso excesivo), WRONG_ADDRESS
(direccion incorrecta en la guia).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reporte registrado y soporte notificado
   DADO comprador que reporta su paquete como perdido
   CUANDO envia el formulario
   ENTONCES ShipmentIncident creado con status=OPEN
   Y el equipo de soporte recibe la notificacion en <= 5 minutos
   Y el comprador ve el mensaje "Responderemos en 24 horas habiles"

   Escenario 2: Orden sin guia de envio — error claro
   DADO orden en PAYMENT_CONFIRMED sin guia creada
   CUANDO el comprador intenta reportar un problema
   ENTONCES HTTP 400 con "Tu orden aun no ha sido enviada."

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (ShipmentIncident.created_at automatico)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-07: Reportar Problema de Envio
   * - **Incluye**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **Test**
     - TST-FR-LOG-07.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-6 de UC-LOG-07
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

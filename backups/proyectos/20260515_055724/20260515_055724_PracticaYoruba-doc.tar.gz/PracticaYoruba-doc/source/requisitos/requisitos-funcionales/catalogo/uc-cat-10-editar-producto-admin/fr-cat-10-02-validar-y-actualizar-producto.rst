.. meta::
   :artefacto: FR-CAT-10.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-10.02: Validar campos modificados, persistir y purgar cache del producto
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-10.02
   * - **Nombre**
     - Aplicar cambios al producto, actualizar imagenes y purgar el cache de la ficha
   * - **UC Origen**
     - UC-CAT-10: Editar Producto (Admin)
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar los campos modificados del producto,
   persistir los cambios y purgar el cache de la ficha del producto
   CUANDO el admin guarda una edicion.

**Descripcion:**

La edicion usa PATCH semantics: solo los campos enviados en el body
se validan y actualizan. Los campos ausentes no se modifican.

Tras el guardado exitoso, se invalidan las claves de cache:

- ``product:{pk}:detail`` — la ficha del producto
- ``catalogue:page:*`` — todas las paginas del catalogo (si cambio el precio)
- ``categories:tree`` — solo si cambio la categoria del producto

Si el precio ``base_price`` cambia: se actualiza el snapshot del carrito
para los visitantes que tenian este producto en su carrito. Esto ocurre
de forma transparente: al recargar el carrito (FR-CART-02.04), el sistema
detecta la diferencia y notifica al visitante.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Precio editado — cache purgado
   DADO admin que cambia base_price de 850 a 900
   CUANDO guarda
   ENTONCES Product.base_price = 900 en la BD
   Y el cache product:{pk}:detail es eliminado
   Y la proxima vez que un visitante vea la ficha, vera el precio actualizado

   Escenario 2: Edicion de descripcion — cache de ficha purgado
   DADO admin que actualiza la descripcion
   CUANDO guarda
   ENTONCES solo el cache product:{pk}:detail se invalida
   Y el cache del catalogo general no se purga (el precio no cambio)

   Escenario 3: Cambio de categoria
   DADO admin que mueve un producto de "Soperas" a "Collares"
   CUANDO guarda
   ENTONCES el producto desaparece de la categoria "Soperas"
   Y aparece en "Collares"
   Y el cache categories:tree se invalida (cambiaron los product_count)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (snapshot inmutable — los OrderItems
  existentes NO se ven afectados por el cambio de precio; el precio
  del snapshot de la orden queda como estaba al momento del checkout)
- **BR-001** (base_price es sin IVA)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-10: Editar Producto
   * - **Depende de**
     - FR-CAT-09.02 (el producto fue creado previamente)
   * - **Test**
     - TST-FR-CAT-10.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-CAT-10
   * - 1.1.0
     - 2026-05-05
     - Verificacion de nombres canonicos. Sin codigo Python. Nombres de modelos correctos.

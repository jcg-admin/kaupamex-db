.. meta::
   :artefacto: FR-AUTH-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-07.01: Listar direcciones del comprador
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-07.01
   * - **Nombre**
     - Recuperar y presentar las direcciones guardadas del comprador
   * - **UC Origen**
     - UC-AUTH-07: Gestionar direcciones
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista de direcciones del comprador
   CUANDO accede a la seccion de gestion de direcciones.

**Descripcion:**

Cada direccion retornada incluye:

- ``id``, ``alias`` (nombre del comprador para identificarla, ej: "Casa", "Trabajo")
- ``recipient_name``, ``street``, ``city``, ``state``, ``zip_code``, ``country``
- ``phone`` (telefono del destinatario)
- ``is_default`` — booleano indicando si es la direccion predeterminada para checkout

El comprador puede tener maximo **5 direcciones** guardadas
(configurable en SiteSettings). La respuesta incluye cuantas le
quedan disponibles.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado
   CUANDO accede a GET /api/v1/auth/addresses/
   ENTONCES ve su lista de direcciones

   Escenario 1: Sin direcciones guardadas
   DADO comprador sin ninguna direccion
   CUANDO lista las direcciones
   ENTONCES respuesta 200 con lista vacia []
   Y se informa que puede agregar hasta 5 direcciones

   Escenario 2: Multiples direcciones
   DADO comprador con 3 direcciones una marcada como default
   CUANDO lista
   ENTONCES las 3 aparecen ordenadas: default primero, luego por fecha
   Y is_default=true solo en una de ellas

   Escenario 3: Aislamiento
   DADO comprador A autenticado
   CUANDO lista sus direcciones
   ENTONCES solo ve SUS direcciones, nunca las de otro comprador

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF:** RNF-SEC-003 (aislamiento)
- **Notas:** El limite de 5 direcciones se verifica en FR-AUTH-07.02.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-07: Gestionar direcciones
   * - **Depende de**
     - FR-AUTH-02.03 (sesion activa)
   * - **Requerido por**
     - FR-AUTH-07.02 (crear/editar direccion), FR-ORD-01 (checkout usa esta lista)
   * - **Test**
     - TST-FR-AUTH-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-07

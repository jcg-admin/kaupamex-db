.. meta::
   :artefacto: FR-NEW-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-new-04-01:

FR-NEW-04.01: Crear y enviar campana de newsletter
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-04.01
   * - **Nombre**
     - Crear y enviar campana de newsletter
   * - **UC Origen**
     - UC-NEW 04 ENVIAR CAMPANA NEWSLETTER
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-016 NEWSLETTER via UC-INC-03
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE enviar el newsletter a todos los suscriptores activos CUANDO el admin confirma el envio.

**Descripcion:**

``NewsletterCampaign`` se crea con subject, content_html y la lista de destinatarios.
El envio se ejecuta en cola — no bloqueante.
Cada email incluye el enlace de desuscripcion con token unico por suscriptor.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Campana enviada exitosamente
   DADO 500 suscriptores activos
   CUANDO el admin confirma la campana
   ENTONCES 500 emails se encolan para envio
   Y la campana queda con status=ENVIADA

   Escenario: Vista previa antes de enviar
   DADO admin que quiere revisar el email antes
   CUANDO solicita vista previa
   ENTONCES el admin recibe el email en su propio correo como prueba


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Cada email tiene un enlace de desuscripcion unico — no un enlace generico.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW 04 ENVIAR CAMPANA NEWSLETTER
   * - **Depende de**
     - FR-NEW-03.01 (lista de suscriptores)
   * - **Requerido por**
     - Ninguno
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-NEW-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NEW 04 ENVIAR CAMPANA NEWSLETTER

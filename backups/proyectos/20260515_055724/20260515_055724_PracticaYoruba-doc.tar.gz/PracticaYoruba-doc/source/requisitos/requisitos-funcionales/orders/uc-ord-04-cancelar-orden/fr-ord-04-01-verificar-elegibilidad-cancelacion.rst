.. meta::
   :artefacto: FR-ORD-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-04-01:

==========================================================
FR-ORD-04.01: Verificar elegibilidad para cancelacion
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-04.01
   * - **Nombre**
     - Verificar que la orden puede ser cancelada por el comprador
   * - **UC Origen**
     - UC-ORD-04: Cancelar orden
   * - **Paso UC**
     - Pasos 2-3 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden esta en un estado que
   permite la cancelacion por el comprador CUANDO lo solicita.

**Descripcion:**

Estados cancelables por el comprador:

- ``PENDING_PAYMENT`` — puede cancelar sin restriccion
- ``PAYMENT_CONFIRMED`` — puede cancelar si el admin aun no
  inicio la preparacion (configurable, ventana de cancelacion)

Estados NO cancelables por el comprador:

- ``IN_PREPARATION`` — en proceso, requiere intervencion del admin
- ``SHIPPED`` — ya enviada, requiere gestion de devolucion
- ``DELIVERED`` — entregada, solo devolucion (UC-RET-01)
- ``CANCELLED`` / ``CANCELLED_TIMEOUT`` — ya cancelada

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador que solicita cancelar su orden
   CUANDO se verifica la elegibilidad
   ENTONCES solo procede si el estado lo permite

   Escenario 1: Orden en PENDING_PAYMENT — cancelable
   DADO orden con status = PENDING_PAYMENT
   CUANDO se verifica
   ENTONCES es elegible para cancelacion
   Y proceso continua a FR-ORD-04.02

   Escenario 2: Orden en SHIPPED — no cancelable
   DADO orden con status = SHIPPED
   CUANDO se verifica
   ENTONCES error 422: CANCELACION_NO_PERMITIDA
   Y el mensaje sugiere iniciar una devolucion al recibirla

   Escenario 3: Orden ya cancelada
   DADO orden con status = CANCELLED
   CUANDO se intenta cancelar de nuevo
   ENTONCES error 422: ORDEN_YA_CANCELADA

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **Notas:** El admin puede cancelar ordenes en estados mas avanzados
  mediante UC-ORD-08 (cancelacion admin). Esta verificacion es solo
  para la cancelacion por el comprador.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-04: Cancelar orden
   * - **Depende de**
     - FR-ORD-02.01 (propiedad verificada via INC-01)
   * - **Requerido por**
     - FR-ORD-04.02 (ejecutar la cancelacion)
   * - **Include**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-ORD-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-04

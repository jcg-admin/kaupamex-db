.. meta::
   :artefacto: FR-REV-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reviews
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rev-02-01:

FR-REV-02.01: Listar resenas aprobadas del producto
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-REV-02.01
   * - **Nombre**
     - Listar resenas aprobadas del producto
   * - **UC Origen**
     - UC-REV 02 VER RESENAS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-012 REVIEW
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las resenas aprobadas CUANDO el visitante consulta un producto.

**Descripcion:**

Lista paginada con:

- ``rating``, ``title``, ``body``
- ``reviewer_name`` (first_name o 'Comprador verificado')
- ``created_at``, imagenes
- Promedio general y distribucion por estrella

Solo resenas con ``status=APPROVED`` son visibles publicamente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Producto con resenas
   DADO producto con 10 resenas aprobadas
   CUANDO se consultan
   ENTONCES aparecen las 10 con el promedio calculado

   Escenario: Sin resenas aprobadas
   DADO producto nuevo sin resenas
   CUANDO se consultan
   ENTONCES lista vacia y promedio=0


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Las resenas PENDING o REJECTED no son visibles para el visitante.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-REV 02 VER RESENAS
   * - **Depende de**
     - Ninguno — consulta publica
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-REV-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-REV 02 VER RESENAS

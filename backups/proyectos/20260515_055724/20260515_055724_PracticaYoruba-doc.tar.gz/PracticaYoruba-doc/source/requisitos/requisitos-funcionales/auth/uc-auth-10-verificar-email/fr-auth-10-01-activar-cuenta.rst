.. meta::
   :artefacto: FR-AUTH-10.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-10.01: Activar cuenta al verificar email
=================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-10.01
   * - **Nombre**
     - Validar token de verificacion y activar la cuenta
   * - **UC Origen**
     - UC-AUTH-10: Verificar email
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el token de verificacion y cambiar
   ``is_active`` a ``True`` CUANDO el comprador sigue el enlace
   del email de verificacion.

**Descripcion:**

Proceso:

1. Extrae el token del query parameter ``?token=``
2. Verifica la firma HMAC del token
3. Verifica que no este expirado (24 horas)
4. Verifica que no haya sido usado (idempotente: si ya esta activo
   la respuesta es exitosa igualmente)
5. ``user.is_active = True`` + ``user.save()``
6. Invalida el token de verificacion (marca como usado)

Respuesta exitosa: redirige a login con mensaje de exito o
retorna 200 si es una API call directa.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO token de verificacion valido
   CUANDO el comprador sigue el enlace
   ENTONCES la cuenta queda activa

   Escenario 1: Verificacion exitosa primera vez
   DADO token valido y cuenta inactiva
   CUANDO se verifica
   ENTONCES is_active = True
   Y el comprador puede hacer login

   Escenario 2: Idempotencia — cuenta ya activa
   DADO token valido pero cuenta ya verificada previamente
   CUANDO se usa el enlace de nuevo
   ENTONCES respuesta exitosa (200) sin error
   Y is_active permanece True (sin cambio)

   Escenario 3: Token expirado (mas de 24h)
   DADO token de mas de 24 horas
   CUANDO se intenta usar
   ENTONCES error 400 con opcion de solicitar nuevo enlace

   Escenario 4: Rate limit reenvio
   DADO comprador que solicito reenvio 3 veces en la ultima hora
   CUANDO solicita un cuarto reenvio
   ENTONCES error 429 con Retry-After

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting para reenvios)
- **Notas:** Maximo 3 reenvios del email de verificacion por hora.
  El limite es por cuenta, no por IP, para evitar abuso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-10: Verificar email
   * - **Depende de**
     - FR-AUTH-01.05 (email de verificacion enviado al registrar)
   * - **Requerido por**
     - FR-AUTH-02.02 (login requiere is_active=True)
   * - **Test**
     - TST-FR-AUTH-10.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-10

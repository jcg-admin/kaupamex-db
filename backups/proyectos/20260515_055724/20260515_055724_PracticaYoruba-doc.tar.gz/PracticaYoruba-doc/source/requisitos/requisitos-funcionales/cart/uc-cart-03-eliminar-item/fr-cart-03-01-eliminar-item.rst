.. meta::
   :artefacto: FR-CART-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-03-01:

==============================================
FR-CART-03.01: Eliminar item del carrito
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-03.01
   * - **Nombre**
     - Eliminar el CartItem del carrito y actualizar los totales
   * - **UC Origen**
     - UC-CART-03: Eliminar item del carrito
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE eliminar el CartItem y recalcular los totales
   CUANDO el actor solicita quitar un item del carrito.

**Descripcion:**

Proceso de eliminacion:

1. Verifica que el CartItem pertenece al carrito activo del actor
2. ``CartItem.delete()``
3. Si el carrito queda vacio y tenia un voucher aplicado:
   el voucher se mantiene aplicado (el descuento sera 0 con carrito
   vacio pero el codigo queda listo para cuando se agregue un item)
4. Recalcula y retorna el carrito completo actualizado

Comportamiento especial cuando queda el ultimo item:

- El carrito queda en estado vacio (``items: []``)
- Se muestra CTA de "Continuar comprando" apuntando al catalogo
- No se elimina el objeto Cart, solo el CartItem

----

3. Criterio de Aceptacion
--------------------------

::

   DADO actor con un item en el carrito que quiere eliminar
   CUANDO hace DELETE /api/v1/cart/items/{id}/
   ENTONCES el item desaparece del carrito

   Escenario 1: Eliminacion exitosa con items restantes
   DADO carrito con 3 items
   CUANDO se elimina uno
   ENTONCES quedan 2 items
   Y los totales se recalculan sin ese item

   Escenario 2: Eliminacion del ultimo item
   DADO carrito con 1 solo item
   CUANDO se elimina
   ENTONCES items: []
   Y total: 0, subtotal: 0

   Escenario 3: Item de otro carrito
   DADO CartItem que pertenece al carrito de otro usuario
   CUANDO se intenta eliminar
   ENTONCES error 404 (sin revelar que existe)

   Escenario 4: CartItem inexistente
   DADO ID de CartItem que no existe
   CUANDO se intenta eliminar
   ENTONCES error 404

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **Notas:** No existe "reducir cantidad en 1" como operacion separada.
  Para cambiar la cantidad se usa PUT /api/v1/cart/items/{id}/
  con el nuevo valor de quantity.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-03: Eliminar item del carrito
   * - **Depende de**
     - FR-CART-02.01 (carrito activo identificado)
   * - **Requerido por**
     - FR-CART-02.02 (totales actualizados tras la eliminacion)
   * - **Test**
     - TST-FR-CART-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-03

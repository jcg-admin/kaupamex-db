.. meta::
   :artefacto: FR-CAT-09.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-09-01:

FR-CAT-09.01: Crear producto con validacion de SKU unico
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-09.01
   * - **Nombre**
     - Crear producto con validacion de SKU unico
   * - **UC Origen**
     - UC-CAT 09 CREAR PRODUCTO ADMIN
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos / Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear el producto con todos sus campos CUANDO el administrador completa el formulario.

**Descripcion:**

Campos obligatorios: ``name``, ``sku``, ``category``, ``price``, ``description``.
``sku`` debe ser unico en todo el catalogo (case-insensitive).
Estado inicial: ``is_active=True``, ``is_featured=False``, ``stock=0``.
Al menos una imagen es recomendada (advertencia si no se sube ninguna).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: SKU duplicado
   DADO sku 'ORU-001' ya existente
   CUANDO el admin intenta crear un producto con ese sku
   ENTONCES error 409: SKU_DUPLICADO

   Escenario: Producto creado exitosamente
   DADO todos los campos validos y sku unico
   CUANDO se crea
   ENTONCES el producto aparece en el catalogo si is_active=True
   Y stock=0 hasta que se actualice desde inventario


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** N/A

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 09 CREAR PRODUCTO ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-INV-04.01 (ajustar stock del nuevo producto)
   * - **Test**
     - TST-FR-CAT-09.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 09 CREAR PRODUCTO ADMIN

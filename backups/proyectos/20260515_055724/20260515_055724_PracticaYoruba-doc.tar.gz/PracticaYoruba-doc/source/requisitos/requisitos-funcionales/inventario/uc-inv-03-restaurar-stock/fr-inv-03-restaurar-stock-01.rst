.. meta::
   :artefacto: FR-INV-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inv-03-01:

FR-INV-03.01: Restaurar stock al cancelar orden — idempotente
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-03.01
   * - **Nombre**
     - Restaurar stock al cancelar orden — idempotente
   * - **UC Origen**
     - UC-INV 03 RESTAURAR STOCK
   * - **Paso UC**
     - Tras UC-ORD-04.02 o UC-ORD-08.01
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE restaurar el stock decrementado CUANDO la orden es cancelada.

**Descripcion:**

Por cada OrderItem de la orden cancelada:

1. Busca el StockMovement de tipo SALE con reference_id = order_number
2. Si ya existe un StockMovement de tipo CANCELLATION para esa orden: no hace nada (idempotente)
3. Si no: ``variant.stock += order_item.quantity`` con ``select_for_update()``
4. Crea StockMovement(CANCELLATION, +quantity)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Restauracion exitosa
   DADO orden cancelada con 2 items decrementados
   CUANDO se restaura el stock
   ENTONCES cada variante incrementa su stock en la cantidad del OrderItem

   Escenario: Restauracion idempotente
   DADO restauracion ya ejecutada para esta orden
   CUANDO se llama de nuevo
   ENTONCES no se modifica nada — retorna OK sin errores


----

4. Reglas y Restricciones
--------------------------

- **BR-005 (usa las cantidades del snapshot OrderItem)**

- :ref:`RNF-AVAIL-002`
- **Notas:** La idempotencia previene doble restauracion si el proceso de cancelacion se ejecuta dos veces.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV 03 RESTAURAR STOCK
   * - **Depende de**
     - FR-ORD-04.02 o FR-ORD-08.01 (orden cancelada)
   * - **Requerido por**
     - Ninguno — fin del flujo
   * - **Test**
     - TST-FR-INV-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INV 03 RESTAURAR STOCK

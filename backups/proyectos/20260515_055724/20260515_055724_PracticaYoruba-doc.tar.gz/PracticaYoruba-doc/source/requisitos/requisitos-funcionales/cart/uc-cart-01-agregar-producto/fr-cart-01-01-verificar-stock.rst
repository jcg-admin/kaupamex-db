.. meta::
   :artefacto: FR-CART-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-01-01:

==================================================
FR-CART-01.01: Verificar disponibilidad de stock
==================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-01.01
   * - **Nombre**
     - Verificar que la variante solicitada tiene stock disponible
   * - **UC Origen**
     - UC-CART-01: Agregar producto al carrito
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-005 CART + MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que ``ProductVariant.stock > 0``
   CUANDO el visitante intenta agregar un producto al carrito.

**Descripcion:**

Logica de verificacion:

1. Si el producto no tiene variantes: verifica ``Product.stock``
2. Si el producto tiene variantes: verifica ``ProductVariant.stock``
   para la variante especifica solicitada
3. Si el item ya existe en el carrito: verifica que
   ``stock_actual >= cantidad_en_carrito + cantidad_solicitada``
4. No reserva stock en este momento — la reserva ocurre en checkout
   (UC-ORD-01). El carrito es optimista.

Si el producto esta activo pero sin stock se puede agregar con
indicador visual de "sin stock" solo si SiteSettings lo permite
(configurable). Por defecto se bloquea la adicion.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO visitante que quiere agregar un producto
   CUANDO el sistema verifica el stock
   ENTONCES solo procede si hay disponibilidad

   Escenario 1: Stock disponible
   DADO variante con stock = 5 y cantidad solicitada = 1
   CUANDO se verifica
   ENTONCES hay disponibilidad
   Y el proceso continua a FR-CART-01.02

   Escenario 2: Producto sin stock
   DADO variante con stock = 0
   CUANDO se verifica
   ENTONCES error 409: codigo PRODUCTO_SIN_STOCK
   Y el carrito no se modifica

   Escenario 3: Incremento supera el stock
   DADO variante con stock = 2 y ya hay 2 en el carrito
   CUANDO se intenta agregar 1 mas
   ENTONCES error 409: codigo STOCK_INSUFICIENTE
   Y el mensaje indica el maximo disponible (2)

   Escenario 4: Variante desactivada
   DADO variante con is_active = False
   CUANDO se intenta agregar
   ENTONCES error 404: el producto no esta disponible

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica en verificacion de stock
- **Notas:** El stock no se decrementa aqui. Solo se decrementa
  cuando la orden es confirmada (FR-INV-02.01).
  El carrito es una estructura optimista que puede quedar con items
  cuyo stock cambie mientras el comprador navega.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-01: Agregar producto al carrito
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-CART-01.02 (agregar item al carrito)
   * - **RNF**
     - RNF-PERF-001 (respuesta < 400ms P95)
   * - **Test**
     - TST-FR-CART-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-01

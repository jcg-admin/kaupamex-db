.. meta::
   :artefacto: FR-ORD-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-03-01:

=====================================================
FR-ORD-03.01: Listar historial de ordenes
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-03.01
   * - **Nombre**
     - Retornar el historial paginado de ordenes del comprador
   * - **UC Origen**
     - UC-ORD-03: Listar ordenes
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER (apps.orders)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el historial paginado de ordenes del
   comprador autenticado CUANDO las consulta.

**Descripcion:**

Cada item del listado incluye:

- ``order_number``, ``status``, ``created_at``
- ``total`` (del OrderValue)
- ``items_count`` (numero de lineas de la orden)
- ``thumbnail_url`` (imagen del primer item para identificacion rapida)
- Acciones disponibles segun el estado

Ordenamiento: mas reciente primero (``-created_at``).
Paginacion: 10 ordenes por pagina (configurable en SiteSettings).
Filtros opcionales: ``?status=DELIVERED``, ``?date_from=``, ``?date_to=``

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado
   CUANDO consulta GET /api/v1/orders/
   ENTONCES ve sus ordenes paginadas

   Escenario 1: Sin ordenes
   DADO comprador sin ninguna orden
   CUANDO lista
   ENTONCES respuesta 200 con results: [] y count: 0

   Escenario 2: Mas de 10 ordenes — paginacion
   DADO comprador con 25 ordenes
   CUANDO consulta la primera pagina
   ENTONCES recibe 10 ordenes con next apuntando a la pagina 2

   Escenario 3: Filtro por estado
   DADO comprador con ordenes en distintos estados
   CUANDO filtra por ?status=DELIVERED
   ENTONCES solo recibe ordenes entregadas

   Escenario 4: Aislamiento
   DADO comprador A con 5 ordenes y comprador B con 3 ordenes
   CUANDO comprador A lista sus ordenes
   ENTONCES solo ve sus 5 ordenes, nunca las de B

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF:** RNF-SEC-003 (aislamiento), RNF-PERF-001 (< 400ms P95)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-03: Listar ordenes
   * - **Depende de**
     - FR-AUTH-02.03 (sesion activa)
   * - **Requerido por**
     - FR-ORD-02.01 (el comprador navega al detalle desde el listado)
   * - **RNF**
     - RNF-SEC-003, RNF-PERF-003 (paginacion)
   * - **Test**
     - TST-FR-ORD-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-03

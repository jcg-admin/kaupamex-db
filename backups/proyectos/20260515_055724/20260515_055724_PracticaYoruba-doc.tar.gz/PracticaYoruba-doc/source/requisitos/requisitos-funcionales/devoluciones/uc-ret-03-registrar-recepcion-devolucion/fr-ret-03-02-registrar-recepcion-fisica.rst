.. meta::
   :artefacto: FR-RET-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-RET-03.02: Registrar la recepcion fisica del producto devuelto
=================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-03.02
   * - **Nombre**
     - Marcar la devolucion como completada y notificar al comprador de la recepcion
   * - **UC Origen**
     - UC-RET-03: Registrar Recepcion de Devolucion (Admin)
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el estado de la devolucion a COMPLETED,
   restaurar el stock si el producto esta en condiciones y notificar
   al comprador de la recepcion CUANDO el admin confirma la recepcion.

**Descripcion:**

En una transacción atómica: el sistema establece
``ReturnRequest.status = 'COMPLETED'``, registra
``ReturnRequest.received_at`` y ``ReturnRequest.product_condition``
(``GOOD``, ``DAMAGED`` o ``UNUSABLE``). Si la condición es ``GOOD``,
para cada ``ReturnItem`` incrementa ``ProductVariant.stock`` en la
cantidad devuelta y crea un ``StockMovement`` de tipo ``'RETURN'``
con referencia ``RET:<return_request_pk>``. Encola la notificación
al comprador de forma asíncrona.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto en buen estado — stock restaurado
   DADO devolucion aprobada con producto en condicion GOOD
   CUANDO el admin confirma la recepcion
   ENTONCES ReturnRequest.status = COMPLETED
   Y el stock del producto aumenta en la cantidad devuelta
   Y StockMovement RETURN creado

   Escenario 2: Producto danahado — sin restauracion de stock
   DADO producto recibido en condicion DAMAGED
   CUANDO el admin registra la recepcion
   ENTONCES ReturnRequest.status = COMPLETED
   Y el stock NO se restaura (el producto no se puede revender)

----

4. Reglas y Restricciones
--------------------------

- **Notas:** La notificacion al comprador confirma la recepcion pero
  no indica el estado del reembolso — el reembolso ya fue procesado
  en FR-RET-02.02 cuando se aprobo la solicitud.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET-03: Registrar Recepcion
   * - **Depende de**
     - FR-RET-02.02 (solicitud aprobada)
   * - **Test**
     - TST-FR-RET-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-6 de UC-RET-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

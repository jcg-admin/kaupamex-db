.. meta::
   :artefacto: FR-AUTH-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-07.02: Crear o editar una direccion
============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-07.02
   * - **Nombre**
     - Persistir nueva direccion o actualizar una existente
   * - **UC Origen**
     - UC-AUTH-07: Gestionar direcciones
   * - **Paso UC**
     - Pasos 3-5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear o actualizar la direccion CUANDO el comprador
   completa y envia el formulario de direccion.

**Descripcion:**

Campos requeridos en la creacion:

- ``alias``: nombre para identificar la direccion (max 50 chars)
- ``recipient_name``: nombre completo del destinatario (max 150 chars)
- ``street``: calle, numero exterior e interior (max 200 chars)
- ``city``: ciudad (max 100 chars)
- ``state``: estado/provincia (max 100 chars)
- ``zip_code``: codigo postal (max 10 chars)
- ``country``: codigo ISO 3166-1 alpha-2 (ej: "MX", "US")
- ``phone``: telefono del destinatario (max 20 chars)

Comportamiento especial de ``is_default``:

- Si el comprador no tiene ninguna direccion aun, la primera
  se marca como ``is_default=True`` automaticamente
- Si se marca una direccion como default, la anterior default
  queda en ``is_default=False`` (solo una puede ser default)

Limite de 5 direcciones: si el comprador ya tiene 5, se rechaza
la creacion con error 422.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador con menos de 5 direcciones
   CUANDO crea una nueva direccion valida
   ENTONCES la direccion queda guardada y aparece en la lista

   Escenario 1: Primera direccion automaticamente default
   DADO comprador sin ninguna direccion
   CUANDO crea la primera
   ENTONCES is_default=True automaticamente

   Escenario 2: Cambio de direccion default
   DADO comprador con direccion A como default
   CUANDO crea direccion B y la marca como default
   ENTONCES direccion B queda is_default=True
   Y direccion A queda is_default=False

   Escenario 3: Limite de 5 alcanzado
   DADO comprador con 5 direcciones ya guardadas
   CUANDO intenta crear una sexta
   ENTONCES error 422: "Has alcanzado el limite de 5 direcciones"

   Escenario 4: Codigo postal invalido
   DADO zip_code con letras para pais MX
   CUANDO se valida
   ENTONCES error 422 indicando el formato esperado para MX

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La validacion del formato de zip_code es por pais.
  Para MX son 5 digitos. Para US son 5 o 9 digitos (ZIP+4).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-07: Gestionar direcciones
   * - **Depende de**
     - FR-AUTH-07.01 (lista cargada)
   * - **Requerido por**
     - FR-ORD-01 (checkout usa las direcciones guardadas)
   * - **Test**
     - TST-FR-AUTH-07.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-07

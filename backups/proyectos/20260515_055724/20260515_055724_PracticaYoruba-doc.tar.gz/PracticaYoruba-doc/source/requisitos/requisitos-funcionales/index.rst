.. meta::
   :tipo: Indice
   :estado: En proceso
   :version: 8.0.0

======================
Requisitos Funcionales
======================

Capa 4 de la jerarquia ADR-GOB-003 — **129 FRs** escritos manualmente.

Cada FR es redactado uno por uno con contenido especifico derivado del UC.

.. list-table::
   :widths: 40 60
   :header-rows: 1

   * - Dominio
     - FRs
   * - auth
     - 19
   * - cart
     - 10
   * - catalogo
     - 12
   * - comms
     - 11
   * - config
     - 5
   * - devoluciones
     - 4
   * - includes
     - 3
   * - inventario
     - 5
   * - logistica
     - 7
   * - notifications
     - 7
   * - orders
     - 13
   * - payments
     - 11
   * - promociones
     - 4
   * - reportes
     - 4
   * - reviews
     - 3
   * - sistema
     - 4
   * - wishlist
     - 3
   * - yoruba
     - 4

.. toctree::
   :maxdepth: 1
   :caption: Dominios

   auth/index
   cart/index
   catalogo/index
   comms/index
   config/index
   devoluciones/index
   includes/index
   inventario/index
   logistica/index
   notifications/index
   orders/index
   payments/index
   promociones/index
   reportes/index
   reviews/index
   sistema/index
   wishlist/index
   yoruba/index

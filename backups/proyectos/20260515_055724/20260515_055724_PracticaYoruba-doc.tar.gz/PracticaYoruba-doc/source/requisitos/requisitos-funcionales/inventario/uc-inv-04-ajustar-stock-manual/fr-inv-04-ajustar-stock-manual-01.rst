.. meta::
   :artefacto: FR-INV-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inv-04-01:

FR-INV-04.01: Ajustar stock manualmente con auditoria
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-04.01
   * - **Nombre**
     - Ajustar stock manualmente con auditoria
   * - **UC Origen**
     - UC-INV 04 AJUSTAR STOCK MANUAL
   * - **Paso UC**
     - Pasos 3-4
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el stock y registrar el ajuste en el historial CUANDO el admin lo realiza.

**Descripcion:**

El admin ingresa:

- ``variant_id``: la variante a ajustar
- ``nueva_cantidad``: el nuevo valor absoluto de stock (>= 0)
- ``motivo``: CONTEO_FISICO / MERMA / ROBO / DEVOLUCION / OTRO
- ``observaciones``: texto libre opcional

El ``delta`` se calcula: ``nueva_cantidad - stock_actual``.
Si delta = 0: no se realiza ningun cambio.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Ajuste por conteo fisico
   DADO variante con stock=10 y conteo fisico que encontro stock=8
   CUANDO el admin ajusta a 8 con motivo CONTEO_FISICO
   ENTONCES variante.stock=8, delta=-2
   Y StockMovement(ADJUSTMENT, delta=-2) queda con el admin responsable

   Escenario: Ajuste a cero
   DADO variante con ordenes activas y admin que ajusta a 0
   CUANDO se intenta
   ENTONCES advertencia de ordenes activas que requieren confirmacion explicita

   Escenario: Delta cero — sin cambio
   DADO variante con stock=5 y admin que ingresa 5 como nueva cantidad
   CUANDO se procesa
   ENTONCES no se crea StockMovement y se informa que no hubo cambio


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El ajuste es por valor absoluto, no por delta. Esto simplifica el formulario y reduce errores.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV 04 AJUSTAR STOCK MANUAL
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - Ninguno — fin del flujo
   * - **Test**
     - TST-FR-INV-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INV 04 AJUSTAR STOCK MANUAL

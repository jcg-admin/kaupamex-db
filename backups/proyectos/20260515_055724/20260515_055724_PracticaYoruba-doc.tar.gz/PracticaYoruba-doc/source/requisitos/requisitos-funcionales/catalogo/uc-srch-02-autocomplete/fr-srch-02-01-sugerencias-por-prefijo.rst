.. meta::
   :artefacto: FR-SRCH-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-14

FR-SRCH-02.01: Sugerencias de productos por prefijo con cache
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SRCH-02.01
   * - **Nombre**
     - Retornar hasta 5 sugerencias de Product.name por prefijo, cacheadas 60s
   * - **UC Origen**
     - UC-SRCH-02: Autocomplete / Sugerencias
   * - **Paso UC**
     - Pasos 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE (``apps.catalogue``)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar hasta 5 productos cuyo ``name`` comienza
   con el prefijo recibido, usando la DatabaseCache con TTL de 60
   segundos, CUANDO el visitante escribe 2 o mas caracteres.

**Descripcion:**

El sistema normaliza el prefijo (strip + colapso de espacios +
truncado a 100 chars) y construye la clave de cache
``autocomplete:<prefijo_normalizado_lowercase>``. Si hay un
valor cacheado valido, lo retorna directamente. Si no, consulta
``Product.name__istartswith=prefijo`` con ``is_active=True`` e
``is_published=True``, limite 5 resultados ordenados por ``name``.
Almacena el resultado en cache con TTL 60s y retorna la lista.

Si el prefijo tiene menos de 2 caracteres, retorna lista vacia
sin error (degradacion elegante — el frontend controla con debounce).

Si el repositorio no responde, retorna lista vacia sin error visible
al visitante (``[]``).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cache miss — consulta BD y cachea
   DADO prefijo "col" con 3 productos cuyo name empieza con "col"
   CUANDO se llama GET /api/v1/catalogue/autocomplete/?q=col por primera vez
   ENTONCES retorna HTTP 200 con lista de hasta 5 productos {id, name, slug}
   Y el resultado queda cacheado con clave "autocomplete:col"

   Escenario 2: Cache hit — no consulta BD
   DADO que "autocomplete:col" ya esta en cache
   CUANDO se llama GET /api/v1/catalogue/autocomplete/?q=col
   ENTONCES retorna HTTP 200 con los datos cacheados
   Y no se ejecuta ninguna query SQL

   Escenario 3: Prefijo demasiado corto
   DADO prefijo "c" (1 caracter)
   CUANDO se llama GET /api/v1/catalogue/autocomplete/?q=c
   ENTONCES retorna HTTP 200 con lista vacia []
   Y no se lanza ningun error

----

4. Reglas y Restricciones
--------------------------

- La clave de cache usa el prefijo en lowercase: ``autocomplete:col`` no
  ``autocomplete:Col``.
- Maximo 5 resultados en la respuesta.
- TTL de cache: 60 segundos.
- Solo productos ``is_active=True`` e ``is_published=True``.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SRCH-02
   * - **Test**
     - TST-FR-SRCH-02.01

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-14
     - Version inicial. Derivado de UC-SRCH-02 pasos 3-4.
       Creado en Sprint 6 (H-S6-008).

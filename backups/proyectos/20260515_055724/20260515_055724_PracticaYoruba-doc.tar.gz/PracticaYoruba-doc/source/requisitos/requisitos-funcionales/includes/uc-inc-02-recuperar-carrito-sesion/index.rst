.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inc-02-recuperar-carrito-sesion
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inc-02-02-recuperar-carrito-unificado
   fr-inc-02-recuperar-carrito-sesion-01

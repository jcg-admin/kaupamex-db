.. meta::
   :artefacto: FR-SYS-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-SYS-03.02: Notificar al admin los productos bajo el umbral minimo de stock
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-03.02
   * - **Nombre**
     - El Procesador Periodico detecta y notifica productos con stock bajo que no fueron alertados
   * - **UC Origen**
     - UC-SYS-03: Notificar Stock Minimo (Actor: Tiempo)
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El Procesador Periodico DEBE identificar los productos con stock
   bajo el umbral que no fueron notificados en las ultimas 24 horas
   y enviar el reporte al admin CUANDO el proceso se ejecuta.

**Descripcion:**

**Descripcion:**

El sistema lee ``SiteSettings.min_stock_threshold`` y obtiene los
identificadores de ``StockAlert`` creados en las últimas 24 horas
para excluirlos del reporte (deduplicación). Consulta dos grupos:

- **Stock bajo:** ``ProductVariant`` con ``stock > 0`` y
  ``stock ≤ min_stock_threshold``, excluyendo los que ya recibieron
  alerta en las últimas 24 horas.
- **Agotados:** ``ProductVariant`` con ``stock = 0``.

Si alguno de los dos grupos tiene registros, encola de forma asíncrona
la notificación al administrador con el detalle de ambos grupos.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reporte de stock enviado con productos bajo umbral
   DADO 2 productos bajo el umbral y 1 agotado, ninguno alertado en 24h
   CUANDO el proceso se ejecuta
   ENTONCES el admin recibe un email con el detalle de los 3 productos
   Y StockAlert creado para cada uno (deduplicacion futura)

   Escenario 2: Sin productos nuevos bajo umbral — sin notificacion
   DADO todos los productos con stock normal o ya alertados en 24h
   CUANDO el proceso se ejecuta
   ENTONCES no se envia ninguna notificacion

----

4. Reglas y Restricciones
--------------------------

- **Relacionado con:** FR-INV-02.02 (alerta en tiempo real por venta)
  — este FR es el proceso periodico de revisacion global

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS-03: Notificar Stock Minimo
   * - **Test**
     - TST-FR-SYS-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-SYS-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

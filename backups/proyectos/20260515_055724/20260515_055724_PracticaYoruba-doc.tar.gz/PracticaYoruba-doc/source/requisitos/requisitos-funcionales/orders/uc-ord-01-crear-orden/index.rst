.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-01-crear-orden
================================

**5 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-01-01-validar-carrito-y-datos
   fr-ord-01-02-capturar-snapshot
   fr-ord-01-02-verificar-stock-atomico
   fr-ord-01-03-calcular-totales-y-crear-snapshots
   fr-ord-01-03-decrementar-stock-vaciar-carrito

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-09-buscar-orden-admin
=======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-09-01-buscar-ordenes-admin
   fr-ord-09-02-buscar-y-filtrar-ordenes-admin

.. meta::
   :artefacto: FR-QST-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-qst-02-01:

FR-QST-02.01: Listar preguntas respondidas del producto
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-02.01
   * - **Nombre**
     - Listar preguntas respondidas del producto
   * - **UC Origen**
     - UC-QST 02 VER PREGUNTAS
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las preguntas con respuesta CUANDO el visitante consulta un producto.

**Descripcion:**

Solo preguntas con ``status=ANSWERED`` y con respuesta publicada.
Ordenamiento: mas recientes primero.
Las preguntas PENDING o REJECTED no son visibles.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Producto con preguntas respondidas
   DADO producto con 5 preguntas respondidas
   CUANDO se listan
   ENTONCES aparecen las 5 con la pregunta y la respuesta

   Escenario: Sin preguntas respondidas
   DADO producto nuevo
   CUANDO se listan
   ENTONCES lista vacia con CTA de hacer la primera pregunta


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Las preguntas y respuestas ayudan al visitante a resolver dudas sin contactar al equipo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST 02 VER PREGUNTAS
   * - **Depende de**
     - Ninguno — consulta publica
   * - **Requerido por**
     - FR-QST-01.01 (el visitante puede hacer una pregunta si no encontro respuesta)
   * - **Test**
     - TST-FR-QST-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-QST 02 VER PREGUNTAS

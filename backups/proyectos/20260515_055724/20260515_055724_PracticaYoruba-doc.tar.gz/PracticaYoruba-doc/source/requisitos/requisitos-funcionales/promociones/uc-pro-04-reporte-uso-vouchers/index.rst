.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pro-04-reporte-uso-vouchers
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pro-04-02-calcular-roi-y-mostrar-reporte
   fr-pro-04-reporte-uso-vouchers-01

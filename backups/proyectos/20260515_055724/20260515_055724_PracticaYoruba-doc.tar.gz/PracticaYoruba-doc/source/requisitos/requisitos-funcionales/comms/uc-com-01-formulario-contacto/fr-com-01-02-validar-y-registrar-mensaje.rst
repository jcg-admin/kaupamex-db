.. meta::
   :artefacto: FR-COM-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-04-30
   :fecha_actualizacion: 2026-05-03

.. _fr-com-01-02:

========================================================================
FR-COM-01.02: Validar los campos del formulario y registrar el mensaje
========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-01.02
   * - **Nombre**
     - Validar campos obligatorios, formato de email, limite de envios y persistir ContactMessage
   * - **UC Origen**
     - UC-COM-01: Formulario de Contacto
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-014 CONTACT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar todos los campos del formulario de
   contacto, verificar que el remitente no supero el limite de
   envios diarios y persistir el ContactMessage CUANDO el visitante
   envia el formulario.

**Descripcion:**

Las validaciones se ejecutan en este orden; la primera que falle
retorna el error al visitante sin continuar con las siguientes:

1. **Presencia y longitud de cada campo.** Nombre entre 2 y 100
   caracteres, asunto entre 5 y 150, cuerpo del mensaje entre 20
   y 2000. Cada campo que falla retorna su propio mensaje de error
   — el visitante ve exactamente qué corregir sin perder el contenido
   del resto de los campos.

2. **Formato del email.** El email debe cumplir el formato RFC 5322.
   Si no cumple, se informa con un mensaje específico para el campo
   email.

3. **Límite de envíos diarios (EX-02).** El sistema cuenta cuántos
   mensajes de contacto se registraron con ese mismo email en las
   últimas 24 horas. Si ya se enviaron 5 o más, se rechaza el nuevo
   envío con HTTP 429 y se indica el tiempo de espera. Esta verificación
   protege la bandeja del equipo ante envíos automatizados.

4. **Persistencia.** Si todas las validaciones pasan, el sistema
   registra el mensaje con estado ``UNREAD``. Si el visitante está
   autenticado, el mensaje queda vinculado a su cuenta; si no, el
   campo de cuenta queda vacío. En ambos casos el mensaje muestra
   los datos que el visitante escribió en el formulario —
   no los de la cuenta — de modo que el visitante puede usar una
   dirección de contacto distinta a la de su cuenta.

5. **Notificación al equipo.** Tras guardar el mensaje, el sistema
   encola una notificación interna al equipo de atención. El encolo
   es asíncrono: la respuesta HTTP al visitante no espera a que el
   equipo sea notificado.

Si el visitante ya tiene sesión activa (Alt. B del UC), el formulario
se presenta con el nombre y el email precargados desde su cuenta.
Puede modificarlos antes de enviar.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Mensaje enviado exitosamente por visitante anonimo
   DADO visitante anonimo que completa nombre="Ana Lopez", email="ana@ejemplo.com",
   asunto="Consulta sobre envios a Guadalajara", mensaje de 35 caracteres
   CUANDO POST /api/v1/contact/
   ENTONCES HTTP 200 con {"status": "received",
   "estimated_response": "en menos de 48 horas habiles"}
   Y ContactMessage creado con status=UNREAD y user=null
   Y la notificacion interna al equipo queda encolada

   Escenario 2: Campo con error — mensaje especifico por campo
   DADO visitante que envia asunto="Hola" (4 caracteres, menos de 5)
   Y nombre y email validos
   CUANDO POST /api/v1/contact/
   ENTONCES HTTP 400 con {"errors": {"subject":
   "El asunto debe tener entre 5 y 150 caracteres."}}
   Y el resto de los campos NO se pierde (el frontend los conserva)

   Escenario 3: Limite diario superado — error con tiempo de espera
   DADO email "spam@ejemplo.com" que ya envio 5 mensajes en las ultimas 24h
   CUANDO intenta enviar el sexto
   ENTONCES HTTP 429 con {"errors": {"__all__":
   "Limite de mensajes alcanzado. Intenta mas tarde."}}
   Y no se crea ningun ContactMessage

   Escenario 4: Usuario autenticado — campos precargados pero modificables
   DADO usuario autenticado "Juan Perez" con email "juan@cuenta.com"
   CUANDO accede al formulario de contacto
   ENTONCES el formulario llega con sender_name="Juan Perez"
   y sender_email="juan@cuenta.com" precargados
   Y si Juan cambia el email a "juan-trabajo@empresa.com" antes de enviar,
   el ContactMessage guarda "juan-trabajo@empresa.com" y user=juan.pk

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-010 (el formulario de contacto no requiere
  autenticacion — acceso publico)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms incluyendo la
  consulta de limite diario y la escritura del ContactMessage),
  RNF-SEC-004 (el rate limiting por email previene inundacion de la
  bandeja del equipo)
- **Notas:** El mensaje de contacto registra el origen de la solicitud
  para que el admin pueda detectar patrones de envío masivo. Este dato
  no es visible en ningún endpoint público.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM-01: Formulario de Contacto
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8
   * - **Depende de**
     - FR-COM-01.01 (el formulario fue presentado con los campos)
   * - **Requerido por**
     - FR-COM-02.01 (el admin ve el mensaje en la bandeja)
   * - **Test**
     - TST-FR-COM-01.02 (pendiente — incluir test del limite de
       envios con freeze_time para simular las 24h)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial
   * - 1.2.0
     - 2026-05-03
     - Eliminado código Python real; reemplazado por prosa y
       pseudocódigo numerado conforme al estándar de documentación

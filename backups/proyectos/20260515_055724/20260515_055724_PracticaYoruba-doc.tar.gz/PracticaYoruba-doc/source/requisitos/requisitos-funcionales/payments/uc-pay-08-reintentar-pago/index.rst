.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-08-reintentar-pago
====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-08-01-reintentar-pago-fallido
   fr-pay-08-02-reintentar-con-otro-metodo

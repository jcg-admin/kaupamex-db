.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-08-cancelar-orden-admin
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-08-01-cancelar-orden-admin
   fr-ord-08-02-cancelar-y-reembolsar-admin

.. meta::
   :artefacto: FR-AUTH-09.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-09.02: Restablecer la contrasena con el token
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.02
   * - **Nombre**
     - Validar token y persistir la nueva contrasena
   * - **UC Origen**
     - UC-AUTH-09: Recuperar contrasena
   * - **Paso UC**
     - Pasos 5-7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el token, aplicar la nueva contrasena e
   invalidar el token CUANDO el visitante sigue el enlace de recuperacion.

**Descripcion:**

Proceso de restablecimiento:

1. Verifica la firma HMAC del token
2. Verifica que el token no haya sido usado previamente
3. Verifica que el token no este expirado (1 hora)
4. Valida que new_password cumple las reglas de Django
5. ``user.set_password(new_password)`` + ``user.save()``
6. Invalida el token de recuperacion (marca como usado)
7. Invalida todos los refresh tokens activos del usuario
8. Envia email de confirmacion de cambio (UC-INC-03)

----

3. Criterio de Aceptacion
--------------------------

::

   DADO token de recuperacion valido y nueva contrasena
   CUANDO se restablece
   ENTONCES la nueva contrasena queda activa

   Escenario 1: Token expirado
   DADO token de mas de 1 hora
   CUANDO se intenta usar
   ENTONCES error 400: "El enlace de recuperacion ha expirado"
   Y se ofrece solicitar uno nuevo

   Escenario 2: Token ya usado
   DADO token que ya fue utilizado exitosamente
   CUANDO se intenta reusar
   ENTONCES error 400: "Este enlace ya fue utilizado"

   Escenario 3: Restablecimiento exitoso
   DADO token valido y nueva contrasena cumpliendo reglas
   CUANDO se restablece
   ENTONCES respuesta 200
   Y todas las sesiones activas del usuario quedan cerradas
   Y el usuario debe hacer login con la nueva contrasena

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** El cierre de todas las sesiones al restablecer la contrasena
  es una medida de seguridad critica: si el restablecimiento fue por
  cuenta comprometida, el atacante pierde el acceso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar contrasena
   * - **Depende de**
     - FR-AUTH-09.01 (token enviado al email)
   * - **Requerido por**
     - FR-AUTH-02.01 (el usuario puede hacer login con nueva contrasena)
   * - **Include**
     - UC-INC-03 (email de confirmacion)
   * - **Test**
     - TST-FR-AUTH-09.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-09

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-04-filtrar-por-categoria
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-04-02-filtrar-productos-por-categoria
   fr-cat-04-filtrar-por-categoria-01-filtrar-catalogo-por-categoria

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — PROMOCIONES
=====================================

**4 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-pro-01-crear-voucher-admin
     - 1
   * - uc-pro-02-editar-voucher-admin
     - 1
   * - uc-pro-03-desactivar-voucher-admin
     - 1
   * - uc-pro-04-reporte-uso-vouchers
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-pro-01-crear-voucher-admin/index
   uc-pro-02-editar-voucher-admin/index
   uc-pro-03-desactivar-voucher-admin/index
   uc-pro-04-reporte-uso-vouchers/index

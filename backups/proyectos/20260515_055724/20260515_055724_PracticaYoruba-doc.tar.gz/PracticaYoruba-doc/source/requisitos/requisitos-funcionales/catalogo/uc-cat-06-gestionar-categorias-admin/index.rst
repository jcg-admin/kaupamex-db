.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-06-gestionar-categorias-admin
===============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-06-02-crud-categorias-y-jerarquia
   fr-cat-06-gestionar-categorias-admin-01-crear,-editar-y-desactivar-cat

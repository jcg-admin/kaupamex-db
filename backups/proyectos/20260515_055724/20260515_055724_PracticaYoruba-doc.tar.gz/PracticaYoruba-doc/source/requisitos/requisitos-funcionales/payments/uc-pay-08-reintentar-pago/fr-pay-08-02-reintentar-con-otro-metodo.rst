.. meta::
   :artefacto: FR-PAY-08.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-08.02: Permitir reintentar el pago con el mismo o diferente gateway
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-08.02
   * - **Nombre**
     - Crear un nuevo intento de pago para una orden con pago fallido o pendiente
   * - **UC Origen**
     - UC-PAY-08: Reintentar Pago
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE permitir al comprador intentar pagar una orden
   fallida o pendiente usando el mismo u otro gateway de pago
   CUANDO el comprador solicita reintentar.

**Descripcion:**

Una orden puede tener múltiples registros ``Payment`` si el comprador
reintenta. La relación es ``Order (1) → (*) Payment``.

El reintento solo es posible si ``Order.status = 'PENDING_PAYMENT'``
(una orden cuyo pago falló vuelve a este estado). Si no es así →
``ORDEN_NO_REINTENTABLE``. El ``Payment`` fallido anterior conserva
su ``status = 'FAILED'``. El sistema crea un nuevo ``Payment`` para
el reintento delegando al gateway seleccionado: si es
``MERCADOPAGO`` invoca FR-PAY-01.02; si es ``PAYPAL`` invoca
FR-PAY-02.02. El Strategy Pattern (BR-006) hace transparente el
cambio de gateway entre reintentos.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reintento con diferente gateway
   DADO orden en PENDING_PAYMENT cuyo pago con Mercado Pago fallo
   CUANDO el comprador elige pagar con PayPal
   ENTONCES se crea un nuevo Payment con gateway=PAYPAL
   Y el Payment anterior queda con status=FAILED
   Y la orden sigue en PENDING_PAYMENT hasta que el nuevo pago se aprueba

   Escenario 2: Orden ya pagada — no reintentable
   DADO orden con Payment.status=APPROVED
   CUANDO el comprador intenta reintentar
   ENTONCES HTTP 400 con ORDEN_NO_REINTENTABLE

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-006 (Strategy Pattern), BR-007 (multiples gateways)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-08: Reintentar Pago
   * - **Depende de**
     - FR-PAY-01.02 o FR-PAY-02.02 (segun el gateway elegido)
   * - **Test**
     - TST-FR-PAY-08.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-PAY-08
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

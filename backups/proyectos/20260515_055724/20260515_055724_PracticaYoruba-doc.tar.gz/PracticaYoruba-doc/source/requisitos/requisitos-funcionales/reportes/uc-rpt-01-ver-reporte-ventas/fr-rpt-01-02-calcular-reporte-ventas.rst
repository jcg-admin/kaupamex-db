.. meta::
   :artefacto: FR-RPT-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-rpt-01-02:

=================================================================================
FR-RPT-01.02: Calcular el reporte de ventas con métricas y tendencia temporal
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-01.02
   * - **Nombre**
     - Agregar ingresos, número de órdenes y ticket promedio para el
       período solicitado, calcular la variación respecto al período
       anterior y señalar si los datos del período en curso son parciales
   * - **UC Origen**
     - UC-RPT-01: Ver Reporte de Ventas
   * - **Paso UC**
     - Pasos 3 y 5 del flujo principal
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE agregar los datos de órdenes entregadas para
   el período seleccionado, calcular la variación porcentual
   respecto al período equivalente anterior, indicar si los datos
   son parciales cuando el período no ha concluido, y presentar
   el resultado con las métricas clave de ventas CUANDO el admin
   accede al reporte de ventas.

**Descripcion:**

El reporte opera exclusivamente sobre órdenes con estado
``DELIVERED`` o ``SHIPPED``. Las órdenes canceladas, las que están
en preparación o las que están pendientes de pago no se incluyen,
porque aún no representan ingresos reales del negocio.

**Períodos disponibles.**
El admin puede seleccionar períodos predefinidos —diario, semanal,
mensual, anual— o un rango de fechas personalizado. El sistema
calcula automáticamente el período equivalente anterior para la
comparativa: si el período seleccionado es mayo 2026, el anterior
es abril 2026; si es el año 2026, el anterior es 2025.

**Métricas calculadas.**
El reporte presenta cuatro métricas principales: el ingreso total
acumulado en el período, el número total de órdenes, el ticket
promedio por orden y el IVA total recaudado. Junto a cada métrica
se muestra la variación porcentual respecto al período anterior,
acompañada de un indicador visual que señala si la tendencia es
positiva, negativa o neutral (Alt. C).

**Período en curso con datos parciales (Alt. A).**
Cuando el período seleccionado no ha concluido —por ejemplo, el
mes actual— el reporte muestra los datos disponibles hasta el
momento con un indicador claro de que la información es parcial.
La variación porcentual en este caso se calcula sobre los días
transcurridos del período anterior equivalente para que la
comparativa sea proporcional.

**Sin datos para el período (Alt. B).**
Si no hay órdenes entregadas en el período solicitado, el reporte
muestra todas las métricas en cero. La variación porcentual no
se puede calcular y el campo aparece vacío con una nota explicativa.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reporte mensual completo con variación positiva
   DADO admin que solicita el reporte de mayo 2026
   Y mayo tuvo total_revenue=$85,000 y abril tuvo $70,000
   CUANDO accede al reporte con period=MONTHLY
   ENTONCES el reporte muestra total_revenue=$85,000, total_orders=47,
   avg_ticket=$1,808.51, variacion_pct=+21.4%
   Y el indicador de tendencia es positivo (↑)

   Escenario 2: Período en curso — datos marcados como parciales
   DADO admin que solicita el reporte del mes actual que aún no terminó
   CUANDO el sistema calcula el reporte
   ENTONCES los datos muestran los acumulados hasta hoy
   Y aparece el indicador "Datos parciales — mes en curso"
   Y la variación se calcula proporcional a los días transcurridos
   del mes anterior

   Escenario 3: Período sin órdenes entregadas — reporte en cero
   DADO admin que consulta un mes sin ninguna orden entregada
   CUANDO el sistema calcula el reporte (Alt. B)
   ENTONCES total_revenue=0, total_orders=0, avg_ticket=0
   Y el campo de variación aparece vacío con la nota
   "Sin datos en el período anterior para calcular la variación"

   Escenario 4: Rango personalizado de 15 días — sin período anterior predefinido
   DADO admin que solicita del 2026-04-10 al 2026-04-25
   CUANDO el sistema calcula el período anterior equivalente
   ENTONCES el período anterior es 2026-03-26 al 2026-04-10 (15 días previos)
   Y la variación se calcula sobre ese rango

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms — el reporte
  opera sobre datos ya consolidados en la base de datos mediante
  aggregaciones, no sobre cálculos en tiempo real)
- **Notas:** El módulo REPORTS no tiene modelos de datos propios.
  Todas las métricas se calculan mediante aggregaciones sobre los
  modelos de ORDER y PAYMENT en el momento de la consulta.
  Solo los administradores con permisos de reportes pueden acceder
  a estos datos financieros.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT-01: Ver Reporte de Ventas
   * - **Relacionado con**
     - FR-RPT-04.02 (el admin puede exportar este reporte)
   * - **Test**
     - TST-FR-RPT-01.02 (pendiente — verificar que las órdenes
       canceladas no se incluyen en las métricas; verificar que
       el cálculo del período anterior es correcto para rangos
       personalizados de longitud impar)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — código Python real, sin secciones completas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: cuatro métricas, período parcial, variación
       proporcional, rango personalizado, 4 escenarios BDD con datos
       concretos; eliminado código Python real

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-10-verificar-email
=====================================

**4 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-10-01-activar-cuenta
   fr-auth-10-02-validar-token-y-activar-cuenta
   fr-auth-10-03-registrar-auditoria-y-confirmar
   fr-auth-10-04-exc-y-nfr-verificacion

.. meta::
   :artefacto: FR-AUTH-09.06
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-09-06:

==========================================================
FR-AUTH-09.06: Excepciones y NFR del flujo de recuperacion
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.06
   * - **Nombre**
     - EX-01 a EX-04 y restricciones tecnicas del flujo de recuperacion de contraseña
   * - **UC Origen**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Paso UC**
     - PARTE 5 y PARTE 6
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El flujo de recuperacion DEBE manejar fallos del servicio de email
   y del repositorio de forma que el usuario siempre pueda recuperar
   el acceso sin quedar bloqueado por errores del sistema.

**Descripcion:**

**EX-01 — Fallo al enviar email:**

El Procesador Asincrono falla al intentar enviar el email. El token sigue
existiendo en la BD con su tiempo de vida. El usuario puede:

- Esperar y solicitar un nuevo enlace
- El admin puede reenviar manualmente si tiene acceso al panel

No se retorna error al usuario en la Fase 1 — la respuesta siempre
es el mensaje generico HTTP 200 (porque revelar que el envio fallo
ayudaría a confirmar la existencia de la cuenta).

**EX-02 — Token no encontrado:**

Cubierto en FR-AUTH-09.04 (TOKEN_INVALIDO).

**EX-03 — Error al actualizar contraseña:**

Cubierto en FR-AUTH-09.04 (rollback atomico, token no marcado como used).

**EX-04 — Repositorio no disponible:**

HTTP 503 generico. El usuario puede reintentar. El token sigue vigente.

**Performance (6.1):**

- Fase 1 P95 <= 500ms (busqueda + generacion token + encolar)
- El envio del email es asincrono — no bloquea la respuesta
- Fase 2 P95 <= 800ms (verificar token + el algoritmo de hash de contraseñas + guardar)
- Tiempo de vida del token: 1 hora (configurable en SiteSettings)

**Seguridad (6.2):**

- Respuesta identica si el email existe o no (anti-enumeracion)
- Token de 256 bits de entropia (generado por un generador criptograficamente seguro)
- Token almacenado hasheado en la BD
- Invalidar tokens previos al solicitar nuevo enlace
- Todas las sesiones invalidadas al restablecer
- Atomicidad garantizada con @transaction.atomic

**Confiabilidad (6.3):** si cualquier paso de la Fase 2 falla,
la contraseña anterior sigue siendo valida y el token puede reusarse.

**Usabilidad (6.4):** formulario minimalista (solo email en Fase 1),
indicador de fortaleza en Fase 2, mensajes claros si el token expiro.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Fallo de email no revela existencia de cuenta
   DADO fallo del servidor de SMTP al enviar el email de recuperacion
   CUANDO el sistema procesa la solicitud
   ENTONCES la respuesta HTTP 200 es identica que si el email se hubiera enviado
   Y un observador externo no puede saber si el email existe o si el envio fallo

   Escenario 2: Token de alta entropia
   DADO generacion de 1000 tokens
   CUANDO se analizan los tokens
   ENTONCES ninguno de los tokens se puede predecir a partir de los demas
   Y cada token tiene al menos 256 bits de entropia (secrets.token_urlsafe(32))

   Escenario 3: Solicitar nuevo enlace invalida el anterior
   DADO usuario que solicita recuperacion dos veces seguidas
   CUANDO usa el enlace del primer email (que fue invalidado)
   ENTONCES HTTP 400 con TOKEN_INVALIDO
   Y solo el enlace del segundo email (el mas reciente) es valido

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — 3 solicitudes/hora/IP)
- **RNF del sistema:** RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-001

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Secciones**
     - PARTE 5 (EX-01 a EX-04) y PARTE 6 (6.1 a 6.4)
   * - **BR**
     - BR-015
   * - **RNF del sistema**
     - RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-001
   * - **Test**
     - TST-FR-AUTH-09.06 (pendiente — mock del Procesador Asincrono y del Servicio de Email Externo)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de PARTE 5 y 6 de UC-AUTH-09

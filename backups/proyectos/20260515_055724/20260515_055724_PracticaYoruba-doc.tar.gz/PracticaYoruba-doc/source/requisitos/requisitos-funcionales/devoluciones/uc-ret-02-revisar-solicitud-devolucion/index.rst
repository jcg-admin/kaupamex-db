.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ret-02-revisar-solicitud-devolucion
=================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ret-02-02-aprobar-o-rechazar-solicitud
   fr-ret-02-revisar-solicitud-devolucion-01

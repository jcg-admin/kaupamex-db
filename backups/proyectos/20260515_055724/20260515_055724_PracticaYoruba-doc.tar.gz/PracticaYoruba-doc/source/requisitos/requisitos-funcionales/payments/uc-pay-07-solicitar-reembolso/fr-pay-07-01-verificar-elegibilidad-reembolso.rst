.. meta::
   :artefacto: FR-PAY-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-07-01:

FR-PAY-07.01: Verificar elegibilidad y procesar reembolso
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-07.01
   * - **Nombre**
     - Verificar elegibilidad y procesar reembolso
   * - **UC Origen**
     - UC-PAY-07: Solicitar reembolso
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-007 PAYMENT + Gateway
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la elegibilidad y ejecutar el reembolso en el gateway CUANDO el comprador o el sistema lo solicita.

**Descripcion:**

Condiciones de elegibilidad:

- El pago existe y tiene ``status = APPROVED``
- No existe un reembolso pendiente o completado por el mismo importe
- El ``amount`` del reembolso no supera el ``payment.amount``

Proceso:

1. Llama al endpoint de reembolso del gateway correspondiente:
   - MP: ``POST /v1/payments/{id}/refunds``
   - PayPal: ``POST /v2/payments/captures/{id}/refund``
2. Crea ``Refund(payment, amount, gateway_refund_id, status=PENDING)``
3. El gateway procesa el reembolso (puede tardar 3-10 dias habiles)
4. El webhook del gateway notifica cuando el reembolso se acredita

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reembolso total exitoso
   DADO pago aprobado por 500
   CUANDO se solicita reembolso total
   ENTONCES el gateway acepta y retorna gateway_refund_id
   Y Refund queda en BD con status=PENDING
   Y se notifica al comprador del reembolso iniciado

   Escenario: Reembolso parcial
   DADO pago aprobado por 500
   CUANDO se solicita reembolso de 200
   ENTONCES Refund.amount = 200
   Y Payment.status = PARTIALLY_REFUNDED

   Escenario: Reembolso duplicado bloqueado
   DADO reembolso ya en curso por el mismo importe
   CUANDO se solicita otro igual
   ENTONCES error 409: REEMBOLSO_YA_EN_CURSO


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002 (auditoria)`
- **Notas:** Los reembolsos son asincronos — el gateway los procesa en dias habiles. El estado se actualiza via webhook.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-07: Solicitar reembolso
   * - **Depende de**
     - FR-PAY-05.01 (pago verificado como APPROVED)
   * - **Requerido por**
     - FR-NOT-05.01 (email de reembolso al comprador)
   * - **Test**
     - TST-FR-PAY-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-07

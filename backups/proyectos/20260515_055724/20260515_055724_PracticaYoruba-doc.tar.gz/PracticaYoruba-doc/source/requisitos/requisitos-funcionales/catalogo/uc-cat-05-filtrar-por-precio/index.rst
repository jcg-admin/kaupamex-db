.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-05-filtrar-por-precio
=======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-05-02-filtrar-por-rango-precio
   fr-cat-05-filtrar-por-precio-01-filtrar-catalogo-por-rango-de

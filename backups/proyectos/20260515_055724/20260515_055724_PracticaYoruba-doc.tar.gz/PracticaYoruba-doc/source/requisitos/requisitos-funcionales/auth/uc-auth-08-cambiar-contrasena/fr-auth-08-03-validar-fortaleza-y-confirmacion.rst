.. meta::
   :artefacto: FR-AUTH-08.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-08.03: Validar fortaleza de la nueva contraseña y confirmacion
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.03
   * - **Nombre**
     - Validar requisitos de la nueva contraseña y que coincide con su confirmacion
   * - **UC Origen**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Paso UC**
     - Pasos 5 y 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (Django password validators + frontend)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que la nueva contraseña cumple los requisitos
   de seguridad y que el campo de confirmacion es identico CUANDO el
   usuario esta editando los campos de nueva contraseña.

**Descripcion:**

**Paso 5 — Validacion en tiempo real en el cliente (indicador de fortaleza):**

El indicador de fortaleza se calcula en el cliente sin llamadas al servidor.
Criterios (cada uno suma a la fortaleza):

- Longitud >= 8 caracteres (minimo requerido)
- Longitud >= 12 caracteres (fortaleza media)
- Contiene letras mayusculas Y minusculas
- Contiene al menos 1 numero
- Contiene al menos 1 caracter especial (!@#$%...)

El indicador muestra: DEBIL / MEDIA / FUERTE / MUY FUERTE

**Paso 7 — Validacion de confirmacion (cliente):**

En tiempo real al escribir en el campo de confirmacion:
si las dos entradas no coinciden → muestra "Las contraseñas no coinciden"
en rojo bajo el campo de confirmacion.

**Validacion en servidor (al hacer POST):**

Los validadores de Django configurados en ``AUTH_PASSWORD_VALIDATORS``:

- ``MinimumLengthValidator`` — minimo 8 caracteres
- ``UserAttributeSimilarityValidator`` — no similar al username/email
- ``CommonPasswordValidator`` — no en lista de contraseñas comunes
- Confirmacion: ``password == password_confirm`` (serializer)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Contraseña debil rechazada en el servidor
   DADO nueva contraseña "1234" (solo 4 digitos)
   CUANDO el servidor valida
   ENTONCES HTTP 400 con {"detalles": {"new_password":
   ["La contraseña debe tener al menos 8 caracteres."]}}
   Y el cambio no ocurre

   Escenario 2: Contraseña similar al username rechazada
   DADO usuario "juanito123" que intenta contraseña "juanito"
   CUANDO el servidor valida
   ENTONCES HTTP 400 con "La contraseña es demasiado similar a tu nombre de usuario."

   Escenario 3: Confirmacion no coincide
   DADO new_password = "MiPass123!" y confirm = "MiPass124!"
   CUANDO el servidor valida
   ENTONCES HTTP 400 con {"detalles":
   {"new_password_confirm": ["Las contraseñas no coinciden."]}}

   Escenario 4: Contraseña comun rechazada
   DADO nueva contraseña "password123"
   CUANDO el servidor valida
   ENTONCES HTTP 400 con "Esta contraseña es demasiado comun."

----

4. Reglas y Restricciones
--------------------------

- **Notas:** El indicador de fortaleza es informativo — no bloquea
  el envio en el cliente. La validacion real que importa es la del
  servidor. El indicador ayuda al usuario a crear contraseñas mejores.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Depende de**
     - FR-AUTH-08.01 (contraseña actual verificada)
   * - **Requerido por**
     - FR-AUTH-08.04 (verificar que es diferente a la actual)
   * - **Test**
     - TST-FR-AUTH-08.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5 y 7 de UC-AUTH-08

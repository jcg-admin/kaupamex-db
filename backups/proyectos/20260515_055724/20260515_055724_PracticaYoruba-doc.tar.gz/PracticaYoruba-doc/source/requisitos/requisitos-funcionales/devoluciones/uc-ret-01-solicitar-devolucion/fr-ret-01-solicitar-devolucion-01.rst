.. meta::
   :artefacto: FR-RET-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ret-01-01:

FR-RET-01.01: Crear solicitud de devolucion
===========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-01.01
   * - **Nombre**
     - Crear solicitud de devolucion
   * - **UC Origen**
     - UC-RET 01 SOLICITAR DEVOLUCION
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-010 RETURNS via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la solicitud de devolucion CUANDO el comprador la envía dentro del plazo.

**Descripcion:**

Validaciones previas:

- La orden esta en estado DELIVERED
- No han pasado mas de ``SiteSettings.max_return_days`` desde la entrega
- No existe ya una solicitud activa para esa orden

La solicitud se crea con ``status=PENDING_REVIEW``.
Las evidencias (fotos) se almacenan en el Servicio de Archivos.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Solicitud exitosa
   DADO orden DELIVERED dentro del plazo
   CUANDO el comprador crea la solicitud con motivo y descripcion
   ENTONCES ReturnRequest.status=PENDING_REVIEW
   Y el equipo de admin la ve en la cola de revision

   Escenario: Plazo vencido
   DADO orden entregada hace mas de 30 dias
   CUANDO el comprador intenta solicitar devolucion
   ENTONCES error 422: PLAZO_DEVOLUCION_VENCIDO


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El plazo de devolucion se configura en SiteSettings.max_return_days.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET 01 SOLICITAR DEVOLUCION
   * - **Depende de**
     - Propiedad verificada via INC-01
   * - **Requerido por**
     - FR-RET-02.01 (admin revisa la solicitud)
   * - **Include**
     - UC-INC-01
   * - **Test**
     - TST-FR-RET-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RET 01 SOLICITAR DEVOLUCION

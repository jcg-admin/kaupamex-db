.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — INVENTARIO
====================================

**5 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-inv-01-ver-stock
     - 1
   * - uc-inv-02-decrementar-stock
     - 1
   * - uc-inv-03-restaurar-stock
     - 1
   * - uc-inv-04-ajustar-stock-manual
     - 1
   * - uc-inv-05-importar-productos-csv
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-inv-01-ver-stock/index
   uc-inv-02-decrementar-stock/index
   uc-inv-03-restaurar-stock/index
   uc-inv-04-ajustar-stock-manual/index
   uc-inv-05-importar-productos-csv/index

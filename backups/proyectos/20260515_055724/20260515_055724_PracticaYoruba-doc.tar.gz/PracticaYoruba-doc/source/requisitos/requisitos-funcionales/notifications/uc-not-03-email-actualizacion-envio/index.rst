.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-03-email-actualizacion-envio
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-03-02-encolar-email-tracking
   fr-not-03-email-actualizacion-envio-01

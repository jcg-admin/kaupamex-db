.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-01-ext-cuotas-msi
===================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-01-ext-01-consultar-planes-cuotas
   fr-pay-01-ext-02-crear-preferencia-con-cuotas

.. meta::
   :artefacto: FR-CFG-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cfg-01-02:

==================================================================================
FR-CFG-01.02: Validar formato, verificar conectividad y cifrar las credenciales
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-01.02
   * - **Nombre**
     - Verificar el formato de las credenciales, comprobar la conectividad
       real con el gateway y persistir las credenciales cifradas en el
       repositorio de configuración
   * - **UC Origen**
     - UC-CFG-01: Configurar Gateways de Pago
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Validación + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato de las credenciales ingresadas
   por el admin, verificar la conectividad real con el gateway usando
   esas credenciales y, solo si la verificación es exitosa, persistir
   las credenciales cifradas en el repositorio de configuración, sin
   interrumpir el servicio si había credenciales previas válidas.

**Descripcion:**

La configuración de un gateway es una operación crítica: un error
puede dejar el sitio sin capacidad de procesar pagos. Por eso el
proceso tiene tres pasos diferenciados antes de escribir nada en
el repositorio.

**Validación de formato (paso 5).**
Cada campo de credenciales tiene un formato esperado que el sistema
verifica sin contactar al gateway. Por ejemplo, un identificador de
aplicación tiene un prefijo reconocible y una longitud determinada.
Esta validación es inmediata y evita consultas innecesarias al
gateway cuando el admin cometió un error de tipeo evidente. Si un
campo no cumple el formato, el sistema indica exactamente qué campo
falla y el formato correcto, sin perder los demás campos correctos
(Alt. A).

**Verificación de conectividad (paso 6).**
Una vez que el formato es válido, el sistema realiza una petición
de prueba al gateway con las nuevas credenciales. Esta petición no
procesa ningún pago; es una llamada de verificación de autenticación
que el gateway acepta de forma gratuita. Si el gateway rechaza las
credenciales (Alt. B), el repositorio no se toca: la configuración
anterior sigue activa sin ningún período de inactividad.

Si el gateway responde indicando que está en mantenimiento (EX-02),
el sistema almacena las credenciales de todas formas pero marca el
gateway como pendiente de verificación. Un proceso periódico reintenta
la verificación automáticamente hasta confirmar que el gateway está
operativo.

**Persistencia cifrada (paso 7).**
Solo cuando la verificación pasa, el sistema cifra las credenciales
usando el mecanismo simétrico de cifrado configurado en el entorno
(RNF-SEC-002) y las escribe en el repositorio. El cifrado ocurre en
el servidor; las credenciales en claro nunca tocan el repositorio ni
los logs.

**Enmascaramiento en la interfaz (paso 2).**
Cuando el admin abre la configuración de un gateway ya configurado,
las credenciales se muestran enmascaradas —por ejemplo, solo los
últimos cuatro caracteres visibles— para que el admin pueda confirmar
visualmente que existe configuración sin ver el valor real.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Credenciales válidas guardadas correctamente
   DADO admin que ingresa el access_token de producción de Mercado Pago
   CUANDO el sistema verifica el formato, comprueba la conectividad
   con el gateway y recibe confirmación de autenticación correcta
   ENTONCES las credenciales quedan cifradas en el repositorio
   Y el gateway aparece como activo y operativo en el panel
   Y el siguiente checkout puede procesar pagos con ese gateway

   Escenario 2: Credenciales con formato inválido — error por campo
   DADO admin que escribe un identificador de aplicación con caracteres
   no permitidos en el campo del cliente de PayPal
   CUANDO el sistema valida el formato sin contactar al gateway
   ENTONCES HTTP 400 con {"errors": {"paypal_client_id":
   "El identificador debe comenzar con 'A' seguido de letras y números."}}
   Y el resto de campos válidos no se pierden

   Escenario 3: Credenciales con formato correcto pero rechazadas por el gateway
   DADO admin que ingresa un token caducado de Mercado Pago (Alt. B)
   CUANDO el sistema comprueba la conectividad y el gateway responde 401
   ENTONCES HTTP 400 con {"codigo_error": "CREDENCIALES_INVALIDAS",
   "mensaje": "El gateway rechazó las credenciales. Verifícalas en el
   panel de Mercado Pago."}
   Y la configuración anterior del gateway permanece activa sin cambio

   Escenario 4: Gateway en mantenimiento durante la verificación (EX-02)
   DADO gateway que responde con código de mantenimiento temporal
   CUANDO el sistema intenta la verificación
   ENTONCES las credenciales se guardan cifradas en el repositorio
   Y el gateway queda marcado como "pendiente de verificación"
   Y el proceso periódico reintentará la verificación automáticamente

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-009 (las credenciales del gateway nunca
  pasan al frontend ni aparecen en los logs del sistema)
- **RNF aplicables:** RNF-SEC-002 (cifrado simétrico de credenciales
  en reposo), RNF-PERF-001 (P95 <= 500ms para el proceso completo
  incluyendo la petición de verificación al gateway)
- **Notas:** El cambio de credenciales es inmediato y no requiere
  reiniciar ningún proceso del servidor. La rotación periódica de
  credenciales (Alt. C) sigue exactamente el mismo flujo que la
  configuración inicial.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG-01: Configurar Gateways de Pago
   * - **Requerido por**
     - FR-PAY-01.02 (el checkout de Mercado Pago usa las
       credenciales cifradas aquí),
       FR-PAY-02.02 (el checkout de PayPal idem)
   * - **Test**
     - TST-FR-CFG-01.02 (pendiente — verificar que las credenciales
       en claro no aparecen en los logs; verificar que un rechazo
       del gateway no modifica la configuración activa previa)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: tres pasos diferenciados en prosa,
       enmascaramiento en la interfaz, EX-02 de mantenimiento,
       Alt. B sin interrumpir la configuración activa,
       4 escenarios BDD con datos concretos

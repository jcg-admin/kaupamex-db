.. meta::
   :artefacto: FR-AUTH-09.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-09-05:

========================================================
FR-AUTH-09.05: Registrar auditoria y confirmar restablecimiento
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.05
   * - **Nombre**
     - Crear registro de auditoria del restablecimiento y confirmar al usuario
   * - **UC Origen**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Paso UC**
     - Pasos 22 y 23 del flujo principal (Fase 2)
   * - **Modulo**
     - MOD-001 ACCOUNTS (AccessAuditLog + respuesta)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Auditoria + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar el restablecimiento de contraseña en
   auditoria e informar al usuario que puede iniciar sesion con
   su nueva contraseña CUANDO el restablecimiento fue exitoso.

**Descripcion:**

**Paso 22 — Registro de auditoria:**

El sistema crea un registro ``AccessAuditLog`` con los campos:
referencia al ``User``, tipo de evento ``RESTABLECIMIENTO_CONTRASENA``,
dirección IP del cliente, resultado ``EXITOSO``, y un campo
``metadata`` que contiene el identificador primario del
``PasswordResetToken`` utilizado. Esta referencia permite correlacionar
el restablecimiento con la solicitud original para obtener la traza
completa: solicitud → token → uso. Ningún campo del registro contiene
la contraseña anterior ni la nueva.

**Paso 23 — Confirmacion al usuario:**

.. code-block:: json

   HTTP 200
   {
     "mensaje": "Tu contraseña fue restablecida exitosamente.",
     "info": "Todas tus sesiones activas han sido cerradas.",
     "redirect": "/login/"
   }

El campo ``redirect`` permite al frontend llevar al usuario al login
directamente sin hardcodear la URL. El usuario debe iniciar sesion
con su nueva contraseña en todos sus dispositivos.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Auditoria creada con referencia al token
   DADO restablecimiento exitoso
   CUANDO se crea el registro
   ENTONCES AccessAuditLog tiene event_type = RESTABLECIMIENTO_CONTRASENA
   Y metadata.token_id = ID del PasswordResetToken usado
   Y NINGUNA contraseña aparece en el registro

   Escenario 2: Usuario redirigido al login para iniciar sesion
   DADO confirmacion exitosa retornada
   CUANDO el frontend procesa la respuesta
   ENTONCES redirige al usuario a /login/
   Y el usuario puede iniciar sesion con su nueva contraseña
   Y sus sesiones anteriores ya no son validas

   Escenario 3: Flujo completo de recuperacion trazable
   DADO incidente de seguridad donde se sospecha restablecimiento no autorizado
   CUANDO el administrador revisa el log de auditoria
   ENTONCES puede ver: timestamp de la solicitud, IP desde donde se solicito,
   ID del token, timestamp del uso, IP desde donde se uso el enlace
   Y todo sin que ningun campo contenga contraseñas

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (created_at automatico en AccessAuditLog)
- **RNF aplicables:** RNF-PROC-002 (auditoria de restablecimiento de credenciales)
- **Notas:** La cadena de auditoria completa (solicitud + uso) permite
  detectar si alguien solicito el enlace desde una IP diferente a la
  que lo uso. Esto podria indicar interceptacion del email.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Depende de**
     - FR-AUTH-09.04 (nueva contraseña establecida y token invalidado)
   * - **Requerido por**
     - Ninguno — ultimo paso del Sistema en UC-AUTH-09
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-09.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 22 y 23 de UC-AUTH-09
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Bloque JSON conservado — contrato de respuesta HTTP.

.. meta::
   :artefacto: FR-PAY-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-07.02: Validar elegibilidad del reembolso y ejecutarlo en el gateway
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-07.02
   * - **Nombre**
     - Verificar que el pago es elegible para reembolso y ejecutar el reembolso en el gateway
   * - **UC Origen**
     - UC-PAY-07: Solicitar Reembolso
   * - **Paso UC**
     - Pasos 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el pago esta aprobado y dentro del
   periodo de reembolso, ejecutar el reembolso en el gateway y
   registrar el Refund CUANDO el admin solicita un reembolso.

**Descripcion:**

En una transacción atómica: si ``Payment.status`` es distinto de
``'APPROVED'`` → ``PAGO_NO_REEMBOLSABLE``. En caso contrario, el
sistema determina el importe a reembolsar (total si no se especifica
monto, parcial si se especifica un monto menor). Ejecuta el reembolso
en el gateway correspondiente usando ``Payment.gateway_payment_id``,
crea un registro ``Refund`` con el importe, el identificador de
reembolso retornado por el gateway, estado ``PROCESSED`` y el motivo.
Finalmente actualiza ``Payment.status``: ``'REFUNDED'`` si el importe
reembolsado es igual al total del pago, o ``'PARTIALLY_REFUNDED'`` si
es menor.

El reembolso parcial es posible — el campo ``amount`` en
``Process_refund`` permite especificar un monto menor al total.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reembolso total exitoso
   DADO pago aprobado de $1824.80
   CUANDO el admin solicita el reembolso total
   ENTONCES se ejecuta el reembolso en el gateway
   Y Refund.amount = 1824.80 y Payment.status = REFUNDED
   Y el comprador recibe el reembolso en 3-5 dias habiles

   Escenario 2: Reembolso parcial
   DADO pago aprobado de $1824.80 con un item devuelto de $850
   CUANDO el admin solicita reembolso parcial de $850
   ENTONCES Refund.amount = 850 y Payment.status = PARTIALLY_REFUNDED

   Escenario 3: Pago no aprobado — no reembolsable
   DADO pago en estado PENDING
   CUANDO el admin intenta reembolsar
   ENTONCES HTTP 400 con PAGO_NO_REEMBOLSABLE

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-006 (Strategy Pattern — cada gateway
  implementa su propio metodo de reembolso)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-07: Solicitar Reembolso
   * - **Relacionado con**
     - FR-ORD-04.03 (cancelacion) y FR-RET-02.01 (devolucion aprobada)
   * - **Test**
     - TST-FR-PAY-07.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-6 de UC-PAY-07
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

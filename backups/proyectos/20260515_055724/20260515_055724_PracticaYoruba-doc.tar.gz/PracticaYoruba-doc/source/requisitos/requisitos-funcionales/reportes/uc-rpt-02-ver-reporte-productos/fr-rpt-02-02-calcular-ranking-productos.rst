.. meta::
   :artefacto: FR-RPT-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-rpt-02-02:

==================================================================================
FR-RPT-02.02: Ranking de productos más vendidos e indicador de catálogo inactivo
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-02.02
   * - **Nombre**
     - Calcular el ranking de productos por unidades vendidas e ingresos,
       el porcentaje de productos activos sin ninguna venta en el período
       y la lista de productos sin ventas para acción directa del admin
   * - **UC Origen**
     - UC-RPT-02: Ver Reporte de Productos
   * - **Paso UC**
     - Pasos 3 y 5 del flujo principal
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular el ranking de productos por unidades
   vendidas e ingresos generados, el porcentaje del catálogo activo
   que no registró ninguna venta en el período como indicador de
   salud del catálogo, y la lista de productos sin ventas para
   que el admin pueda actuar directamente sobre ellos CUANDO accede
   al reporte de productos.

**Descripcion:**

El reporte de productos opera sobre los ``OrderItem`` de órdenes con
estado ``DELIVERED`` o ``SHIPPED`` en el período seleccionado. Los
productos cancelados no se cuentan porque no representan ventas reales.

**Ranking de productos (paso 3).**
El ranking ordena los productos por unidades vendidas de mayor a menor.
Para cada producto del ranking el reporte muestra el nombre, las
unidades vendidas en el período, los ingresos totales generados por
ese producto y su posición en el ranking. El admin puede ajustar
cuántos productos aparecen en el top: el valor predeterminado es 20
y el máximo es 100.

**Indicador de catálogo inactivo (paso 5).**
El sistema calcula qué porcentaje de los productos activos del
catálogo no tuvo ninguna venta en el período. Este indicador señala
si el catálogo tiene productos publicados que no generan demanda.
Un porcentaje alto puede indicar productos con precios incorrectos,
categorías mal asignadas o productos que conviene desactivar para
mantener el catálogo limpio.

**Lista de productos sin ventas (Alt. C).**
El admin puede activar el filtro de «productos sin ventas» para ver
exactamente qué productos activos no vendieron nada. Desde esta lista
puede acceder directamente a la ficha de edición de cada producto o
desactivarlo sin necesidad de navegar por separado al catálogo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Ranking de los 10 productos más vendidos del mes
   DADO admin que solicita el reporte de mayo 2026 con limit=10
   CUANDO accede al reporte
   ENTONCES el listado muestra los 10 productos con más unidades vendidas
   Y cada uno indica: posición, nombre, units_sold y revenue en el período
   Y el primer lugar es el producto con mayor número de unidades vendidas

   Escenario 2: Indicador de catálogo inactivo
   DADO catálogo con 100 productos activos donde 30 no tuvieron
   ninguna venta en el período
   CUANDO el sistema calcula el indicador de salud del catálogo
   ENTONCES el reporte muestra inactive_product_pct=30.0%
   Y el indicador visual señala que un 30% del catálogo no generó ventas

   Escenario 3: Lista de productos sin ventas para acción directa
   DADO admin que activa el filtro "productos sin ventas" (Alt. C)
   CUANDO el sistema filtra el catálogo activo
   ENTONCES aparece la lista de los 30 productos sin ventas en el período
   Y cada producto tiene el enlace directo a su edición y la opción
   de desactivarlo sin salir del reporte

   Escenario 4: Período sin ninguna orden entregada
   DADO período donde no hay ninguna orden con estado DELIVERED o SHIPPED
   CUANDO el sistema calcula el ranking (Alt. B)
   ENTONCES el ranking está vacío y las métricas muestran cero
   Y el indicador de inactividad no se calcula (todos los productos
   tienen cero ventas, lo que no aporta información útil)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms — las aggregaciones
  sobre ``OrderItem`` con filtros de estado y fecha deben estar
  optimizadas con índices adecuados)
- **Notas:** El nombre del producto que aparece en el ranking es el
  nombre capturado en el snapshot del ``OrderItem`` en el momento
  de la compra (BR-005), no el nombre actual del catálogo. Esto
  garantiza que el reporte refleja lo que realmente se vendió incluso
  si el producto fue renombrado posteriormente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT-02: Ver Reporte de Productos
   * - **Relacionado con**
     - FR-RPT-04.02 (el admin puede exportar este reporte en CSV o XLSX)
   * - **Relacionado con**
     - FR-CAT-11.02 (el admin puede desactivar productos directamente
       desde la lista de productos sin ventas)
   * - **Test**
     - TST-FR-RPT-02.02 (pendiente — verificar que los productos
       cancelados no aparecen en el ranking; verificar que el nombre
       del producto usa el snapshot del OrderItem)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — código Python real, secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: ranking, indicador de catálogo inactivo,
       lista de productos sin ventas con acción directa, nombre del
       snapshot BR-005, 4 escenarios BDD con datos concretos

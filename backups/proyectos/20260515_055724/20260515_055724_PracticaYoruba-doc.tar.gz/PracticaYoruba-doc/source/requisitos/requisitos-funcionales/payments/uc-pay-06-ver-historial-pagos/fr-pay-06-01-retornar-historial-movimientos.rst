.. meta::
   :artefacto: FR-PAY-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-06-01:

FR-PAY-06.01: Retornar historial de pagos y reembolsos
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-06.01
   * - **Nombre**
     - Retornar historial de pagos y reembolsos
   * - **UC Origen**
     - UC-PAY-06: Ver historial de pagos
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-007 PAYMENT via UC-INC-01
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el historial cronologico de todos los movimientos economicos de la orden CUANDO el comprador lo solicita.

**Descripcion:**

Historial incluye en orden cronologico:

- Cada intento de pago: ``gateway``, ``status``, ``amount``, ``created_at``
- Cada reembolso: ``amount``, ``status``, ``gateway_refund_id``, ``created_at``
- Balance neto calculado: ``total_pagado - total_reembolsado``
- Indicador de si la orden esta economicamente cerrada (saldo = 0)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Orden con un pago exitoso
   DADO orden con 1 Payment APPROVED
   CUANDO se consulta el historial
   ENTONCES aparece un movimiento de tipo PAGO por el total de la orden
   Y balance_neto = total de la orden

   Escenario: Orden con pago y reembolso parcial
   DADO orden con Payment APPROVED y Refund COMPLETED de la mitad
   CUANDO se consulta
   ENTONCES aparecen 2 movimientos: PAGO y REEMBOLSO
   Y balance_neto = pago - reembolso

   Escenario: Orden con multiples intentos fallidos
   DADO orden con 2 intentos FAILED y 1 APPROVED
   CUANDO se consulta
   ENTONCES los 3 intentos aparecen en orden cronologico
   Y se indica claramente cual fue el exitoso


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003 (aislamiento)`
- **Notas:** Los intentos fallidos se muestran con su motivo si el gateway lo proporciona.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-06: Ver historial de pagos
   * - **Depende de**
     - FR-ORD-02.01 (propiedad verificada)
   * - **Requerido por**
     - Ninguno — es consulta de solo lectura
   * - **Include**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-PAY-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-06

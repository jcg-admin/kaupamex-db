.. meta::
   :artefacto: FR-RPT-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rpt-03-01:

FR-RPT-03.01: Calcular metricas de compradores del periodo
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-03.01
   * - **Nombre**
     - Calcular metricas de compradores del periodo
   * - **UC Origen**
     - UC-RPT 03 VER REPORTE COMPRADORES
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular metricas de comportamiento de compradores CUANDO el admin consulta el reporte.

**Descripcion:**

Metricas calculadas:

- ``total_compradores``: compradores distintos con al menos una orden en el periodo
- ``compradores_nuevos``: con su primera orden en el periodo
- ``compradores_recurrentes``: con ordenes en periodos anteriores que volvieron
- ``tasa_retencion``: % de compradores del periodo anterior que volvieron a comprar
- ``valor_promedio_vida``: avg del total gastado por comprador en el periodo

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reporte con buena retencion
   DADO 100 compradores del mes anterior y 60 volvieron este mes
   CUANDO se calcula
   ENTONCES tasa_retencion=60%

   Escenario: Reporte del primer mes (sin periodo anterior)
   DADO reporte del primer mes de operacion
   CUANDO se calcula
   ENTONCES todos son 'nuevos' y tasa_retencion=N/A


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La tasa de retencion requiere datos de al menos dos periodos — indica N/A si no hay periodo anterior.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT 03 VER REPORTE COMPRADORES
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-RPT-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RPT 03 VER REPORTE COMPRADORES

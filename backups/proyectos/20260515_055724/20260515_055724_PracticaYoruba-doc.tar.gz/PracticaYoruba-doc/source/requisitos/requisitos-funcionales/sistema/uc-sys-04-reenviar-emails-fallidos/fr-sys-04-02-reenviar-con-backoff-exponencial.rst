.. meta::
   :artefacto: FR-SYS-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-SYS-04.02: Reintentar emails fallidos con espera exponencial progresiva
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-04.02
   * - **Nombre**
     - El Procesador Periodico reintenta emails en estado FALLIDO usando backoff exponencial
   * - **UC Origen**
     - UC-SYS-04: Reenviar Emails Fallidos (Actor: Tiempo)
   * - **Paso UC**
     - Pasos 2, 4, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications — EmailQueue)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El Procesador Periodico DEBE reintentar los emails en estado FALLIDO
   cuyo tiempo de espera ya paso, usando backoff exponencial y marcando
   como FALLIDO_DEFINITIVO tras 4 intentos fallidos.

**Descripcion:**

**Descripcion:**

El backoff exponencial usa los intervalos: intento 1 → 0 min,
intento 2 → 5 min, intento 3 → 30 min, intento 4 → 120 min.

El sistema consulta los ``EmailQueue`` con ``status = 'FAILED'``,
``retry_at`` en el pasado y ``retry_count < 4``, ordenados por
``retry_at``. Para cada mensaje intenta el envío al servicio de
correo externo. Si tiene éxito: establece ``EmailQueue.status = 'SENT'``
y registra ``EmailQueue.sent_at``. Si falla: incrementa
``EmailQueue.retry_count`` y, si ya alcanzó 4 intentos, establece
``EmailQueue.status = 'FAILED_PERMANENTLY'``; en caso contrario
calcula el próximo ``EmailQueue.retry_at`` usando el intervalo de
backoff correspondiente al nuevo ``retry_count``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email reenviado exitosamente en el segundo intento
   DADO email con retry_count=1 y retry_at en el pasado
   CUANDO el proceso ejecuta el reenvio
   ENTONCES status=SENT y sent_at registrado
   Y el comprador recibe el email

   Escenario 2: Cuarto fallo — marcado como definitivamente fallido
   DADO email con retry_count=3 que falla una vez mas
   CUANDO el proceso lo intenta por cuarta vez
   ENTONCES status=FAILED_PERMANENTLY
   Y no se vuelve a intentar automaticamente
   Y el admin puede ver el listado de emails fallidos en el panel

   Escenario 3: Backoff exponencial respetado
   DADO email que fallo por primera vez
   CUANDO se calcula el siguiente intento
   ENTONCES retry_at = ahora + 5 minutos (intento 2)
   Y si falla de nuevo: retry_at = ahora + 30 minutos (intento 3)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-003 (backoff exponencial obligatorio
  para respetar los limites del Servicio de Email Externo)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS-04: Reenviar Emails Fallidos
   * - **Incluye**
     - UC-INC-03 (envio de email con plantilla)
   * - **Test**
     - TST-FR-SYS-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 4, 6 y 7 de UC-SYS-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-05-email-reembolso
====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-05-02-encolar-email-reembolso
   fr-not-05-email-reembolso-01

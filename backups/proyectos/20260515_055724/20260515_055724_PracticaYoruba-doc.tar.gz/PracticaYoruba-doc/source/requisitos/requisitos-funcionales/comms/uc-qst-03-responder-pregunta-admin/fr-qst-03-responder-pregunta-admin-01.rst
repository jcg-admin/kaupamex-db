.. meta::
   :artefacto: FR-QST-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-qst-03-01:

FR-QST-03.01: Responder y publicar una pregunta
===============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-03.01
   * - **Nombre**
     - Responder y publicar una pregunta
   * - **UC Origen**
     - UC-QST 03 RESPONDER PREGUNTA ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE guardar la respuesta y publicar la pregunta CUANDO el admin responde.

**Descripcion:**

``Question.answer = respuesta_del_admin``
``Question.status = ANSWERED``
Notifica al visitante que su pregunta fue respondida (email via UC-INC-03).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Respuesta publicada
   DADO pregunta en PENDING_MODERATION
   CUANDO el admin responde
   ENTONCES Question.status=ANSWERED y aparece en la ficha del producto

   Escenario: Respuesta vacia no permitida
   DADO admin que intenta guardar respuesta vacia
   CUANDO se envia
   ENTONCES error 422: RESPUESTA_REQUERIDA


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La pregunta y la respuesta son publicas una vez publicadas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST 03 RESPONDER PREGUNTA ADMIN
   * - **Depende de**
     - FR-QST-01.01 (pregunta en moderacion)
   * - **Requerido por**
     - FR-QST-02.01 (aparece en la ficha)
   * - **Include**
     - UC-INC-03
   * - **Test**
     - TST-FR-QST-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-QST 03 RESPONDER PREGUNTA ADMIN

.. meta::
   :artefacto: FR-CART-02.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-02-03:

====================================================================
FR-CART-02.03: Verificar disponibilidad en tiempo real de cada item
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-02.03
   * - **Nombre**
     - Contrastar el stock actual del repositorio contra cada item del carrito
   * - **UC Origen**
     - UC-CART-02: Ver Carrito
   * - **Paso UC**
     - Paso 3 del flujo principal
   * - **Modulo**
     - MOD-005 CART + MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la disponibilidad actual de cada item
   del carrito consultando el repositorio de inventario CUANDO el
   visitante accede a la vista del carrito.

**Descripcion:**

La verificación se hace en el momento de mostrar el carrito,
no cuando se agregó el item. El stock puede haber cambiado.

Para cada item del carrito el sistema consulta el ``ProductVariant``
correspondiente (identificado por ``product_id`` y ``variant_id``) y
obtiene su ``ProductVariant.stock`` actual. Según el resultado asigna
un estado de disponibilidad:

- Si el ``ProductVariant`` no existe o su ``stock`` es 0 →
  ``availability = 'OUT_OF_STOCK'``.
- Si el ``stock`` existe pero es inferior a la cantidad
  solicitada en el item → ``availability = 'REDUCED_STOCK'``
  con ``max_available = stock``.
- En cualquier otro caso → ``availability = 'AVAILABLE'``.

Si un item tiene ``OUT_OF_STOCK`` o ``REDUCED_STOCK``:

- Se marca visualmente en la interfaz (Alt. C)
- El boton "Proceder al checkout" se deshabilita hasta que el
  visitante resuelva el problema (elimine el item o ajuste la cantidad)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Todos los items disponibles
   DADO carrito con 2 items, ambos con stock suficiente
   CUANDO el visitante accede al carrito
   ENTONCES ambos items muestran estado AVAILABLE
   Y el boton de checkout esta habilitado

   Escenario 2: Item sin stock
   DADO item en el carrito que agoto su stock desde que fue agregado
   CUANDO el sistema verifica disponibilidad
   ENTONCES el item se marca como OUT_OF_STOCK
   Y aparece el aviso "Este producto ya no esta disponible"
   Y el boton de checkout queda deshabilitado

   Escenario 3: Stock insuficiente para la cantidad solicitada
   DADO item con quantity=5 en el carrito pero solo 3 en stock
   CUANDO el sistema verifica
   ENTONCES el item muestra REDUCED_STOCK con max_available=3
   Y aparece el aviso "Solo quedan 3 unidades. Ajusta la cantidad."
   Y el boton de checkout queda deshabilitado hasta ajuste

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (la verificacion no debe
  degradar el tiempo de carga del carrito — max 1 query por item,
  o una sola query con IN para todos los items del carrito)
- **Notas:** La verificacion es de lectura — no reserva stock.
  El stock se decrementa formalmente en el checkout (FR-INV-02.01).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-02: Ver Carrito
   * - **Depende de**
     - FR-CART-02.01 (carrito recuperado de la sesion)
   * - **Requerido por**
     - FR-CART-02.02 (calcular subtotal — solo con items disponibles)
   * - **Test**
     - TST-FR-CART-02.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 3 de UC-CART-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Logica OUT_OF_STOCK/REDUCED_STOCK/AVAILABLE preservada con
       nombres canonicos ProductVariant.stock.

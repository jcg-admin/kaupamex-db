.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-06-cambiar-metodo-envio
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-06-01-actualizar-metodo-envio
   fr-ord-06-02-cambiar-metodo-y-recalcular

.. meta::
   :artefacto: FR-AUTH-10.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-10-02:

==========================================================
FR-AUTH-10.02: Validar token del enlace y activar la cuenta
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-10.02
   * - **Nombre**
     - Verificar el token de verificacion de email y activar la cuenta de forma atomica
   * - **UC Origen**
     - UC-AUTH-10: Verificar Email
   * - **Paso UC**
     - Pasos 4 a 11 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (EmailVerificationToken)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Validacion + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar el token del enlace de activacion,
   comprobar que no ha expirado ni fue usado, y activar la cuenta
   de forma atomica CUANDO el usuario hace clic en el enlace.

**Descripcion:**

El enlace tiene la forma ``/verificar-email/?token=<token_en_claro>``.

**Pasos 4 a 9 — Validacion del token:**

El sistema calcula el hash del token recibido en el parámetro de
consulta y busca en ``EmailVerificationToken`` un registro con ese
hash, que no haya sido usado y cuya expiración sea posterior al
momento actual. Si no existe un registro que cumpla las tres
condiciones, el sistema retorna ``TOKEN_INVALIDO`` con redirección
a la página de reenvío de verificación.

Si el token es válido pero la cuenta del usuario ya está activa
(``User.is_active`` es verdadero), el sistema retorna HTTP 200
indicando que la cuenta ya estaba verificada —Alternativa D del UC—
sin tratar esto como un error, garantizando idempotencia ante
dobles clics en el mismo enlace.

**Pasos 10 y 11 — Activar la cuenta e invalidar el token:**

En una transacción atómica el sistema activa la cuenta estableciendo
``User.is_active = True`` y registrando en ``User.email_verified_at``
el timestamp del momento de activación, y marca el
``EmailVerificationToken`` como usado con su timestamp de uso. Si
cualquiera de las dos operaciones falla se ejecuta rollback completo,
dejando la cuenta inactiva y el token disponible para reintento.

``email_verified_at`` es el campo que distingue cuentas verificadas
de cuentas suspendidas (ambas pueden tener ``User.is_active = False``
por razones diferentes, como se documenta en FR-AUTH-02.10).

El proceso es **idempotente**: si el sistema recibe la misma solicitud
dos veces (doble clic en el enlace), la segunda vez la cuenta ya esta
activa y retorna 200 con el mensaje de Alt. D.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token valido — cuenta activada exitosamente
   DADO token de verificacion valido (no expirado, no usado)
   CUANDO el usuario hace clic en el enlace
   ENTONCES user.is_active = True
   Y user.email_verified_at = timestamp de activacion
   Y el token queda con used = True
   Y el usuario puede iniciar sesion (FR-AUTH-02.09 ahora pasa)

   Escenario 2: Token expirado (mas de 24 horas)
   DADO token generado hace 25 horas (tiempo de vida: 24 horas)
   CUANDO el usuario hace clic en el enlace tardio
   ENTONCES HTTP 400 con TOKEN_INVALIDO y redirect a /reenviar-verificacion/
   Y la cuenta permanece en is_active = False
   Y el usuario puede solicitar un nuevo enlace

   Escenario 3: Cuenta ya verificada — idempotencia (Alt. D)
   DADO usuario que hace clic en el mismo enlace por segunda vez
   CUANDO el sistema procesa la solicitud
   ENTONCES HTTP 200 con "Tu cuenta ya estaba verificada"
   Y no se genera ningun error
   Y user.is_active no cambia (ya era True)

   Escenario 4: Atomicidad — fallo al activar no deja token marcado como usado
   DADO OperationalError al guardar user.is_active = True
   CUANDO el guardado falla
   ENTONCES rollback completo — user.is_active sigue siendo False
   Y el token sigue con used = False
   Y el usuario puede reintentar con el mismo enlace

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (token de un solo uso con expiracion),
  RNF-AVAIL-002 (idempotencia — multiples clicks en el mismo enlace)
- **Notas:** El campo ``email_verified_at`` es fundamental para la
  logica de FR-AUTH-02.10 (distinguir cuenta no verificada de cuenta
  suspendida). Debe actualizarse junto con ``is_active = True``.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-10: Verificar Email
   * - **Depende de**
     - FR-AUTH-01.05 (token de verificacion generado en el registro)
   * - **Requerido por**
     - FR-AUTH-10.03 (registrar auditoria y confirmar al usuario)
   * - **Relacionado con**
     - FR-AUTH-02.09 (que verifica is_active al hacer login)
   * - **Test**
     - TST-FR-AUTH-10.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-11 de UC-AUTH-10
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminados 2 bloques code-block Python.
       Logica de TOKEN_INVALIDO, idempotencia Alt.D y transaccion atomica preservadas.

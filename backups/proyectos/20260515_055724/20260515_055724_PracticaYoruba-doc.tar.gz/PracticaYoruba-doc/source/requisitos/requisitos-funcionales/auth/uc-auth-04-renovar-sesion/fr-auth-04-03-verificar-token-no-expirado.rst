.. meta::
   :artefacto: FR-AUTH-04.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-04-03:

============================================================
FR-AUTH-04.03: Verificar que el refresh token no ha expirado
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.03
   * - **Nombre**
     - Comprobar que el campo exp del payload del token no ha vencido
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Paso 4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el campo ``exp`` del payload del
   refresh token no ha vencido CUANDO el token no esta en la blacklist.

**Descripcion:**

La verificacion de expiracion es automatica en el Servicio de Autenticacion al decodificar
el token. El campo ``exp`` es un Unix timestamp UTC.

Tiempo de vida del refresh token:

- **Normal (sin "Recordarme"):** ``now + la configuracion del Servicio de Autenticacion.REFRESH_TOKEN_LIFETIME``
  = ahora + 7 dias
- **Con "Recordarme":** ``now + SiteSettings.remember_me_days`` dias

Si el token ha expirado (``exp < timezone.now()``):

- HTTP 401 con ``codigo_error: SESION_EXPIRADA``
- Mensaje orientado a la accion: "Tu sesion ha expirado. Inicia sesion de nuevo."
- El cliente redirige al usuario a UC-AUTH-02

La expiracion es la razon mas comun por la que falla la renovacion
en condiciones normales — el usuario simplemente no uso el sistema
por mas de 7 dias (o por mas de ``remember_me_days`` si activo esa opcion).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token vigente — renovacion procede
   DADO refresh token cuyo exp es en 3 dias
   CUANDO se verifica la expiracion
   ENTONCES la verificacion pasa
   Y el proceso continua a FR-AUTH-04.04 (verificar cuenta activa)

   Escenario 2: Token expirado hace 1 hora
   DADO refresh token cuyo exp fue hace 1 hora
   CUANDO se intenta renovar
   ENTONCES HTTP 401 con {"codigo_error": "SESION_EXPIRADA",
   "mensaje": "Tu sesion ha expirado. Inicia sesion de nuevo.",
   "redirect": "/login/"}
   Y el cliente redirige al usuario al login con mensaje claro

   Escenario 3: Token casi por expirar — se renueva igualmente
   DADO refresh token que expira en 2 minutos (casi en el limite)
   CUANDO el cliente lo usa para renovar
   ENTONCES la renovacion es exitosa (exp aun no ha llegado)
   Y el nuevo refresh token tiene su tiempo de vida completo (7 dias)
   Y el ciclo de vida se extiende sin interrumpir al usuario

   Escenario 4: Diferencia de reloj entre cliente y servidor
   DADO cliente con reloj adelantado 2 minutos vs el servidor
   CUANDO el cliente cree que el access token expiro y solicita renovacion
   ENTONCES el servidor verifica su propio reloj (UTC)
   Y si exp del refresh aun es futuro segun el servidor, la renovacion es exitosa

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001, RNF-USAB-001 (mensaje claro de
  sesion expirada orientado a la accion del usuario)
- **Notas:** El cliente inteligente solicita la renovacion cuando el
  access token esta proximo a expirar (ej: cuando quedan menos de
  60 segundos), no cuando ya expiro. Esto evita interrupciones.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Depende de**
     - FR-AUTH-04.02 (token no revocado)
   * - **Requerido por**
     - FR-AUTH-04.04 (verificar cuenta activa del usuario)
   * - **Test**
     - TST-FR-AUTH-04.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 4 de UC-AUTH-04

.. meta::
   :artefacto: FR-CHT-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cht-01-01:

FR-CHT-01.01: Retornar variantes activas del producto
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-01.01
   * - **Nombre**
     - Retornar variantes activas del producto
   * - **UC Origen**
     - UC-CHT 01 VER VARIANTES
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las variantes activas con precio y stock CUANDO se carga la ficha del producto.

**Descripcion:**

Por cada VariantType del producto:

- ``type_name``: nombre del tipo (Tamano, Presentacion, Material)
- ``options``: lista de VariantOptions con ``label``, ``is_available`` y ``effective_price``

``effective_price = variant.price_override`` si no es null, sino ``product.price``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Producto con variantes de tamano
   DADO producto con variantes Chico, Mediano y Grande
   CUANDO se cargan
   ENTONCES las 3 variantes aparecen con su precio y disponibilidad

   Escenario: Variante agotada
   DADO variante Grande con stock=0
   CUANDO se cargan
   ENTONCES is_available=false en Grande
   Y el selector lo muestra deshabilitado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** Las variantes se retornan junto con la ficha en FR-CAT-02.01 para evitar un request extra.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT 01 VER VARIANTES
   * - **Depende de**
     - FR-CAT-02.01 (ficha del producto cargada)
   * - **Requerido por**
     - FR-CHT-02.01 (el comprador selecciona una variante)
   * - **Test**
     - TST-FR-CHT-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CHT 01 VER VARIANTES

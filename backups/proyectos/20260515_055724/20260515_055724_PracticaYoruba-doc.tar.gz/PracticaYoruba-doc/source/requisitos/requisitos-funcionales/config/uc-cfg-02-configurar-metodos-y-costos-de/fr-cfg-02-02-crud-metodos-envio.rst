.. meta::
   :artefacto: FR-CFG-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cfg-02-02:

==================================================================================
FR-CFG-02.02: Gestionar métodos de envío con validación y efecto inmediato
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-02.02
   * - **Nombre**
     - Crear, editar y desactivar métodos de envío validando consistencia
       de datos, protegiendo los métodos con órdenes activas de la
       eliminación y reflejando los cambios de forma inmediata en el checkout
   * - **UC Origen**
     - UC-CFG-02: Configurar Métodos y Costos de Envío
   * - **Paso UC**
     - Pasos 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar la consistencia de los datos del método
   de envío, proteger los métodos con órdenes activas de la
   eliminación definitiva, persistir los cambios y hacerlos
   disponibles de forma inmediata en el paso de selección de envío
   del checkout CUANDO el admin crea, edita o desactiva un método.

**Descripcion:**

Los métodos de envío son los que el comprador ve y elige en el paso 8
del checkout (FR-ORD-01.03). Cualquier cambio que el admin haga aquí
tiene efecto inmediato en las nuevas órdenes; las órdenes ya creadas
no se ven afectadas.

**Validación de datos (paso 5).**
Los campos obligatorios son: nombre visible para el comprador,
costo (mayor o igual a cero — el cero permite envío gratuito),
y tiempo estimado expresado en días hábiles. Las zonas cubiertas
son opcionales; si no se definen, el método aplica a todo el
territorio de cobertura del sitio. Si algún campo obligatorio falta
o tiene un valor fuera de rango, el sistema indica exactamente qué
campo falla sin perder los demás campos correctos (Alt. A).

**Desactivación con órdenes activas (Alt. B).**
Antes de desactivar un método, el sistema verifica cuántas órdenes
en estados previos al envío lo tienen asignado. Si hay órdenes
activas, informa al admin del número de órdenes afectadas y solicita
confirmación. Si el admin confirma, el método pasa a inactivo para
nuevas órdenes pero las órdenes existentes que lo tenían asignado
lo mantienen; sus compradores siguen viendo el método y sus costos
en el detalle de su orden.

**Eliminación bloqueada (EX-02).**
Un método con órdenes activas no puede eliminarse definitivamente,
solo desactivarse. La eliminación definitiva solo está disponible
para métodos sin ninguna orden registrada. Esta restricción protege
la integridad de los snapshots de las órdenes existentes (BR-005).

**Envío gratuito (Alt. C).**
El admin puede configurar un monto mínimo de orden a partir del cual
el método de envío seleccionado tiene costo cero. Cuando el subtotal
del carrito del comprador supera ese mínimo, el checkout aplica el
descuento de envío automáticamente y el comprador ve el ahorro
reflejado en el resumen de su pedido.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nuevo método creado y disponible de inmediato en el checkout
   DADO admin que crea el método "Express 24h" con costo=$150
   y tiempo estimado de 1 día hábil
   CUANDO guarda la configuración
   ENTONCES el método aparece como opción seleccionable en el checkout
   para la siguiente orden que llegue al paso de selección de envío
   Y el comprador ve "Express 24h — $150 — Entrega en 1 día hábil"

   Escenario 2: Desactivación con órdenes activas — advertencia y confirmación
   DADO método "Mismo Día" con 3 órdenes en estado IN_PREPARATION
   CUANDO el admin intenta desactivarlo
   ENTONCES el sistema muestra "Este método tiene 3 órdenes en proceso.
   ¿Confirmas que no aceptará nuevas órdenes?"
   Y si el admin confirma: el método deja de aparecer en el checkout
   Y las 3 órdenes existentes conservan el método asignado sin cambio

   Escenario 3: Intento de eliminar método con órdenes registradas (EX-02)
   DADO método con historial de órdenes entregadas
   CUANDO el admin intenta eliminarlo definitivamente
   ENTONCES HTTP 400 con {"codigo_error": "METODO_CON_ORDENES",
   "mensaje": "Este método tiene órdenes registradas y no puede eliminarse.
   Solo puedes desactivarlo para que no acepte nuevas órdenes."}

   Escenario 4: Envío gratuito activado — checkout aplica descuento automático
   DADO admin que activa envío gratuito a partir de $800 en el método "Estándar"
   CUANDO un comprador llega al checkout con subtotal=$950
   ENTONCES el checkout muestra "Estándar — Gratis (antes $80)"
   Y el comprador ve cuánto ahorró por superar el mínimo

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (las órdenes existentes conservan el
  snapshot del método de envío; el cambio de costo no las afecta)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms),
  RNF-PROC-002 (los cambios quedan en auditoría con el admin
  responsable y el timestamp)
- **Notas:** El efecto es inmediato porque el checkout consulta los
  métodos activos del repositorio en tiempo real, sin cache de
  larga duración. No se requiere reiniciar ningún proceso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG-02: Configurar Métodos y Costos de Envío
   * - **Requerido por**
     - FR-ORD-01.03 (el checkout presenta los métodos activos
       configurados aquí en el paso 8)
   * - **Test**
     - TST-FR-CFG-02.02 (pendiente — verificar que un método
       desactivado no aparece en el checkout; verificar que las
       órdenes con el método desactivado no cambian su método
       asignado)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: validación de datos, desactivación con
       advertencia de órdenes activas, eliminación bloqueada EX-02,
       envío gratuito por mínimo, 4 escenarios BDD con datos concretos

.. meta::
   :artefacto: FR-RPT-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-rpt-03-02:

=================================================================================
FR-RPT-03.02: Métricas de compradores con tasa de retención e identificación VIP
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-03.02
   * - **Nombre**
     - Calcular nuevos compradores, compradores recurrentes, tasa de
       retención respecto al período anterior y top de compradores por
       gasto total para identificación de clientes de alto valor
   * - **UC Origen**
     - UC-RPT-03: Ver Reporte de Compradores
   * - **Paso UC**
     - Pasos 3 y 5 del flujo principal
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular el número de compradores nuevos y
   recurrentes del período, la tasa de retención comparando con
   el período anterior, y el top de compradores por gasto total
   como indicador de valor de vida del cliente CUANDO el admin
   accede al reporte de compradores.

**Descripcion:**

El reporte de compradores opera sobre las órdenes entregadas del
período para medir el comportamiento real de compra. No basta con
registrar cuántos usuarios se registraron; lo relevante es cuántos
compraron y cuántos volvieron a comprar.

**Métricas principales (paso 3).**
El reporte calcula cuatro métricas:

El **número de compradores nuevos** del período: usuarios que tienen
su primera orden entregada dentro del rango de fechas seleccionado.

El **número de compradores recurrentes**: compradores que realizaron
más de una orden entregada dentro del mismo período.

El **total de compradores únicos** del período: la suma de nuevos
y recurrentes.

El **gasto promedio por comprador**: el ingreso total dividido entre
el número de compradores únicos.

**Tasa de retención (paso 5).**
La retención mide qué porcentaje de los compradores del período
anterior volvió a comprar en el período actual. Si en el trimestre
anterior compraron 200 usuarios y 70 de ellos volvieron a comprar
en el trimestre actual, la tasa de retención es del 35%. Este dato
es el más indicativo de la fidelidad del cliente con el negocio.

**Top de compradores por gasto (Alt. C).**
El admin puede activar la vista de compradores de alto valor, que
muestra los compradores ordenados por gasto total en el período.
El sistema no almacena ni muestra datos personales innecesarios:
el listado muestra el identificador de cuenta y el gasto total,
sin nombre completo ni dirección. El admin puede usar este listado
para exportarlo y diseñar campañas de fidelización.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Métricas completas del primer trimestre de 2026
   DADO admin que solicita el reporte del Q1 2026
   Y en ese período compraron 180 usuarios únicos, de los cuales
   45 ya habían comprado en Q4 2025
   CUANDO accede al reporte
   ENTONCES new_buyers=135, repeat_buyers=45, total_buyers=180
   Y retention_rate respecto a Q4 2025 = porcentaje de Q4 que volvió en Q1

   Escenario 2: Tasa de retención calculada sobre el período anterior
   DADO Q4 2025 con 200 compradores únicos y Q1 2026 donde 70 de ellos
   volvieron a comprar
   CUANDO el sistema calcula la retención
   ENTONCES retention_rate = 35.0% (70 de 200 volvieron)
   Y el indicador muestra la variación respecto a la retención del
   trimestre anterior si está disponible

   Escenario 3: Top compradores por gasto — sin datos personales innecesarios
   DADO admin que activa la vista de alto valor (Alt. C)
   CUANDO el sistema calcula el top de compradores
   ENTONCES el listado muestra identificador de cuenta y gasto total
   Y no expone nombre completo ni dirección del comprador
   Y el admin puede exportar la lista para campañas de fidelización

   Escenario 4: Período sin ninguna orden entregada
   DADO período donde no hay órdenes con estado DELIVERED
   CUANDO el sistema calcula las métricas (Alt. B)
   ENTONCES new_buyers=0, repeat_buyers=0, total_buyers=0
   Y retention_rate no se puede calcular (denominador cero)
   Y el campo aparece vacío con la nota correspondiente

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms — el cálculo de
  retención requiere comparar dos conjuntos de usuarios entre dos
  períodos, lo que puede ser costoso si el historial es extenso;
  se recomienda indexar el campo ``user_id`` en la tabla de órdenes)
- **Notas:** Los compradores invitados (órdenes con ``user=null``)
  no se pueden rastrear entre períodos y no se incluyen en el cálculo
  de retención. Sí se incluyen en el total de compradores únicos del
  período como unidades anónimas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT-03: Ver Reporte de Compradores
   * - **Relacionado con**
     - FR-RPT-04.02 (el admin puede exportar este reporte)
   * - **Test**
     - TST-FR-RPT-03.02 (pendiente — verificar que los invitados
       no se incluyen en el cálculo de retención; verificar que el
       denominador cero en la retención no produce un error aritmético)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — código Python real, secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: cuatro métricas, retención sobre período
       anterior, compradores VIP sin datos personales innecesarios,
       compradores invitados excluidos de retención, 4 escenarios BDD

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-06-sincronizar-carrito
=========================================

**3 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-06-01-fusionar-carritos
   fr-cart-06-02-fusionar-carritos
   fr-cart-06-03-presentar-carrito-fusionado-y-nfr

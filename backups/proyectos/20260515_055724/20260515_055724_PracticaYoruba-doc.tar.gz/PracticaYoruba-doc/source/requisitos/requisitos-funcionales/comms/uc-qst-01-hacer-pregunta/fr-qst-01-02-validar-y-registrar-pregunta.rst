.. meta::
   :artefacto: FR-QST-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-qst-01-02:

==============================================================================
FR-QST-01.02: Validar la pregunta, verificar duplicados y registrar pendiente
==============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-01.02
   * - **Nombre**
     - Validar longitud y duplicidad de la pregunta, almacenarla en estado
       pendiente de moderación y notificar al equipo
   * - **UC Origen**
     - UC-QST-01: Hacer una Pregunta sobre un Producto
   * - **Paso UC**
     - Pasos 6, 7, 8, 9 y 10 del flujo principal
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Validación + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que la pregunta cumple la longitud mínima,
   verificar que no es un duplicado de una pregunta reciente para el
   mismo producto, almacenarla en estado pendiente de moderación y
   notificar al equipo CUANDO el visitante envía su pregunta.

**Descripcion:**

La pregunta puede ser enviada tanto por visitantes autenticados como
por visitantes anónimos. La diferencia está en cómo se identifica al
autor: si el visitante tiene sesión activa, la pregunta queda asociada
a su cuenta; si no, queda asociada al email que proporcionó de forma
voluntaria.

Las validaciones que el sistema aplica antes de aceptar la pregunta son:

1. **Longitud mínima.** La pregunta debe tener al menos 10 caracteres
   después de eliminar los espacios en blanco sobrantes. Una pregunta
   vacía o demasiado corta no aporta información suficiente para que
   el equipo pueda responder con utilidad.

2. **Verificación de duplicados (Alt. B y C).** El sistema compara
   la nueva pregunta con las preguntas existentes del mismo producto
   mediante una revisión de similitud básica por palabras clave. Si
   existe una pregunta idéntica o muy similar, el sistema informa al
   visitante y le muestra la respuesta que ya existe si el duplicado
   ya fue respondido. No se crea un registro nuevo. Si el visitante
   confirma que su pregunta es distinta, puede proceder.

3. **Revisión de contenido (EX-01 y EX-02).** Si la pregunta contiene
   contenido que activa los filtros del sistema, se almacena en estado
   de revisión manual en lugar de pendiente de respuesta normal. El
   visitante recibe la misma confirmación que en el caso habitual para
   no revelar que la pregunta fue marcada para revisión.

Si todas las validaciones pasan, el sistema registra la pregunta con
estado ``PENDING_MODERATION`` y notifica al equipo de forma asíncrona.
El visitante ve un mensaje de confirmación indicando que su pregunta
fue recibida y será respondida.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Pregunta válida registrada y equipo notificado
   DADO visitante autenticado que escribe "¿Esta sopera es apta para uso
   en ceremonias de Yemoja o solo es decorativa?" (62 caracteres)
   CUANDO POST /api/v1/catalogue/products/sopera-de-yemoja/questions/
   ENTONCES QuestionAnswer creado con status=PENDING_MODERATION
   Y el equipo recibe la notificación asíncrona
   Y el visitante ve "Tu pregunta fue recibida, responderemos pronto"

   Escenario 2: Pregunta muy corta — rechazada con mensaje claro
   DADO visitante que envía "¿Por qué?" (8 caracteres sin espacios)
   CUANDO el sistema valida la longitud
   ENTONCES HTTP 400 con {"errors": {"body":
   "La pregunta debe tener al menos 10 caracteres."}}
   Y no se crea ningún registro

   Escenario 3: Pregunta duplicada — se muestra la respuesta existente
   DADO producto con la pregunta "¿Hacen envíos a Monterrey?" ya respondida
   CUANDO el visitante envía una pregunta igual
   ENTONCES el sistema detecta el duplicado
   Y retorna HTTP 200 con la pregunta y respuesta existentes en lugar
   de crear un registro nuevo

   Escenario 4: Visitante anónimo — email requerido para seguimiento
   DADO visitante sin sesión que escribe una pregunta válida
   CUANDO envía el formulario sin email de contacto
   ENTONCES HTTP 400 indicando que el email es necesario para notificarle
   la respuesta
   Y cuando sí lo proporciona, la pregunta se registra correctamente

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-010 (el visitante puede preguntar sin iniciar
  sesión, pero debe proporcionar email para recibir la respuesta)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms), RNF-USAB-001
  (la sección de preguntas es localizable sin desplazamiento en la
  ficha del producto)
- **Notas:** El estado inicial es ``PENDING_MODERATION``, no
  ``PENDING_ANSWER``. El admin decide en UC-QST-04 si la pregunta
  pasa a ``PENDING_ANSWER`` o se rechaza.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST-01: Hacer una Pregunta
   * - **Requerido por**
     - FR-QST-04.02 (el admin modera la pregunta antes de que
       pase a pendiente de respuesta)
   * - **Relacionado con**
     - FR-CAT-02.02 (la ficha del producto muestra las preguntas
       ya respondidas via UC-QST-02)
   * - **Test**
     - TST-FR-QST-01.02 (pendiente — verificar que la detección de
       duplicados no genera falsos positivos en preguntas similares
       pero distintas)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: tres validaciones en prosa, visitante
       anónimo con email, EX-01 y EX-02, estado inicial documentado
       como PENDING_MODERATION, 4 escenarios BDD concretos

.. meta::
   :artefacto: FR-AUTH-04.09
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-04.09: NFR — Performance, Seguridad, Confiabilidad y Usabilidad del refresh
=====================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.09
   * - **Nombre**
     - Restricciones tecnicas del endpoint de renovacion de sesion
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Secciones 6.1 a 6.4 — Requisitos No Funcionales
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint POST /api/v1/auth/refresh/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico

----

2. Especificacion
-----------------

**Declaracion:**

   El endpoint de renovacion DEBE cumplir los requisitos de las cuatro
   dimensiones de calidad definidas en la seccion 6 del UC-AUTH-04.

**Descripcion:**

**Performance (6.1):**

- P95 <= 200ms — no hay comparacion de contraseña, solo consultas a BD
  para verificar blacklist + firma del token + emision del nuevo par
- El refresh es transparente: el usuario nunca espera que suceda

**Seguridad (6.2):**

- Rotacion obligatoria: el refresh token usado se invalida atomicamente
  con la emision del nuevo par
- La invalidacion y la emision son una sola operacion atomica con
  ``@transaction.atomic`` — no pueden quedar inconsistentes
- El refresh token viaja siempre por HTTPS (RNF-SEC-006)

**Confiabilidad (6.3):**

- Atomicidad: la invalidacion del token viejo y la emision del nuevo
  ocurren en la misma transaccion
- Sin interrupcion: el cliente solicita la renovacion ANTES de que
  el access token expire (cuando quedan < 60s), no despues. Esto
  garantiza que nunca hay un gap donde el usuario queda sin acceso.

**Usabilidad (6.4):**

- Transparente para el usuario: la renovacion ocurre en segundo plano,
  el usuario no ve ningun indicador ni interrupcion
- Si la renovacion falla por sesion expirada: el cliente redirige al login
  con el mensaje "Tu sesion ha expirado. Inicia sesion de nuevo." —
  nunca un error tecnico confuso

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Renovacion transparente bajo carga
   DADO 200 usuarios con access tokens proximos a expirar
   CUANDO todos renuevan en el mismo minuto
   ENTONCES P95 del endpoint es <= 200ms
   Y ningun usuario percibe una interrupcion en su sesion

   Escenario 2: Atomicidad verificada
   DADO renovacion exitosa
   CUANDO se inspeccionan las tablas de blacklist
   ENTONCES el token viejo esta en blacklisted_tokens
   Y el nuevo token esta en outstanding_tokens
   Y ambos cambios tienen el mismo timestamp (atomicos)

   Escenario 3: Renovacion proactiva vs reactiva
   DADO cliente que renueva cuando quedan 60s en el access token
   CUANDO el access token expira
   ENTONCES el usuario ya tiene un nuevo access token valido
   Y no hubo ningun momento sin acceso (0 segundos de gap)

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-002

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Secciones UC**
     - 6.1 Performance, 6.2 Seguridad, 6.3 Confiabilidad, 6.4 Usabilidad
   * - **RNF del sistema**
     - RNF-PERF-002, RNF-SEC-001, RNF-AVAIL-002
   * - **Test**
     - TST-FR-AUTH-04.09 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de la seccion 6 de UC-AUTH-04

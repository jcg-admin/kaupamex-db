.. meta::
   :artefacto: FR-CHT-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cht-01-02:

=============================================================================
FR-CHT-01.02: Recuperar variantes activas con stock y precio diferenciado
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-01.02
   * - **Nombre**
     - Recuperar las variantes activas del producto ordenadas por el
       criterio del admin, indicando disponibilidad de stock y precio
       diferenciado cuando la variante lo tiene
   * - **UC Origen**
     - UC-CHT-01: Ver Variantes de Producto
   * - **Paso UC**
     - Pasos 2, 3 y 6 del flujo principal
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar únicamente las variantes activas del
   producto, ordenadas según el criterio establecido por el admin,
   indicando para cada una el stock disponible y el precio que
   aplica, y actualizar el precio mostrado en pantalla de forma
   inmediata en el cliente cuando el visitante selecciona una
   variante diferente.

**Descripcion:**

Las variantes son las distintas presentaciones de un mismo producto.
Para una sopera, por ejemplo, las variantes pueden ser Pequeña,
Mediana y Grande. Cada variante tiene su propio nivel de stock y
puede tener un precio distinto al precio base del producto.

El sistema recupera las variantes junto con la ficha del producto
(FR-CAT-02.02) en una sola respuesta. No hay un endpoint separado
para las variantes: forman parte del objeto producto que se devuelve
al visitante.

**Qué incluye cada variante en la respuesta:**
El nombre de la variante, el stock disponible, un indicador de si
está disponible o agotada, y el precio que aplica. Si la variante
tiene precio diferenciado configurado (FR-CHT-04.02), ese precio
es el que se muestra al seleccionarla. Si no tiene precio
diferenciado, se muestra el precio base del producto.

**Actualización del precio en el cliente (paso 6):**
Cuando el visitante cambia de variante, el precio que aparece en
la ficha se actualiza de forma inmediata sin ninguna solicitud
adicional al servidor. Todos los precios de todas las variantes
se entregaron ya en la respuesta inicial; el cliente los tiene
disponibles para mostrar el correcto según la selección activa.

**Variante única con stock (Alt. A):**
Si solo una variante tiene stock disponible, esa variante queda
preseleccionada automáticamente. Las demás aparecen visualmente
deshabilitadas con el indicador de agotadas para que el visitante
entienda qué opciones existen aunque no estén disponibles.

**Producto sin variantes (EX-01):**
Si el producto no tiene variantes configuradas, el campo
``variants`` de la respuesta es una lista vacía. El visitante
agrega el producto al carrito directamente sin necesidad de
seleccionar nada.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Producto con tres variantes de distintos stocks
   DADO producto "Sopera de Yemoja" con variantes:
   Pequeña (stock=8), Mediana (stock=0), Grande (stock=3)
   CUANDO se carga la ficha del producto
   ENTONCES la respuesta incluye las 3 variantes
   Y Mediana tiene un indicador de agotada y no puede seleccionarse
   Y Pequeña y Grande están disponibles para selección

   Escenario 2: Selección de variante actualiza el precio sin ir al servidor
   DADO producto con Pequeña=$650 y Grande=$1200
   CUANDO el visitante selecciona Grande
   ENTONCES el precio en pantalla cambia de $650 a $1200 de forma inmediata
   Y no se realiza ninguna petición adicional al servidor para obtener
   el precio de la variante Grande

   Escenario 3: Única variante con stock preseleccionada automáticamente
   DADO producto con 3 variantes donde solo Mediana tiene stock (Alt. A)
   CUANDO se carga la ficha
   ENTONCES Mediana aparece preseleccionada
   Y Pequeña y Grande aparecen deshabilitadas con el indicador de agotadas
   Y el botón de agregar al carrito está habilitado con la variante Mediana

   Escenario 4: Producto sin variantes — selector omitido
   DADO producto configurado sin variantes (EX-01)
   CUANDO se carga la ficha
   ENTONCES variants=[] en la respuesta
   Y no aparece ningún selector de variantes en la interfaz
   Y el visitante puede agregar directamente sin seleccionar nada

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 200ms — las variantes
  se incluyen en la misma respuesta que la ficha del producto,
  sin petición adicional), RNF-SEC-003 (el precio de la variante
  siempre se valida en el servidor al agregar al carrito; el precio
  mostrado en el cliente es solo informativo y no se puede manipular
  para obtener un precio distinto al guardado)
- **Notas:** Las variantes se ordenan según el campo ``order``
  configurado por el admin en FR-CHT-03.02. Si dos variantes tienen
  el mismo ``order``, se ordenan alfabéticamente por nombre.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT-01: Ver Variantes de Producto
   * - **Depende de**
     - FR-CAT-02.02 (las variantes se entregan como parte de la
       ficha del producto)
   * - **Requerido por**
     - FR-CHT-02.02 (el visitante selecciona una variante antes de
       agregar al carrito)
   * - **Relacionado con**
     - FR-CHT-04.02 (el precio diferenciado de cada variante)
   * - **Test**
     - TST-FR-CHT-01.02 (pendiente — verificar que las variantes
       agotadas aparecen en la respuesta pero marcadas como no
       disponibles; verificar que la respuesta incluye el precio
       correcto para variantes con precio diferenciado)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — código Python real, secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: variantes en respuesta única sin endpoint
       separado, actualización de precio en cliente sin petición al
       servidor, variante única preseleccionada Alt. A, 4 escenarios
       BDD con datos concretos

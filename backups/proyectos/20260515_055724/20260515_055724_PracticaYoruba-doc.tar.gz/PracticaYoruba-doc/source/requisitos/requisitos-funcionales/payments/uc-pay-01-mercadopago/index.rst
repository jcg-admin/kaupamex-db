.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-01-mercadopago
================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-01-01-crear-preferencia-mp
   fr-pay-01-02-crear-preferencia-mp

.. meta::
   :artefacto: FR-AUTH-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-06.02: Presentar formulario de edicion con datos precargados
=====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-06.02
   * - **Nombre**
     - Retornar los datos actuales del perfil para precargar el formulario de edicion
   * - **UC Origen**
     - UC-AUTH-06: Editar Perfil
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint GET /api/v1/auth/profile/edit/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar los datos actuales del perfil para que
   el formulario de edicion los muestre precargados CUANDO el usuario
   navega a la pagina de edicion.

**Descripcion:**

El formulario de edicion se carga via un GET al endpoint de perfil
(puede reutilizar FR-AUTH-05.02 o un endpoint dedicado de edicion).

Datos retornados para precargar el formulario:

.. code-block:: json

   {
     "first_name": "Juan",
     "last_name": "Perez",
     "phone": "+52 55 1234 5678",
     "avatar_url": "https://cdn.ojayoruba.com/avatars/42.jpg",
     "avatar_exists": true,
     "constraints": {
       "first_name_max": 50,
       "last_name_max": 50,
       "phone_formats": ["internacional", "local_mx"],
       "avatar_max_size_mb": 5,
       "avatar_formats": ["JPEG", "PNG", "WebP"],
       "avatar_min_dimensions": "200x200"
     }
   }

El campo ``constraints`` informa al frontend las reglas de validacion
para que pueda implementar la validacion en cliente (FR-AUTH-06.03)
sin hardcodearlas.

Campos que NO se precargan: ``email`` (no editable aqui),
``password`` (tiene su propio UC), ``username`` (inmutable).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Formulario precargado con datos actuales
   DADO usuario con nombre "Juan", apellido "Perez" y telefono "+52..."
   CUANDO accede al formulario de edicion
   ENTONCES el campo nombre muestra "Juan"
   Y el campo apellido muestra "Perez"
   Y el campo telefono muestra "+52..."
   Y el avatar actual se muestra como miniatura

   Escenario 2: Usuario sin datos opcionales — campos vacios
   DADO usuario que solo tiene email y username
   CUANDO accede al formulario de edicion
   ENTONCES first_name, last_name, phone estan vacios (listos para llenar)
   Y avatar_exists = false (muestra el avatar placeholder)

   Escenario 3: Constraints retornados correctamente
   DADO solicitud del formulario de edicion
   CUANDO se retorna la respuesta
   ENTONCES constraints incluye los limites actuales de la configuracion
   Y el frontend puede validar en cliente sin hardcodear los valores

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-USAB-001 (datos precargados para no
  obligar al usuario a volver a escribir todo)
- **Notas:** Esta es la primera accion del sistema — el usuario
  solo navego a la pagina. Ninguna modificacion ocurre en este paso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-06: Editar Perfil
   * - **Depende de**
     - FR-AUTH-05.01 (perfil cargado en UC-AUTH-05)
   * - **Requerido por**
     - FR-AUTH-06.01 (el usuario modifica los campos y guarda)
   * - **Test**
     - TST-FR-AUTH-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 2 de UC-AUTH-06

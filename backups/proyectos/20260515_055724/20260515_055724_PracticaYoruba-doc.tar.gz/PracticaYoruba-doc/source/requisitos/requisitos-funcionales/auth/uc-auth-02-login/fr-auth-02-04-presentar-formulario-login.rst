.. meta::
   :artefacto: FR-AUTH-02.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-04:

===================================================
FR-AUTH-02.04: Presentar formulario de inicio de sesion
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.04
   * - **Nombre**
     - Presentar el formulario de identificador y contraseña con sus enlaces de apoyo
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE presentar el formulario de inicio de sesion con todos
   sus campos y enlaces de apoyo CUANDO el visitante accede a la
   pagina de autenticacion.

**Descripcion:**

El formulario contiene exactamente:

- Campo ``identificador`` — etiqueta "Email", placeholder "tu@email.com",
  tipo ``email``, autocompletado activado (``autocomplete="email"``)
- Campo ``contraseña`` — etiqueta "Contraseña", tipo ``password``,
  boton de mostrar/ocultar (toggle) con icono de ojo,
  ``autocomplete="current-password"``
- Casilla ``recordarme`` — opcional, desmarcada por defecto.
  Si se activa: el refresh token tiene vida extendida segun
  ``SiteSettings.remember_me_days`` (default: 30 dias)
- Boton de envio — texto "Iniciar sesion", habilitado al cargar

Ademas del formulario, la pagina presenta:

- Enlace "¿Olvidaste tu contraseña?" → UC-AUTH-09 (recuperar contraseña)
- Enlace "Crear cuenta" → UC-AUTH-01 (registro)

El formulario NO incluye CAPTCHA en el MVP — el rate limiting
por IP (FR-AUTH-02.01) actua como primera linea de proteccion.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Formulario presentado correctamente
   DADO visitante que accede a GET /login/
   CUANDO la pagina carga
   ENTONCES el formulario tiene campo identificador, campo contraseña y
   casilla recordarme
   Y el campo identificador tiene el foco automaticamente (autofocus)
   Y los enlaces de recuperacion y registro son visibles

   Escenario 2: Comprador ya autenticado no ve el formulario
   DADO comprador con JWT valido activo
   CUANDO intenta acceder a /login/
   ENTONCES el sistema redirige a /inicio/ (area protegida)
   Y no muestra el formulario de login

   Escenario 3: Toggle de visibilidad de contraseña
   DADO campo contraseña visible en el formulario
   CUANDO el visitante hace clic en el icono de ojo
   ENTONCES el campo alterna entre type="password" y type="text"
   Y el icono cambia para indicar el estado actual

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna — este paso es puramente de presentacion
- **RNF aplicables:** RNF-USAB-002 (campos claramente identificados,
  navegable por teclado, compatible WCAG 2.1 AA)
- **Notas:** El campo identificador acepta email o username.
  El label dice "Email o nombre de usuario" para reflejar ambas opciones.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - Ninguno — es el primer paso del Sistema en este UC
   * - **Requerido por**
     - FR-AUTH-02.05 (validacion en tiempo real del identificador)
   * - **Test**
     - TST-FR-AUTH-02.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 2 de UC-AUTH-02

.. meta::
   :artefacto: FR-AUTH-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-05-01:

=========================================================
FR-AUTH-05.01: Recuperar y presentar datos del perfil
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-05.01
   * - **Nombre**
     - Recuperar los datos del perfil del comprador autenticado
   * - **UC Origen**
     - UC-AUTH-05: Ver perfil
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar y retornar los datos del perfil
   CUANDO el comprador autenticado accede a su perfil.

**Descripcion:**

Datos retornados en el perfil:

- ``username``, ``email``, ``first_name``, ``last_name``
- ``phone`` (puede estar vacio)
- ``avatar_url`` (URL absoluta del avatar si existe, null si no)
- ``date_joined``
- ``profile_completeness`` — porcentaje calculado de campos
  opcionales completados (phone, avatar, direccion guardada)
- Lista de acciones disponibles: editar perfil, gestionar
  direcciones, cambiar contrasena, preferencias de notificacion

Los campos ``is_staff`` y ``is_superuser`` NO se incluyen
en la respuesta para compradores no staff.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado
   CUANDO hace GET /api/v1/auth/profile/
   ENTONCES recibe sus datos de perfil actualizados

   Escenario 1: Perfil completo
   DADO comprador con phone, avatar y direccion guardados
   CUANDO accede al perfil
   ENTONCES profile_completeness = 100
   Y todos los campos opcionales aparecen con sus valores

   Escenario 2: Perfil incompleto
   DADO comprador sin phone ni avatar
   CUANDO accede al perfil
   ENTONCES profile_completeness < 100
   Y los campos faltantes se retornan como null
   Y la respuesta indica que campos completar

   Escenario 3: Avatar con URL correcta
   DADO comprador con avatar subido
   CUANDO accede al perfil
   ENTONCES avatar_url es una URL absoluta accesible
   Y no es una ruta relativa al servidor

   Escenario 4: Aislamiento de datos
   DADO comprador A autenticado
   CUANDO accede a GET /api/v1/auth/profile/
   ENTONCES solo ve SUS datos, nunca datos de otro usuario

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-SEC-003 (aislamiento datos usuario)
- **Notas:** El perfil es del usuario autenticado en el JWT.
  No existe endpoint para ver el perfil de otro usuario.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-05: Ver perfil
   * - **Depende de**
     - FR-AUTH-02.03 (sesion activa con JWT)
   * - **Requerido por**
     - FR-AUTH-06.01 (datos precargados para editar perfil)
   * - **RNF**
     - RNF-SEC-003
   * - **Test**
     - TST-FR-AUTH-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-05

.. meta::
   :artefacto: FR-AUTH-10.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-10-03:

======================================================
FR-AUTH-10.03: Registrar auditoria y confirmar activacion
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-10.03
   * - **Nombre**
     - Crear registro de auditoria y redirigir al usuario al inicio de sesion
   * - **UC Origen**
     - UC-AUTH-10: Verificar Email
   * - **Paso UC**
     - Pasos 12 y 13 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (AccessAuditLog + respuesta)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Auditoria + Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar la verificacion exitosa del email en
   auditoria e informar al usuario que puede iniciar sesion CUANDO
   la cuenta ha sido activada exitosamente.

**Descripcion:**

**Paso 12 — Registro de auditoria:**

El sistema crea un registro ``AccessAuditLog`` con los campos:
referencia al ``User``, tipo de evento ``VERIFICACION_EMAIL``,
dirección IP del cliente, resultado ``EXITOSO``, y un campo
``metadata`` que contiene el identificador primario del
``EmailVerificationToken`` utilizado y el email verificado del
usuario. El email en metadata permite confirmar en auditoría qué
dirección de correo quedó verificada.

**Paso 13 — Confirmacion y redireccion:**

.. code-block:: json

   HTTP 200
   {
     "mensaje": "Tu email fue verificado. Tu cuenta esta activa.",
     "info": "Ahora puedes iniciar sesion con tu email y contraseña.",
     "redirect": "/login/"
   }

El usuario accede al sistema via un navegador (el enlace abre en el
browser). El frontend renderiza la pagina de confirmacion y ofrece
un boton de "Iniciar sesion" que lleva a UC-AUTH-02.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Auditoria creada con email verificado
   DADO verificacion exitosa
   CUANDO se crea el registro
   ENTONCES AccessAuditLog tiene event_type = VERIFICACION_EMAIL
   Y metadata.email = email del usuario verificado
   Y metadata.token_id = ID del token de verificacion

   Escenario 2: Usuario puede iniciar sesion inmediatamente
   DADO cuenta activada via verificacion de email
   CUANDO el usuario hace clic en "Iniciar sesion"
   ENTONCES FR-AUTH-02.09 (verificar email) ahora pasa exitosamente
   Y el usuario puede autenticarse normalmente

   Escenario 3: Fallo de auditoria no revierte la activacion
   DADO error al insertar en AccessAuditLog
   CUANDO falla el INSERT
   ENTONCES la cuenta permanece activa (is_active = True)
   Y el usuario puede iniciar sesion normalmente
   Y el fallo queda en django.log nivel ERROR

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria de activacion de cuenta)
- **Notas:** La confirmacion de activacion es una pagina de destino
  del enlace del email — el usuario la ve en su navegador. No es una
  respuesta de API pura. El ``redirect`` en el JSON lo usa el frontend
  para el boton "Iniciar sesion".

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-10: Verificar Email
   * - **Depende de**
     - FR-AUTH-10.02 (cuenta activada y token marcado como usado)
   * - **Requerido por**
     - Ninguno — ultimo paso del Sistema en UC-AUTH-10
   * - **Habilita**
     - FR-AUTH-02.09 (el login ahora funciona para este usuario)
   * - **RNF**
     - RNF-PROC-002
   * - **Test**
     - TST-FR-AUTH-10.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 12 y 13 de UC-AUTH-10
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Bloque JSON conservado — contrato de respuesta HTTP.

.. meta::
   :artefacto: FR-INC-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/includes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inc-01-01:

FR-INC-01.01: Verificar propiedad de la orden — patron include
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INC-01.01
   * - **Nombre**
     - Verificar propiedad de la orden — patron include
   * - **UC Origen**
     - UC-INC 01 VERIFICAR PROPIEDAD ORDEN
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la orden al UC incluidor CUANDO el actor tiene derecho a ella.

**Descripcion:**

Logica de verificacion:

- **Comprador autenticado**: ``Order.user_id == request.user.id``
- **Visitante con numero de orden**: ``Order.order_number == order_number AND Order.guest_email == email``
- Si no coincide: retorna 404 (sin revelar si la orden existe para otro usuario)

El UC incluidor recibe el objeto Order para continuar su flujo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Comprador autenticado dueno de la orden
   DADO comprador autenticado y la orden le pertenece
   CUANDO verifica
   ENTONCES retorna el objeto Order al UC incluidor

   Escenario: Acceso a orden ajena
   DADO comprador A intentando acceder a la orden del comprador B
   CUANDO verifica
   ENTONCES error 404 — sin revelar que la orden existe

   Escenario: Visitante con numero y email correcto
   DADO visitante que ingresa order_number y guest_email correctos
   CUANDO verifica
   ENTONCES retorna el objeto Order


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** La respuesta 404 (no 403) es intencional — no revelar si la orden existe protege la privacidad.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INC 01 VERIFICAR PROPIEDAD ORDEN
   * - **Depende de**
     - JWT del actor o (order_number + guest_email)
   * - **Requerido por**
     - UC-ORD-02, UC-ORD-04, UC-ORD-05, UC-ORD-06, UC-PAY-05, UC-PAY-06, UC-LOG-03, UC-LOG-07
   * - **Test**
     - TST-FR-INC-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INC 01 VERIFICAR PROPIEDAD ORDEN

.. meta::
   :artefacto: FR-INV-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INV-01.02: Mostrar dashboard de stock con alertas por umbral minimo
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-01.02
   * - **Nombre**
     - Listar productos con stock actual, estado de alerta y filtro por estado
   * - **UC Origen**
     - UC-INV-01: Ver Stock
   * - **Paso UC**
     - Pasos 2, 3 y 5 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el inventario completo con el estado de
   alerta de cada producto calculado respecto al umbral minimo
   configurado en SiteSettings CUANDO el admin accede al dashboard
   de inventario.

**Descripcion:**

El sistema lee ``SiteSettings.min_stock_threshold`` (valor por
defecto 5) y clasifica cada ``ProductVariant`` según su stock:
``'AGOTADO'`` si ``stock = 0``, ``'BAJO'`` si ``stock ≤ min_stock_threshold``,
o ``'NORMAL'`` en caso contrario. Recupera todos los registros
``ProductVariant`` con carga anticipada del ``Product`` y la variante
correspondiente, ordenados por ``Product.name`` y ``variant.order``.

El admin puede filtrar por estado: ``?status=BAJO`` retorna solo
los productos bajo el umbral. ``?status=AGOTADO`` retorna los sin stock.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Dashboard con productos en diferentes estados
   DADO inventario con NORMAL=10, BAJO=3, AGOTADO=1 productos
   CUANDO el admin accede
   ENTONCES cada producto muestra su stock actual y su estado NORMAL/BAJO/AGOTADO
   Y los productos BAJO y AGOTADO se destacan visualmente

   Escenario 2: Filtro por estado BAJO
   DADO GET /api/v1/admin/inventory/?status=BAJO
   CUANDO el admin filtra
   ENTONCES solo aparecen productos con 1 <= stock <= min_threshold

   Escenario 3: Umbral configurable respetado
   DADO SiteSettings.min_stock_threshold = 10
   CUANDO se calcula el estado
   ENTONCES un producto con stock=8 aparece como BAJO (8 <= 10)

----

4. Reglas y Restricciones
--------------------------

- **Notas:** El umbral minimo es global (SiteSettings). En una futura
  iteracion se puede hacer por-producto.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV-01: Ver Stock
   * - **Requerido por**
     - FR-ORD-01.02 (la reserva atomica consulta el mismo stock)
   * - **Test**
     - TST-FR-INV-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-INV-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

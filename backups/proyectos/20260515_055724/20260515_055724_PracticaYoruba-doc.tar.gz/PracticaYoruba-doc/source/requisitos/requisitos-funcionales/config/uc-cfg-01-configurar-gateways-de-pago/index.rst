.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cfg-01-configurar-gateways-de-pago
================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cfg-01-02-guardar-credenciales-cifradas
   fr-cfg-01-configurar-gateways-de-pago-01

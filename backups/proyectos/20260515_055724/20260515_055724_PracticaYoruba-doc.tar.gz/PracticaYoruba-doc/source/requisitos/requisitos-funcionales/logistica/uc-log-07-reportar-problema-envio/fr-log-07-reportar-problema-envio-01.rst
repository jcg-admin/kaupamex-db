.. meta::
   :artefacto: FR-LOG-07.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-07-01:

FR-LOG-07.01: Crear reporte de problema de envio
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-07.01
   * - **Nombre**
     - Crear reporte de problema de envio
   * - **UC Origen**
     - UC-LOG 07 REPORTAR PROBLEMA ENVIO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear el reporte de problema CUANDO el comprador lo reporta.

**Descripcion:**

El reporte se crea con:

- ``order``, ``user``, ``tipo_problema``, ``descripcion``
- ``evidencias[]``: archivos de imagen adjuntos (max 5, 5MB c/u)
- ``status = RECIBIDO``

Rate limiting: maxima 1 reporte activo por orden.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reporte creado exitosamente
   DADO comprador con orden SHIPPED o DELIVERED
   CUANDO reporta 'paquete danado' con foto adjunta
   ENTONCES el reporte queda en BD con status=RECIBIDO
   Y el equipo lo ve en la cola de admin

   Escenario: Reporte duplicado por la misma orden
   DADO orden con reporte ya activo
   CUANDO el comprador intenta crear otro
   ENTONCES error 409: REPORTE_YA_EXISTENTE


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El reporte requiere que la orden este en estado SHIPPED o DELIVERED.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 07 REPORTAR PROBLEMA ENVIO
   * - **Depende de**
     - Propiedad verificada via INC-01
   * - **Requerido por**
     - Equipo de soporte revisa en panel admin
   * - **Include**
     - UC-INC-01
   * - **Test**
     - TST-FR-LOG-07.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 07 REPORTAR PROBLEMA ENVIO

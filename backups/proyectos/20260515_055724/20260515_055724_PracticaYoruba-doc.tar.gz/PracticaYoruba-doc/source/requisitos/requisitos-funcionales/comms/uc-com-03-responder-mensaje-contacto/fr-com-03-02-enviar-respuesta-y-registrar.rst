.. meta::
   :artefacto: FR-COM-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-04-30
   :fecha_actualizacion: 2026-05-03

.. _fr-com-03-02:

==============================================================================
FR-COM-03.02: Enviar respuesta al remitente y registrar en el historial
==============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-03.02
   * - **Nombre**
     - Encolar el email de respuesta, actualizar ContactMessage a REPLIED y registrar ContactReply
   * - **UC Origen**
     - UC-COM-03: Responder Mensaje de Contacto
   * - **Paso UC**
     - Pasos 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-014 CONTACT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicacion + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE encolar el email de respuesta al remitente via
   UC-INC-03, actualizar el estado del ContactMessage a REPLIED y
   crear un registro ContactReply con el admin responsable y el
   timestamp CUANDO el admin confirma el envio de la respuesta.

**Descripcion:**

La operación ocurre de forma que el registro de la respuesta y
el cambio de estado del mensaje quedan garantizados incluso si
el encolo del email falla posteriormente:

1. **Guardia contra duplicados.** Si el mensaje ya tiene estado
   ``REPLIED``, el sistema rechaza el intento con un error claro
   antes de hacer ninguna escritura.

2. **Registro en el historial.** Se crea un ``ContactReply`` con
   el cuerpo de la respuesta, el admin que la redactó y el
   momento exacto del envío.

3. **Actualización del estado.** El ``ContactMessage`` pasa a
   estado ``REPLIED``.

4. **Encolo del email al remitente.** El email se encola de forma
   asíncrona via UC-INC-03 usando la plantilla ``CONTACT_REPLY``.
   La respuesta HTTP al admin no espera a que el email sea entregado.

**EX-01 — Fallo del Servicio de Email Externo:**
Si el encolo falla, el ``ContactReply`` y el estado ``REPLIED`` ya
fueron persistidos. El admin puede reenviar desde el historial del
mensaje (Alt. B del UC) sin que se duplique el registro: el reenvío
encola un nuevo email pero no crea otro ``ContactReply``.

**Alt. A — Nota interna:**
El admin puede añadir una nota interna además de la respuesta al
remitente. La nota queda en el historial del mensaje marcada como
interna — solo visible para el equipo — y no dispara ningún email
al visitante.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Respuesta enviada y mensaje actualizado
   DADO mensaje id=42 de "Ana Lopez" con email "ana@ejemplo.com"
   CUANDO el admin escribe "Hola Ana, si enviamos a Guadalajara..."
   Y hace clic en enviar
   ENTONCES ContactReply creado con replied_by=admin, replied_at=timestamp
   Y ContactMessage.status = REPLIED
   Y email encolado al destinatario ana@ejemplo.com
   Y HTTP 200 con el ContactReply creado

   Escenario 2: Respuesta a mensaje ya respondido — error claro
   DADO mensaje id=42 que ya tiene status=REPLIED
   CUANDO el admin intenta enviar otra respuesta
   ENTONCES HTTP 400 con {"codigo_error": "MENSAJE_YA_RESPONDIDO",
   "mensaje": "Este mensaje ya fue respondido. Usa la opcion de reenvio."}
   Y no se crea un segundo ContactReply

   Escenario 3: Fallo del servicio de email — respuesta guardada igual
   DADO fallo en el Servicio de Email Externo al intentar encolar
   CUANDO el sistema detecta el fallo
   ENTONCES ContactReply se creo y ContactMessage.status = REPLIED (ya persistidos)
   Y HTTP 200 con aviso: "Respuesta guardada. El email al remitente
   sera reenviado automaticamente cuando el servicio este disponible."

   Escenario 4: Nota interna — sin email al remitente
   DADO admin que agrega una nota interna "pendiente de verificar con el courier"
   CUANDO POST con {"is_internal": true}
   ENTONCES ContactReply.is_internal = True
   Y ContactMessage.status no cambia (el mensaje no esta formalmente respondido)
   Y ningun email es encolado al remitente

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 2s — la respuesta HTTP
  no espera el envio del email, solo el encolo), RNF-AVAIL-003
  (si el servicio de email falla, el sistema reintenta via FR-SYS-04.02
  con backoff exponencial)
- **Notas:** El email del remitente no se muestra al admin en texto
  plano en la UI salvo en la bandeja de detalle. El sistema lo usa
  directamente para el envio sin necesidad de que el admin lo copie.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM-03: Responder Mensaje de Contacto
   * - **Depende de**
     - FR-COM-02.02 (el admin accede al detalle desde la bandeja)
   * - **Incluye**
     - UC-INC-03 (encolar email con plantilla CONTACT_REPLY)
   * - **Relacionado con**
     - FR-SYS-04.02 (reintento con backoff si el email falla)
   * - **Test**
     - TST-FR-COM-03.02 (pendiente — mock del servicio de email,
       verificar que ContactReply persiste aunque el mock falle)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial
   * - 1.2.0
     - 2026-05-03
     - Eliminado código Python; descripción reemplazada por
       prosa numerada con los 4 pasos de la operación

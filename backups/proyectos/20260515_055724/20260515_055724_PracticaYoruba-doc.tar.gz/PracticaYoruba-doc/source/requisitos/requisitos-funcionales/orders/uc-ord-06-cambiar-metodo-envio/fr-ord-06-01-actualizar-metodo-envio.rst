.. meta::
   :artefacto: FR-ORD-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-ORD-06.01: Actualizar metodo de envio
=========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-06.01
   * - **Nombre**
     - Cambiar el ShippingMethod de una orden en PENDING_PAYMENT
   * - **UC Origen**
     - UC-ORD-06: Cambiar metodo de envio
   * - **Paso UC**
     - Pasos 3-4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el metodo de envio de la orden y
   recalcular el total CUANDO el comprador selecciona uno diferente.

**Descripcion:**

Solo en estado ``PENDING_PAYMENT``. El cambio actualiza:

- ``ShippingInfo.method_name`` (snapshot del nuevo metodo)
- ``OrderValue.shipping_cost`` = costo del nuevo metodo
- ``OrderValue.total`` = recalculado con el nuevo costo de envio

Si el nuevo metodo resulta en envio gratis (subtotal supera umbral),
``shipping_cost`` queda en 0.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO orden en PENDING_PAYMENT con metodo A
   CUANDO el comprador selecciona metodo B
   ENTONCES shipping_cost y total se recalculan

   Escenario 1: Cambio a metodo mas economico
   DADO orden con shipping_cost = 120
   CUANDO se cambia a metodo con costo = 80
   ENTONCES shipping_cost = 80 y total se reduce en 40

   Escenario 2: Cambio a envio gratis
   DADO subtotal que supera el umbral de envio gratis
   CUANDO se selecciona metodo con costo = 0
   ENTONCES shipping_cost = 0 y aparece badge de envio gratis

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (el nuevo snapshot reemplaza al anterior)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-06: Cambiar metodo de envio
   * - **Depende de**
     - FR-ORD-02.01 (propiedad verificada)
   * - **Requerido por**
     - FR-PAY-01.01 (el pago incluye el costo de envio)
   * - **Test**
     - TST-FR-ORD-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-06

.. meta::
   :artefacto: FR-AUTH-04.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-04-04:

============================================================
FR-AUTH-04.04: Verificar que la cuenta del usuario sigue activa
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-04.04
   * - **Nombre**
     - Comprobar que el usuario no fue suspendido entre el login y la renovacion
   * - **UC Origen**
     - UC-AUTH-04: Renovar Sesion
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — User.is_active)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la cuenta del usuario sigue activa
   CUANDO el token de renovacion es valido y no ha expirado.

**Descripcion:**

Este paso es critico porque entre el momento del login (cuando se
emitio el refresh token) y el momento de la renovacion, la cuenta
puede haber sido suspendida por el administrador.

El access token JWT es stateless — no se puede revocar antes de su
expiracion de 15 minutos. Sin embargo, el refresh token requiere
una llamada al servidor, donde se puede verificar el estado actual
de la cuenta.

El sistema recupera el registro ``User`` asociado a la credencial
de renovación y comprueba el campo ``User.is_active``. Si el
usuario no existe en el repositorio o su cuenta está inactiva,
el proceso se interrumpe.

Si la cuenta está suspendida (``User.is_active = False``):

- HTTP 401 con ``codigo_error: CUENTA_INACTIVA``
- El refresh token queda en la blacklist (se invalida para que no
  se pueda seguir intentando renovar con el mismo token)
- El cliente informa al usuario del estado de su cuenta

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Cuenta activa — renovacion procede
   DADO refresh token valido de un usuario con is_active = True
   CUANDO se verifica el estado de la cuenta
   ENTONCES la verificacion pasa
   Y el proceso continua a FR-AUTH-04.01 (emitir nuevas credenciales)

   Escenario 2: Admin suspendio la cuenta entre login y renovacion
   DADO usuario que inicio sesion hace 3 dias y hoy fue suspendido por el admin
   CUANDO su cliente intenta renovar el access token expirado
   ENTONCES HTTP 401 con {"codigo_error": "CUENTA_INACTIVA",
   "mensaje": "Tu cuenta esta suspendida. Contacta al soporte."}
   Y el refresh token se invalida en la blacklist
   Y el usuario no puede obtener nuevas credenciales hasta que el admin reactive

   Escenario 3: Usuario eliminado (borrado de BD)
   DADO refresh token de un usuario cuyo registro fue eliminado de la BD
   CUANDO se intenta renovar
   ENTONCES HTTP 401 con {"codigo_error": "CUENTA_NO_ENCONTRADA"}
   Y el token se invalida

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** Este es uno de los pocos momentos donde el estado
  del servidor se consulta durante el ciclo de vida de un JWT.
  Es el "punto de control" que permite revocar el acceso a un usuario
  a pesar de la naturaleza stateless del access token.
  El access token actual del usuario (si lo tiene) seguira siendo valido
  hasta su exp de 15 minutos — esta es la unica ventana residual.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-04: Renovar Sesion
   * - **Depende de**
     - FR-AUTH-04.03 (token no expirado)
   * - **Requerido por**
     - FR-AUTH-04.01 (rotar tokens — emitir nuevas credenciales)
   * - **Test**
     - TST-FR-AUTH-04.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 5 de UC-AUTH-04

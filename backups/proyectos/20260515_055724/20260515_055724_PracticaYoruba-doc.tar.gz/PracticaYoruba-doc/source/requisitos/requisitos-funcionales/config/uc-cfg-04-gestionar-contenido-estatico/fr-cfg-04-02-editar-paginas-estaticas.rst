.. meta::
   :artefacto: FR-CFG-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cfg-04-02:

==========================================================================
FR-CFG-04.02: Publicar contenido estático con versionado y reversión
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-04.02
   * - **Nombre**
     - Persistir la nueva versión del contenido estático, incrementar el
       número de versión, permitir la reversión a versiones anteriores
       y soportar publicación programada para fecha futura
   * - **UC Origen**
     - UC-CFG-04: Gestionar Contenido Estático
   * - **Paso UC**
     - Paso 5 del flujo principal; Alt. B (reversión); Alt. C (programado)
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE persistir el nuevo contenido como una versión
   numerada de la página, mantener el historial completo de versiones
   anteriores, permitir la reversión a cualquier versión previa y
   soportar la publicación programada para una fecha y hora futura
   CUANDO el admin confirma la publicación de una página estática.

**Descripcion:**

Las páginas estáticas que el admin puede editar son: Acerca de,
Términos y Condiciones, Política de Privacidad, Política de
Devoluciones y Preguntas Frecuentes. Cada una tiene una lista de
versiones numeradas de forma creciente. La versión activa es la que
ven los visitantes del sitio.

**Publicación inmediata (paso 5).**
Cuando el admin confirma la publicación, el sistema crea un nuevo
registro de versión con el contenido HTML editado, el número de
versión siguiente, el admin responsable y el timestamp. La versión
anterior no se elimina: pasa a estado ``ARCHIVED`` y queda en el
historial. La versión recién publicada pasa a estado ``PUBLISHED``
y el sistema invalida el cache de la página para que los visitantes
vean el nuevo contenido inmediatamente.

**Reversión a versión anterior (Alt. B).**
El admin puede seleccionar cualquier versión archivada y publicarla
de nuevo. La reversión crea una nueva versión numerada con el
contenido de la versión elegida, en lugar de modificar el registro
histórico. De este modo el historial es siempre acumulativo: se puede
saber exactamente qué contenido estuvo publicado y cuándo.

**Publicación programada (Alt. C).**
El admin puede guardar el contenido editado como borrador con una
fecha y hora de publicación futura. El sistema almacena la versión
con estado ``SCHEDULED`` y el Actor Tiempo la publica automáticamente
en el momento configurado. El admin puede modificar o cancelar la
publicación programada mientras el estado sea ``SCHEDULED``.

**Imágenes no encontradas (EX-02).**
Si el HTML del nuevo contenido contiene referencias a imágenes que
el Servicio de Archivos no puede localizar, el sistema advierte al
admin antes de publicar. El admin puede corregir las URLs o confirmar
la publicación aceptando que algunas imágenes podrían no mostrarse.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Términos y Condiciones actualizados — versión incrementada
   DADO página "Términos y Condiciones" en versión 4
   CUANDO el admin edita y publica
   ENTONCES se crea la versión 5 con el nuevo contenido
   Y la versión 4 pasa a estado ARCHIVED (no se elimina)
   Y el cache de la página se invalida
   Y los visitantes ven el contenido nuevo en el siguiente acceso

   Escenario 2: Reversión a versión anterior — crea nueva versión
   DADO admin que quiere volver al contenido de la versión 3
   CUANDO selecciona la versión 3 y publica
   ENTONCES se crea la versión 6 con el contenido de la versión 3
   Y el historial muestra versiones 1 a 6 de forma continua
   Y la versión 3 original sigue en ARCHIVED sin modificación

   Escenario 3: Publicación programada — Actor Tiempo la activa
   DADO admin que programa la actualización de "Política de Devoluciones"
   para el 2026-06-01 a las 00:00
   CUANDO guarda como SCHEDULED
   ENTONCES la versión queda en estado SCHEDULED hasta la fecha configurada
   Y el 2026-06-01 a las 00:00 el Actor Tiempo la publica automáticamente

   Escenario 4: Imagen no encontrada — aviso antes de publicar (EX-02)
   DADO nuevo contenido HTML con una URL de imagen inaccesible
   CUANDO el admin intenta publicar
   ENTONCES el sistema muestra "El contenido tiene 1 imagen que no se
   puede localizar. ¿Confirmas la publicación de todas formas?"
   Y si el admin confirma: la página se publica con el aviso registrado

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms), RNF-PROC-002
  (auditoría: el historial de versiones incluye admin responsable
  y timestamp para cada versión)
- **Notas:** La numeración de versiones es global por página y es
  siempre creciente. No se reutilizan números. El sistema no permite
  editar ni eliminar versiones archivadas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG-04: Gestionar Contenido Estático
   * - **Test**
     - TST-FR-CFG-04.02 (pendiente — verificar que la reversión
       crea una nueva versión numerada en lugar de modificar la
       versión histórica; verificar que SCHEDULED no publica antes
       de la fecha configurada)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: versionado acumulativo, reversión sin
       modificar histórico, publicación programada SCHEDULED, EX-02
       de imagen no encontrada, 4 escenarios BDD

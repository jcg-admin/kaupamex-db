.. meta::
   :artefacto: FR-AUTH-02.23
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-23:

===========================================================
FR-AUTH-02.23: NFR Confiabilidad — Disponibilidad del login
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.23
   * - **Nombre**
     - Restricciones de confiabilidad del endpoint de autenticacion
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Seccion 6.3 — Requisitos No Funcionales de Confiabilidad
   * - **Modulo**
     - MOD-001 ACCOUNTS (endpoint POST /api/v1/auth/login/)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico — Confiabilidad

----

2. Especificacion
-----------------

**Declaracion:**

   El endpoint de autenticacion DEBE mantener su disponibilidad
   y comportarse de forma predecible ante fallos parciales del
   sistema CUANDO opera en condiciones degradadas.

**Descripcion:**

Requisitos de confiabilidad del login:

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Aspecto
     - Comportamiento requerido
   * - Disponibilidad del endpoint
     - Cumple el SLO de BReq-007: 99.5% mensual en horario comercial
   * - Degradacion controlada ante fallo de BD
     - EX-02 (FR-AUTH-02.17): retorna 503 sin exponer internos,
       la cuenta NO queda afectada
   * - Integridad del registro de auditoria
     - Si falla el INSERT en AccessAuditLog, el login continua.
       El fallo de auditoria NO impide el acceso legitimo.
   * - Consistencia del contador de intentos
     - El contador usa DatabaseCache con transacciones atomicas.
       Bajo carga concurrente no hay race conditions en el contador.

**Degradacion controlada:**

El endpoint de login debe funcionar incluso si subsistemas opcionales
no estan disponibles:

- Fallo en auditoria → login continua, se loguea el fallo
- Fallo en ``last_login`` update → login continua, tokens ya emitidos
- Fallo en reset del contador → login continua (conservativo)

Solo el fallo en la BD principal (busqueda de usuario, comparacion
de contraseña) impide completar el login (EX-02).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Login funciona con auditoria degradada
   DADO fallo temporal en la tabla AccessAuditLog (sin espacio en disco)
   CUANDO el usuario intenta autenticarse
   ENTONCES el login completa exitosamente
   Y los tokens son retornados al usuario
   Y el fallo de auditoria se registra en el log del servidor

   Escenario 2: Disponibilidad mensual
   DADO medicion de disponibilidad del endpoint /api/v1/auth/login/
   DURANTE 30 dias en horario comercial (8am-10pm)
   ENTONCES el uptime es >= 99.5%
   Y el downtime no planeado es <= 3.6 horas en el periodo

   Escenario 3: Consistencia bajo carga concurrente
   DADO 100 usuarios simultaneos intentando login con la misma IP
   CUANDO se ejecuta la prueba de concurrencia
   ENTONCES el contador de intentos es correcto (no hay race conditions)
   Y un mismo intento fallido no incrementa el contador mas de una vez

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-AVAIL-001 (99.5% uptime en horario comercial)
- **Notas:** El endpoint de login es el mas critico del sistema.
  Sin login, ninguna funcionalidad protegida es accesible.
  Es prioritario en el monitoreo de disponibilidad.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Seccion UC**
     - 6.3 Confiabilidad
   * - **RNF del sistema**
     - RNF-AVAIL-001
   * - **BReq**
     - BReq-007 (SLO de disponibilidad)
   * - **Test**
     - TST-FR-AUTH-02.23 (pendiente — monitoreo con UptimeRobot)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de la seccion 6.3 de UC-AUTH-02

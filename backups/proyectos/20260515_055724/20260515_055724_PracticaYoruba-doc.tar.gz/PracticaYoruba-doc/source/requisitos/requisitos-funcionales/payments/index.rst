.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — PAYMENTS
==================================

**11 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-pay-01-ext-cuotas-msi
     - 2
   * - uc-pay-01-mercadopago
     - 1
   * - uc-pay-02-paypal
     - 1
   * - uc-pay-03-webhook-mercadopago
     - 2
   * - uc-pay-04-webhook-paypal
     - 1
   * - uc-pay-05-ver-estado-pago
     - 1
   * - uc-pay-06-ver-historial-pagos
     - 1
   * - uc-pay-07-solicitar-reembolso
     - 1
   * - uc-pay-08-reintentar-pago
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-pay-01-ext-cuotas-msi/index
   uc-pay-01-mercadopago/index
   uc-pay-02-paypal/index
   uc-pay-03-webhook-mercadopago/index
   uc-pay-04-webhook-paypal/index
   uc-pay-05-ver-estado-pago/index
   uc-pay-06-ver-historial-pagos/index
   uc-pay-07-solicitar-reembolso/index
   uc-pay-08-reintentar-pago/index

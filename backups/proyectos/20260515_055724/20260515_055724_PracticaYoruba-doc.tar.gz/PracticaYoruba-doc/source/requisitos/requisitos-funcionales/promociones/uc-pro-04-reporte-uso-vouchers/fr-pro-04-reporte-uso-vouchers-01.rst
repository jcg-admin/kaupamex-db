.. meta::
   :artefacto: FR-PRO-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pro-04-01:

FR-PRO-04.01: Generar reporte de uso de vouchers
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-04.01
   * - **Nombre**
     - Generar reporte de uso de vouchers
   * - **UC Origen**
     - UC-PRO 04 REPORTE USO VOUCHERS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las metricas de uso de vouchers CUANDO el admin consulta el reporte.

**Descripcion:**

Por voucher activo en el periodo:

- ``uses_count``: veces utilizado
- ``total_discount``: suma de descuentos otorgados
- ``orders_generated``: ordenes donde se aplico
- ``avg_order_value``: valor promedio de ordenes con el voucher

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Reporte del mes
   DADO admin que consulta el reporte del mes actual
   CUANDO se genera
   ENTONCES aparecen todos los vouchers usados en el mes con sus metricas

   Escenario: Exportar a CSV
   DADO admin que exporta el reporte
   CUANDO descarga
   ENTONCES CSV con codigo, tipo, usos, descuento_total, ordenes_generadas


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El reporte consulta VoucherUsage directamente — datos frescos en cada consulta.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO 04 REPORTE USO VOUCHERS
   * - **Depende de**
     - Uso de vouchers registrado en VoucherUsage
   * - **Requerido por**
     - Ninguno — reporte de solo lectura
   * - **Test**
     - TST-FR-PRO-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PRO 04 REPORTE USO VOUCHERS

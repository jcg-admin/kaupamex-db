.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-09-crear-producto-admin
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-09-02-validar-y-crear-producto
   fr-cat-09-crear-producto-admin-01-crear-producto-con-validacion

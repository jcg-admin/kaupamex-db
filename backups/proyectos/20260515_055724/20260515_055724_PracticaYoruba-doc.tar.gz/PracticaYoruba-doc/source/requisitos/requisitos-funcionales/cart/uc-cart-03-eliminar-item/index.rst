.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-03-eliminar-item
===================================

**3 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-03-01-eliminar-item
   fr-cart-03-02-eliminar-y-recalcular
   fr-cart-03-03-presentar-carrito-actualizado

.. meta::
   :artefacto: FR-RET-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-RET-02.02: Aprobar o rechazar la solicitud de devolucion con reembolso automatico
======================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-02.02
   * - **Nombre**
     - Cambiar el estado de la solicitud y disparar el reembolso si es aprobada
   * - **UC Origen**
     - UC-RET-02: Revisar Solicitud de Devolucion (Admin)
   * - **Paso UC**
     - Pasos 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar el estado de la solicitud, notificar
   al comprador y disparar el reembolso automaticamente si la
   devolucion es aprobada CUANDO el admin toma una decision.

**Descripcion:**

En una transacción atómica: el sistema actualiza
``ReturnRequest.status`` a ``'APPROVED'`` o ``'REJECTED'`` según la
decisión, registra ``ReturnRequest.reviewed_by``,
``ReturnRequest.review_notes`` y el timestamp de revisión. Encola
la notificación al comprador de forma asíncrona. Si la decisión
es aprobación, recupera el ``Payment`` más reciente de la orden con
``status = 'APPROVED'`` y encola el reembolso asíncrono (FR-PAY-07.02)
con el importe correspondiente a los ``ReturnItem`` aprobados.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Devolucion aprobada — reembolso automatico
   DADO solicitud de devolucion en estado PENDING
   CUANDO el admin la aprueba
   ENTONCES ReturnRequest.status = APPROVED
   Y el reembolso se inicia automaticamente (FR-PAY-07.02)
   Y el comprador recibe la notificacion de aprobacion

   Escenario 2: Devolucion rechazada — motivo requerido
   DADO solicitud que el admin rechaza por "producto usado"
   CUANDO el admin guarda el rechazo
   ENTONCES ReturnRequest.status = REJECTED
   Y ReturnRequest.review_notes = "producto usado"
   Y el comprador recibe la notificacion con el motivo

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria — reviewed_by y review_notes)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET-02: Revisar Solicitud
   * - **Depende de**
     - FR-RET-01.02 (la solicitud fue creada)
   * - **Relacionado con**
     - FR-PAY-07.02 (reembolso automatico si se aprueba)
   * - **Test**
     - TST-FR-RET-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5-7 de UC-RET-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-ORD-01.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-ord-01-03:

=========================================================
FR-ORD-01.03: Decrementar stock y vaciar el carrito
=========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01.03
   * - **Nombre**
     - Decrementar stock de cada variante y vaciar el carrito post-checkout
   * - **UC Origen**
     - UC-ORD-01: Crear orden desde carrito
   * - **Paso UC**
     - Paso 7 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-009 INVENTORY + MOD-005 CART
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE decrementar el stock de cada variante y vaciar
   el carrito CUANDO la orden es creada exitosamente.

**Descripcion:**

Estas dos operaciones ocurren dentro de la misma transaccion que
crea la orden (FR-ORD-01.02):

**Decremento de stock** (delegado en MOD-INVENTORY):

- Por cada OrderItem: ``StockMovement.create(SALE, -quantity)``
- ``ProductVariant.stock -= quantity`` con ``select_for_update()``
- Si el stock cae a cero o por debajo del umbral: se encola alerta
  para UC-SYS-03

**Vaciado del carrito:**

- ``CartItem.objects.filter(cart=cart).delete()``
- El objeto ``Cart`` se conserva (no se elimina) para la proxima sesion
- El voucher del carrito se desvincula (``Cart.voucher = None``)
- El ``VoucherUsage`` se crea aqui para registrar el uso del cupon

----

3. Criterio de Aceptacion
--------------------------

::

   DADO orden creada exitosamente
   CUANDO se procesan los efectos secundarios
   ENTONCES stock y carrito quedan actualizados

   Escenario 1: Stock decrementado correctamente
   DADO OrderItem con quantity = 2 y variante con stock = 5
   CUANDO se decrementa
   ENTONCES variante.stock = 3
   Y existe un StockMovement con delta = -2 y reference_id = order_number

   Escenario 2: Carrito vaciado
   DADO carrito con 3 items antes del checkout
   CUANDO se vacia
   ENTONCES el carrito tiene 0 CartItems
   Y el proximo GET /api/v1/cart/ devuelve items: []

   Escenario 3: Registro de uso del voucher
   DADO orden con voucher aplicado
   CUANDO se crea el VoucherUsage
   ENTONCES existe VoucherUsage(voucher, user, order, discount_applied)
   Y Voucher.uses_count incrementa en 1

   Escenario 4: Fallo en decremento — rollback
   DADO error al decrementar el stock de uno de los items
   CUANDO falla la transaccion
   ENTONCES la orden NO queda creada (rollback completo)
   Y el carrito permanece intacto
   Y el stock no cambia

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (las cantidades del OrderItem son inmutables
  — el decremento se basa en OrderItem.quantity, no en el CartItem)
- **Notas:** El rollback en caso de fallo es critico para la integridad.
  Un error en el decremento de stock no puede dejar una orden "huerfana"
  sin el decremento correspondiente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01: Crear orden desde carrito
   * - **Depende de**
     - FR-ORD-01.02 (orden creada con snapshot)
   * - **Requerido por**
     - FR-NOT-01.01 (email de confirmacion de orden)
   * - **BR**
     - BR-005
   * - **RNF**
     - RNF-PROC-002 (auditoria de operaciones criticas)
   * - **Test**
     - TST-FR-ORD-01.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-01

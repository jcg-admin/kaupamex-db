.. meta::
   :artefacto: FR-AUTH-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-03-01:

================================================
FR-AUTH-03.01: Invalidar el refresh token
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.01
   * - **Nombre**
     - Agregar el refresh token a la blacklist de tokens invalidos
   * - **UC Origen**
     - UC-AUTH-03: Cerrar sesion
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Seguridad

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE insertar el refresh token en la blacklist
   CUANDO el comprador solicita cerrar sesion.

**Descripcion:**

Proceso de invalidacion:

1. Decodifica el refresh token para extraer el ``jti`` (JWT ID unico)
2. Inserta el ``jti`` en ``el repositorio de sesiones revocadas``
   de django-el Servicio de Autenticacion
3. El access token vigente expira de forma natural en 15 minutos
   — no es posible invalidarlo de forma stateless

El riesgo de los 15 minutos restantes del access token es aceptado
como trade-off del diseno JWT stateless.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado con refresh token valido
   CUANDO hace POST /api/v1/auth/logout/ con el refresh token
   ENTONCES el token queda invalido de forma inmediata

   Escenario 1: Logout exitoso
   DADO refresh token valido
   CUANDO se ejecuta el logout
   ENTONCES respuesta 200 OK
   Y el refresh token figura en la blacklist

   Escenario 2: Reuso del token invalidado
   DADO refresh token ya en blacklist
   CUANDO se intenta usar en POST /auth/refresh/
   ENTONCES se retorna 401 "Token is blacklisted"

   Escenario 3: Logout de todos los dispositivos
   DADO comprador con 3 refresh tokens activos en distintos dispositivos
   CUANDO selecciona cerrar sesion en todos
   ENTONCES los 3 refresh tokens quedan en la blacklist

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La blacklist persiste en BD. La tabla se limpia
  periodicamente por el Procesador Asincrono que elimina tokens
  ya expirados naturalmente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar sesion
   * - **Depende de**
     - FR-AUTH-02.03 (token emitido en login)
   * - **Requerido por**
     - Ninguno (fin del flujo de sesion)
   * - **RNF**
     - RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-03

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inv-02-decrementar-stock
======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inv-02-02-decrementar-y-alertar-umbral
   fr-inv-02-decrementar-stock-01

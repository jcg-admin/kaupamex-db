.. meta::
   :artefacto: FR-QST-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-qst-01-01:

FR-QST-01.01: Crear pregunta sobre el producto
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-01.01
   * - **Nombre**
     - Crear pregunta sobre el producto
   * - **UC Origen**
     - UC-QST 01 HACER PREGUNTA
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la pregunta CUANDO el visitante la envia.

**Descripcion:**

``Question.status = PENDING_MODERATION``
Campos: ``product``, ``user`` (null si anonimo), ``email`` (para notificar la respuesta), ``question_text``.
Rate limiting: max 3 preguntas por IP o email en 24 horas.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Pregunta creada exitosamente
   DADO visitante con pregunta valida sobre un producto activo
   CUANDO la envia
   ENTONCES Question.status=PENDING_MODERATION y el admin la ve en la cola

   Escenario: Rate limit alcanzado
   DADO IP con 3 preguntas en las ultimas 24 horas
   CUANDO intenta una cuarta
   ENTONCES error 429: LIMITE_PREGUNTAS_DIARIAS


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-004`
- **Notas:** El email del visitante se usa solo para notificar la respuesta — no se muestra publicamente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST 01 HACER PREGUNTA
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-QST-03.01 (admin responde)
   * - **Test**
     - TST-FR-QST-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-QST 01 HACER PREGUNTA

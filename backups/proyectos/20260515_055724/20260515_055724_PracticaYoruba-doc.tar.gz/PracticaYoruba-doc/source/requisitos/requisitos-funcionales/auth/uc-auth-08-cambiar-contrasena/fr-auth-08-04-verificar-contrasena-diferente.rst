.. meta::
   :artefacto: FR-AUTH-08.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-08-04:

==========================================================
FR-AUTH-08.04: Verificar que la nueva contraseña es diferente a la actual
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.04
   * - **Nombre**
     - Rechazar si la nueva contraseña es identica a la actual almacenada
   * - **UC Origen**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Paso UC**
     - Paso 10 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — ChangePasswordSerializer)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la nueva contraseña es diferente
   a la actualmente almacenada CUANDO la contraseña actual ya fue
   verificada como correcta.

**Descripcion:**

El sistema verifica si la nueva contraseña es idéntica a la
actualmente almacenada usando la comparación segura en tiempo
constante de Django (``User.check_password``). Si la verificación
retorna verdadero —es decir, el hash de la nueva contraseña coincide
con el almacenado— el sistema rechaza la solicitud con HTTP 400 e
indica que la nueva contraseña debe ser diferente a la actual.

Este paso ocurre en el servidor después de que la contraseña actual
fue verificada como correcta (FR-AUTH-08.01). Esto es necesario porque:

- El usuario no debería poder "cambiar" a la misma contraseña
- Evita el patrón de "rotar contraseñas" que la misma contraseña
  anterior siga siendo efectiva

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nueva contraseña identica a la actual — rechazada
   DADO usuario con contraseña "MiPass123!" que intenta cambiarla a "MiPass123!"
   CUANDO el sistema verifica en el paso 10
   ENTONCES HTTP 400 con {"detalles": {"new_password":
   ["La nueva contraseña debe ser diferente a la actual."]}}
   Y la contraseña almacenada NO cambia

   Escenario 2: Nueva contraseña diferente — procede
   DADO usuario con contraseña "MiPass123!" que intenta cambiarla a "NuevaClave456!"
   CUANDO el sistema verifica
   ENTONCES las contraseñas son diferentes
   Y el proceso continua a FR-AUTH-08.02 (almacenar y notificar)

   Escenario 3: Comparacion en tiempo constante
   DADO nueva contraseña igual a la actual y nueva contraseña diferente
   CUANDO se mide el tiempo de ambas comparaciones
   ENTONCES el tiempo es estadisticamente equivalente (hmac.compare_digest)
   Y no se puede distinguir por timing si la contraseña era igual o diferente

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (comparacion en tiempo constante
  para prevenir timing attacks incluso en esta verificacion)
- **Notas:** La comparacion usa ``check_password`` que internamente
  usa ``constant_time_compare`` de Django. Nunca se comparan los
  hashes directamente — se usa la API de Django.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar Contraseña
   * - **Depende de**
     - FR-AUTH-08.03 (nueva contraseña valida en fortaleza y confirmacion)
   * - **Requerido por**
     - FR-AUTH-08.02 (almacenar nueva contraseña e invalidar sesiones)
   * - **Test**
     - TST-FR-AUTH-08.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 10 de UC-AUTH-08
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Logica de User.check_password y rechazo HTTP 400 preservada.

.. meta::
   :artefacto: FR-NOT-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-03-02:

================================================================================
FR-NOT-03.02: Notificar al comprador las actualizaciones del estado de su envío
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-03.02
   * - **Nombre**
     - Recuperar los datos del envío, seleccionar la plantilla según
       el evento, incluir el número de rastreo y la URL de seguimiento,
       y encolar el email de forma asíncrona al comprador
   * - **UC Origen**
     - UC-NOT-03: Email de Actualización de Envío
   * - **Paso UC**
     - Pasos 2 al 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El Sistema de Notificaciones DEBE recuperar los datos completos
   del envío, verificar el email y las preferencias del comprador,
   seleccionar la plantilla según el evento recibido y encolar el
   email de actualización de forma asíncrona CUANDO se produce un
   cambio en el estado de la guía de envío o se registra un número
   de rastreo por primera vez.

**Descripcion:**

Este FR cubre tres tipos de eventos relacionados con el envío que
generan notificaciones al comprador:

**Primer registro del número de rastreo (FR-LOG-02.02).**
Cuando el admin registra el número de rastreo en la guía de envío,
el comprador recibe el aviso más esperado de todo el proceso: su
pedido ya tiene número de seguimiento. El email incluye el número
de rastreo de forma prominente y el enlace completo de seguimiento
del courier construido a partir de la plantilla de URL configurada
para ese courier (FR-LOG-06.02).

**Actualización de estado via webhook del courier (FR-LOG-04.02).**
Cuando el courier notifica un cambio de estado —en tránsito, en
reparto, entregado— el Sistema de Notificaciones selecciona la
plantilla correspondiente y envía el aviso. El email refleja el
nuevo estado en lenguaje orientado al comprador, no en los
códigos internos del courier. Por ejemplo, el estado ``OUT_FOR_DELIVERY``
del courier se traduce como "Tu pedido está en camino y llegará hoy".

**Problema de envío reportado (Alt. C — FR-LOG-07.02).**
Cuando el comprador reporta un problema con su envío, el sistema
le envía una confirmación de que el reporte fue recibido e indica
el tiempo de respuesta estimado del equipo. Esto evita que el
comprador reenvíe el reporte repetidamente por no tener confirmación.

En los tres casos, antes de encolar el email el sistema verifica
que el comprador tiene email válido y que no desactivó las
notificaciones de envío en sus preferencias. Si alguna verificación
falla, el proceso termina sin acción y registra el motivo.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Número de rastreo registrado — comprador notificado con enlace
   DADO guía de DHL a la que el admin acaba de agregar el número 1234567890
   CUANDO el evento llega al Sistema de Notificaciones
   ENTONCES el email muestra "Tu número de rastreo: 1234567890"
   Y contiene el enlace completo de seguimiento de DHL con el
   número incrustado (p. ej. https://dhl.com/?tracking=1234567890)
   Y el comprador puede hacer clic y ver el estado en el sitio de DHL

   Escenario 2: Courier notifica "en reparto hoy" — mensaje en lenguaje claro
   DADO webhook del courier con estado OUT_FOR_DELIVERY
   CUANDO el Sistema de Notificaciones procesa el evento
   ENTONCES el email dice "Tu pedido está en camino y llegará hoy"
   Y no muestra el código interno OUT_FOR_DELIVERY al comprador

   Escenario 3: Problema de envío reportado — confirmación inmediata
   DADO comprador que reportó su paquete como demorado en FR-LOG-07.02
   CUANDO el Sistema de Notificaciones recibe el evento (Alt. C)
   ENTONCES el email confirma "Recibimos tu reporte sobre el envío"
   Y indica "Te responderemos en menos de 24 horas hábiles"
   Y el comprador sabe que no necesita volver a contactar

   Escenario 4: Comprador con notificaciones de envío desactivadas
   DADO comprador que desactivó los avisos de envío en FR-NOT-06.02
   CUANDO el Sistema de Notificaciones verifica sus preferencias
   ENTONCES no se encola ningún email
   Y el sistema registra "omitida por preferencia" en auditoría

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-002 (P95 <= 60 segundos desde el
  evento de envío hasta el encole del email — este tiempo es mayor
  que el de la confirmación de orden porque la urgencia es menor),
  RNF-AVAIL-003 (reintentos con espera progresiva via FR-SYS-04.02)
- **Notas:** La URL de seguimiento se construye usando la plantilla
  del courier (FR-LOG-06.02). Si el courier no tiene plantilla
  configurada, el email omite el enlace de seguimiento e indica
  al comprador que contacte al equipo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-03: Email de Actualización de Envío
   * - **Disparado por**
     - FR-LOG-02.02 (registro del número de rastreo),
       FR-LOG-04.02 (webhook del courier),
       FR-LOG-07.02 (problema de envío reportado)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla)
   * - **Relacionado con**
     - FR-NOT-06.02 (preferencias del comprador),
       FR-LOG-06.02 (plantilla de URL del courier)
   * - **Test**
     - TST-FR-NOT-03.02 (pendiente — verificar que el código
       OUT_FOR_DELIVERY no aparece en el email; verificar que
       la URL de seguimiento usa la plantilla del courier)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: tres tipos de eventos, traducción de
       códigos del courier, Alt. C de problema reportado, URL de
       seguimiento con plantilla del courier, 4 escenarios BDD

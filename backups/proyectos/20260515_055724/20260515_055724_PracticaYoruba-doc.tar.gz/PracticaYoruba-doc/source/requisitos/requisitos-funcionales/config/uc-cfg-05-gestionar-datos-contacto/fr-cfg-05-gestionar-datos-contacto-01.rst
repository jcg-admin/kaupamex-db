.. meta::
   :artefacto: FR-CFG-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cfg-05-01:

FR-CFG-05.01: Actualizar datos de contacto del negocio
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-05.01
   * - **Nombre**
     - Actualizar datos de contacto del negocio
   * - **UC Origen**
     - UC-CFG 05 GESTIONAR DATOS CONTACTO
   * - **Paso UC**
     - Paso 3
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar los datos de contacto en SiteSettings CUANDO el admin los modifica.

**Descripcion:**

Campos: ``contact_email``, ``contact_phone``, ``contact_address``.
Redes sociales: ``social_instagram``, ``social_facebook``, etc.

Los datos actualizados aparecen de inmediato en el footer y la pagina de contacto.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Actualizacion exitosa
   DADO admin que cambia el email de contacto
   CUANDO guarda
   ENTONCES el nuevo email aparece en el footer y la pagina /contacto/

   Escenario: URL de red social invalida
   DADO URL que no es una URL valida
   CUANDO se intenta guardar
   ENTONCES error 422: URL_INVALIDA


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** Los datos de contacto son criticos para la confianza del comprador — cualquier cambio queda auditado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG 05 GESTIONAR DATOS CONTACTO
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-CFG-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CFG 05 GESTIONAR DATOS CONTACTO

.. meta::
   :artefacto: FR-PAY-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-01-01:

FR-PAY-01.01: Crear preferencia de pago en Mercado Pago
=======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-01.01
   * - **Nombre**
     - Crear preferencia de pago en Mercado Pago
   * - **UC Origen**
     - UC-PAY-01: Pago con Mercado Pago
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-007 PAYMENT + Gateway Mercado Pago
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Integracion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear una preferencia de pago en la API de Mercado Pago CUANDO el comprador selecciona MP como metodo de pago.

**Descripcion:**

Proceso (BR-009 — el backend crea la preferencia, nunca el cliente):

1. Lee las credenciales de MP desde ``PaymentMethodConfig`` (descifradas de BD)
2. Construye el payload de la preferencia:

   - ``items``: lista de OrderItems con nombre, cantidad y precio unitario
   - ``payer``: email del comprador o guest_email
   - ``back_urls``: URLs de retorno para exito, fallo y pendiente
   - ``auto_return``: "approved"
   - ``external_reference``: ``order_number`` para correlacionar el webhook

3. ``POST https://api.mercadopago.com/checkout/preferences`` con el access_token
4. MP retorna ``preference_id`` y ``init_point`` (URL de pago)
5. Se crea el registro ``Payment(order, gateway=MERCADOPAGO, preference_id, status=PENDING)``
6. Se retorna el ``init_point`` al frontend para redirigir al comprador

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Preferencia creada exitosamente
   DADO orden en PENDING_PAYMENT
   CUANDO se crea la preferencia en MP
   ENTONCES MP retorna preference_id e init_point
   Y Payment queda en BD con status=PENDING
   Y el comprador es redirigido a init_point

   Escenario: Credenciales MP invalidas
   DADO credenciales de MP incorrectas o vencidas
   CUANDO se intenta crear la preferencia
   ENTONCES MP retorna 401
   Y el sistema retorna error 503: GATEWAY_NO_DISPONIBLE
   Y se registra el fallo para auditoria

   Escenario: Orden ya tiene preferencia activa
   DADO orden con preference_id existente y aun vigente
   CUANDO el comprador intenta pagar de nuevo
   ENTONCES se reutiliza el preference_id existente
   Y no se crea una preferencia duplicada en MP


----

4. Reglas y Restricciones
--------------------------

- **BR-009 (el backend crea la preferencia — las credenciales NUNCA van al cliente)**

- :ref:`RNF-SEC-002 (cifrado de credenciales)`
- :ref:`RNF-SEC-006 (HTTPS obligatorio)`
- **Notas:** El access_token de MP se descifra en memoria durante el request y no se loguea.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-01: Pago con Mercado Pago
   * - **Depende de**
     - FR-ORD-01.02 (orden creada en PENDING_PAYMENT)
   * - **Requerido por**
     - FR-PAY-03.01 (webhook de MP confirma el pago)
   * - **BR**
     - BR-009
   * - **Test**
     - TST-FR-PAY-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-01

.. meta::
   :artefacto: FR-QST-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-qst-03-02:

==================================================================================
FR-QST-03.02: Persistir la respuesta, publicar la pregunta y notificar al autor
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-QST-03.02
   * - **Nombre**
     - Validar la respuesta del admin, cambiar el estado de la pregunta
       a ``ANSWERED``, publicarla en la ficha del producto y notificar
       al autor si proporcionó email
   * - **UC Origen**
     - UC-QST-03: Responder Pregunta (Admin)
   * - **Paso UC**
     - Pasos 7, 8 y 9 del flujo principal
   * - **Modulo**
     - MOD-015 QUESTION
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos + Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el texto de la respuesta, persistir la
   respuesta junto con el admin que la redactó y el momento de
   publicación, cambiar el estado de la pregunta a ``ANSWERED`` y
   encolar la notificación al autor de la pregunta si dejó su email
   CUANDO el admin confirma la publicación.

**Descripcion:**

El texto de la respuesta requiere una longitud mínima de 10
caracteres. Una respuesta demasiado corta no aporta valor informativo
y puede indicar un guardado accidental.

Al publicar, el sistema registra junto a la respuesta el admin que la
redactó y el momento exacto de publicación. Este registro sirve como
auditoría de contenido y como referencia para el admin que quiera
corregirla después.

Una vez publicada, la pregunta pasa a estado ``ANSWERED`` y queda
disponible de inmediato en FR-QST-02.02 para cualquier visitante de
la ficha del producto. No hay un paso adicional de aprobación: el acto
de responder implica la publicación.

Si el autor de la pregunta proporcionó su email al enviarla, el
sistema encola un aviso via UC-INC-03 informándole que su pregunta
tiene respuesta. El encolo es asíncrono y no retrasa la respuesta
HTTP al admin.

**Alt. A — Edición del texto de la pregunta antes de responder:**

Si el texto original de la pregunta tiene redacción confusa o
contiene datos personales que conviene eliminar antes de publicarla
públicamente, el admin puede editar el texto de la pregunta en el
mismo flujo. La edición queda registrada en auditoría con la versión
original y la versión publicada.

**Alt. B — Pregunta ya respondida por otro admin:**

Si entre que el admin seleccionó la pregunta y confirmó su respuesta
otro miembro del equipo la respondió, el sistema detecta el conflicto
al intentar guardar y lo informa con un mensaje claro. El admin puede
ver la respuesta ya existente y decidir si la edita o la deja como está.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Respuesta publicada y visitante notificado
   DADO pregunta en estado PENDING_ANSWER con email del autor registrado
   CUANDO el admin escribe "Esta sopera es apta para ceremonias de Yemoja.
   Viene consagrada de origen." y confirma
   ENTONCES QuestionAnswer.status = ANSWERED
   Y la respuesta es visible en FR-QST-02.02 para cualquier visitante
   Y se encola el aviso al email del autor de la pregunta

   Escenario 2: Respuesta demasiado corta — rechazada antes de guardar
   DADO admin que escribe "Sí." (3 caracteres) como respuesta
   CUANDO intenta publicar
   ENTONCES HTTP 400 con {"errors": {"answer_body":
   "La respuesta debe tener al menos 10 caracteres."}}
   Y el estado de la pregunta no cambia

   Escenario 3: Admin edita el texto de la pregunta antes de responder
   DADO pregunta con datos personales en el texto original
   CUANDO el admin edita el texto antes de publicar
   ENTONCES la versión publicada muestra el texto editado
   Y la auditoría conserva el texto original y el editado con el admin responsable

   Escenario 4: Conflicto de respuesta concurrente
   DADO dos admins que seleccionan la misma pregunta al mismo tiempo
   CUANDO el segundo intenta guardar su respuesta después de que el primero ya guardó
   ENTONCES HTTP 409 con {"codigo_error": "PREGUNTA_YA_RESPONDIDA",
   "mensaje": "Otro miembro del equipo respondió esta pregunta.
   Puedes ver su respuesta y editarla si lo necesitas."}

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms), RNF-PROC-002
  (auditoría obligatoria: admin responsable, timestamp de publicación
  y versiones del texto si fue editado)
- **Notas:** La notificación al autor es opcional por diseño: si el
  autor no proporcionó email al enviar la pregunta, el sistema no
  intenta contactarle. No se exige email para preguntar (BR-010).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-QST-03: Responder Pregunta (Admin)
   * - **Depende de**
     - FR-QST-04.02 (la pregunta debe estar en PENDING_ANSWER
       para poder ser respondida)
   * - **Requerido por**
     - FR-QST-02.02 (la respuesta publicada aparece en la ficha
       del producto)
   * - **Incluye**
     - UC-INC-03 (notificación al autor si dejó email)
   * - **Test**
     - TST-FR-QST-03.02 (pendiente — verificar el conflicto
       concurrente usando select_for_update en el test; verificar
       que la notificación no se encola si el autor no dejó email)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: longitud mínima de respuesta, edición
       de pregunta con auditoría, conflicto concurrente, notificación
       condicional, 4 escenarios BDD

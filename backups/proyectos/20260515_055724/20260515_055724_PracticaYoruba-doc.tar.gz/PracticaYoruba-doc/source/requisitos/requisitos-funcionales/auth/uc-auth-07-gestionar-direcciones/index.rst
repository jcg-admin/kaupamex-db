.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-07-gestionar-direcciones
===========================================

**5 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-07-01-listar-direcciones
   fr-auth-07-02-crear-editar-direccion
   fr-auth-07-03-validar-campos-y-zona-de-envio
   fr-auth-07-04-almacenar-y-gestionar-predeterminada
   fr-auth-07-05-exc-y-nfr-direcciones

.. meta::
   :artefacto: FR-CART-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-03-02:

=====================================================
FR-CART-03.02: Eliminar el CartItem y recalcular el subtotal
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-03.02
   * - **Nombre**
     - Eliminar el item especificado de la sesion y recalcular totales
   * - **UC Origen**
     - UC-CART-03: Eliminar Item del Carrito
   * - **Paso UC**
     - Pasos 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart — session cart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE eliminar el CartItem especificado de la sesion
   del visitante y recalcular el subtotal del carrito CUANDO el
   visitante solicita eliminar un item.

**Descripcion:**

El carrito vive en la sesión Django (BR-003). La eliminación opera
directamente sobre el diccionario de sesión. Si la clave
``cart_item_key`` no existe en el carrito, la operación es
idempotente y no produce ningún cambio (EX-02).

Si el item existe, el sistema lo elimina del diccionario de sesión.
Si tras la eliminación el carrito queda vacío y existe un voucher
aplicado en ``session['cart_voucher']``, el voucher se elimina
automáticamente porque ya no hay items a los que aplicar el descuento.
A continuación el sistema recalcula el subtotal sumando
``item.price × item.quantity`` para todos los items restantes y
persiste el diccionario actualizado en sesión.

El ``cart_item_key`` identifica de forma unica el item en el carrito.
Para productos sin variante: ``f"product_{product_id}"``.
Para productos con variante: ``f"product_{product_id}_variant_{variant_id}"``.

Si el carrito queda vacio tras la eliminacion (Alt. C): el voucher
aplicado se elimina automaticamente porque ya no hay items a los que aplicar.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Item eliminado y subtotal recalculado
   DADO carrito con 3 items (A: 100, B: 50, C: 200) — subtotal 350
   CUANDO el visitante elimina el item B
   ENTONCES el item B ya no esta en la sesion
   Y el nuevo subtotal es 300 (A + C)
   Y la respuesta incluye el carrito actualizado con 2 items

   Escenario 2: Ultimo item eliminado — carrito vacio con voucher
   DADO carrito con solo 1 item y voucher aplicado de 10%
   CUANDO el visitante elimina el unico item
   ENTONCES el carrito queda vacio
   Y el voucher tambien es eliminado de la sesion (ya no aplica)
   Y la respuesta incluye el estado de carrito vacio

   Escenario 3: Item ya no existe — idempotente (EX-02)
   DADO carrito sin el item especificado (eliminado en otra pestana)
   CUANDO se solicita eliminar ese item
   ENTONCES el sistema retorna 200 con el estado actual del carrito
   Y no genera error 404 (idempotencia — el resultado es el mismo)

   Escenario 4: request.session.modified = True obligatorio
   DADO modificacion del diccionario de sesion
   CUANDO se guarda el carrito actualizado
   ENTONCES request.session.modified = True fue establecido
   Y Django garantiza que la sesion se persiste en la BD de sesiones

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion Django), BR-004 (sin
  login requerido — el carrito de sesion es de cualquier visitante)
- **RNF aplicables:** RNF-SEC-003 (aislamiento — solo se eliminan
  items del carrito de la sesion actual, nunca de otra sesion)
- **Notas:** La sesion de Django usa la BD por defecto
  (``django.contrib.sessions.backends.db``). El ``session_key``
  en la cookie identifica de forma unica la sesion del visitante.
  No se puede eliminar un item de la sesion de otro visitante.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-03: Eliminar Item del Carrito
   * - **Depende de**
     - FR-CART-02.01 (el carrito existe y el item fue listado)
   * - **Requerido por**
     - FR-CART-03.03 (presentar el carrito actualizado o el estado vacio)
   * - **BR**
     - BR-003, BR-004
   * - **Test**
     - TST-FR-CART-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3 y 4 de UC-CART-03

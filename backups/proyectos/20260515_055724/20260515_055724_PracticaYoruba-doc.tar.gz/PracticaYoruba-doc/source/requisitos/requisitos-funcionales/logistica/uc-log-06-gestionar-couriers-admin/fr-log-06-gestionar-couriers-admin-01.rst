.. meta::
   :artefacto: FR-LOG-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-log-06-01:

FR-LOG-06.01: Crear y gestionar couriers del sistema
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-06.01
   * - **Nombre**
     - Crear y gestionar couriers del sistema
   * - **UC Origen**
     - UC-LOG 06 GESTIONAR COURIERS ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear o actualizar el courier y sus credenciales CUANDO el admin lo configura.

**Descripcion:**

Campos del courier:

- ``name``, ``slug`` (generado), ``is_active``
- ``api_url``: URL base de la API del courier (si tiene integracion)
- ``api_key_encrypted``: credencial cifrada con Fernet
- ``tracking_url_template``: template con placeholder ``{tracking}``

Al desactivar un courier con guias activas: el sistema rechaza con error.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Crear courier con API
   DADO admin que configura DHL con api_url y api_key
   CUANDO crea el courier
   ENTONCES el courier aparece disponible en UC-LOG-01
   Y la api_key queda cifrada en BD

   Escenario: Desactivar courier con envios activos
   DADO courier con 5 guias en IN_TRANSIT
   CUANDO el admin intenta desactivarlo
   ENTONCES error 422: COURIER_CON_ENVIOS_ACTIVOS


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-002`
- **Notas:** Las credenciales del courier se cifran igual que las de los gateways de pago.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG 06 GESTIONAR COURIERS ADMIN
   * - **Depende de**
     - Ninguno — accion directa del admin
   * - **Requerido por**
     - FR-LOG-01.01 (el courier disponible para crear guias)
   * - **Test**
     - TST-FR-LOG-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-LOG 06 GESTIONAR COURIERS ADMIN

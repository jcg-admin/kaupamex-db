.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ret-03-registrar-recepcion-devolucion
===================================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ret-03-02-registrar-recepcion-fisica
   fr-ret-03-registrar-recepcion-devolucion-01

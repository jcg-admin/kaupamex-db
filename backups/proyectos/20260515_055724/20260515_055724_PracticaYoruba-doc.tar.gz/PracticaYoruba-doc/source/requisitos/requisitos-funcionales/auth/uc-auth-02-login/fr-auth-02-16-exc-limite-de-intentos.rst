.. meta::
   :artefacto: FR-AUTH-02.16
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-16:

==========================================================
FR-AUTH-02.16: EX-01 — Manejar limite de intentos fallidos
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.16
   * - **Nombre**
     - EX-01: Bloquear temporalmente la IP al superar el limite de intentos
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - EX-01 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — rate limiter)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Seguridad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE bloquear temporalmente la IP de origen y retornar
   429 con el tiempo de espera CUANDO se supera el limite configurado
   de intentos fallidos en la ventana de tiempo.

**Descripcion:**

Esta excepcion es detectada en FR-AUTH-02.01 (primer paso del servidor)
y aplica a cualquier intento de login, independientemente de si el
identificador es valido o no.

Parametros de bloqueo (configurables en ``SiteSettings``):

- **Maximo de intentos:** 5 por ventana (``rate_limit_max_attempts``)
- **Ventana de tiempo:** 15 minutos (``rate_limit_window_seconds = 900``)
- **Duracion del bloqueo:** misma ventana — el bloqueo expira cuando
  expira la key del cache (Django DatabaseCache con TTL)

Respuesta al detectar la excepcion:

.. code-block:: http

   HTTP/1.1 429 Too Many Requests
   Retry-After: 743
   Content-Type: application/json

   {
     "codigo_error": "LIMITE_INTENTOS_EXCEDIDO",
     "mensaje": "Demasiados intentos. Intenta de nuevo en 13 minutos.",
     "retry_after_seconds": 743
   }

El valor ``Retry-After`` se calcula como el TTL restante de la key
en el cache. El mensaje humano aproxima a minutos para mejor UX.

Al recibir este error, el sistema:

1. NO verifica el identificador ni la contraseña
2. NO incrementa el contador (ya esta bloqueado)
3. Registra el intento bloqueado en auditoria con tipo ``ACCESO_BLOQUEADO``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Sexto intento — bloqueo activo
   DADO IP con exactamente 5 intentos fallidos en los ultimos 15 minutos
   CUANDO hace el sexto intento (con cualquier credencial)
   ENTONCES respuesta HTTP 429
   Y header Retry-After con los segundos restantes del bloqueo
   Y el body incluye "codigo_error": "LIMITE_INTENTOS_EXCEDIDO"
   Y el identificador y la contraseña NO son procesados

   Escenario 2: Bloqueo expira naturalmente
   DADO IP bloqueada cuya ventana de 15 minutos vencio
   CUANDO realiza un nuevo intento
   ENTONCES el sistema lo procesa como si fuera el primero
   Y el contador reinicia desde 0 (la key del cache ya expiro)
   Y no requiere ninguna accion manual del admin para desbloquear

   Escenario 3: Registro de auditoria del bloqueo
   DADO IP bloqueada que intenta de nuevo
   CUANDO se detecta el bloqueo en FR-AUTH-02.01
   ENTONCES el intento queda en AccessAuditLog con event_type=ACCESO_BLOQUEADO
   Y la IP de origen queda registrada para analisis de seguridad

   Escenario 4: Retry-After con precision de segundos
   DADO bloqueo que inicio hace 3 minutos (quedan 12 minutos = 720s)
   CUANDO se retorna el 429
   ENTONCES Retry-After: 720 (segundos exactos del TTL del cache)
   Y el mensaje dice "en 12 minutos" (redondeado para el usuario)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — define la politica de
  limite de intentos como regla de negocio)
- **RNF aplicables:** RNF-SEC-004 (rate limiting en endpoints criticos)
- **Notas:** El bloqueo es por IP, no por cuenta de usuario.
  En redes con NAT (empresas, universidades) esto puede afectar a
  multiples usuarios. Esta limitacion es una decision de diseno
  aceptada — el rate limiting por cuenta requeriria revelar si
  la cuenta existe (riesgo de enumeracion).

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Detectado en**
     - FR-AUTH-02.01 (verificar bloqueo — primer paso del servidor)
   * - **Depende de**
     - FR-AUTH-02.08 (cada intento fallido que incrementa el contador)
   * - **Relacionado con**
     - FR-AUTH-02.14 (reset del contador tras login exitoso)
   * - **BR**
     - BR-015
   * - **RNF**
     - RNF-SEC-004
   * - **Test**
     - TST-FR-AUTH-02.16 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-01 de UC-AUTH-02

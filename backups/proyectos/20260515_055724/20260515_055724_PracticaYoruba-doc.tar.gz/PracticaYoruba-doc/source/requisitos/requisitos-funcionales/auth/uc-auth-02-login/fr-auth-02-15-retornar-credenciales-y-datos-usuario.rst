.. meta::
   :artefacto: FR-AUTH-02.15
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-15:

========================================================
FR-AUTH-02.15: Retornar credenciales y datos del usuario
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.15
   * - **Nombre**
     - Construir y retornar la respuesta final del login con tokens y perfil
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Paso 20 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE construir la respuesta con los tokens y los datos
   basicos del usuario y retornarla al cliente CUANDO todos los pasos
   previos del login han sido completados exitosamente.

**Descripcion:**

Respuesta HTTP 200 con el siguiente body:

.. code-block:: json

   {
     "access": "eyJhbGciOiJIUzI1NiIsInR...",
     "refresh": "eyJhbGciOiJIUzI1NiIsInR...",
     "user": {
       "id": 42,
       "username": "juanito123",
       "email": "juan@ejemplo.com",
       "first_name": "Juan",
       "last_name": "Perez",
       "is_staff": false,
       "avatar_url": "https://cdn.ojayoruba.com/avatars/42.jpg",
       "last_login": "2026-05-03T15:30:00Z"
     }
   }

**Campos que NO se retornan:**

- ``password`` (ni el hash)
- ``is_superuser``
- Campos internos del modelo (``date_joined`` excepto si el
  frontend lo necesita explicitamente)

El campo ``is_staff`` se incluye para que el frontend sepa si debe
mostrar el acceso al panel de administracion.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Respuesta completa y correcta
   DADO login exitoso de usuario "juan@ejemplo.com"
   CUANDO se retorna la respuesta
   ENTONCES HTTP 200 con body que incluye access, refresh y user
   Y user.email = "juan@ejemplo.com"
   Y user.password = ausente
   Y access es un JWT valido con exp en 15 minutos

   Escenario 2: Token de staff muestra is_staff=true
   DADO usuario administrador que hace login
   CUANDO se retorna la respuesta
   ENTONCES user.is_staff = true
   Y el frontend puede mostrar el link al panel de admin

   Escenario 3: Avatar URL es absoluta y accesible
   DADO usuario con avatar subido
   CUANDO se retorna la respuesta
   ENTONCES avatar_url es una URL absoluta HTTPS
   Y la URL es accesible publicamente (no requiere autenticacion)

   Escenario 4: Usuario sin avatar
   DADO usuario sin foto de perfil
   CUANDO se retorna la respuesta
   ENTONCES avatar_url = null
   Y el frontend muestra el avatar placeholder por defecto

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **RNF aplicables:** RNF-SEC-006 (la respuesta viaja por HTTPS),
  RNF-PERF-002 (el login completo < 500ms P95)
- **Notas:** Los tokens en la respuesta son los mismos generados en
  FR-AUTH-02.03 y FR-AUTH-02.11. Este paso solo los empaqueta en
  la respuesta final junto con los datos del usuario.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Depende de**
     - FR-AUTH-02.14 (contador de intentos reseteado)
   * - **Requerido por**
     - Ninguno — es el ultimo paso del flujo principal de UC-AUTH-02
   * - **Habilita (postcondicion)**
     - El usuario puede llamar a cualquier endpoint protegido usando
       el access token retornado
   * - **RNF**
     - RNF-PERF-002, RNF-SEC-006
   * - **Test**
     - TST-FR-AUTH-02.15 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 20 de UC-AUTH-02

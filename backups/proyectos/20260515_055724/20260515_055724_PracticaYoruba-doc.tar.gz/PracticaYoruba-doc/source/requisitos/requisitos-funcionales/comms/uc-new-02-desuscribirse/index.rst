.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-new-02-desuscribirse
==================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-new-02-02-desuscribir-por-token
   fr-new-02-desuscribirse-01

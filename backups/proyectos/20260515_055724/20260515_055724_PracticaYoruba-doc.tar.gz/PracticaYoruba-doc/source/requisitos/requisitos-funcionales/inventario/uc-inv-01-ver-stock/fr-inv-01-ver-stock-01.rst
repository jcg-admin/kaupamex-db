.. meta::
   :artefacto: FR-INV-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inv-01-01:

FR-INV-01.01: Listar inventario con alertas de stock
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-01.01
   * - **Nombre**
     - Listar inventario con alertas de stock
   * - **UC Origen**
     - UC-INV 01 VER STOCK
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el inventario con el estado de cada variante CUANDO el admin lo consulta.

**Descripcion:**

Cada item del inventario muestra:

- ``product_name``, ``sku``, ``variant_label``
- ``stock``: cantidad actual
- ``threshold``: umbral de alerta
- ``status``: NORMAL (stock > threshold), BAJO (0 < stock <= threshold), AGOTADO (stock = 0)

Filtros: ``?status=BAJO``, ``?category=slug``.
Ordenamiento: agotados primero, luego bajos, luego normales.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Vista con productos en diferentes estados
   DADO inventario con productos NORMAL, BAJO y AGOTADO
   CUANDO el admin consulta
   ENTONCES los AGOTADOS aparecen primero
   Y los BAJOS en segundo lugar con indicador de alerta

   Escenario: Exportar inventario a CSV
   DADO admin que exporta
   CUANDO solicita la exportacion
   ENTONCES descarga CSV con sku, nombre, variante, stock, umbral, estado


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** El stock mostrado es el de BD — no hay cache. La lectura directa garantiza datos frescos.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV 01 VER STOCK
   * - **Depende de**
     - Ninguno — consulta de solo lectura
   * - **Requerido por**
     - FR-INV-04.01 (ajustar stock desde la vista)
   * - **Test**
     - TST-FR-INV-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INV 01 VER STOCK

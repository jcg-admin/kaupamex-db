.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-04-renovar-sesion
====================================

**9 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-04-01-rotar-tokens
   fr-auth-04-02-verificar-token-no-revocado
   fr-auth-04-03-verificar-token-no-expirado
   fr-auth-04-04-verificar-cuenta-sigue-activa
   fr-auth-04-05-emitir-nuevo-access-token
   fr-auth-04-06-registrar-auditoria-renovacion
   fr-auth-04-07-exc-repositorio-y-emision
   fr-auth-04-08-exc-rotacion-de-claves
   fr-auth-04-09-nfr-renovacion

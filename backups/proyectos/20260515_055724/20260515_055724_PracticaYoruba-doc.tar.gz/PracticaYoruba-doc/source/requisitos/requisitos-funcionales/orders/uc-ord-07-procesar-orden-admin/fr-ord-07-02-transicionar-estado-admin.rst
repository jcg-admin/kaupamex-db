.. meta::
   :artefacto: FR-ORD-07.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-07.02: Transicionar el estado de la orden con validacion de maquina de estados
======================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-07.02
   * - **Nombre**
     - Validar que la transicion de estado es valida y ejecutarla con notificacion
   * - **UC Origen**
     - UC-ORD-07: Procesar Orden (Admin)
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que la transicion de estado solicitada es
   permitida por la maquina de estados y ejecutarla notificando al
   usuario CUANDO el admin actualiza el estado de una orden.

**Descripcion:**

Máquina de estados de las órdenes — transiciones permitidas:

- ``PENDING_PAYMENT`` → ``PAYMENT_CONFIRMED``, ``CANCELLED``
- ``PAYMENT_CONFIRMED`` → ``IN_PREPARATION``, ``CANCELLED``
- ``IN_PREPARATION`` → ``SHIPPED``
- ``SHIPPED`` → ``DELIVERED``
- ``DELIVERED``, ``CANCELLED``, ``CANCELLED_TIMEOUT`` → estados terminales sin transición posible

El sistema verifica que ``new_status`` esté en la lista de
transiciones permitidas para el ``Order.status`` actual. Si no →
error de transición no permitida. Si sí, actualiza ``Order.status``,
encola la notificación al usuario de forma asíncrona (UC-NOT-02)
y crea un registro ``OrderStatusLog`` con el estado anterior, el
nuevo estado y la referencia al administrador que realizó el cambio.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Transicion valida — PAYMENT_CONFIRMED -> IN_PREPARATION
   DADO orden en PAYMENT_CONFIRMED
   CUANDO el admin la marca como EN_PREPARACION
   ENTONCES order.status = IN_PREPARATION
   Y se crea OrderStatusLog con el admin que hizo el cambio
   Y se encola notificacion al usuario

   Escenario 2: Transicion invalida — SHIPPED -> PAYMENT_CONFIRMED
   DADO orden en estado SHIPPED
   CUANDO el admin intenta revertirla a PAYMENT_CONFIRMED
   ENTONCES HTTP 400 con {"codigo_error": "TRANSICION_NO_PERMITIDA",
   "mensaje": "No se puede revertir una orden ya enviada."}

   Escenario 3: Historial de estados trazable
   DADO orden que paso por 4 estados
   CUANDO el admin revisa el historial
   ENTONCES OrderStatusLog tiene un registro por cada transicion
   Y cada registro tiene el admin responsable y el timestamp

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria de cambios de estado)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-07: Procesar Orden Admin
   * - **Relacionado con**
     - UC-NOT-02 (email de estado de orden al usuario)
   * - **Test**
     - TST-FR-ORD-07.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-ORD-07

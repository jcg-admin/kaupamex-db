.. meta::
   :artefacto: FR-AUTH-03.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-03.05: EX-01 — Error al revocar credenciales
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.05
   * - **Nombre**
     - EX-01: Limpiar estado del cliente aunque falle la revocacion en servidor
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - EX-01 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS (manejo de fallo en blacklist)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Confiabilidad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE limpiar el estado del cliente y confirmar el logout
   aunque el repositorio de sesiones no responda CUANDO falla la
   revocacion del token en el servidor.

**Descripcion:**

Si la insercion en la blacklist falla (ej: error de BD):

1. El servidor retorna 200 OK con un indicador de advertencia
2. El cliente limpia sus tokens de todas formas
3. El token tecnicamente puede seguir siendo valido hasta su expiracion
4. El evento se registra como ``CIERRE_SESION_PARCIAL`` en el log
5. Tras la recuperacion de la BD, el administrador puede invalidar
   manualmente los tokens pendientes si el riesgo lo justifica

Respuesta en caso de EX-01:

.. code-block:: json

   HTTP 200 OK
   {
     "mensaje": "Sesion cerrada. Algunos datos de sesion podrian
                 expirar en los proximos minutos.",
     "redirect": "/catalogo/",
     "warning": "partial_revocation"
   }

El usuario ve el logout como exitoso — la comunicacion tecnica
del problema parcial se hace via el campo ``warning``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: BD de blacklist no disponible
   DADO fallo de conexion al intentar insertar en token_blacklist
   CUANDO el sistema intenta revocar el token
   ENTONCES retorna 200 con el campo "warning": "partial_revocation"
   Y el cliente limpia sus tokens de todas formas
   Y el evento se registra como CIERRE_SESION_PARCIAL en el log

   Escenario 2: El token expira naturalmente como fallback
   DADO token que no pudo ser invalidado por fallo de BD
   CUANDO pasan 7 dias (su tiempo de vida)
   ENTONCES el token expira automaticamente por su campo exp
   Y sin importar el fallo de revocacion, el riesgo cesa

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-001 (el logout debe funcionar
  incluso en condiciones degradadas)
- **Notas:** Esta es la diferencia entre tokens stateless (JWT) y
  stateful (sesiones de Django). Con sesiones, invalidar en el
  servidor garantiza el logout completo. Con JWT, si falla el
  servidor hay un riesgo residual hasta la expiracion del token.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Detectado en**
     - FR-AUTH-03.01 (al intentar insertar en blacklist)
   * - **RNF**
     - RNF-AVAIL-001
   * - **Test**
     - TST-FR-AUTH-03.05 (pendiente — mock de fallo en blacklist)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-01 de UC-AUTH-03

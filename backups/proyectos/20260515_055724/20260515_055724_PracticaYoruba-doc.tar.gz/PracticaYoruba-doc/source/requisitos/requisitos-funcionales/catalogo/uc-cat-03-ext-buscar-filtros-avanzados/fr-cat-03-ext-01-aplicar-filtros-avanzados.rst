.. meta::
   :artefacto: FR-CAT-03-EXT.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-03-ext-01:

FR-CAT-03-EXT.01: Aplicar filtros avanzados sobre resultados de busqueda
========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-03-EXT.01
   * - **Nombre**
     - Aplicar filtros avanzados sobre resultados de busqueda
   * - **UC Origen**
     - UC-CAT-03-EXT: Buscar con filtros avanzados
   * - **Paso UC**
     - Pasos 3-5
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE aplicar filtros adicionales sobre los resultados de busqueda CUANDO el visitante activa el panel de filtros avanzados.

**Descripcion:**

Filtros adicionales combinados como AND sobre el queryset de UC-CAT-03:

- ``category``: filtra por categoria especifica
- ``min_price`` / ``max_price``: rango de precio con IVA
- ``in_stock``: solo productos con stock > 0

La URL refleja todos los filtros activos para que sea compartible.
El contador de resultados se actualiza con cada cambio de filtro.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Filtros combinados con busqueda
   DADO busqueda 'collar' con filtros ?category=oshun&max_price=300
   CUANDO se aplican
   ENTONCES solo aparecen collares de Oshun de hasta $300

   Escenario: Sin resultados tras aplicar filtros
   DADO filtros que excluyen todos los resultados de la busqueda
   CUANDO se aplican
   ENTONCES lista vacia con sugerencia de ampliar los filtros

   Escenario: Limpiar filtros — volver a resultados base
   DADO filtros activos
   CUANDO el visitante hace clic en limpiar filtros
   ENTONCES se vuelve a los resultados de la busqueda original sin filtros


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PERF-001`
- **Notas:** Los filtros avanzados se procesan en el servidor, no en el cliente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-03-EXT: Buscar con filtros avanzados
   * - **Depende de**
     - FR-CAT-03.01 (resultados de busqueda base)
   * - **Requerido por**
     - FR-CAT-02.01 (ver detalle de cada resultado filtrado)
   * - **Test**
     - TST-FR-CAT-03-EXT.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT-03-EXT

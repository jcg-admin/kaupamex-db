.. meta::
   :artefacto: FR-ORD-01-EXT.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-01-EXT.02: Checkout express — orden directa sin gestion de carrito
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01-EXT.02
   * - **Nombre**
     - Crear orden directa desde la ficha del producto sin pasar por el carrito
   * - **UC Origen**
     - UC-ORD-01-EXT: Checkout Express
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear una orden con un solo item desde la ficha
   del producto sin requerir que el visitante agregue el producto
   al carrito primero CUANDO el visitante elige "Comprar ahora".

**Descripcion:**

El checkout express usa la misma lógica de FR-ORD-01.02 y
FR-ORD-01.03 pero construye un carrito virtual en memoria con un
solo item: recupera el ``Product`` activo, construye la entrada
del carrito con ``product_id``, ``variant_id``, ``Product.name``,
precio actual y la cantidad solicitada, y pasa ese carrito virtual
directamente a las mismas funciones de reserva de stock y creación
de orden.

El carrito de sesión del visitante no se ve afectado —
los items que tenía siguen ahí.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Checkout express exitoso
   DADO visitante autenticado en la ficha de "Sopera de Yemoja" que elige qty=1
   CUANDO hace clic en "Comprar ahora"
   ENTONCES se crea una orden con ese unico item
   Y el carrito de sesion sigue teniendo sus items anteriores
   Y el visitante va al pago con la orden creada

   Escenario 2: Sin stock — error inmediato
   DADO producto con stock=0
   CUANDO el visitante hace clic en "Comprar ahora"
   ENTONCES HTTP 409 con STOCK_INSUFICIENTE
   Y el boton "Comprar ahora" estaba deshabilitado desde FR-CAT-02.02
   (este escenario ocurre solo si el stock cambio en el instante)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (los snapshots son identicos al checkout
  normal), BR-011 (el invitado puede usar checkout express con email)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01-EXT: Checkout Express
   * - **Depende de**
     - FR-ORD-01.02 (reserva de stock) y FR-ORD-01.03 (snapshots)
   * - **Test**
     - TST-FR-ORD-01-EXT.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-ORD-01-EXT

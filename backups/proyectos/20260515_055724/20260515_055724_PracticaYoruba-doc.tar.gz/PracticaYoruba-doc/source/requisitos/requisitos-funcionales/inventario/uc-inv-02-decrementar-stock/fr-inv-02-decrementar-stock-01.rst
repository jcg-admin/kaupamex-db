.. meta::
   :artefacto: FR-INV-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-inv-02-01:

FR-INV-02.01: Decrementar stock atomicamente al confirmar orden
===============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-02.01
   * - **Nombre**
     - Decrementar stock atomicamente al confirmar orden
   * - **UC Origen**
     - UC-INV 02 DECREMENTAR STOCK
   * - **Paso UC**
     - Paso 7 de UC-ORD-01
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE decrementar el stock de cada variante de forma atomica CUANDO la orden es creada.

**Descripcion:**

Implementado con ``SELECT FOR UPDATE`` para prevenir condiciones de
carrera. En una transacción atómica: bloquea la fila del
``ProductVariant``, verifica que ``ProductVariant.stock ≥ qty``
(si no → ``InsufficientStockError``), decrementa el stock y persiste
el cambio. Crea un ``StockMovement`` con tipo ``'SALE'``, delta
negativo, stock antes y después del decremento, y la referencia al
número de orden.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Decremento exitoso
   DADO variante con stock=5 y OrderItem con quantity=2
   CUANDO se decrementa
   ENTONCES variante.stock=3
   Y StockMovement(delta=-2, stock_before=5, stock_after=3) queda en BD

   Escenario: Stock insuficiente al decrementar
   DADO variante con stock=1 y OrderItem con quantity=2
   CUANDO se intenta decrementar
   ENTONCES InsufficientStockError — rollback de toda la transaccion

   Escenario: Concurrencia — dos ordenes simultaneas
   DADO stock=1 y dos ordenes intentando decrementar 1 simultaneamente
   CUANDO la primera obtiene el lock
   ENTONCES la primera decrementa exitosamente a 0
   Y la segunda recibe InsufficientStockError


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-AVAIL-002 (idempotencia)`
- **Notas:** El uso de select_for_update() garantiza que no hay race conditions en el decremento.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV 02 DECREMENTAR STOCK
   * - **Depende de**
     - FR-ORD-01.02 (orden creada con snapshot)
   * - **Requerido por**
     - FR-SYS-03.01 (alerta si stock cae bajo umbral)
   * - **Test**
     - TST-FR-INV-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-INV 02 DECREMENTAR STOCK
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

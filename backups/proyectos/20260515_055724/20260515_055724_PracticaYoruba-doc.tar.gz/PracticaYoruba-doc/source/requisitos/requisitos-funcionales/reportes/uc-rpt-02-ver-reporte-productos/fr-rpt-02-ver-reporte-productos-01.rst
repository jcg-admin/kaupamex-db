.. meta::
   :artefacto: FR-RPT-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rpt-02-01:

FR-RPT-02.01: Calcular ranking de productos vendidos
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-02.01
   * - **Nombre**
     - Calcular ranking de productos vendidos
   * - **UC Origen**
     - UC-RPT 02 VER REPORTE PRODUCTOS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el ranking de productos por unidades o ingresos CUANDO el admin lo consulta.

**Descripcion:**

``OrderItem.objects.filter(order__status='DELIVERED', order__created_at__range=[desde,hasta])
  .values('product_name','sku').annotate(
  unidades=Sum('quantity'), ingresos=Sum('subtotal'))
  .order_by('-unidades')[:limite]``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Top 10 productos del mes
   DADO admin que consulta el top 10 por unidades del mes
   CUANDO se genera
   ENTONCES aparecen los 10 productos con mas unidades vendidas con nombre y SKU

   Escenario: Filtro por categoria
   DADO admin que filtra por categoria 'Collares'
   CUANDO se aplica
   ENTONCES el ranking solo incluye productos de esa categoria


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El ranking usa los nombres del snapshot (OrderItem.product_name) — no los nombres actuales del catalogo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT 02 VER REPORTE PRODUCTOS
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-RPT-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RPT 02 VER REPORTE PRODUCTOS

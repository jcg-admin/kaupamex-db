.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-02-email-estado-orden
=======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-02-02-encolar-email-estado-orden
   fr-not-02-email-estado-orden-01

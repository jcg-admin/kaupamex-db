.. meta::
   :artefacto: FR-CAT-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-02.02: Recuperar la ficha completa del producto con precio y disponibilidad
===================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-02.02
   * - **Nombre**
     - Obtener datos del producto, precio vigente, stock actual, variantes y contenido social
   * - **UC Origen**
     - UC-CAT-02: Ver Detalle de Producto
   * - **Paso UC**
     - Pasos 2 al 9 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar la informacion completa del producto
   publicado, calcular su precio vigente con descuento si aplica,
   verificar el stock actual y agregar variantes, preguntas y resenas
   CUANDO el visitante accede a la ficha de un producto.

**Descripcion:**

La ficha del producto se construye en capas, usando el Servicio de
Cache con clave ``product:{pk}:detail`` y TTL de 300 segundos.
Si el producto fue modificado, el cache se invalida en el save del modelo
(signal ``post_save``).

Estructura de la respuesta:

.. code-block:: json

   {
     "id": 42,
     "name": "Sopera de Yemoja",
     "slug": "sopera-de-yemoja",
     "description": "...",
     "short_description": "...",
     "images": [{"url": "...", "alt": "..."}],
     "sku": "YOR-042",
     "category": {"id": 5, "name": "Soperas"},
     "base_price": 850.00,
     "discount": {"pct": 15, "final_price": 722.50, "valid_until": "2026-06-01"},
     "iva_rate": 0.16,
     "availability": "IN_STOCK",
     "stock_quantity": 12,
     "variants": [...],
     "questions": [...],
     "reviews": {"average_rating": 4.5, "count": 8, "items": [...]},
     "related_products": [...]
   }

Si el producto tiene ``is_published=False``:
HTTP 404 (no 403 — no revelar si el producto existe sin publicar).

Si el recurso esta en cache: P50 < 100ms.
Si no esta en cache: una sola query con ``select_related`` +
``prefetch_related`` para las variantes e imagenes.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Ficha completa con descuento activo
   DADO producto con base_price=850 y descuento de 15%
   CUANDO GET /api/v1/catalogue/products/sopera-de-yemoja/
   ENTONCES HTTP 200 con base_price=850, discount.pct=15, discount.final_price=722.50
   Y el frontend muestra el precio original tachado y el precio con descuento

   Escenario 2: Producto despublicado — 404
   DADO producto con is_published=False
   CUANDO el visitante accede via URL directa
   ENTONCES HTTP 404
   Y se ofrecen productos alternativos de la misma categoria

   Escenario 3: Stock agotado — boton deshabilitado
   DADO producto con stock=0 en todas sus variantes
   CUANDO se carga la ficha
   ENTONCES availability = OUT_OF_STOCK
   Y el campo "agregar_al_carrito_habilitado" = false
   Y se muestra la opcion de notificacion de reposicion

   Escenario 4: Cache invalidado tras edicion del admin
   DADO admin que edita el precio del producto
   CUANDO el signal post_save se dispara
   ENTONCES el cache de product:{pk}:detail se elimina
   Y la siguiente solicitud reconstruye la ficha desde el repositorio

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-001 (precio sin IVA), BR-012 (maximo un
  descuento activo por producto en MOD-018 DASHBOARD)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms sin cache,
  P50 < 100ms con cache)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-02: Ver Detalle de Producto
   * - **Depende de**
     - UC-CHT-01 (variantes), UC-QST-02 (preguntas), UC-REV-02 (resenas)
   * - **Requerido por**
     - FR-CART-01.01 (el visitante agrega el producto al carrito desde la ficha)
   * - **Test**
     - TST-FR-CAT-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-9 de UC-CAT-02
   * - 1.1.0
     - 2026-05-05
     - Verificacion de nombres canonicos. Sin codigo Python. Nombres de modelos correctos.

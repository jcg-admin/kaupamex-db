.. meta::
   :artefacto: FR-RPT-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-rpt-04-02:

=================================================================================
FR-RPT-04.02: Generar el archivo de exportación y servirlo con URL de descarga
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-04.02
   * - **Nombre**
     - Generar el archivo de exportación en CSV o XLSX con el mismo
       contenido que la vista del reporte, servirlo con una URL de
       descarga de validez limitada y soportar exportación asíncrona
       para conjuntos de datos grandes
   * - **UC Origen**
     - UC-RPT-04: Exportar Reporte
   * - **Paso UC**
     - Paso 5 del flujo principal; Alt. C (exportación periódica automática)
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar el archivo de exportación del reporte
   seleccionado en el formato indicado por el admin, servirlo mediante
   una URL de descarga con validez de una hora, y procesarlo de forma
   asíncrona cuando el número de filas supere el umbral que haría lenta
   la respuesta síncrona CUANDO el admin solicita la exportación de
   un reporte.

**Descripcion:**

La exportación comparte los mismos datos y el mismo período que la
vista del reporte activa. El admin ve en pantalla exactamente lo que
contendrá el archivo. Las columnas del archivo reproducen las métricas
de la vista, sin añadir ni omitir ninguna.

**Formatos disponibles.** El sistema produce dos formatos: CSV, que
es el más portable y compatible con cualquier herramienta de análisis,
y XLSX, que preserva el formato visual y es más cómodo para revisiones
directas en hojas de cálculo. El nombre del archivo incluye el tipo de
reporte, el período y el formato para facilitar su identificación.

**Exportación síncrona para reportes pequeños.**
Si el número de filas del reporte está por debajo del umbral
configurado, el sistema genera el archivo de forma inmediata y
retorna la URL de descarga en la misma respuesta. La URL apunta al
Servicio de Archivos temporal y tiene validez de una hora; pasado
ese tiempo el archivo se elimina automáticamente.

**Exportación asíncrona para reportes grandes.**
Cuando el reporte supera el umbral de filas, la generación del
archivo puede tardar varios segundos. En ese caso el sistema retorna
inmediatamente con un código 202 y un identificador de trabajo que
el admin puede consultar para conocer el progreso. Cuando el archivo
está listo, el identificador de trabajo devuelve la URL de descarga.

**Exportación periódica automática (Alt. C).**
El admin puede configurar que un reporte específico se exporte
automáticamente con la frecuencia que elija —semanal o mensual—
y se envíe al email del admin configurado. El Actor Tiempo dispara
la exportación en el momento acordado usando el mismo mecanismo
que la exportación manual.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Exportación CSV de reporte pequeño — descarga inmediata
   DADO admin que exporta el reporte de ventas de mayo 2026 en CSV
   Y el reporte tiene 47 filas
   CUANDO solicita la exportación
   ENTONCES HTTP 200 con download_url válida durante una hora
   Y el archivo CSV tiene las mismas columnas y valores que la vista
   del reporte en pantalla

   Escenario 2: Exportación XLSX de reporte grande — proceso asíncrono
   DADO admin que exporta el reporte anual de productos con 5000 filas
   CUANDO solicita la exportación
   ENTONCES HTTP 202 con {"job_id": "exp-20260505-00042", "status": "processing"}
   Y al consultar el job_id cuando está listo: HTTP 200 con download_url

   Escenario 3: URL de descarga expirada — error claro
   DADO admin que intenta descargar 90 minutos después de solicitar el archivo
   CUANDO accede a la URL de descarga
   ENTONCES HTTP 410 con {"mensaje": "Este archivo ya no está disponible.
   Genera una nueva exportación desde el reporte."}

   Escenario 4: Exportación periódica configurada — archivo enviado por email
   DADO admin que configura exportación mensual del reporte de compradores
   CUANDO el Actor Tiempo dispara la exportación el primer día del mes
   ENTONCES el archivo se genera y se envía al email del admin configurado
   Y el admin recibe el CSV con los datos del mes anterior

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms para la respuesta
  inicial, que puede ser síncrona con el archivo o asíncrona con el
  job_id), RNF-SEC-003 (la URL de descarga es temporal y firmada;
  no es posible adivinarla ni compartirla más allá de la hora de validez)
- **Notas:** El umbral de filas para la exportación asíncrona es
  configurable en SiteSettings. El valor predeterminado es 1000 filas.
  Los archivos de exportación no se almacenan de forma permanente en
  el servidor; el Servicio de Archivos los elimina automáticamente
  al expirar la URL.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT-04: Exportar Reporte
   * - **Depende de**
     - FR-RPT-01.02, FR-RPT-02.02 y FR-RPT-03.02 (los datos que
       se exportan son los mismos que calcula cada uno de estos FRs)
   * - **Test**
     - TST-FR-RPT-04.02 (pendiente — verificar que el archivo CSV
       tiene exactamente las mismas columnas que la vista del reporte;
       verificar que la URL expira después de una hora y retorna 410)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — código Python real, secciones incompletas)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: síncrono vs asíncrono por umbral, URL con
       validez de 1 hora, exportación periódica Alt. C, error 410 al
       expirar, 4 escenarios BDD con datos concretos

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-rev-02-ver-resenas
================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-rev-02-02-recuperar-resenas-aprobadas
   fr-rev-02-ver-resenas-01

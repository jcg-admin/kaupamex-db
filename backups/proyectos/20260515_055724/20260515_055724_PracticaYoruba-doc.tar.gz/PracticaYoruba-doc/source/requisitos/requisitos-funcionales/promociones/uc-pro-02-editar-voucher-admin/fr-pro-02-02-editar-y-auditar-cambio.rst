.. meta::
   :artefacto: FR-PRO-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PRO-02.02: Editar el voucher y registrar el cambio en auditoria
===================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-02.02
   * - **Nombre**
     - Validar y persistir los cambios del voucher registrando quien los hizo
   * - **UC Origen**
     - UC-PRO-02: Editar Voucher (Admin)
   * - **Paso UC**
     - Pasos 2, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar los campos modificados del voucher,
   persistir los cambios y registrar en auditoria quien hizo el
   cambio CUANDO el admin edita un voucher existente.

**Descripcion:**

Los campos editables de un voucher activo:

- ``valid_until`` — se puede extender o reducir la vigencia
- ``max_uses`` — se puede aumentar o reducir el limite de usos
- ``min_order_amount`` — se puede cambiar el monto minimo
- ``discount_value`` — se puede cambiar el valor del descuento

Los campos NO editables de un voucher con usos registrados:

- ``code`` — el codigo es inmutable una vez que el voucher fue usado
- ``discount_type`` — el tipo no puede cambiar (PERCENTAGE→FIXED rompe semantica)

Si ``Voucher.current_uses > 0``, los campos ``code`` y
``discount_type`` son inmutables → ``CAMPO_INMUTABLE_CON_USOS``.
En caso contrario, el sistema aplica los cambios solicitados al
``Voucher`` y crea un ``VoucherChangeLog`` con los campos modificados
y sus nuevos valores, y la referencia al administrador responsable.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Extension de vigencia exitosa
   DADO voucher con valid_until=2026-05-31
   CUANDO el admin lo extiende a 2026-06-30
   ENTONCES Voucher.valid_until = 2026-06-30
   Y VoucherChangeLog registra el cambio con el admin responsable

   Escenario 2: Cambio de codigo bloqueado si hay usos
   DADO voucher con current_uses=50 que el admin quiere renombrar
   CUANDO intenta cambiar el codigo
   ENTONCES HTTP 400 con CAMPO_INMUTABLE_CON_USOS

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (auditoria de cambios en vouchers)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO-02: Editar Voucher
   * - **Test**
     - TST-FR-PRO-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 4 y 5 de UC-PRO-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

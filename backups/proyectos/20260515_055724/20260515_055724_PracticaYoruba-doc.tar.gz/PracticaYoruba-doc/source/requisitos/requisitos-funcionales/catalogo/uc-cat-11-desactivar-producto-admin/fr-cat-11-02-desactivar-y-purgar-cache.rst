.. meta::
   :artefacto: FR-CAT-11.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-11.02: Desactivar producto con validacion de impacto y purga de cache
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-11.02
   * - **Nombre**
     - Desactivar el producto con advertencias de impacto y purgar todos sus caches
   * - **UC Origen**
     - UC-CAT-11: Desactivar Producto (Admin)
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE informar al admin del impacto de la desactivacion,
   solicitar confirmacion y desactivar el producto purgando sus caches
   CUANDO el admin solicita desactivar un producto.

**Descripcion:**

Antes de desactivar, el sistema calcula y muestra el impacto de la
operación al administrador:

- **Stock restante:** suma del ``ProductVariant.stock`` de todas las
  variantes del producto.
- **Carritos activos:** número de sesiones de carrito que contienen
  el producto (consultado al Servicio de Cache, no directamente a BD).
- **Wishlists:** número de registros ``WishlistItem`` que referencian
  el producto.

Tras la confirmación del administrador, el sistema establece
``Product.is_active = False`` y ``Product.is_published = False``, y
purga los caches afectados: la entrada de detalle del producto, el
árbol de categorías y todas las páginas del catálogo paginado.

El producto desactivado:
- No aparece en el catalogo ni en busquedas
- Los carritos que lo tienen muestran el item como OUT_OF_STOCK (FR-CART-02.03)
- Las wishlist que lo tienen lo marcan como no disponible
- Las ordenes existentes con ese producto NO se ven afectadas (snapshot BR-005)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Desactivacion con stock — advertencia visible
   DADO producto con stock=10 unidades
   CUANDO el admin hace clic en desactivar
   ENTONCES se muestra "Este producto tiene 10 unidades en stock"
   Y se requiere confirmacion explicita antes de proceder

   Escenario 2: Desactivacion completada — caches purgados
   DADO admin que confirma la desactivacion
   CUANDO el sistema desactiva el producto
   ENTONCES is_active=False e is_published=False en la BD
   Y el producto desaparece del catalogo en la proxima carga (sin cache)
   Y los caches del catalogo y de la ficha son eliminados

   Escenario 3: Ordenes previas sin afectar (snapshot)
   DADO cliente que ya pago una orden con el producto
   CUANDO el admin desactiva el producto
   ENTONCES la orden sigue existiendo con el snapshot del precio (BR-005)
   Y el admin puede seguir gestionando esa orden (envio, devolucion)

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (snapshot inmutable — las ordenes previas
  conservan los datos del producto al momento de la compra)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-11: Desactivar Producto
   * - **Relacionado con**
     - FR-CART-02.03 (carrito muestra OUT_OF_STOCK)
       y FR-INV-01.01 (el stock sigue en BD)
   * - **Test**
     - TST-FR-CAT-11.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-CAT-11

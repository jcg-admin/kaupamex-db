.. meta::
   :artefacto: FR-AUTH-10.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-10-04:

===================================================
FR-AUTH-10.04: Excepciones y NFR de verificacion de email
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-10.04
   * - **Nombre**
     - EX-01 a EX-03 y restricciones tecnicas del flujo de verificacion de email
   * - **UC Origen**
     - UC-AUTH-10: Verificar Email
   * - **Paso UC**
     - PARTE 5 y PARTE 6
   * - **Modulo**
     - MOD-001 ACCOUNTS (EmailVerificationToken)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El flujo de verificacion de email DEBE ser robusto ante tokens
   manipulados o repositorios no disponibles, y garantizar que el
   usuario siempre puede obtener un nuevo enlace si el anterior
   no funciona.

**Descripcion:**

**EX-01 — Token no encontrado:**

El token del URL no existe en la BD (manipulado, de otro sistema, ya
purged). El sistema retorna TOKEN_INVALIDO con redirect a reenviar-verificacion.

**EX-02 — Repositorio no disponible:**

HTTP 503 generico. La cuenta no se modifica. El usuario puede reintentar
cuando el sistema se recupere — el token sigue vigente.

**EX-03 — Error al actualizar estado:**

Si el UPDATE de ``is_active`` falla a mitad de la transaccion, el
rollback garantiza que el token no queda como ``used=True`` con la
cuenta sin activar. El usuario puede reintentar con el mismo enlace.

**Performance (6.1):**

- P95 <= 500ms — solo verificacion de token (lookup por hash) + UPDATE atomico
- Tiempo de vida del token: 24 horas (SiteSettings.email_verification_ttl_hours)
  — suficiente para que el usuario reciba el email y lo abra sin prisa

**Seguridad (6.2):**

- Token de un solo uso: ``used=True`` inmediatamente al activar
- Token no predecible: generado con un generador criptograficamente seguro — 256 bits
- Token almacenado como hash (SHA-256) en la BD
- Al reenviar: tokens anteriores del mismo usuario quedan expirados
- Reenvio siempre responde igual (proteccion anti-enumeracion)

**Confiabilidad (6.3):**

- Activar cuenta + marcar token usado = atomico (transaction.atomic)
- El usuario nunca queda atrapado sin poder activar su cuenta:
  siempre puede solicitar un nuevo enlace

**Usabilidad (6.4):**

- El enlace del email lleva directamente a la pagina de confirmacion
- Si el enlace expiró: la pagina explica que hacer y ofrece un boton
  de reenvio directamente — el usuario no necesita recordar la URL
- El mensaje de confirmacion es positivo y claro: "Tu cuenta esta activa"

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token manipulado — informacion minima revelada
   DADO URL con token modificado por el usuario
   CUANDO el sistema busca el hash del token
   ENTONCES HTTP 400 con TOKEN_INVALIDO (mismo mensaje que expirado o usado)
   Y el sistema no revela si el token existio o fue manipulado

   Escenario 2: Reenvio invalida tokens anteriores
   DADO usuario que solicito verificacion dos veces
   CUANDO usa el enlace del primer email (ya invalidado)
   ENTONCES TOKEN_INVALIDO porque su expires_at fue adelantado
   Y solo el enlace mas reciente es valido

   Escenario 3: Rollback garantiza consistencia
   DADO fallo a mitad de la transaccion (entre UPDATE user y UPDATE token)
   CUANDO el rollback ocurre
   ENTONCES user.is_active sigue siendo False
   Y verif_token.used sigue siendo False
   Y el usuario puede reintentar con el mismo enlace valido

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **RNF del sistema:** RNF-PERF-001, RNF-SEC-001, RNF-AVAIL-002

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-10: Verificar Email
   * - **Secciones**
     - PARTE 5 (EX-01 a EX-03) y PARTE 6 (6.1 a 6.4)
   * - **RNF del sistema**
     - RNF-PERF-001, RNF-SEC-001, RNF-AVAIL-002
   * - **Test**
     - TST-FR-AUTH-10.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de PARTE 5 y 6 de UC-AUTH-10

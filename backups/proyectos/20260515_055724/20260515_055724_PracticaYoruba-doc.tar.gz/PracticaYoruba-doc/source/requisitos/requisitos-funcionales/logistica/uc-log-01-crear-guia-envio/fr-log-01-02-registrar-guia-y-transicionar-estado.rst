.. meta::
   :artefacto: FR-LOG-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-01.02: Registrar la guia de envio y transicionar la orden a EN_ENVIO
============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-01.02
   * - **Nombre**
     - Crear ShipmentGuide, actualizar el estado de la orden y notificar al comprador
   * - **UC Origen**
     - UC-LOG-01: Crear Guia de Envio
   * - **Paso UC**
     - Pasos 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar la guia de envio, actualizar el estado
   de la orden a SHIPPED y encolar la notificacion al comprador CUANDO
   el admin confirma los datos de la guia.

**Descripcion:**

En una transacción atómica: el sistema recupera el ``Courier`` activo
por su identificador, crea un registro ``ShipmentGuide`` con referencia
a la ``Order``, al ``Courier``, el número de rastreo (puede quedar vacío
si se registra después en FR-LOG-02), estado ``'CREATED'`` y referencia
al administrador. Actualiza ``Order.status = 'SHIPPED'`` y encola la
notificación al comprador de forma asíncrona (UC-NOT-03).

Tras crear la guía, la ``OrderAddress`` queda inmutable — ya no se puede
cambiar (FR-ORD-05.02).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Guia creada con numero de rastreo
   DADO admin que registra una guia con courier=DHL y tracking=1234567890
   CUANDO guarda
   ENTONCES ShipmentGuide.status = CREATED con tracking_number=1234567890
   Y Order.status = SHIPPED
   Y la notificacion al comprador se encola

   Escenario 2: Guia sin numero de rastreo inicial
   DADO admin que solo tiene el courier pero aun no el numero de rastreo
   CUANDO crea la guia sin tracking_number
   ENTONCES ShipmentGuide se crea con tracking_number='' (vacio)
   Y el numero se agrega despues via FR-LOG-02.01
   Y la orden ya transiciona a SHIPPED

   Escenario 3: Ordenes elegibles mostradas correctamente
   DADO lista de ordenes del admin
   CUANDO accede a la vista de crear guia
   ENTONCES solo aparecen ordenes en PAYMENT_CONFIRMED o IN_PREPARATION
   Y las ordenes en PENDING_PAYMENT o SHIPPED no aparecen

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (ShipmentGuide.created_at automatico),
  BR-005 (OrderAddress inmutable tras crear la guia)
- **RNF aplicables:** RNF-PROC-002 (auditoria — created_by registra
  quien creo la guia)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-01: Crear Guia de Envio
   * - **Depende de**
     - FR-ORD-07.02 (la orden esta en PAYMENT_CONFIRMED o IN_PREPARATION)
   * - **Requerido por**
     - FR-LOG-02.01 (registrar el numero de rastreo si no se dio al crear)
   * - **Test**
     - TST-FR-LOG-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5-7 de UC-LOG-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ret-04-ver-estado-devolucion
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ret-04-02-recuperar-estado-devolucion
   fr-ret-04-ver-estado-devolucion-01

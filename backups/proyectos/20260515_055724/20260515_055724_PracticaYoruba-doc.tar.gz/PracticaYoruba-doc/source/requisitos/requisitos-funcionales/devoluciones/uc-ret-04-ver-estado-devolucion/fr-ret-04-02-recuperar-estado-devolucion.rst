.. meta::
   :artefacto: FR-RET-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/devoluciones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-RET-04.02: Recuperar el estado de la devolucion con historial y reembolso
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RET-04.02
   * - **Nombre**
     - Verificar propiedad y retornar el detalle de la devolucion con el estado del reembolso
   * - **UC Origen**
     - UC-RET-04: Ver Estado de Devolucion
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-010 RETURNS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la devolucion pertenece al comprador
   y retornar su estado actual con el historial de cambios y el
   estado del reembolso asociado CUANDO el comprador consulta.

**Descripcion:**

El sistema busca el ``ReturnRequest`` por identificador y verifica
que ``ReturnRequest.requested_by`` coincide con el usuario
autenticado. Si no existe o no coincide → HTTP 404 (RNF-SEC-003).

Retorna el estado actual del ``ReturnRequest``, el motivo, los
``ReturnItem`` asociados con sus ``OrderItem``, y el reembolso
asociado si la solicitud está en estado ``'APPROVED'`` o
``'COMPLETED'``. El reembolso se obtiene del ``Payment`` más
reciente de la orden con ``status`` en ``'REFUNDED'`` o
``'PARTIALLY_REFUNDED'``, recuperando el ``Refund`` más reciente
de ese pago.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Devolucion aprobada con reembolso en proceso
   DADO devolucion aprobada con reembolso iniciado
   CUANDO el comprador consulta
   ENTONCES HTTP 200 con status=APPROVED y refund.status=PROCESADO
   Y el comprador sabe que el reembolso llega en 3-5 dias

   Escenario 2: Devolucion pendiente — sin reembolso aun
   DADO solicitud recien enviada sin revision
   CUANDO el comprador consulta
   ENTONCES status=PENDING y refund=null

   Escenario 3: Otro usuario intenta ver la devolucion — 404
   DADO usuario B que intenta acceder a la devolucion de usuario A
   CUANDO consulta
   ENTONCES HTTP 404 (no 403, RNF-SEC-003)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — 404 en lugar de 403)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RET-04: Ver Estado de Devolucion
   * - **Incluye**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-RET-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-RET-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

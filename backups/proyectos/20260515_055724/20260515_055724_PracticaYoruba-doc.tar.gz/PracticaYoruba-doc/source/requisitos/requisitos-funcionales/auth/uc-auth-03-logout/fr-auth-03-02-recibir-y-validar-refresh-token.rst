.. meta::
   :artefacto: FR-AUTH-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-03-02:

================================================================
FR-AUTH-03.02: Recibir y validar la solicitud de cierre de sesion
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-03.02
   * - **Nombre**
     - Recibir el refresh token y verificar que corresponde a una sesion activa
   * - **UC Origen**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recibir el refresh token del body del request
   y verificar que corresponde a una sesion activa reconocida
   CUANDO el comprador solicita cerrar sesion.

**Descripcion:**

El endpoint ``POST /api/v1/auth/logout/`` recibe:

.. code-block:: json

   {"refresh": "eyJhbGciOiJIUzI1NiIsInR..."}

Verificaciones en este paso:

1. El campo ``refresh`` esta presente en el body
2. El token tiene firma valida (firmado con ``SIGNING_KEY``)
3. El token no ha expirado (``exp`` del payload)
4. El token existe en el repositorio de sesiones activas
   (fue emitido legitimamente por este sistema)

Si cualquier verificacion falla, el comportamiento es:

- **Token ausente:** retorna 400 (EX-02 — sin credenciales)
- **Firma invalida:** retorna 401 (token no emitido por el sistema)
- **Token expirado:** procede igualmente al logout — la sesion
  ya no era activa, pero se limpia el estado del cliente (Alt. B)
- **Token en blacklist:** procede igualmente — logout idempotente (Alt. A)

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token valido y activo
   DADO refresh token valido enviado en el body
   CUANDO el sistema lo recibe en el paso 2-3
   ENTONCES la firma es verificada correctamente
   Y el proceso continua a FR-AUTH-03.01 (invalidar en blacklist)

   Escenario 2: Token expirado — logout igualmente exitoso
   DADO refresh token que ya expiro naturalmente (mas de 7 dias)
   CUANDO se solicita el logout
   ENTONCES el sistema considera el logout exitoso (Alt. B)
   Y limpia el estado del cliente de todas formas
   Y retorna 200 OK sin error

   Escenario 3: Token ya en blacklist — idempotencia
   DADO refresh token que ya fue invalidado previamente
   CUANDO se intenta hacer logout de nuevo con el mismo token
   ENTONCES el sistema retorna 200 OK (no es un error)
   Y no modifica el estado de la blacklist
   Y el usuario queda en estado no autenticado

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-002 (idempotencia — multiples solicitudes
  de logout con el mismo token no generan errores)
- **Notas:** El access token NO se envia en el logout. El access token
  expira naturalmente en 15 minutos tras el logout. El refresh token
  es el que se invalida para impedir la renovacion de sesion.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-03: Cerrar Sesion (Logout)
   * - **Depende de**
     - FR-AUTH-02.11 (refresh token emitido en el login)
   * - **Requerido por**
     - FR-AUTH-03.01 (revocar el token en la blacklist)
   * - **Test**
     - TST-FR-AUTH-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2 y 3 de UC-AUTH-03

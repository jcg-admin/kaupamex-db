.. meta::
   :artefacto: FR-AUTH-09.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-09-04:

==============================================================
FR-AUTH-09.04: Validar token del enlace y establecer nueva contraseña
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-09.04
   * - **Nombre**
     - Verificar token del enlace de recuperacion y persistir la nueva contraseña
   * - **UC Origen**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Paso UC**
     - Pasos 10, 11, 12 y 19-21 del flujo principal (Fase 2)
   * - **Modulo**
     - MOD-001 ACCOUNTS (PasswordResetToken + blacklist)
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Validacion + Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el token del enlace de recuperacion,
   verificar que no expiro ni fue usado, y establecer la nueva
   contraseña de forma atomica CUANDO el usuario accede al enlace.

**Descripcion:**

**Pasos 10, 11, 12 — Validacion del token:**

El enlace tiene la forma ``/reset-password/?token=<token_en_claro>``.

El sistema calcula el hash del token recibido en texto claro y busca
en ``PasswordResetToken`` un registro con ese hash, que no haya sido
usado y cuya fecha de expiración sea posterior al momento actual. Si
no existe ningún registro que cumpla las tres condiciones, el sistema
retorna ``TOKEN_INVALIDO`` sin distinguir el motivo exacto (token
inexistente, ya usado o expirado) para no revelar información.

**Pasos 19, 20, 21 — Almacenar nueva contraseña e invalidar:**

En una transacción atómica el sistema realiza tres operaciones:
establece la nueva contraseña en ``User.password`` usando el
algoritmo PBKDF2-SHA256, marca el ``PasswordResetToken`` como
usado registrando el timestamp de uso (el registro se conserva para
auditoría, no se elimina), e invalida todas las sesiones activas
del usuario forzando rotación en el próximo intento de refresco.
Si cualquiera de las tres operaciones falla, se ejecuta rollback
completo y ninguna de las tres tiene efecto.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Token valido — nueva contraseña establecida
   DADO token valido del enlace de recuperacion (no expirado, no usado)
   CUANDO el usuario envia el POST con la nueva contraseña
   ENTONCES la nueva contraseña queda almacenada (PBKDF2-SHA256)
   Y el token queda marcado como used=True
   Y todas las sesiones previas del usuario quedan invalidadas
   Y el usuario es redirigido al login

   Escenario 2: Token expirado (mas de 1 hora)
   DADO token generado hace 2 horas (tiempo de vida: 1 hora)
   CUANDO el usuario hace clic en el enlace del email
   ENTONCES HTTP 400 con {"codigo_error": "TOKEN_INVALIDO",
   "mensaje": "El enlace ha expirado. Solicita uno nuevo.",
   "redirect": "/recuperar-contrasena/"}
   Y el sistema ofrece la opcion de solicitar un nuevo enlace

   Escenario 3: Token ya usado — no reutilizable
   DADO token que ya fue usado para establecer una contraseña
   CUANDO alguien intenta usarlo de nuevo (mismo enlace del email)
   ENTONCES HTTP 400 con TOKEN_INVALIDO
   Y la contraseña actual NO se modifica
   (sea correcta o incorrecta la nueva contraseña enviada)

   Escenario 4: Atomicidad — fallo al guardar no invalida sesiones
   DADO OperationalError al guardar la nueva contraseña
   CUANDO falla el guardado
   ENTONCES rollback completo — contraseña anterior intacta
   Y el token NO se marca como usado (puede reintentarse)
   Y las sesiones NO fueron invalidadas

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-001 (atomicidad y token de un solo uso)
- **Notas:** El token se almacena hasheado en la BD. Incluso si
  alguien accede a la BD no puede usar los tokens almacenados porque
  no sabe el valor original. El usuario que hizo clic en el enlace
  tiene el token en claro en la URL.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-09: Recuperar Contraseña
   * - **Depende de**
     - FR-AUTH-09.03 (token generado y email enviado)
   * - **Requerido por**
     - FR-AUTH-09.05 (registrar auditoria y confirmar al usuario)
   * - **Test**
     - TST-FR-AUTH-09.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 10-12 y 19-21 de UC-AUTH-09
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminados 2 bloques code-block Python.
       Logica de validacion TOKEN_INVALIDO y transaccion atomica preservadas.

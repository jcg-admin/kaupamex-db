.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-sys-03-notificar-stock-minimo
===========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-sys-03-02-notificar-stock-bajo
   fr-sys-03-notificar-stock-minimo-01

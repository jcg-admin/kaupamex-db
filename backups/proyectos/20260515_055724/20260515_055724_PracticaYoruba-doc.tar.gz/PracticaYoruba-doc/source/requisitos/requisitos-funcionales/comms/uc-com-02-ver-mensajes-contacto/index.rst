.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-com-02-ver-mensajes-contacto
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-com-02-02-listar-y-marcar-leido
   fr-com-02-ver-mensajes-contacto-01

.. meta::
   :artefacto: FR-AUTH-02.03
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-02-03:

==============================================
FR-AUTH-02.03: Emitir par de tokens JWT
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.03
   * - **Nombre**
     - Generar y retornar access token y refresh token
   * - **UC Origen**
     - UC-AUTH-02: Iniciar sesion
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Autenticacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar y retornar un par de tokens JWT
   CUANDO la autenticacion de credenciales es exitosa.

**Descripcion:**

Tokens generados:

- **access token**: JWT firmado con HS256. Payload incluye
  ``user_id``, ``username``, ``is_staff``, ``exp`` (15 minutos).
  Se usa en el header ``Authorization: Bearer <token>`` de cada request.

- **refresh token**: JWT firmado con HS256. Payload incluye solo
  ``user_id`` y ``exp`` (7 dias). Se usa exclusivamente en
  ``POST /api/v1/auth/refresh/`` para obtener nuevos access tokens.

El contador de intentos fallidos de la IP se reinicia a 0
tras un login exitoso.

Adicionalmente se retornan los datos basicos del usuario:
``user_id``, ``username``, ``email``, ``is_staff``.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO autenticacion de credenciales exitosa
   CUANDO el sistema emite los tokens
   ENTONCES el cliente recibe access y refresh token

   Escenario 1: Respuesta con tokens
   DADO credenciales correctas
   CUANDO se emiten los tokens
   ENTONCES la respuesta 200 contiene:
   - access: string JWT valido
   - refresh: string JWT valido
   - user: {id, username, email, is_staff}

   Escenario 2: Access token expira en 15 minutos
   DADO access token emitido hace 15 minutos y 1 segundo
   CUANDO se usa en un endpoint protegido
   ENTONCES el sistema retorna 401 con mensaje de token expirado

   Escenario 3: Reinicio del contador de intentos
   DADO IP con 3 intentos fallidos previos
   CUANDO el login es exitoso
   ENTONCES el contador de intentos fallidos de esa IP se reinicia a 0

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica en la emision del token
- **RNF aplicables:** RNF-SEC-001 (autenticacion JWT), RNF-SEC-006 (HTTPS obligatorio)
- **Notas:** Los tokens se transmiten siempre sobre HTTPS (RNF-SEC-006).
  El refresh token no debe almacenarse en localStorage en el cliente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar sesion
   * - **Depende de**
     - FR-AUTH-02.02 (credenciales autenticadas)
   * - **Requerido por**
     - FR-AUTH-04.01 (renovar sesion con refresh token)
   * - **RNF**
     - RNF-SEC-001, RNF-SEC-006
   * - **Test**
     - TST-FR-AUTH-02.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-02

.. meta::
   :artefacto: FR-AUTH-06.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-06-01:

====================================================
FR-AUTH-06.01: Actualizar campos del perfil
====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-06.01
   * - **Nombre**
     - Persistir los cambios del formulario de edicion de perfil
   * - **UC Origen**
     - UC-AUTH-06: Editar perfil
   * - **Paso UC**
     - Pasos 3-5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE actualizar unicamente los campos modificados
   CUANDO el comprador envia el formulario de edicion de perfil.

**Descripcion:**

Campos actualizables y sus restricciones:

- ``first_name``: maximo 150 caracteres
- ``last_name``: maximo 150 caracteres
- ``phone``: formato libre, maximo 20 caracteres, puede vaciarse
- ``avatar``: JPG, PNG o WebP, maximo 5MB. Si se sube un nuevo avatar
  el anterior se elimina del almacenamiento

**Campos no editables en este UC:**

- ``username`` — inmutable en todo el ciclo de vida del usuario
- ``email`` — requiere re-verificacion, es un flujo separado
- ``password`` — requiere flujo especifico (UC-AUTH-08)

Solo los campos presentes en el request se actualizan
(PATCH semantics). Los campos ausentes permanecen sin cambio.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado con formulario de perfil
   CUANDO envia los campos modificados
   ENTONCES solo esos campos cambian en la BD

   Escenario 1: Actualizacion parcial
   DADO solo first_name enviado en el body
   CUANDO se procesa
   ENTONCES solo first_name cambia en BD
   Y phone, last_name, avatar permanecen intactos

   Escenario 2: Avatar reemplazado
   DADO comprador con avatar existente
   CUANDO sube un nuevo avatar
   ENTONCES el nuevo avatar queda almacenado
   Y el avatar anterior es eliminado del almacenamiento
   Y avatar_url en el perfil apunta al nuevo archivo

   Escenario 3: Formato de avatar invalido
   DADO archivo PDF enviado como avatar
   CUANDO se procesa
   ENTONCES error 422: "Formato no permitido. Usa JPG, PNG o WebP"

   Escenario 4: Avatar supera el limite
   DADO imagen de 6MB enviada como avatar
   CUANDO se procesa
   ENTONCES error 413: "El archivo supera el limite de 5MB"

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica
- **Notas:** La ruta de almacenamiento del avatar sigue el patron
  ``profiles/user_{pk}_{timestamp}.{ext}`` para evitar colisiones
  y facilitar la limpieza del avatar anterior.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-06: Editar perfil
   * - **Depende de**
     - FR-AUTH-05.01 (datos actuales del perfil cargados)
   * - **Requerido por**
     - FR-AUTH-05.01 refleja los cambios en la proxima consulta
   * - **Test**
     - TST-FR-AUTH-06.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-06

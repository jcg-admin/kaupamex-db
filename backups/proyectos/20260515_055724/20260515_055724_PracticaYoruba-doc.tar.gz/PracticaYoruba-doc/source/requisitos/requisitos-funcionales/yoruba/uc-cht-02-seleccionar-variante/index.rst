.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cht-02-seleccionar-variante
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cht-02-02-validar-y-agregar-al-carrito
   fr-cht-02-seleccionar-variante-01

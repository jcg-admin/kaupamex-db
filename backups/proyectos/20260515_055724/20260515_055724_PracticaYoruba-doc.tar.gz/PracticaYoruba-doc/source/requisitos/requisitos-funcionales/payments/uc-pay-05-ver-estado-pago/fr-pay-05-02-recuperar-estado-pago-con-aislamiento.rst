.. meta::
   :artefacto: FR-PAY-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-05.02: Recuperar el estado del pago verificando propiedad de la orden
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-05.02
   * - **Nombre**
     - Retornar el estado del pago de una orden propia del usuario autenticado
   * - **UC Origen**
     - UC-PAY-05: Ver Estado de Pago
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden pertenece al usuario y
   retornar el estado del pago asociado CUANDO el usuario consulta
   el estado de su pago.

**Descripcion:**

El sistema busca la ``Order`` por ``order_number`` y ``user``
simultáneamente. Si no existe → HTTP 404 (nunca HTTP 403, RNF-SEC-003).
Recupera el ``Payment`` más reciente de la orden ordenado por
``-Payment.created_at``. Si no existe ningún pago, retorna
``status = 'NO_PAYMENT'``; en caso contrario retorna el
``Payment.gateway``, ``Payment.status``, ``Payment.amount`` y
``Payment.created_at``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Pago aprobado — estado retornado
   DADO orden pagada con Mercado Pago
   CUANDO el usuario consulta el estado
   ENTONCES HTTP 200 con gateway=MERCADOPAGO, status=APPROVED, amount=1824.80

   Escenario 2: Sin pago aun — estado pendiente
   DADO orden recien creada sin pago procesado
   CUANDO el usuario consulta
   ENTONCES payment.status = NO_PAYMENT y order_status = PENDING_PAYMENT

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — 404 para ordenes de otros usuarios)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-05: Ver Estado de Pago
   * - **Incluye**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **Test**
     - TST-FR-PAY-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-3 de UC-PAY-05
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-AUTH-07.04
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-07.04: Almacenar direccion y gestionar la predeterminada
=================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-07.04
   * - **Nombre**
     - Persistir la nueva direccion y garantizar invariante de una sola predeterminada
   * - **UC Origen**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Paso UC**
     - Pasos 10, 11 y 12 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — Address model)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE almacenar la nueva direccion y mantener la invariante
   de que solo existe una direccion predeterminada por usuario CUANDO
   los datos han sido validados.

**Descripcion:**

La operación se ejecuta en una transacción atómica con tres pasos
secuenciales:

1. **Verificar límite de direcciones.** El sistema cuenta las
   ``Address`` actuales del usuario. Si el total iguala o supera
   ``SiteSettings.max_addresses_per_user``, la operación se rechaza
   con ``LIMITE_DIRECCIONES`` antes de crear nada.

2. **Crear la nueva dirección.** El sistema crea el registro
   ``Address`` asociado al usuario con ``is_default = False``
   independientemente de lo solicitado — el valor definitivo se
   establece en el siguiente paso.

3. **Gestionar la dirección predeterminada.** Si el usuario marcó
   la nueva dirección como predeterminada, o si es la primera
   dirección del usuario (el conteo previo era 0), el sistema
   actualiza en bloque todas las demás direcciones del usuario
   a ``is_default = False`` y establece ``is_default = True``
   únicamente en la nueva. Esta actualización en bloque garantiza
   la invariante de una sola predeterminada sin iterar registro
   a registro.

Si el usuario no marcó la dirección como predeterminada y ya
existe al menos una dirección, la nueva queda con
``is_default = False`` y la predeterminada anterior no se modifica.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Primera direccion — automaticamente predeterminada
   DADO usuario sin ninguna direccion guardada
   CUANDO guarda su primera direccion (sin marcar "predeterminada")
   ENTONCES la direccion queda con is_default = True
   Y el usuario tiene 1 direccion que es la predeterminada

   Escenario 2: Nueva predeterminada — desmarca la anterior
   DADO usuario con direccion A como predeterminada
   CUANDO guarda una nueva direccion B marcada como "predeterminada"
   ENTONCES direccion B queda is_default = True
   Y direccion A queda is_default = False
   Y solo existe 1 direccion predeterminada en todo momento

   Escenario 3: Nueva direccion sin marcar como predeterminada
   DADO usuario con 2 direcciones, A es predeterminada
   CUANDO guarda nueva direccion C sin marcarla como predeterminada
   ENTONCES C queda is_default = False
   Y A sigue siendo la predeterminada
   Y el usuario ahora tiene 3 direcciones con 1 predeterminada

   Escenario 4: Limite de direcciones alcanzado
   DADO usuario con SiteSettings.max_addresses_per_user = 5 y ya tiene 5
   CUANDO intenta agregar una sexta
   ENTONCES HTTP 409 con {"codigo_error": "LIMITE_DIRECCIONES",
   "mensaje": "Has alcanzado el limite de 5 direcciones guardadas.",
   "sugerencia": "Elimina una direccion antes de agregar una nueva."}

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-013 (AbstractBaseModel — ``created_at`` y
  ``updated_at`` automaticos en el modelo Address)
- **RNF aplicables:** RNF-SEC-003 (aislamiento — el limite se verifica
  sobre las direcciones del usuario autenticado, nunca del total global)
- **Notas:** El limite ``max_addresses_per_user`` es configurable en
  SiteSettings. Default: 5. El UPDATE de is_default usa ``.update()``
  para ser atomico — no itera sobre cada direccion individualmente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Depende de**
     - FR-AUTH-07.03 (campos validados y zona verificada)
   * - **Requerido por**
     - FR-ORD-01.01 (el checkout usa las direcciones guardadas del usuario)
   * - **BR**
     - BR-013
   * - **Test**
     - TST-FR-AUTH-07.04 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 10, 11 y 12 de UC-AUTH-07
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Los 3 pasos atomicos preservados integros en texto numerado.

.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — AUTH
==============================

**76 FRs** escritos uno por uno con contenido real.

Dominio auth/ completado — los 10 UCs del modulo ACCOUNTS tienen
sus FRs con 6 secciones, logica real, BDD con datos concretos y
cadena Depende de → Requerido por.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-auth-01-registrar
     - 5
   * - uc-auth-02-login
     - 24
   * - uc-auth-03-logout
     - 8
   * - uc-auth-04-renovar-sesion
     - 9
   * - uc-auth-05-ver-perfil
     - 4
   * - uc-auth-06-editar-perfil
     - 5
   * - uc-auth-07-gestionar-direcciones
     - 5
   * - uc-auth-08-cambiar-contrasena
     - 6
   * - uc-auth-09-recuperar-contrasena
     - 6
   * - uc-auth-10-verificar-email
     - 4

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-auth-01-registrar/index
   uc-auth-02-login/index
   uc-auth-03-logout/index
   uc-auth-04-renovar-sesion/index
   uc-auth-05-ver-perfil/index
   uc-auth-06-editar-perfil/index
   uc-auth-07-gestionar-direcciones/index
   uc-auth-08-cambiar-contrasena/index
   uc-auth-09-recuperar-contrasena/index
   uc-auth-10-verificar-email/index

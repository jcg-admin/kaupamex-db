.. meta::
   :artefacto: FR-INV-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INV-05.02: Procesar el CSV fila a fila y crear productos como borradores
===========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-05.02
   * - **Nombre**
     - Validar el CSV, crear productos validos en borrador e informar el resultado fila a fila
   * - **UC Origen**
     - UC-INV-05: Importar Productos CSV
   * - **Paso UC**
     - Pasos 4, 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE procesar el CSV fila por fila, crear los productos
   validos en estado borrador y generar un reporte de resultados con
   los errores por fila CUANDO el admin sube un archivo CSV de productos.

**Descripcion:**

El proceso es tolerante a fallos parciales: si una fila falla,
las demás siguen procesándose. El admin ve exactamente qué falló.

El sistema valida que el CSV incluya los encabezados obligatorios:
``name``, ``sku``, ``base_price`` y ``category_slug``. Si alguno
falta → ``ENCABEZADO_INVALIDO``. Para cada fila, en una transacción
individual: crea un ``Product`` con los campos del CSV, estado
``is_active = False`` e ``is_published = False`` (borrador), y la
referencia al administrador importador. Si la fila falla (SKU
duplicado, categoría inexistente, precio inválido u otro error),
registra la fila y el motivo del fallo sin interrumpir el resto del
proceso. Retorna el conteo de productos creados y fallidos con detalle
de cada caso.

La respuesta se retorna inmediatamente como HTTP 202 si el archivo
es grande (> 100 filas), con un job_id para polling.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: CSV con 50 filas validas y 3 con SKU duplicado
   DADO archivo CSV con 53 filas
   CUANDO el admin lo sube
   ENTONCES se crean 50 productos en estado borrador
   Y el reporte indica las 3 filas falladas con el motivo (SKU duplicado)

   Escenario 2: Encabezado invalido — error inmediato
   DADO CSV sin la columna "sku"
   CUANDO el sistema valida el encabezado
   ENTONCES HTTP 400 con ENCABEZADO_INVALIDO antes de procesar ninguna fila

   Escenario 3: Archivo grande — respuesta asincrona
   DADO archivo CSV con 500 filas
   CUANDO el admin lo sube
   ENTONCES HTTP 202 con job_id para polling de progreso

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-USAB-002 (retroalimentacion de operaciones
  largas — 202 + polling para archivos grandes)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV-05: Importar Productos CSV
   * - **Relacionado con**
     - FR-CAT-09.02 (los borradores se publican via crear producto)
   * - **Test**
     - TST-FR-INV-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-7 de UC-INV-05
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

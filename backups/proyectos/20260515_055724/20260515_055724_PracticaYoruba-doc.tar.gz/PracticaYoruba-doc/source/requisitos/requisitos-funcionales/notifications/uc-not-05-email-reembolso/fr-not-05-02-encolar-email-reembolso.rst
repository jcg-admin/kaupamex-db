.. meta::
   :artefacto: FR-NOT-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-05-02:

================================================================================
FR-NOT-05.02: Confirmar al comprador la ejecución del reembolso en el gateway
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-05.02
   * - **Nombre**
     - Encolar el email de confirmación de reembolso indicando el monto,
       el gateway y el tiempo estimado de acreditación, diferenciando
       entre reembolso total y parcial
   * - **UC Origen**
     - UC-NOT-05: Email de Reembolso
   * - **Paso UC**
     - Pasos 2 al 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El Sistema de Notificaciones DEBE encolar el email de confirmación
   de reembolso con el monto acreditado, el gateway de pago al que
   se procesó y el tiempo estimado de acreditación CUANDO FR-PAY-07.02
   registra la ejecución exitosa del reembolso en el gateway.

**Descripcion:**

El reembolso fue ejecutado en el gateway antes de que este FR actúe.
La notificación tiene como objetivo único informar al comprador de
que el dinero está en camino, con datos suficientes para que pueda
hacer seguimiento por su cuenta si lo desea.

El email incluye tres datos concretos que el comprador necesita:

El **monto exacto** del reembolso. Este dato responde a la pregunta
más importante del comprador: ¿cuánto voy a recibir? Si el reembolso
fue parcial (Alt. C), el email especifica qué items fueron
reembolsados y cuáles no, con el monto correspondiente a cada parte.

El **gateway de pago** al que se procesó. El comprador necesita
saber en cuál de sus métodos de pago aparecerá el cargo revertido,
especialmente si tiene más de uno registrado.

El **tiempo estimado de acreditación**. Este dato depende del gateway
y se obtiene de su configuración, no se codifica en la plantilla.
Mercado Pago tiene tiempos distintos que PayPal, y el email refleja
el tiempo real del gateway utilizado.

**EX-02 — Rebote permanente:**
Si el email del comprador tiene un rebote permanente registrado,
el sistema no encola el email y notifica al admin para que gestione
la comunicación del reembolso por un canal alternativo. El dinero
ya fue acreditado; la notificación es informativa y no afecta al
reembolso en sí.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Reembolso total — email con monto completo y tiempo del gateway
   DADO reembolso de $1824.80 procesado exitosamente en Mercado Pago
   CUANDO el Sistema de Notificaciones recibe el evento
   ENTONCES el email muestra "Te reembolsamos $1,824.80 a tu cuenta de Mercado Pago"
   Y el tiempo de acreditación corresponde al configurado para ese gateway
   Y no menciona tiempos de otros gateways

   Escenario 2: Reembolso parcial — desglose por items aprobados y no aprobados
   DADO devolución aprobada solo para 2 de 3 items, reembolso de $1200 de $1824.80
   CUANDO el Sistema de Notificaciones genera el email (Alt. C)
   ENTONCES el email muestra el desglose: qué items fueron reembolsados
   Y el monto parcial de $1200 claramente identificado
   Y los items no reembolsados con el motivo correspondiente

   Escenario 3: Email con rebote permanente — admin notificado
   DADO comprador cuyo email tiene rebote permanente registrado (EX-02)
   CUANDO el Sistema de Notificaciones detecta el rebote
   ENTONCES no se encola el email al comprador
   Y se crea un aviso interno para el admin indicando que debe
   contactar al comprador por otro canal para informarle del reembolso

   Escenario 4: Preferencia de notificaciones de reembolso desactivada
   DADO comprador que desactivó los avisos de reembolso en FR-NOT-06.02
   CUANDO el Sistema de Notificaciones verifica las preferencias
   ENTONCES no se encola ningún email
   Y el proceso registra "omitida por preferencia" en auditoría

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-003 (reintentos con espera progresiva
  para fallos temporales del Servicio de Email Externo; sin reintento
  para rebote permanente)
- **Notas:** El tiempo de acreditación es un dato informativo. Si el
  reembolso tarda más de lo indicado, el comprador debe contactar al
  gateway directamente; el negocio no controla los tiempos internos
  del procesador de pagos.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-05: Email de Reembolso
   * - **Disparado por**
     - FR-PAY-07.02 (ejecución del reembolso en el gateway)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla)
   * - **Relacionado con**
     - FR-NOT-06.02 (preferencias del comprador),
       FR-SYS-04.02 (reintentos con espera progresiva)
   * - **Test**
     - TST-FR-NOT-05.02 (pendiente — verificar que el tiempo de
       acreditación en el email coincide con el configurado para
       el gateway; verificar que el rebote permanente genera aviso
       al admin en lugar de reintento)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: tres datos concretos del email (monto,
       gateway, tiempo), reembolso parcial con desglose, EX-02 con
       aviso al admin, 4 escenarios BDD

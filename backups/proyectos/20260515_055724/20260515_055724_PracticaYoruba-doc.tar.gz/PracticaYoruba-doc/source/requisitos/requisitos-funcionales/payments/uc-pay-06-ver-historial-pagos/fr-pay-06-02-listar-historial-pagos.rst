.. meta::
   :artefacto: FR-PAY-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-06.02: Listar el historial de pagos del usuario autenticado
==================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-06.02
   * - **Nombre**
     - Recuperar todos los pagos de las ordenes del usuario paginados por fecha
   * - **UC Origen**
     - UC-PAY-06: Ver Historial de Pagos
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el historial de todos los pagos
   (aprobados, fallidos y reembolsados) de las ordenes del usuario
   autenticado, paginados y ordenados por fecha descendente.

**Descripcion:**

El sistema recupera todos los registros ``Payment`` cuya
``Payment.order__user`` coincida con el usuario autenticado,
con carga anticipada de la ``Order`` asociada, ordenados por
``-Payment.created_at``.

Cada item del listado incluye:

- Numero de orden
- Gateway de pago (Mercado Pago / PayPal)
- Estado del pago (APPROVED, FAILED, REFUNDED)
- Monto
- Fecha

No se incluyen los detalles de tarjeta ni credenciales del comprador.
Solo datos de la transaccion que son propiedad del usuario.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Historial con pagos de diferentes estados
   DADO usuario con 3 ordenes: una aprobada, una fallida, una reembolsada
   CUANDO accede al historial de pagos
   ENTONCES HTTP 200 con los 3 pagos ordenados del mas reciente al mas antiguo
   Y cada pago muestra el numero de orden, el estado y el monto

   Escenario 2: Sin pagos — lista vacia
   DADO usuario sin ordenes previas
   CUANDO accede al historial
   ENTONCES HTTP 200 con items=[]

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — solo se retornan
  pagos de ordenes del usuario autenticado)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-06: Ver Historial de Pagos
   * - **Test**
     - TST-FR-PAY-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-3 de UC-PAY-06
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

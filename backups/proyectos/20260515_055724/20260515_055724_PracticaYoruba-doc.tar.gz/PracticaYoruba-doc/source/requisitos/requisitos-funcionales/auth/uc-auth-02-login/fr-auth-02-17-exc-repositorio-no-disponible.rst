.. meta::
   :artefacto: FR-AUTH-02.17
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-17:

==============================================================
FR-AUTH-02.17: EX-02 — Manejar repositorio de usuarios no disponible
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.17
   * - **Nombre**
     - EX-02: Responder con error temporal si la BD no esta disponible
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - EX-02 — Excepcion del sistema (PARTE 5)
   * - **Modulo**
     - MOD-001 ACCOUNTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Disponibilidad — Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar un error temporal generico sin exponer
   detalles internos CUANDO la base de datos no responde durante
   el proceso de autenticacion.

**Descripcion:**

Esta excepción cubre fallos de conectividad con el repositorio durante
cualquiera de los pasos que requieren acceso a la base de datos,
principalmente FR-AUTH-02.08.

Cuando el repositorio no responde, el sistema:

- Retorna HTTP 503 al cliente con el mensaje «El servicio está
  temporalmente no disponible. Intenta de nuevo en unos momentos.»
  El error interno del repositorio nunca aparece en la respuesta.
- No incrementa el contador de intentos fallidos del origen —
  el fallo es del sistema, no del usuario.
- Registra el error completo en el log del servidor con nivel ERROR,
  incluyendo timestamp, origen del request y traza del fallo, para
  que el administrador pueda diagnosticar sin necesidad de ver la
  respuesta del cliente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: BD no disponible durante la busqueda
   DADO MySQL inaccesible al momento del login
   CUANDO el sistema intenta buscar el usuario
   ENTONCES respuesta HTTP 503 Service Unavailable
   Y el body es {"codigo_error": "ERROR_SISTEMA",
   "mensaje": "El servicio esta temporalmente no disponible..."}
   Y el body NO contiene la excepcion de MySQL ni paths internos
   Y el contador de intentos de la IP NO incrementa

   Escenario 2: Log del error para diagnostico
   DADO OperationalError de MySQL capturado
   CUANDO se maneja la excepcion
   ENTONCES el error completo se escribe en django.log con nivel ERROR
   Y incluye: timestamp, IP del request, tipo de error, stack trace
   Y el administrador puede diagnosticar sin ver la respuesta del cliente

   Escenario 3: Retry del usuario tras recuperacion
   DADO usuario que recibio el 503 y espero a que la BD se recuperara
   CUANDO reintenta el login
   ENTONCES el sistema procesa el intento normalmente
   Y el usuario puede autenticarse si sus credenciales son correctas

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **RNF aplicables:** RNF-AVAIL-001 (disponibilidad 99.5% — este
  escenario es el que afecta la disponibilidad)
- **Notas:** El 503 informa al cliente que puede reintentar mas tarde,
  a diferencia del 500 que sugiere un error permanente. Usar 503
  con Retry-After es la practica correcta en este caso.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Detectado en**
     - FR-AUTH-02.08 (busqueda en el repositorio)
   * - **Requerido por**
     - El administrador monitorea el log para detectar este patron
   * - **RNF**
     - RNF-AVAIL-001
   * - **Test**
     - TST-FR-AUTH-02.17 (pendiente — mock de error del repositorio)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de EX-02 de UC-AUTH-02

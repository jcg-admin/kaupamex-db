.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-10-editar-producto-admin
==========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-10-02-validar-y-actualizar-producto
   fr-cat-10-editar-producto-admin-01-editar-producto-preservando-sn

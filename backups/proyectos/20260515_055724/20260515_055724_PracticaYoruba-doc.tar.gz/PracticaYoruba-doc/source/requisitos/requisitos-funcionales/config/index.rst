.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — CONFIG
================================

**5 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-cfg-01-configurar-gateways-de-pago
     - 1
   * - uc-cfg-02-configurar-metodos-y-costos-de
     - 1
   * - uc-cfg-03-configurar-sitesettings--iva-
     - 1
   * - uc-cfg-04-gestionar-contenido-estatico
     - 1
   * - uc-cfg-05-gestionar-datos-contacto
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-cfg-01-configurar-gateways-de-pago/index
   uc-cfg-02-configurar-metodos-y-costos-de/index
   uc-cfg-03-configurar-sitesettings--iva-/index
   uc-cfg-04-gestionar-contenido-estatico/index
   uc-cfg-05-gestionar-datos-contacto/index

.. meta::
   :artefacto: FR-PAY-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-05-01:

FR-PAY-05.01: Consultar y retornar el estado del pago
=====================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-05.01
   * - **Nombre**
     - Consultar y retornar el estado del pago
   * - **UC Origen**
     - UC-PAY-05: Ver estado de pago
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-007 PAYMENT via UC-INC-01
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el estado actual del pago de la orden CUANDO el comprador la consulta tras verificar su propiedad.

**Descripcion:**

Datos retornados:

- ``payment_id``, ``gateway`` (MERCADOPAGO / PAYPAL)
- ``status``: PENDING / APPROVED / FAILED / REFUNDED
- ``amount``, ``installments`` (cuotas si aplica)
- ``created_at``, ``updated_at``
- ``actions_available``: lista de acciones segun el estado
  (ej: [``reintentar``] si FAILED, [``solicitar_reembolso``] si APPROVED)
- Si hay reembolsos: lista con ``refund_id``, ``amount``, ``status`` de cada uno

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Pago aprobado — sin acciones de reintento
   DADO orden con Payment.status = APPROVED
   CUANDO se consulta el estado
   ENTONCES se muestra APROBADO con el monto y la fecha
   Y actions_available incluye solicitar_reembolso

   Escenario: Pago fallido — accion de reintento disponible
   DADO orden con Payment.status = FAILED
   CUANDO se consulta el estado
   ENTONCES se muestra FALLIDO con el motivo si esta disponible
   Y actions_available incluye reintentar_pago

   Escenario: Orden ajena
   DADO comprador consultando orden que no es suya
   CUANDO se verifica la propiedad
   ENTONCES error 404 sin revelar que la orden existe


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003 (aislamiento de datos de usuario)`
- **Notas:** El estado del pago se lee desde BD local, no se hace una llamada al gateway en cada consulta.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-05: Ver estado de pago
   * - **Depende de**
     - FR-ORD-02.01 (propiedad verificada via INC-01)
   * - **Requerido por**
     - FR-PAY-08.01 (reintentar pago) / FR-PAY-07.01 (solicitar reembolso)
   * - **Include**
     - UC-INC-01 (verificar propiedad de la orden)
   * - **Test**
     - TST-FR-PAY-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-05

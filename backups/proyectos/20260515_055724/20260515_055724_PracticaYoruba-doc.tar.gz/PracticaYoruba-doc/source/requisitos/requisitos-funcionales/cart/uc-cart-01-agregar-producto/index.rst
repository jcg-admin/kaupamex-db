.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cart-01-agregar-producto
======================================

**3 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cart-01-01-verificar-stock
   fr-cart-01-02-agregar-item-carrito
   fr-cart-01-03-retornar-totales

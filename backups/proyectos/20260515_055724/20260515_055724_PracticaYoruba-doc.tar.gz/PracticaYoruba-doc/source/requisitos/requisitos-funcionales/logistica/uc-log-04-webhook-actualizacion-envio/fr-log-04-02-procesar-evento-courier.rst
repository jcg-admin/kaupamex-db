.. meta::
   :artefacto: FR-LOG-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-04.02: Verificar autenticidad del webhook y actualizar el estado del envio
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-04.02
   * - **Nombre**
     - Validar la firma del webhook del courier, actualizar la guia y notificar al comprador
   * - **UC Origen**
     - UC-LOG-04: Webhook Actualizacion de Envio
   * - **Paso UC**
     - Pasos 2, 3, 4, 5, 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la autenticidad del webhook del courier,
   actualizar el estado de la guia de envio, y si corresponde
   marcar la orden como entregada CUANDO recibe una notificacion
   del courier.

**Descripcion:**

En una transacción atómica: el sistema recupera el ``Courier`` activo
por su slug y verifica la firma del webhook según el mecanismo del
courier (RNF-SEC-005). Si la firma no es válida → HTTP 401.

El sistema busca el ``ShipmentGuide`` por ``tracking_number`` con
``SELECT FOR UPDATE``. Si no existe, retorna HTTP 200 sin procesar
(idempotente). En caso contrario, mapea el estado del courier al estado
interno y actualiza ``ShipmentGuide.status``. Crea un
``ShipmentEvent`` con el nuevo estado, la descripción y el timestamp
del evento. Si el nuevo estado es ``'DELIVERED'``, actualiza
``Order.status = 'DELIVERED'``. Encola la notificación al comprador
de forma asíncrona.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Webhook de entrega recibido y procesado
   DADO courier que notifica que el paquete fue entregado
   CUANDO el sistema lo procesa
   ENTONCES ShipmentGuide.status = DELIVERED
   Y Order.status = DELIVERED
   Y ShipmentEvent creado con el timestamp del courier
   Y notificacion al comprador encolada

   Escenario 2: Firma invalida — rechazado
   DADO webhook con firma incorrecta
   CUANDO el sistema verifica la firma
   ENTONCES HTTP 401 y no se procesa el evento

   Escenario 3: Tracking no reconocido — ignorado
   DADO webhook para un tracking_number sin guia en el sistema
   CUANDO el sistema busca la guia
   ENTONCES HTTP 200 (para que el courier no reintente)
   Y no se crea ningun registro ni se genera error

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-005 (verificacion de firma segun el
  mecanismo de cada courier), RNF-AVAIL-002 (idempotente — si
  el mismo evento llega dos veces, el segundo no duplica datos)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-04: Webhook Actualizacion de Envio
   * - **Depende de**
     - FR-LOG-01.02 (la guia existe con tracking_number)
   * - **Relacionado con**
     - UC-NOT-03 (notificacion de actualizacion de envio al comprador)
   * - **Test**
     - TST-FR-LOG-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-7 de UC-LOG-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

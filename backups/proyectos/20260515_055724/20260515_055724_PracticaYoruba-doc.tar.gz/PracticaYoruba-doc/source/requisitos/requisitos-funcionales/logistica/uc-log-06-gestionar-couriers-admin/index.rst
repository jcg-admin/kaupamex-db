.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-06-gestionar-couriers-admin
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-06-02-crud-couriers-y-templates
   fr-log-06-gestionar-couriers-admin-01

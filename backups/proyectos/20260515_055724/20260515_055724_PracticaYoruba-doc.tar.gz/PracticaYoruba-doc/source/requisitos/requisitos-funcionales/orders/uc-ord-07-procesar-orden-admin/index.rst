.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-07-procesar-orden-admin
=========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-07-01-cambiar-estado-en-preparacion
   fr-ord-07-02-transicionar-estado-admin

.. meta::
   :artefacto: FR-PAY-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-PAY-04.02: Verificar aprobacion de PayPal y capturar el pago
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-04.02
   * - **Nombre**
     - Verificar la firma del webhook de PayPal, capturar el pago y actualizar la orden
   * - **UC Origen**
     - UC-PAY-04: Webhook PayPal
   * - **Paso UC**
     - Pasos 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-007 PAYMENT
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la autenticidad del webhook de PayPal,
   capturar el pago aprobado via la API del gateway y actualizar
   el estado de la orden de forma idempotente.

**Descripcion:**

PayPal usa un flujo de dos pasos: aprobación (usuario en PayPal)
y captura (el backend confirma el cargo).

En una transacción atómica: si ya existe un ``Payment`` con ese
``gateway_payment_id`` y ``status = 'APPROVED'``, el procesamiento
concluye sin cambios (idempotencia). Si el evento es
``CHECKOUT.ORDER.APPROVED``, el sistema captura el pago en el gateway.
Si la captura retorna estado ``COMPLETED``, actualiza
``Payment.status = 'APPROVED'`` y ``Order.status = 'PAYMENT_CONFIRMED'``
usando el ``reference_id`` incluido en la respuesta del gateway para
correlacionar con ``Order.order_number``.

La captura del pago ocurre en el servidor, no en el frontend.
El frontend solo redirige al comprador de vuelta; el backend
verifica el estado real via el webhook o una consulta directa.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Captura exitosa tras aprobacion del usuario
   DADO comprador que aprobo el pago en la interfaz de PayPal
   CUANDO el backend recibe el webhook CHECKOUT.ORDER.APPROVED
   ENTONCES el backend captura el pago via la API del gateway
   Y Payment.status = APPROVED y Order.status = PAYMENT_CONFIRMED

   Escenario 2: Pago cancelado por el usuario en PayPal
   DADO comprador que cancelo en la interfaz de PayPal
   CUANDO el sistema detecta la cancelacion
   ENTONCES Payment.status = CANCELLED y Order.status sigue PENDING_PAYMENT
   Y el comprador puede reintentar con otro metodo de pago

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-006 (Strategy Pattern — PayPalGateway.capture_payment),
  BR-009 (credenciales en servidor)
- **RNF aplicables:** RNF-SEC-005 (verificacion de firma via SDK oficial PayPal)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-04: Webhook PayPal
   * - **Depende de**
     - FR-PAY-02.02 (Payment con preference_id ya existe)
   * - **Test**
     - TST-FR-PAY-04.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-6 de UC-PAY-04
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

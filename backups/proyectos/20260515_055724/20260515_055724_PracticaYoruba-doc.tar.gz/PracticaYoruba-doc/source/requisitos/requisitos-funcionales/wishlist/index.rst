.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — WISHLIST
==================================

**3 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-wish-01-agregar-a-wishlist
     - 1
   * - uc-wish-02-ver-lista-deseos
     - 1
   * - uc-wish-03-mover-wishlist-carrito
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-wish-01-agregar-a-wishlist/index
   uc-wish-02-ver-lista-deseos/index
   uc-wish-03-mover-wishlist-carrito/index

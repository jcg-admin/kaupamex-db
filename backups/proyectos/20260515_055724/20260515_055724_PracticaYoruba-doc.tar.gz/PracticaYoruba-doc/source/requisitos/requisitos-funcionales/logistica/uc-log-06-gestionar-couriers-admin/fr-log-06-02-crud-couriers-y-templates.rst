.. meta::
   :artefacto: FR-LOG-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-06.02: Crear y editar couriers con URL de seguimiento y configuracion de webhook
========================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-06.02
   * - **Nombre**
     - CRUD de couriers con template de URL de seguimiento y credenciales cifradas
   * - **UC Origen**
     - UC-LOG-06: Gestionar Couriers (Admin)
   * - **Paso UC**
     - Pasos 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar y persistir la configuracion del courier
   incluyendo el template de URL de seguimiento y las credenciales
   de webhook de forma segura CUANDO el admin crea o edita un courier.

**Descripcion:**

El modelo Courier tiene:

- ``name`` — nombre del courier (ej: DHL, FedEx, Correos MX)
- ``slug`` — identificador para los webhooks (``/api/v1/webhooks/courier/{slug}/``)
- ``tracking_url_template`` — URL con el placeholder ``{tracking}``
  (ej: ``https://www.dhl.com.mx/es/express/rastreo.html?AWB={tracking}``)
- ``webhook_secret`` — credencial cifrada para verificar firmas (RNF-SEC-002)
- ``is_active`` — si el courier esta disponible para nuevas guias

Validación del template de URL: el sistema verifica que
``Courier.tracking_url_template`` contenga el marcador ``{tracking}``.
Si no está presente, rechaza con error de validación. Además genera
una URL de prueba con el valor ``TEST123`` y verifica que el resultado
comience con ``http``; si no, rechaza el template como URL inválida.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Courier creado con template de URL valido
   DADO admin que crea courier DHL con template="https://dhl.com/?tracking={tracking}"
   CUANDO guarda
   ENTONCES el courier existe con el template correcto
   Y FR-LOG-02.02 puede construir la URL de seguimiento para cualquier guia de DHL

   Escenario 2: Template sin el marcador {tracking} — error
   DADO template = "https://dhl.com/tracking"
   CUANDO el admin guarda
   ENTONCES HTTP 400 con "El template debe incluir el marcador {tracking}."

   Escenario 3: Credencial de webhook almacenada cifrada
   DADO admin que configura el webhook_secret de un courier
   CUANDO se guarda
   ENTONCES el valor en la BD esta cifrado (RNF-SEC-002)
   Y el valor en claro solo existe en memoria durante la verificacion de webhooks

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-002 (webhook_secret cifrado en reposo)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-06: Gestionar Couriers
   * - **Requerido por**
     - FR-LOG-01.02 (crear guia) y FR-LOG-04.02 (autenticar webhook)
   * - **Test**
     - TST-FR-LOG-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-5 de UC-LOG-06
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

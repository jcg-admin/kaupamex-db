.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-log-01-crear-guia-envio
=====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-log-01-02-registrar-guia-y-transicionar-estado
   fr-log-01-crear-guia-envio-01

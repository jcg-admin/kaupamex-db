.. meta::
   :artefacto: FR-CART-05.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cart-05-01:

===================================================
FR-CART-05.01: Persistir carrito en la cuenta
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-05.01
   * - **Nombre**
     - Vincular el carrito de sesion a la cuenta del comprador
   * - **UC Origen**
     - UC-CART-05: Guardar carrito
   * - **Paso UC**
     - Pasos 2-4 del flujo principal
   * - **Modulo**
     - MOD-005 CART (apps.cart)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE vincular el Cart de sesion al usuario autenticado
   CUANDO el visitante inicia sesion teniendo un carrito activo.

**Descripcion:**

Este FR se ejecuta como parte del flujo de login (UC-AUTH-02),
no como una accion explicita del comprador:

1. Al autenticarse exitosamente, se detecta si habia un Cart de sesion
2. Si habia carrito de sesion Y el usuario ya tenia un carrito en BD:
   se ejecuta la fusion (FR-CART-06.01)
3. Si habia carrito de sesion Y el usuario NO tenia carrito en BD:
   se asigna ``Cart.user = user``, ``Cart.session_key = None``
4. Si no habia carrito de sesion: no hay accion (el carrito en BD
   ya existe o se crea bajo demanda)

El comprador no necesita hacer nada explicitamente — el guardado
ocurre automaticamente al iniciar sesion.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO visitante con carrito de sesion que inicia sesion
   CUANDO la autenticacion es exitosa
   ENTONCES el carrito queda vinculado a la cuenta

   Escenario 1: Carrito anonimo sin carrito previo en cuenta
   DADO visitante con 2 items y sin carrito en BD
   CUANDO inicia sesion
   ENTONCES el Cart.user_id se asigna al usuario
   Y Cart.session_key queda en None
   Y los 2 items persisten en la cuenta

   Escenario 2: Carrito anonimo con carrito previo en cuenta
   DADO visitante con 1 item nuevo y carrito de BD con 2 items
   CUANDO inicia sesion
   ENTONCES se ejecuta la fusion (FR-CART-06.01)
   Y el resultado tiene los 3 items (o la cantidad fusionada)

   Escenario 3: Login sin carrito anonimo
   DADO comprador que inicia sesion sin haber agregado nada
   CUANDO se autentica
   ENTONCES se recupera su carrito de BD si existe
   Y si no existe se crea uno vacio al primer acceso

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-003 (carrito en sesion para anonimos),
  BR-004 (carrito sin login)
- **Notas:** La vinculacion es parte del proceso de login,
  no una operacion separada del cliente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-05: Guardar carrito
   * - **Depende de**
     - FR-AUTH-02.03 (login exitoso)
   * - **Requerido por**
     - FR-CART-06.01 (fusion si habia dos carritos)
   * - **BR**
     - BR-003, BR-004
   * - **Test**
     - TST-FR-CART-05.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CART-05

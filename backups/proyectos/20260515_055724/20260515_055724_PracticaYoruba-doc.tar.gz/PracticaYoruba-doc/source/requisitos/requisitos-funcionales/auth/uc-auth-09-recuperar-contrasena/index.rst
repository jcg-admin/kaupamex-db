.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-09-recuperar-contrasena
==========================================

**6 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-09-01-generar-token-recuperacion
   fr-auth-09-02-restablecer-contrasena
   fr-auth-09-03-generar-token-hmac-y-enviar-email
   fr-auth-09-04-validar-token-y-establecer-nueva
   fr-auth-09-05-registrar-auditoria-y-confirmar
   fr-auth-09-06-exc-y-nfr-recuperacion

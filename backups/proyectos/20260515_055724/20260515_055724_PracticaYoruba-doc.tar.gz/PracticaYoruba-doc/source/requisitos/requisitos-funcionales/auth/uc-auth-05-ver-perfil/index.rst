.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-05-ver-perfil
================================

**4 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-05-01-recuperar-datos-perfil
   fr-auth-05-02-recuperar-datos-del-perfil
   fr-auth-05-03-calcular-completitud-perfil
   fr-auth-05-04-exc-y-nfr-perfil

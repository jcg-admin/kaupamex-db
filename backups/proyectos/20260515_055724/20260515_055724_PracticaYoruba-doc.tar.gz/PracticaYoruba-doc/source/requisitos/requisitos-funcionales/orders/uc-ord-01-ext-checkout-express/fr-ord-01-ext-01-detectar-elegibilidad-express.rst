.. meta::
   :artefacto: FR-ORD-01-EXT.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-ORD-01-EXT.01: Detectar elegibilidad para checkout express
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-01-EXT.01
   * - **Nombre**
     - Verificar si el comprador cumple las condiciones para checkout express
   * - **UC Origen**
     - UC-ORD-01-EXT: Checkout Express
   * - **Paso UC**
     - Paso 1 del flujo principal del EXT
   * - **Modulo**
     - MOD-006 ORDER + MOD-001 ACCOUNTS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE detectar si el comprador es elegible para el
   checkout express CUANDO inicia el proceso de checkout.

**Descripcion:**

Condiciones de elegibilidad (todas deben cumplirse):

1. El comprador esta autenticado (no aplica para invitados)
2. Tiene al menos una orden previa con estado ``DELIVERED``
   (es comprador recurrente)
3. Tiene una direccion guardada con ``is_default = True``
4. El metodo de envio predeterminado o el mas economico disponible
   tiene cobertura para esa direccion

Si todas las condiciones se cumplen, el endpoint de checkout
retorna un campo ``express_available: true`` junto con el
resumen de los datos que se usarian.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador que inicia el checkout
   CUANDO el sistema evalua la elegibilidad
   ENTONCES informa si el express esta disponible

   Escenario 1: Primer compra — no elegible
   DADO comprador sin ordenes previas
   CUANDO evalua elegibilidad
   ENTONCES express_available: false
   Y el flujo normal de checkout se presenta

   Escenario 2: Comprador recurrente con direccion default
   DADO comprador con 3 ordenes entregadas y direccion default
   CUANDO evalua elegibilidad
   ENTONCES express_available: true
   Y el resumen incluye la direccion y el costo de envio estimado

   Escenario 3: Sin direccion default
   DADO comprador recurrente pero sin direccion guardada
   CUANDO evalua elegibilidad
   ENTONCES express_available: false

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La deteccion de elegibilidad es silenciosa —
  si no es elegible simplemente presenta el checkout normal
  sin mencionar que el express existe.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-01-EXT: Checkout Express
   * - **Extiende**
     - UC-ORD-01 (se activa en el paso de inicio del checkout)
   * - **Depende de**
     - FR-AUTH-07.01 (dirreccion default existe)
   * - **Requerido por**
     - FR-ORD-01.01 (si express: salta a confirmacion directa)
   * - **Test**
     - TST-FR-ORD-01-EXT.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-01-EXT

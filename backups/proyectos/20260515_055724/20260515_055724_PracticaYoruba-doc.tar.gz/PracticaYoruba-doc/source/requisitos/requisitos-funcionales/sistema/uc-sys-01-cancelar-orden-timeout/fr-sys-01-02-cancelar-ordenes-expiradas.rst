.. meta::
   :artefacto: FR-SYS-01.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-SYS-01.02: Cancelar ordenes expiradas y restaurar su stock atomicamente
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-01.02
   * - **Nombre**
     - El Procesador Periodico cancela ordenes PENDING_PAYMENT expiradas y restaura el stock
   * - **UC Origen**
     - UC-SYS-01: Cancelar Orden por Timeout (Actor: Tiempo)
   * - **Paso UC**
     - Pasos 2, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER + MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El Procesador Periodico DEBE identificar las ordenes en
   PENDING_PAYMENT que superaron el timeout de pago, cancelarlas
   y restaurar el stock de forma atomica e idempotente.

**Descripcion:**

El comando de gestión se ejecuta via cron (CNST-ARQ-001 T6).

El sistema lee ``SiteSettings.payment_timeout_minutes`` (valor por
defecto 30) y calcula el límite temporal. Consulta todas las ``Order``
con ``status = 'PENDING_PAYMENT'`` y ``created_at`` anterior al
límite, ordenadas de la más antigua a la más reciente.

Para cada orden, en una transacción atómica individual: recarga el
estado actual de la orden para garantizar idempotencia — si ya no
está en ``'PENDING_PAYMENT'`` la omite. Si sigue en ese estado,
actualiza ``Order.status = 'CANCELLED_TIMEOUT'`` y restaura el stock
de todos sus items (FR-INV-03.02). Si la transacción falla, registra
el error y continúa con la siguiente orden.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Ordenes expiradas canceladas y stock restaurado
   DADO 3 ordenes en PENDING_PAYMENT creadas hace mas de 30 minutos
   CUANDO el cron ejecuta el comando
   ENTONCES las 3 ordenes quedan en CANCELLED_TIMEOUT
   Y el stock de cada item se restaura idempotentemente (FR-INV-03.02)

   Escenario 2: Orden pagada entre el inicio y el fin del proceso
   DADO orden que pago exactamente durante la ejecucion del comando
   CUANDO el comando intenta cancelarla
   ENTONCES refresh_from_db detecta status=PAYMENT_CONFIRMED
   Y la orden NO se cancela (el status ya no es PENDING_PAYMENT)

   Escenario 3: Error en una orden — proceso continua
   DADO un error en la cancelacion de una orden especifica
   CUANDO el comando lo detecta
   ENTONCES registra el error en el log y continua con las demas
   Y la siguiente ejecucion del cron reintenta esa orden

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-002 (idempotencia — si el cron se
  ejecuta dos veces, la segunda no duplica ninguna cancelacion)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS-01: Cancelar Orden Timeout
   * - **Depende de**
     - FR-INV-03.02 (restaurar stock idempotente)
   * - **Test**
     - TST-FR-SYS-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-6 de UC-SYS-01
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

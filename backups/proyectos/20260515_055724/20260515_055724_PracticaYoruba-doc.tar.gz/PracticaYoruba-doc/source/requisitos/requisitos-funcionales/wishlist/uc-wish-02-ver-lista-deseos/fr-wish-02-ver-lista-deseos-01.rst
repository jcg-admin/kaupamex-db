.. meta::
   :artefacto: FR-WISH-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/wishlist
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-wish-02-01:

FR-WISH-02.01: Ver lista de deseos con alertas de precio
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-WISH-02.01
   * - **Nombre**
     - Ver lista de deseos con alertas de precio
   * - **UC Origen**
     - UC-WISH 02 VER LISTA DESEOS
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-011 WISHLIST
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar la lista de deseos con el precio actual y alertas de rebaja CUANDO el comprador la consulta.

**Descripcion:**

Por cada WishlistItem:

- Datos actuales del producto: nombre, imagen, precio actual, disponibilidad
- ``price_dropped``: true si el precio actual < price_at_add
- ``price_change``: diferencia entre el precio actual y el precio al guardar
- ``is_available``: si tiene stock disponible actualmente

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Producto con rebaja
   DADO item guardado a 200 y precio actual es 150
   CUANDO se consulta la lista
   ENTONCES price_dropped=true y price_change=-50

   Escenario: Producto sin stock
   DADO item en lista cuyo stock llego a 0
   CUANDO se consulta
   ENTONCES is_available=false con indicador visual


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-003`
- **Notas:** Las rebajas se detectan comparando el precio actual con price_at_add.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-WISH 02 VER LISTA DESEOS
   * - **Depende de**
     - FR-WISH-01.01 (item agregado)
   * - **Requerido por**
     - FR-WISH-03.01 (mover al carrito)
   * - **Test**
     - TST-FR-WISH-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-WISH 02 VER LISTA DESEOS

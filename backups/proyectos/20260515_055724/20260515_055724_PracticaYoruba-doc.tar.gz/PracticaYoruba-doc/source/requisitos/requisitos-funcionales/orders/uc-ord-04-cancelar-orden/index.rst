.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-04-cancelar-orden
===================================

**4 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-04-01-verificar-elegibilidad-cancelacion
   fr-ord-04-02-ejecutar-cancelacion-restaurar-stock
   fr-ord-04-03-validar-estado-y-cancelar
   fr-ord-04-04-notificar-cancelacion

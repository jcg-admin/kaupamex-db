.. meta::
   :artefacto: FR-CHT-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/yoruba
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cht-03-01:

FR-CHT-03.01: Crear, editar y reordenar variantes del producto
==============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CHT-03.01
   * - **Nombre**
     - Crear, editar y reordenar variantes del producto
   * - **UC Origen**
     - UC-CHT 03 GESTIONAR VARIANTES ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-003 CHARTSIZE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE persistir los cambios de variantes CUANDO el admin los configura.

**Descripcion:**

Operaciones:

- Crear VariantType: nombre del tipo de variante para el producto
- Crear VariantOption: label y orden de cada opcion
- Reordenar: actualiza ``VariantOption.order`` por drag-and-drop
- Desactivar: ``VariantOption.is_active=False`` (no elimina fisicamente)

Al reordenar: el primer elemento es la variante preseleccionada por defecto en la ficha.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Agregar nueva variante
   DADO producto sin variante de 'Presentacion'
   CUANDO el admin agrega 'Presentacion' con opciones 'Individual' y 'Pack x3'
   ENTONCES aparece el selector en la ficha del producto

   Escenario: Desactivar variante con ordenes activas
   DADO variante con ordenes en PENDING_PAYMENT
   CUANDO el admin intenta desactivarla
   ENTONCES advertencia de ordenes activas con esa variante


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** El reordenamiento determina la variante preseleccionada — tiene impacto en la conversion.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CHT 03 GESTIONAR VARIANTES ADMIN
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-CHT-01.01 (la ficha muestra las variantes actualizadas)
   * - **Test**
     - TST-FR-CHT-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CHT 03 GESTIONAR VARIANTES ADMIN

.. meta::
   :artefacto: FR-ORD-08.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-ORD-08.01: Cancelar orden (Admin) con motivo
================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-08.01
   * - **Nombre**
     - Cancelar cualquier orden activa con motivo obligatorio (Admin)
   * - **UC Origen**
     - UC-ORD-08: Cancelar orden (Admin)
   * - **Paso UC**
     - Pasos 2-5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER (apps.orders)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cancelar la orden con el motivo proporcionado y
   ejecutar los efectos secundarios CUANDO un administrador lo solicita.

**Descripcion:**

El admin puede cancelar ordenes en cualquier estado activo:
``PENDING_PAYMENT``, ``PAYMENT_CONFIRMED``, ``IN_PREPARATION``.

No puede cancelar: ``SHIPPED``, ``DELIVERED``, ``CANCELLED``.

Proceso:

1. Valida que el estado permite cancelacion admin
2. Requiere ``cancellation_reason`` obligatorio (min 10 chars)
3. ``Order.status = CANCELLED``, ``Order.admin_cancelled_by = admin``
4. Restaura stock (misma logica que FR-ORD-04.02)
5. Si habia pago: inicia reembolso
6. Notifica al comprador con el motivo de la cancelacion

----

3. Criterio de Aceptacion
--------------------------

::

   DADO admin con una orden activa a cancelar
   CUANDO ejecuta la cancelacion con motivo
   ENTONCES la orden queda cancelada con auditoria completa

   Escenario 1: Orden IN_PREPARATION cancelada por admin
   DADO orden en IN_PREPARATION con pago confirmado
   CUANDO el admin cancela con motivo "Producto agotado en almacen"
   ENTONCES Order.status = CANCELLED
   Y el stock se restaura
   Y se inicia el reembolso
   Y el comprador recibe email con el motivo

   Escenario 2: Motivo obligatorio ausente
   DADO admin que intenta cancelar sin motivo
   CUANDO se procesa
   ENTONCES error 422: MOTIVO_REQUERIDO

   Escenario 3: Orden SHIPPED — no cancelable por admin
   DADO orden en SHIPPED
   CUANDO el admin intenta cancelar
   ENTONCES error 422: CANCELACION_NO_PERMITIDA_EN_SHIPPED

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (restauracion usa cantidades del snapshot)
- **RNF:** RNF-PROC-002 (auditoria obligatoria con admin y motivo)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-08: Cancelar orden (Admin)
   * - **Depende de**
     - Ninguno (accion directa del admin)
   * - **Requerido por**
     - FR-PAY-07.01 (reembolso si habia pago)
   * - **Test**
     - TST-FR-ORD-08.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-ORD-08

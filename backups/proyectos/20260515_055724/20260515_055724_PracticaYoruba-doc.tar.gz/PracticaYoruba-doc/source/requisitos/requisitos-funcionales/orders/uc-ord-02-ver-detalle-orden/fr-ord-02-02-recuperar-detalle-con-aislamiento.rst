.. meta::
   :artefacto: FR-ORD-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-02.02: Recuperar detalle de orden verificando propiedad del usuario
==========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-02.02
   * - **Nombre**
     - Recuperar el detalle completo de la orden validando que pertenece al usuario autenticado
   * - **UC Origen**
     - UC-ORD-02: Ver Detalle de Orden
   * - **Paso UC**
     - Pasos 2, 3 y 4 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la orden pertenece al usuario
   autenticado y retornar su detalle completo CUANDO el usuario
   accede a la ficha de una orden.

**Descripcion:**

La verificación de propiedad usa UC-INC-01. El sistema recupera el
registro ``Order`` por ``order_number`` y ``user`` simultáneamente.
Si no existe ningún registro que cumpla ambas condiciones, el sistema
retorna HTTP 404 — nunca HTTP 403 — para no revelar la existencia de
la orden a usuarios no autorizados (RNF-SEC-003). La consulta carga
de forma anticipada ``OrderValue``, ``OrderAddress`` y todos los
``OrderItem`` asociados para evitar el problema N+1.

La respuesta incluye el estado de la guia de envio si LOGISTICS
ya la creo (PARTE 7 del UC), y el estado del reembolso si hay
una devolucion en proceso.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Detalle de orden propia retornado correctamente
   DADO usuario autenticado que accede a su propia orden ORD-20260503-00042
   CUANDO GET /api/v1/orders/ORD-20260503-00042/
   ENTONCES HTTP 200 con el detalle completo: items, precios snapshot,
   direccion snapshot, estado actual, guia de envio si existe

   Escenario 2: Intentar ver orden de otro usuario — 404
   DADO usuario A que intenta acceder a la orden de usuario B
   CUANDO GET /api/v1/orders/ORD-de-usuario-B/
   ENTONCES HTTP 404 (no 403 — no revela que la orden existe)
   Y el usuario A no sabe si esa orden existe o no

   Escenario 3: Precio snapshot no cambia aunque el producto cambie
   DADO orden con OrderItem.unit_price=850 (snapshot)
   Y el producto fue editado y ahora tiene base_price=950
   CUANDO se retorna el detalle de la orden
   ENTONCES OrderItem.unit_price = 850 (el snapshot inmutable)
   Y el total de la orden sigue siendo el mismo que al momento del checkout

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-005 (los snapshots son inmutables)
- **RNF aplicables:** RNF-SEC-003 (aislamiento — 404 en lugar de
  403 para no revelar la existencia de ordenes de otros usuarios)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-02: Ver Detalle de Orden
   * - **Incluye**
     - UC-INC-01 (verificar propiedad)
   * - **Test**
     - TST-FR-ORD-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-4 de UC-ORD-02

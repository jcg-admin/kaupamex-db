.. meta::
   :artefacto: FR-PAY-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-04-01:

FR-PAY-04.01: Verificar firma y procesar evento PayPal
======================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-04.01
   * - **Nombre**
     - Verificar firma y procesar evento PayPal
   * - **UC Origen**
     - UC-PAY-04: Webhook PayPal
   * - **Paso UC**
     - Pasos 2-5
   * - **Modulo**
     - MOD-007 PAYMENT + SDK PayPal
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - Integracion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la autenticidad del webhook de PayPal y actualizar el estado del pago CUANDO PayPal notifica un evento.

**Descripcion:**

PayPal firma sus webhooks con certificados SSL. La verificacion usa la SDK oficial:

1. Llama a ``paypalrestsdk.WebhookEvent.verify(...)`` con los headers y el body raw
2. Si la verificacion falla: retorna 401
3. Filtra solo los eventos relevantes: ``PAYMENT.CAPTURE.COMPLETED``, ``PAYMENT.CAPTURE.DENIED``
4. Extrae el ``order_id`` de PayPal desde el payload
5. Proceso identico al de MP (FR-PAY-03.02): idempotencia por ``gateway_payment_id``

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Pago PayPal completado
   DADO evento PAYMENT.CAPTURE.COMPLETED valido
   CUANDO se procesa
   ENTONCES Payment.status = APPROVED
   Y Order.status = PAYMENT_CONFIRMED

   Escenario: Evento no relevante ignorado
   DADO evento de tipo CHECKOUT.ORDER.CREATED
   CUANDO llega el webhook
   ENTONCES respuesta 200 sin procesar nada
   Y no se modifica ningun registro


----

4. Reglas y Restricciones
--------------------------

- **BR-007 (PayPal es gateway secundario)**

- :ref:`RNF-AVAIL-002 (idempotencia)`
- :ref:`RNF-SEC-005 (firma)`
- **Notas:** PayPal puede enviar el mismo evento varias veces. La idempotencia por gateway_payment_id protege contra duplicados.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-04: Webhook PayPal
   * - **Depende de**
     - Llamada entrante de PayPal
   * - **Requerido por**
     - FR-NOT-01.01 (email de confirmacion)
   * - **Test**
     - TST-FR-PAY-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-04

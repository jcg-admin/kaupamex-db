.. meta::
   :artefacto: FR-CART-04.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-04-03:

=======================================================================
FR-CART-04.03: Validar existencia, vigencia, usos y condiciones del cupon
=======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-04.03
   * - **Nombre**
     - Ejecutar las 4 verificaciones del cupon antes de calcular el beneficio
   * - **UC Origen**
     - UC-CART-04: Aplicar Cupon de Descuento
   * - **Paso UC**
     - Pasos 5, 6, 7 y 8 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar la existencia, vigencia, disponibilidad
   de usos y condiciones del cupon sobre el carrito CUANDO el
   visitante solicita aplicar un codigo.

**Descripcion:**

Las validaciones se ejecutan en orden. La primera que falle
retorna el error correspondiente sin continuar:

1. **Existencia:** el sistema busca un ``Voucher`` con el código
   recibido (insensible a mayúsculas) y ``Voucher.is_active = True``.
   Si no existe → ``CUPON_INVALIDO``.

2. **Vigencia:** si ``Voucher.valid_from`` es posterior al momento
   actual → ``CUPON_NO_VIGENTE``. Si ``Voucher.valid_until`` está
   definido y es anterior al momento actual → ``CUPON_EXPIRADO``.

3. **Usos disponibles:** si ``Voucher.max_uses`` está definido y
   ``Voucher.current_uses ≥ Voucher.max_uses`` → ``CUPON_AGOTADO``.

4. **Condiciones del carrito:** si ``Voucher.min_order_amount`` está
   definido y el subtotal del carrito es inferior a ese valor →
   ``MONTO_MINIMO_NO_CUMPLIDO``. Si ``Voucher.restricted_categories``
   no está vacío y ningún item del carrito pertenece a alguna de esas
   categorías → ``CATEGORIA_NO_APLICA``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Todas las validaciones pasan
   DADO cupon activo, vigente, con usos disponibles y carrito que cumple
   CUANDO se valida
   ENTONCES la validacion pasa y el proceso continua al calculo (FR-CART-04.01)

   Escenario 2: Codigo inexistente — error especifico
   DADO codigo "DESCUENTO123" que no existe en la BD
   CUANDO se valida
   ENTONCES HTTP 400 con {"codigo_error": "CUPON_INVALIDO",
   "mensaje": "El codigo no es valido."}

   Escenario 3: Monto minimo no cumplido — mensaje orientado a la accion
   DADO cupon con min_order_amount=500 y carrito con subtotal=300
   CUANDO se valida la condicion
   ENTONCES HTTP 400 con {"codigo_error": "MONTO_MINIMO_NO_CUMPLIDO",
   "mensaje": "Este cupon requiere un minimo de $500.00 en tu carrito.",
   "faltante": 200.00}

   Escenario 4: EX-02 — Race condition (cupon se agota entre verificacion y uso)
   DADO cupon con 1 uso disponible que es reclamado por dos sesiones simultaneas
   CUANDO ambas pasan la verificacion de usos al mismo tiempo
   ENTONCES la BD usa select_for_update() al incrementar current_uses
   Y solo una sesion recibe el descuento; la otra recibe CUPON_AGOTADO

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-008 (Voucher con Strategy Pattern — tipos
  polimorficos: porcentaje, monto fijo, envio gratis)
- **RNF aplicables:** RNF-SEC-004 (rate limiting de intentos de cupon
  para prevenir fuerza bruta de codigos)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-04: Aplicar Cupon
   * - **Depende de**
     - FR-CART-04.02 (formato del codigo validado)
   * - **Requerido por**
     - FR-CART-04.01 (calcular y aplicar el beneficio)
   * - **Test**
     - TST-FR-CART-04.03 (pendiente — incluir test de race condition
       con select_for_update)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 5-8 de UC-CART-04

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-new-03-gestionar-suscriptores
===========================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-new-03-02-listar-y-exportar-suscriptores
   fr-new-03-gestionar-suscriptores-01

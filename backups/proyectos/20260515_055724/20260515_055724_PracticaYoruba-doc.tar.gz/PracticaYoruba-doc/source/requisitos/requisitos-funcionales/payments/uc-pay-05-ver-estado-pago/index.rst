.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-05-ver-estado-pago
====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-05-01-consultar-estado-pago
   fr-pay-05-02-recuperar-estado-pago-con-aislamiento

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-03-webhook-mercadopago
========================================

**3 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-03-01-verificar-firma-mp
   fr-pay-03-02-procesar-estado-pago
   fr-pay-03-03-verificar-firma-y-procesar-pago

.. meta::
   :artefacto: FR-INV-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/inventario
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-INV-03.02: Restaurar stock de forma idempotente al cancelar una orden
========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-INV-03.02
   * - **Nombre**
     - Restaurar el stock decrementado verificando que no fue ya restaurado para esa orden
   * - **UC Origen**
     - UC-INV-03: Restaurar Stock
   * - **Paso UC**
     - Pasos 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-009 INVENTORY
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que el stock no fue ya restaurado para
   esta orden y restaurarlo de forma idempotente CUANDO una orden es
   cancelada.

**Descripcion:**

La idempotencia se garantiza verificando si ya existe un
``StockMovement`` de tipo ``'CANCELLATION'`` con la referencia de
la orden. En una transacción atómica: si ya existe ese registro,
la operación concluye sin cambios. En caso contrario, para cada
``OrderItem`` incrementa el ``ProductVariant.stock`` en la cantidad
del item y crea un ``StockMovement`` con tipo ``'CANCELLATION'``,
cantidad positiva y ``reference = Order.order_number``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Restauracion exitosa — idempotente
   DADO orden cancelada con 2 items (A: qty=2, B: qty=1)
   CUANDO se restaura el stock
   ENTONCES ProductSize.stock de A += 2 y de B += 1
   Y StockMovement CANCELLATION creado por cada item

   Escenario 2: Restauracion duplicada — ignorada
   DADO orden que ya fue cancelada y el stock restaurado
   CUANDO el sistema intenta restaurar de nuevo (por idempotencia de webhook)
   ENTONCES detecto StockMovement CANCELLATION existente
   Y NO incrementa el stock de nuevo
   Y retorna sin error

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-002 (idempotencia obligatoria)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-INV-03: Restaurar Stock
   * - **Depende de**
     - FR-ORD-04.03 o FR-ORD-08.02 (orden cancelada)
   * - **Test**
     - TST-FR-INV-03.02 (pendiente — test de doble cancelacion)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-5 de UC-INV-03
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

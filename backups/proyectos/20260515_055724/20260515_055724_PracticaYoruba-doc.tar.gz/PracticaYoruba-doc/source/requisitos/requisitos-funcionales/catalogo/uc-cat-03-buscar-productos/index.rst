.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-03-buscar-productos
=====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-03-01-busqueda-por-texto
   fr-cat-03-02-normalizar-y-buscar

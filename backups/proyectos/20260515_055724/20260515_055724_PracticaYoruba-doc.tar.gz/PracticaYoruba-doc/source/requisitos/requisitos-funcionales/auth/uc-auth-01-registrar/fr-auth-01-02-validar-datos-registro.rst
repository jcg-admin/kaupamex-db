.. meta::
   :artefacto: FR-AUTH-01.02
   :tipo: Requisito Funcional
   :dominio: requisitos
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-auth-01-02:

=============================================
FR-AUTH-01.02: Validar datos del formulario
=============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-01.02
   * - **Nombre**
     - Validar formato y reglas de los datos ingresados
   * - **UC Origen**
     - UC-AUTH-01: Registrar cuenta
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato y las reglas de negocio de cada
   campo CUANDO el visitante envia el formulario de registro.

**Descripcion:**

Validaciones por campo:

- **username**: solo caracteres permitidos por Django
  (``[\w.@+-]``), longitud 3-150. Sin espacios al inicio/fin.
- **email**: formato RFC 5322 valido. Se normaliza a minusculas.
- **password**: minimo 8 caracteres. No puede ser identica al username
  ni ser una contrasena en la lista de contrasenas comunes de Django.
- **password_confirm**: debe ser identica al campo ``password``.

Cualquier error de validacion devuelve la lista de errores por campo.
No se revela si el username/email ya existe en este paso.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO el formulario de registro con datos ingresados
   CUANDO el visitante hace submit
   ENTONCES el sistema valida todos los campos antes de procesar

   Escenario 1: Contrasenas no coinciden
   DADO password = "Segura123" y password_confirm = "Segura124"
   CUANDO se valida
   ENTONCES se muestra error "Las contrasenas no coinciden"
   Y el campo password_confirm queda en rojo
   Y no se procesa el registro

   Escenario 2: Contrasena demasiado corta
   DADO password = "abc12"
   CUANDO se valida
   ENTONCES se muestra error "La contrasena debe tener al menos 8 caracteres"

   Escenario 3: Username con caracteres invalidos
   DADO username = "juan perez" (con espacio)
   CUANDO se valida
   ENTONCES se muestra error "El nombre de usuario contiene caracteres no permitidos"

   Escenario 4: Email invalido
   DADO email = "no-es-un-email"
   CUANDO se valida
   ENTONCES se muestra error "Ingresa una direccion de email valida"

   Escenario 5: Todos los campos validos
   DADO username, email, password y confirm correctos
   CUANDO se valida
   ENTONCES no hay errores de formato
   Y el proceso continua a FR-AUTH-01.03

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica en este paso
- **Notas:** Las validaciones de unicidad (username/email ya existe)
  se realizan en FR-AUTH-01.03, no aqui. Esta separacion previene
  la enumeracion de usuarios registrados.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-01: Registrar cuenta
   * - **Depende de**
     - FR-AUTH-01.01 (formulario presentado)
   * - **Requerido por**
     - FR-AUTH-01.03 (verificar unicidad)
   * - **Test**
     - TST-FR-AUTH-01.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-01

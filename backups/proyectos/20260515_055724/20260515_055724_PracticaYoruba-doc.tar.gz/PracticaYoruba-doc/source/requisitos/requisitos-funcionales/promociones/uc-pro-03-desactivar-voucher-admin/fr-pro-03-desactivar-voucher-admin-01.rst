.. meta::
   :artefacto: FR-PRO-03.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/promociones
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pro-03-01:

FR-PRO-03.01: Desactivar voucher y limpiar carritos afectados
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PRO-03.01
   * - **Nombre**
     - Desactivar voucher y limpiar carritos afectados
   * - **UC Origen**
     - UC-PRO 03 DESACTIVAR VOUCHER ADMIN
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE desactivar el voucher y notificar a los carritos que lo tienen CUANDO el admin lo desactiva.

**Descripcion:**

``Voucher.is_active = False``

Los carritos que tienen este voucher aplicado (``Cart.voucher=voucher``) detectan la desactivacion
al cargar el carrito (FR-CART-02.02) — no se eliminan proactivamente.
El comprador ve un mensaje de cupon no valido al abrir su carrito.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Desactivacion exitosa
   DADO voucher activo
   CUANDO el admin lo desactiva
   ENTONCES Voucher.is_active=False inmediatamente

   Escenario: Comprador con el voucher en su carrito
   DADO comprador con el voucher aplicado en su carrito activo
   CUANDO carga el carrito tras la desactivacion
   ENTONCES ve mensaje 'El cupon PROMO10 ya no es valido'
   Y el descuento se elimina del total


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-PROC-002`
- **Notas:** La limpieza de carritos es lazy — ocurre cuando el carrito se carga, no en el momento de desactivar.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PRO 03 DESACTIVAR VOUCHER ADMIN
   * - **Depende de**
     - FR-PRO-01.01 o FR-PRO-02.01 (voucher activo)
   * - **Requerido por**
     - FR-CART-02.02 (totales sin el descuento)
   * - **Test**
     - TST-FR-PRO-03.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PRO 03 DESACTIVAR VOUCHER ADMIN

.. meta::
   :artefacto: FR-NEW-04.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-new-04-02:

================================================================================
FR-NEW-04.02: Registrar la campaña y encolar el envío masivo de forma asíncrona
================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-04.02
   * - **Nombre**
     - Registrar la campaña con su segmento, encolar el envío asíncrono
       al Procesador Periódico y retornar inmediatamente al admin
   * - **UC Origen**
     - UC-NEW-04: Enviar Campaña de Newsletter
   * - **Paso UC**
     - Pasos 8 y 9 del flujo principal
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos + Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE registrar la campaña con el segmento de
   destinatarios y el estado ``QUEUED``, delegar el envío real
   al Procesador Periódico y retornar al admin de forma inmediata
   con un identificador de campaña para seguimiento del progreso,
   CUANDO el admin confirma el envío en el paso 7 del flujo.

**Descripcion:**

El envío masivo nunca bloquea al admin. La operación que realiza
el sistema al confirmar se limita a registrar la intención y
ceder el control: el trabajo real de enviar a cada suscriptor
lo hace el Procesador Periódico en segundo plano.

Al confirmar el envío, el sistema verifica primero que el segmento
tenga al menos un suscriptor activo. Si el segmento está vacío
(EX-01), informa al admin antes de crear ningún registro.

Si el segmento tiene suscriptores, el sistema registra la campaña
con todos sus datos —asunto, contenido HTML, contenido en texto
plano, segmento elegido y número de destinatarios al momento del
encole— y le asigna el estado ``QUEUED``. A continuación retorna
con código 202 y el identificador de la campaña para que el admin
pueda consultar el progreso.

El Procesador Periódico toma las campañas en estado ``QUEUED`` o
``IN_PROGRESS`` y procesa los envíos respetando los límites por
minuto que impone el Servicio de Email Externo. Procesa los
destinatarios en lotes y actualiza el contador de enviados tras
cada lote para que el progreso sea visible en tiempo casi real.
Si un email individual falla, el Procesador lo marca como fallido
y continúa con el siguiente sin detener la campaña completa
(EX-02).

**Envío programado (Alt. A y C):**

Si el admin seleccionó una fecha futura, la campaña se registra
con estado ``SCHEDULED`` en lugar de ``QUEUED`` y con la fecha
configurada. El Actor Tiempo la detecta cuando llega el momento y
la transiciona a ``QUEUED`` para que el Procesador la tome. El admin
puede cancelar o modificar una campaña ``SCHEDULED`` en cualquier
momento antes de que el Actor Tiempo la active.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Campaña encolada — admin recibe respuesta inmediata
   DADO campaña lista con 1200 suscriptores activos en el segmento
   CUANDO el admin confirma el envío
   ENTONCES HTTP 202 con {"campaign_id": 47, "status": "QUEUED",
   "recipients": 1200}
   Y el admin puede seguir trabajando sin esperar al envío

   Escenario 2: Admin consulta el progreso de la campaña
   DADO campaña id=47 con 600 emails ya enviados de 1200
   CUANDO el admin consulta GET /api/v1/admin/newsletter/campaigns/47/
   ENTONCES la respuesta muestra sent_count=600, pending_count=600,
   failed_count=0 y status=IN_PROGRESS

   Escenario 3: Segmento vacío — error antes de crear la campaña
   DADO admin que selecciona un segmento sin suscriptores activos
   CUANDO confirma el envío
   ENTONCES HTTP 400 con {"codigo_error": "SEGMENTO_VACIO",
   "mensaje": "No hay suscriptores activos en el segmento seleccionado."}
   Y no se crea ningún registro de campaña

   Escenario 4: Campaña programada para el día siguiente
   DADO admin que configura el envío para el 2026-05-05 a las 09:00
   CUANDO confirma la programación
   ENTONCES HTTP 202 con status=SCHEDULED y scheduled_at=2026-05-05T09:00Z
   Y la campaña permanece en SCHEDULED hasta que el Actor Tiempo la active
   Y el admin puede cancelarla antes de esa fecha

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 2s para el registro y
  el encole — el tiempo real de envío no cuenta porque es asíncrono),
  RNF-AVAIL-003 (el Procesador Periódico respeta los límites del
  Servicio de Email Externo para no saturar la cuenta de envío)
- **Notas:** El número de destinatarios se fija en el momento del
  encole. Si se suscriben nuevos usuarios después de confirmar la
  campaña, no se añaden a esa campaña — recibirán la siguiente.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW-04: Enviar Campaña de Newsletter
   * - **Depende de**
     - FR-NEW-03.02 (la lista de suscriptores ACTIVE sobre la que
       se calcula el segmento)
   * - **Incluye**
     - UC-INC-03 (cada email individual se encola via este include)
   * - **Relacionado con**
     - FR-SYS-04.02 (los emails fallidos individuales se reintentarán
       con backoff exponencial)
   * - **Test**
     - TST-FR-NEW-04.02 (pendiente — verificar que HTTP 202 llega
       antes de que se procese ningún email; verificar que un fallo
       individual no detiene el resto de la campaña)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: envío asíncrono explicado en prosa,
       campaña programada (SCHEDULED), EX-01 y EX-02 documentados,
       4 escenarios BDD con datos concretos, trazabilidad completa

.. meta::
   :artefacto: FR-AUTH-02.22
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-02-22:

========================================================
FR-AUTH-02.22: NFR Seguridad — Requisitos del endpoint de login
========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-02.22
   * - **Nombre**
     - Restricciones de seguridad especificas del proceso de autenticacion
   * - **UC Origen**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Paso UC**
     - Seccion 6.2 — Requisitos No Funcionales de Seguridad
   * - **Modulo**
     - MOD-001 ACCOUNTS + Apache + Django settings
   * - **Prioridad**
     - Critica
   * - **Tipo**
     - NFR Tecnico — Seguridad

----

2. Especificacion
-----------------

**Declaracion:**

   La implementacion del login DEBE cumplir todos los requisitos
   de seguridad definidos en la seccion 6.2 del UC-AUTH-02 sin
   excepcion.

**Descripcion:**

Requisitos de seguridad del login con su implementacion:

.. list-table::
   :widths: 35 65
   :header-rows: 1

   * - Requisito
     - Implementacion
   * - Contraseñas NUNCA en texto plano
     - Django usa el algoritmo seguro de hash. ``User.password`` siempre tiene
       el formato ``<algoritmo>$<iteraciones>$<sal>$<hash>``
   * - Comparacion en tiempo constante
     - ``user.check_password(raw)`` usa ``comparacion_en_tiempo_constante``
       internamente para prevenir timing attacks
   * - Mensajes de error genericos
     - "Identificador o contraseña incorrectos" — sin distinguir
       cual de los dos fallo (previene enumeracion)
   * - Canal cifrado obligatorio
     - FR-AUTH-02.18 — Apache redirige HTTP → HTTPS, HSTS activado
   * - Control de intentos por IP y por cuenta
     - FR-AUTH-02.01 — DatabaseCache con TTL, BR-015
   * - Credenciales de sesion con vida limitada
     - Access: 15 min, Refresh: 7 dias, rotacion en cada uso
   * - Auditoria de TODOS los intentos
     - FR-AUTH-02.13 — AccessAuditLog con IP, user_agent y resultado
   * - Contraseñas y tokens NUNCA en logs
     - ``settings.py`` con ``LOGGING`` que filtra campos sensibles

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Contraseña nunca en texto plano en BD
   DADO usuario registrado con contraseña "MiPass123!"
   CUANDO se inspecciona User.password en MySQL
   ENTONCES el valor empieza con "pbkdf2_sha256$"
   Y no contiene "MiPass123!" en ninguna forma

   Escenario 2: Logs no contienen contraseñas
   DADO login fallido con contraseña "MiPass123!"
   CUANDO se revisan todos los archivos de log del servidor
   ENTONCES "MiPass123!" no aparece en ningun log
   Y el access token tampoco aparece en los logs

   Escenario 3: Timing attack no distingue user vs password
   DADO 1000 intentos con user inexistente y 1000 con password incorrecta
   CUANDO se miden los tiempos de respuesta de ambos grupos
   ENTONCES la diferencia estadistica de tiempos entre ambos grupos
   es menor a 20ms (no permite distinguirlos estadisticamente)

   Escenario 4: Token de sesion invalido tras cambio de contraseña
   DADO access token emitido antes de un cambio de contraseña
   CUANDO se usa ese access token (aun vigente por menos de 15 min)
   ENTONCES el sistema lo acepta (access tokens son stateless — no
   se pueden revocar antes de su exp — limitacion conocida de JWT)
   Y el refresh token si queda invalido tras FR-AUTH-08.02

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-015 (rate limiting — es un requisito de
  seguridad de negocio)
- **RNF del sistema:** RNF-SEC-001 (JWT), RNF-SEC-003 (aislamiento),
  RNF-SEC-004 (rate limiting), RNF-SEC-006 (HTTPS)
- **Notas:** La limitacion de los access tokens stateless (no
  revocables antes de exp) es un trade-off conocido de JWT.
  El tiempo de vida de 15 minutos minimiza la ventana de riesgo.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-02: Iniciar Sesion (Login)
   * - **Seccion UC**
     - 6.2 Seguridad
   * - **RNF del sistema**
     - RNF-SEC-001, RNF-SEC-003, RNF-SEC-004, RNF-SEC-006
   * - **ADR relacionado**
     - ADR-003 (JWT con el Servicio de Autenticacion)
   * - **Test**
     - TST-FR-AUTH-02.22 (pendiente — penetration testing basico)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de la seccion 6.2 de UC-AUTH-02

.. meta::
   :artefacto: FR-CART-05.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/cart
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-cart-05-03:

==========================================================
FR-CART-05.03: Confirmar guardado, excepciones y NFR del carrito guardado
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CART-05.03
   * - **Nombre**
     - Confirmar al usuario el guardado exitoso y cumplir las restricciones tecnicas
   * - **UC Origen**
     - UC-CART-05: Guardar Carrito para Despues
   * - **Paso UC**
     - Pasos 4 y 5 del flujo principal + PARTE 5 + PARTE 6
   * - **Modulo**
     - MOD-005 CART (apps.cart — SavedCart)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Presentacion + NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE confirmar al usuario que el carrito fue guardado
   con el numero de items, manejar los fallos del repositorio de forma
   controlada y cumplir los requisitos de calidad.

**Descripcion:**

**Pasos 4 y 5 — Confirmacion:**

.. code-block:: json

   HTTP 200
   {
     "mensaje": "Tu carrito fue guardado exitosamente.",
     "items_guardados": 3,
     "guardado_en": "2026-05-03T15:30:00Z",
     "info": "Podras recuperar tu carrito desde tu cuenta en cualquier momento."
   }

**EX-01 y EX-02 — Fallos del repositorio:**

Si el ``SavedCart.objects.create()`` o ``.save()`` falla:

- HTTP 500 con mensaje generico
- El carrito de sesion NO se ve afectado
- El usuario puede reintentar el guardado

**Performance (6.1):** P95 <= 400ms — una operacion de INSERT
o UPDATE sobre ``SavedCart`` mas N inserts en ``SavedCartItem``
dentro de una transaccion atomica.

**Seguridad (6.2):**

- El endpoint requiere autenticacion (IsAuthenticated en DRF)
- El SavedCart siempre se filtra por ``user=request.user`` — un usuario
  no puede leer ni sobreescribir el carrito guardado de otro

**Confiabilidad (6.3):**

- El carrito de sesion activo NO se modifica durante el guardado
- El usuario puede seguir comprando con el carrito actual incluso si
  el guardado falla

**Usabilidad (6.4):**

- El boton "Guardar para despues" es visualmente diferente al de "Checkout"
- La confirmacion muestra el numero de items guardados para que el
  usuario sepa que se guardo correctamente
- El usuario puede acceder al carrito guardado desde su perfil

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Confirmacion con numero de items
   DADO carrito guardado exitosamente con 3 items
   CUANDO se retorna la confirmacion
   ENTONCES HTTP 200 con items_guardados = 3
   Y el campo guardado_en tiene el timestamp actual

   Escenario 2: Error al guardar — carrito de sesion intacto
   DADO OperationalError al persistir el SavedCart
   CUANDO falla el guardado
   ENTONCES HTTP 500 con mensaje generico
   Y el carrito de sesion tiene exactamente los mismos items que antes
   Y el usuario puede reintentar el guardado

   Escenario 3: Usuario no autenticado intentando guardar
   DADO visitante anonimo que hace POST /api/v1/cart/save/
   CUANDO el middleware verifica la autenticacion
   ENTONCES HTTP 401 con AUTENTICACION_REQUERIDA
   Y el carrito de sesion se mantiene intacto para cuando inicie sesion

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-001 (P95 <= 400ms), RNF-SEC-003

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CART-05: Guardar Carrito para Despues
   * - **Depende de**
     - FR-CART-05.02 (carrito persistido en BD)
   * - **Requerido por**
     - FR-CART-06.01 (el carrito guardado se recupera en UC-CART-06)
   * - **Test**
     - TST-FR-CART-05.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-5 + PARTE 5 y 6 de UC-CART-05

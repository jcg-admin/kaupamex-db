.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pro-03-desactivar-voucher-admin
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pro-03-02-desactivar-y-auditar
   fr-pro-03-desactivar-voucher-admin-01

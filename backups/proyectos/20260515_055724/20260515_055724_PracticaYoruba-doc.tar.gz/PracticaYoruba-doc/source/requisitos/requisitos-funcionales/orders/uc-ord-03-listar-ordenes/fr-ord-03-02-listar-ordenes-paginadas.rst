.. meta::
   :artefacto: FR-ORD-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-03.02: Listar ordenes del usuario paginadas ordenadas por fecha
======================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-03.02
   * - **Nombre**
     - Recuperar y paginar las ordenes del usuario autenticado ordenadas por fecha descendente
   * - **UC Origen**
     - UC-ORD-03: Listar Ordenes
   * - **Paso UC**
     - Pasos 2 y 3 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar las ordenes del usuario autenticado
   paginadas y ordenadas por fecha de creacion descendente CUANDO
   el usuario accede a su historial de compras.

**Descripcion:**

El sistema recupera todas las ``Order`` del usuario autenticado
ordenadas por ``-Order.created_at``, con carga anticipada de
``OrderValue`` para evitar N+1. Los resultados se paginan a 10
órdenes por página (RNF-PERF-003).

Cada item del listado incluye un resumen (no el detalle completo):

.. code-block:: json

   {
     "order_number": "ORD-20260503-00042",
     "status": "SHIPPED",
     "status_display": "En camino",
     "created_at": "2026-05-03T14:30:00Z",
     "total": 1824.80,
     "items_count": 2,
     "thumbnail": "https://cdn.ojayoruba.com/products/42.jpg"
   }

El campo ``thumbnail`` usa la imagen del primer OrderItem de la orden
para que el usuario reconozca visualmente la compra.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Historial con ordenes
   DADO usuario con 7 ordenes en diferentes estados
   CUANDO GET /api/v1/orders/?page=1
   ENTONCES HTTP 200 con 7 ordenes ordenadas de mas reciente a mas antigua
   Y cada orden muestra su numero, estado, fecha y total

   Escenario 2: Sin ordenes — lista vacia
   DADO usuario sin ordenes previas
   CUANDO accede al historial
   ENTONCES HTTP 200 con items=[] y sugerencia de ir al catalogo

   Escenario 3: Paginacion correcta
   DADO usuario con 25 ordenes y page_size=10
   CUANDO accede a la pagina 1
   ENTONCES retorna las 10 mas recientes
   Y la respuesta incluye total_pages=3, total_orders=25

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-003 (paginacion de max 10 ordenes
  por pagina en el historial del usuario)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-03: Listar Ordenes
   * - **Requerido por**
     - FR-ORD-02.02 (el usuario hace clic en una orden del listado)
   * - **Test**
     - TST-FR-ORD-03.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-3 de UC-ORD-03

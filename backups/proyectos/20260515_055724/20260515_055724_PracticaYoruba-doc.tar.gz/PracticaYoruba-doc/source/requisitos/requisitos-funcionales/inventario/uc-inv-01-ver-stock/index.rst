.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inv-01-ver-stock
==============================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inv-01-02-mostrar-dashboard-stock
   fr-inv-01-ver-stock-01

.. meta::
   :artefacto: FR-CAT-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cat-04-01:

FR-CAT-04.01: Filtrar catalogo por categoria y subcategorias
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-04.01
   * - **Nombre**
     - Filtrar catalogo por categoria y subcategorias
   * - **UC Origen**
     - UC-CAT 04 FILTRAR POR CATEGORIA
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar los productos de la categoria y sus subcategorias CUANDO se aplica el filtro.

**Descripcion:**

La categoria seleccionada incluye sus descendientes en la jerarquia.
``Product.objects.filter(category__in=get_descendants(category_id), is_active=True)``
El resultado incluye el desglose de cuantos productos hay por subcategoria.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Categoria con subcategorias
   DADO categoria 'Orisha' con subcategorias 'Oshun' y 'Chango'
   CUANDO se filtra por 'Orisha'
   ENTONCES aparecen productos de Oshun y de Chango
   Y el desglose muestra 12 de Oshun y 8 de Chango

   Escenario: URL compartible con filtro activo
   DADO filtro de categoria activo
   CUANDO el visitante copia la URL
   ENTONCES la URL contiene el slug de la categoria
   Y compartirla muestra el mismo filtro a otro visitante


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** El algoritmo de descendientes usa MPTT o closure table para eficiencia.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT 04 FILTRAR POR CATEGORIA
   * - **Depende de**
     - Ninguno — filtro de entrada
   * - **Requerido por**
     - FR-CAT-02.01
   * - **Test**
     - TST-FR-CAT-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CAT 04 FILTRAR POR CATEGORIA

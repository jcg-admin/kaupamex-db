.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-inv-03-restaurar-stock
====================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-inv-03-02-restaurar-idempotente
   fr-inv-03-restaurar-stock-01

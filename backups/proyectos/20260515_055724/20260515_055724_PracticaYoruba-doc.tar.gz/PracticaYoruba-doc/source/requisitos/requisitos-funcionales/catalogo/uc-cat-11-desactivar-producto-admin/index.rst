.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-cat-11-desactivar-producto-admin
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-cat-11-02-desactivar-y-purgar-cache
   fr-cat-11-desactivar-producto-admin-01-desactivar-producto-con-soft-d

.. meta::
   :artefacto: FR-SYS-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/sistema
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-SYS-02.02: Desactivar automaticamente los vouchers con valid_until vencido
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-SYS-02.02
   * - **Nombre**
     - El Procesador Periodico desactiva los vouchers cuya fecha de vigencia expiro
   * - **UC Origen**
     - UC-SYS-02: Desactivar Vouchers Expirados (Actor: Tiempo)
   * - **Paso UC**
     - Pasos 2, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-004 VOUCHER
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Proceso

----

2. Especificacion
-----------------

**Declaracion:**

   El Procesador Periodico DEBE desactivar todos los vouchers activos
   cuya fecha de vencimiento ya paso y registrar cada desactivacion
   en auditoria CUANDO el proceso periodico se ejecuta.

**Descripcion:**

El proceso puede ejecutarse diariamente via cron a las 00:05 UTC.

El sistema filtra todos los ``Voucher`` con ``is_active = True`` y
``valid_until`` anterior al momento actual. Para cada uno establece
``Voucher.is_active = False`` y crea un ``VoucherChangeLog``
indicando que el cambio fue automático (sin usuario responsable) y
el motivo ``'VENCIMIENTO_AUTOMATICO'``.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Vouchers vencidos desactivados
   DADO 3 vouchers activos con valid_until en el pasado
   CUANDO el proceso se ejecuta
   ENTONCES los 3 quedan con is_active=False
   Y VoucherChangeLog creado por cada uno con razon VENCIMIENTO_AUTOMATICO

   Escenario 2: Sin vouchers expirados — proceso sin accion
   DADO todos los vouchers activos con vigencia futura
   CUANDO el proceso se ejecuta
   ENTONCES count=0 sin modificaciones

   Escenario 3: Idempotencia — segunda ejecucion no duplica logs
   DADO voucher ya desactivado en ejecucion anterior
   CUANDO el proceso se ejecuta de nuevo
   ENTONCES el filtro is_active=True no lo incluye
   Y no se crea un segundo VoucherChangeLog

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-AVAIL-002 (idempotente por construccion:
  el filtro ``is_active=True`` excluye vouchers ya desactivados)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-SYS-02: Desactivar Vouchers Expirados
   * - **Relacionado con**
     - FR-PRO-03.02 (desactivacion manual — mismo efecto en is_active)
   * - **Test**
     - TST-FR-SYS-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2, 4 y 5 de UC-SYS-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

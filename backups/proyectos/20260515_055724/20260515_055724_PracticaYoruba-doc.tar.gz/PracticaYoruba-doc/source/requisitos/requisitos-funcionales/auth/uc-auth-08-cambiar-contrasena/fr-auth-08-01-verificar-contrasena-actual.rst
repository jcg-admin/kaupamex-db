.. meta::
   :artefacto: FR-AUTH-08.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-08.01: Verificar contrasena actual
===========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.01
   * - **Nombre**
     - Verificar que la contrasena actual ingresada es correcta
   * - **UC Origen**
     - UC-AUTH-08: Cambiar contrasena
   * - **Paso UC**
     - Paso 2 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE verificar que la contrasena actual ingresada
   coincide con la almacenada CUANDO el comprador solicita cambiarla.

**Descripcion:**

Verificacion con ``user.check_password(current_password)``.
Si no coincide se retorna error sin procesar el cambio.
Este paso previene que alguien con la sesion abierta de otro usuario
pueda cambiarle la contrasena sin conocer la actual.

----

3. Criterio de Aceptacion
--------------------------

::

   DADO comprador autenticado con sesion activa
   CUANDO envia formulario de cambio de contrasena
   ENTONCES primero se verifica la contrasena actual

   Escenario 1: Contrasena actual incorrecta
   DADO current_password incorrecto
   CUANDO se verifica
   ENTONCES error 400: "La contrasena actual es incorrecta"
   Y no se realiza ningun cambio

   Escenario 2: Contrasena actual correcta
   DADO current_password correcto
   CUANDO se verifica
   ENTONCES proceso continua a FR-AUTH-08.02

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** No se aplica rate limiting aqui porque el usuario ya esta autenticado.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar contrasena
   * - **Depende de**
     - FR-AUTH-02.03 (sesion activa)
   * - **Requerido por**
     - FR-AUTH-08.02 (actualizar contrasena)
   * - **Test**
     - TST-FR-AUTH-08.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-08

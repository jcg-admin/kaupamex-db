.. meta::
   :artefacto: FR-AUTH-08.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

FR-AUTH-08.02: Actualizar la contrasena
========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-08.02
   * - **Nombre**
     - Hashear y persistir la nueva contrasena, invalidar otras sesiones
   * - **UC Origen**
     - UC-AUTH-08: Cambiar contrasena
   * - **Paso UC**
     - Pasos 3-5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE hashear la nueva contrasena, guardarla e invalidar
   todos los refresh tokens activos de otros dispositivos CUANDO la
   contrasena actual fue verificada correctamente.

**Descripcion:**

Proceso de actualizacion:

1. Valida que new_password cumpla las reglas de Django
   (min 8 chars, no identica a username, no en lista comun)
2. Valida que new_password != current_password
3. ``user.set_password(new_password)`` — hashea con el algoritmo seguro de hash
4. ``user.save(update_fields=['password'])``
5. Invalida todos los refresh tokens del usuario en la blacklist
   (excepto el del dispositivo actual)
6. Encola email de notificacion de cambio de contrasena (UC-INC-03)

----

3. Criterio de Aceptacion
--------------------------

::

   DADO contrasena actual correcta y nueva contrasena valida
   CUANDO se actualiza
   ENTONCES la nueva contrasena queda activa

   Escenario 1: Nueva igual a la actual
   DADO new_password identica a current_password
   CUANDO se valida
   ENTONCES error 422: "La nueva contrasena debe ser diferente a la actual"

   Escenario 2: Invalidacion de otras sesiones
   DADO usuario con sesion en 3 dispositivos
   CUANDO cambia la contrasena desde dispositivo A
   ENTONCES los refresh tokens de dispositivos B y C quedan en blacklist
   Y el refresh token de A sigue valido

   Escenario 3: Email de notificacion
   DADO cambio de contrasena exitoso
   CUANDO se completa
   ENTONCES el comprador recibe email notificando el cambio
   Y el email incluye instrucciones para reportar si no fue el

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** La invalidacion de otras sesiones es una medida de seguridad.
  Si el cambio fue por compromiso de cuenta, otros dispositivos
  quedan desconectados de forma automatica.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-08: Cambiar contrasena
   * - **Depende de**
     - FR-AUTH-08.01 (contrasena actual verificada)
   * - **Requerido por**
     - Ninguno (fin del flujo)
   * - **Include**
     - UC-INC-03 (notificacion por email)
   * - **RNF**
     - RNF-SEC-001
   * - **Test**
     - TST-FR-AUTH-08.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-AUTH-08

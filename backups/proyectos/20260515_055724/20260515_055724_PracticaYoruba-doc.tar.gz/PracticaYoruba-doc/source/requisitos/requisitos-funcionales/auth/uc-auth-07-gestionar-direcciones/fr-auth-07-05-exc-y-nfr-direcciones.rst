.. meta::
   :artefacto: FR-AUTH-07.05
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-07.05: Excepciones y NFR de gestion de direcciones
===========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-07.05
   * - **Nombre**
     - EX-01/EX-02 y restricciones tecnicas del modulo de direcciones
   * - **UC Origen**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Paso UC**
     - PARTE 5 y PARTE 6
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — Address)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - NFR Tecnico + Manejo de Excepcion

----

2. Especificacion
-----------------

**Declaracion:**

   El modulo de gestion de direcciones DEBE manejar los errores de
   repositorio de forma controlada y cumplir los requisitos de calidad
   de aislamiento y unicidad de predeterminada.

**Descripcion:**

**EX-01 — Error al guardar:**

Fallo en INSERT de la nueva direccion. Los datos del usuario no se
modifican. Se retorna HTTP 500 con mensaje generico.

**EX-02 — Limite de direcciones alcanzado:**

Cubierto en FR-AUTH-07.04 (HTTP 409 LIMITE_DIRECCIONES con sugerencia).

**Performance (6.1):** P95 <= 400ms para carga de lista y guardado.
La lista usa una sola query ``Address.objects.filter(user=user)``
sin joins costosos.

**Seguridad (6.2):**

- Aislamiento: todos los querysets filtran por ``user=request.user``.
  Un usuario no puede ver, editar ni eliminar direcciones de otro.
- El endpoint ``/api/v1/auth/addresses/{id}/`` verifica que el ``id``
  pertenece al usuario del JWT antes de operar.

**Confiabilidad (6.3):**

- Invariante de predeterminada: el UPDATE atomico en FR-AUTH-07.04
  garantiza que siempre hay exactamente 0 o 1 direccion predeterminada.
  Si el UPDATE falla → rollback completo → la nueva direccion no se crea.

**Usabilidad (6.4):**

- La direccion predeterminada aparece primera en la lista (``order_by('-is_default', '-created_at')``).
- El formulario incluye todos los campos del estilo postal mexicano
  (colonia — campo que no existe en otros paises pero es obligatorio en MX).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Aislamiento entre usuarios
   DADO usuario A con 3 direcciones y usuario B con 2 direcciones
   CUANDO usuario A hace GET /api/v1/auth/addresses/
   ENTONCES solo ve sus 3 direcciones, nunca las de B
   Y no puede hacer DELETE de una direccion del usuario B

   Escenario 2: Invariante de predeterminada tras eliminacion
   DADO usuario con 2 direcciones, A es predeterminada
   CUANDO elimina la direccion A (predeterminada)
   ENTONCES la direccion B se convierte automaticamente en predeterminada
   Y el usuario siempre tiene una predeterminada mientras tenga alguna

   Escenario 3: Lista ordenada con predeterminada primero
   DADO usuario con 3 direcciones, B es la predeterminada
   CUANDO lista sus direcciones
   ENTONCES B aparece en primer lugar
   Y el orden del resto es por fecha de creacion (mas reciente primero)

----

4. Reglas y Restricciones
--------------------------

- **RNF del sistema:** RNF-PERF-001, RNF-SEC-003

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Secciones**
     - PARTE 5 y PARTE 6
   * - **RNF del sistema**
     - RNF-PERF-001, RNF-SEC-003
   * - **Test**
     - TST-FR-AUTH-07.05 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de PARTE 5 y 6 de UC-AUTH-07

.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-06-preferencias-notificacion
==============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-06-02-persistir-preferencias
   fr-not-06-preferencias-notificacion-01

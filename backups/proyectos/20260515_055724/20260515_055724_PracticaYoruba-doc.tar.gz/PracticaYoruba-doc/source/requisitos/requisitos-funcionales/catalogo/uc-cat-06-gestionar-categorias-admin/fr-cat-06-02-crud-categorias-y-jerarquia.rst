.. meta::
   :artefacto: FR-CAT-06.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-06.02: Crear, editar y reorganizar categorias con validacion de jerarquia
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-06.02
   * - **Nombre**
     - CRUD de categorias con validacion de arbol aciclico y purga de cache
   * - **UC Origen**
     - UC-CAT-06: Gestionar Categorias (Admin)
   * - **Paso UC**
     - Pasos 3, 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar que la jerarquia resultante de cualquier
   operacion sobre categorias no contiene ciclos y purgar el cache
   CUANDO el admin crea, edita o elimina una categoria.

**Descripcion:**

La validación de ciclos previene situaciones como: A es padre de B,
B es padre de A (ciclo directo), o cadenas más largas. Si el nuevo
padre propuesto es nulo (categoría raíz), no hay ciclo posible. En
caso contrario, el sistema recorre la cadena de ancestros del nuevo
padre propuesto subiendo por el campo ``Category.parent`` hasta
llegar a una categoría raíz. Si en algún punto del recorrido
encuentra la propia categoría que se está moviendo, la operación se
rechaza con ``CICLO_EN_JERARQUIA``.

Tras cualquier modificacion exitosa:
- Se invalida el cache ``categories:tree``
- Se invalida el cache de productos de las categorias afectadas

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Nueva categoria como hija de otra
   DADO admin que crea categoria "Collares de Oshun" como hija de "Collares"
   CUANDO guarda
   ENTONCES la categoria se crea correctamente
   Y aparece en el arbol bajo "Collares"
   Y el cache categories:tree se invalida

   Escenario 2: Ciclo detectado — error claro
   DADO admin que intenta hacer B padre de A cuando A ya es padre de B
   CUANDO guarda
   ENTONCES HTTP 400 con {"codigo_error": "CICLO_EN_JERARQUIA",
   "mensaje": "Esta relacion crearia un ciclo en la jerarquia de categorias."}

   Escenario 3: Eliminar categoria con productos
   DADO admin que elimina una categoria con 5 productos activos
   CUANDO intenta eliminar
   ENTONCES HTTP 400 con aviso de que hay productos en esa categoria
   Y se ofrece la opcion de reasignar los productos antes de eliminar

----

4. Reglas y Restricciones
--------------------------

- **Notas:** La estructura de arbol usa el campo ``parent`` con
  ForeignKey recursiva (``parent = ForeignKey('self', null=True, blank=True)``).
  La profundidad maxima del arbol es de 3 niveles para mantener la
  navegacion simple para el visitante.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-06: Gestionar Categorias
   * - **Requerido por**
     - FR-CAT-08.02 (el arbol de categorias refleja los cambios del admin)
   * - **Test**
     - TST-FR-CAT-06.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 3-6 de UC-CAT-06

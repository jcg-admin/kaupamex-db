.. meta::
   :artefacto: FR-CAT-08.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/catalogo
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-CAT-08.02: Servir el arbol de categorias con cache de larga duracion
========================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CAT-08.02
   * - **Nombre**
     - Retornar la estructura jerarquica de categorias activas con TTL largo de cache
   * - **UC Origen**
     - UC-CAT-08: Listar Categorias
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-002 CATALOGUE
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE retornar el arbol completo de categorias activas
   desde el Servicio de Cache con TTL largo CUANDO se solicita la
   estructura de navegacion del catalogo.

**Descripcion:**

Las categorías cambian rara vez — el cache tiene TTL de 3600 segundos
(1 hora). Se invalida cuando el admin modifica una categoría (señal
``post_save`` en ``Category``).

El sistema intenta obtener el árbol de categorías desde ``DatabaseCache``
con la clave ``categories:tree``. Si no existe entrada válida, recupera
todas las ``Category`` con ``is_active = True``, ordenadas por
``Category.order`` y ``Category.name``, construye el árbol anidado con
sus nodos hijo y almacena el resultado en cache durante 1 hora antes
de retornarlo.

Estructura de respuesta:

.. code-block:: json

   [
     {
       "id": 1, "name": "Soperas", "slug": "soperas",
       "product_count": 12,
       "children": [
         {"id": 5, "name": "Soperas Grandes", "product_count": 4, "children": []}
       ]
     }
   ]

El campo ``product_count`` incluye productos activos y publicados
de la categoria y sus descendientes.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Arbol servido desde cache — P50 muy bajo
   DADO cache populado con el arbol de categorias
   CUANDO 100 visitantes solicitan el arbol simultaneamente
   ENTONCES todos reciben la respuesta desde cache (P50 < 20ms)
   Y el repositorio no recibe ninguna consulta

   Escenario 2: Cache invalidado tras modificacion de categoria
   DADO admin que crea una nueva categoria "Brazaletes"
   CUANDO el signal post_save se dispara
   ENTONCES el cache de categories:tree se elimina
   Y la siguiente solicitud reconstruye el arbol con "Brazaletes" incluida

   Escenario 3: product_count correcto
   DADO categoria "Soperas" con 3 productos activos y 2 inactivos
   CUANDO se retorna el arbol
   ENTONCES product_count = 3 (solo activos y publicados)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (las categorias son el componente
  de navegacion mas frecuentemente cargado — el cache es obligatorio)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CAT-08: Listar Categorias
   * - **Requerido por**
     - FR-CAT-04.02 (filtrar por categoria requiere conocer el arbol)
   * - **Test**
     - TST-FR-CAT-08.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-CAT-08

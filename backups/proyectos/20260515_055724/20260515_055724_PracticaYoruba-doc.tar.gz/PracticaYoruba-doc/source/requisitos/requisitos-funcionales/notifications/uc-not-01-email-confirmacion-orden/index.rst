.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-not-01-email-confirmacion-orden
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-not-01-02-encolar-email-confirmacion
   fr-not-01-email-confirmacion-orden-01

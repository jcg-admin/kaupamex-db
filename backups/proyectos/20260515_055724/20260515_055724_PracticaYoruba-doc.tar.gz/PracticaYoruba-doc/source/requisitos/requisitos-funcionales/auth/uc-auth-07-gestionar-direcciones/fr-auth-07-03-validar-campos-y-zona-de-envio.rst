.. meta::
   :artefacto: FR-AUTH-07.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-07.03: Validar campos y zona de envio de la nueva direccion
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-07.03
   * - **Nombre**
     - Validar formato de los campos de la direccion y cobertura de envio
   * - **UC Origen**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Paso UC**
     - Pasos 6 y 7 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (AddressSerializer + ShippingZoneValidator)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato de cada campo de la direccion
   y verificar que el codigo postal esta dentro de la zona de envio
   soportada CUANDO el usuario solicita guardar una nueva direccion.

**Descripcion:**

**Validacion de campos (paso 6)** segun PARTE 7.1 del UC:

.. list-table::
   :widths: 25 15 60
   :header-rows: 1

   * - Campo
     - Obligatorio
     - Regla de validacion
   * - ``recipient_name``
     - SI
     - 2-100 chars. Solo letras, espacios y caracteres acentuados.
   * - ``street_address``
     - SI
     - 5-200 chars. Calle y numero exterior.
   * - ``interior``
     - NO
     - 0-50 chars. Puede estar vacio.
   * - ``neighborhood``
     - SI
     - 2-100 chars. Colonia o barrio.
   * - ``city``
     - SI
     - 2-100 chars.
   * - ``state``
     - SI
     - Debe ser uno de los 32 estados de Mexico (codigo o nombre completo).
   * - ``zip_code``
     - SI
     - Exactamente 5 digitos numericos para Mexico.
   * - ``phone``
     - SI
     - Formato de telefono valido (minimo 7 digitos).

**Verificacion de zona de envio (paso 7):**

El sistema busca en la tabla ``ShippingZone`` una zona activa cuya
lista de códigos postales contenga el ``zip_code`` recibido. Si no
existe ninguna ``ShippingZone`` activa con cobertura para ese código
postal, el sistema retorna el error ``ZONA_NO_SOPORTADA``.

Excepción: si ``SiteSettings.allow_unsupported_zones`` está activado
(modo de desarrollo), el sistema informa al usuario pero no bloquea
la creación de la dirección.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Todos los campos validos y zona soportada
   DADO direccion completa con CP "06600" (Ciudad de Mexico — soportado)
   CUANDO se valida
   ENTONCES todos los campos pasan y la zona tiene cobertura
   Y el proceso continua al paso 10 (almacenar la direccion)

   Escenario 2: Codigo postal de 4 digitos — invalido
   DADO zip_code = "1234" (solo 4 digitos)
   CUANDO se valida
   ENTONCES HTTP 400 con {"detalles": {"zip_code":
   ["El codigo postal debe tener exactamente 5 digitos."]}}

   Escenario 3: Zona no soportada
   DADO zip_code = "99999" (zona sin cobertura)
   CUANDO se verifica la cobertura
   ENTONCES HTTP 422 con {"codigo_error": "ZONA_NO_SOPORTADA",
   "mensaje": "Aun no hacemos entregas en ese codigo postal.",
   "zonas_disponibles_url": "/api/v1/shipping/zones/"}

   Escenario 4: Estado invalido
   DADO state = "Texas" (no es un estado de Mexico)
   CUANDO se valida
   ENTONCES HTTP 400 con {"detalles": {"state":
   ["Selecciona un estado valido de la Republica Mexicana."]}}

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna especifica — validacion de formato
- **Notas:** La verificacion de zona de envio es la mas util para
  el usuario desde el punto de vista de experiencia: saber antes
  de hacer el pedido si su zona tiene cobertura, no durante el checkout.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-07: Gestionar Direcciones
   * - **Depende de**
     - FR-AUTH-07.01 (lista cargada — el usuario ya tiene el formulario)
   * - **Requerido por**
     - FR-AUTH-07.04 (almacenar la direccion validada)
   * - **Relacionado con**
     - FR-CFG-02.01 (zonas de envio configuradas por el admin)
   * - **Test**
     - TST-FR-AUTH-07.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 6 y 7 de UC-AUTH-07
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.
       Logica de verificacion de ShippingZone preservada en texto.

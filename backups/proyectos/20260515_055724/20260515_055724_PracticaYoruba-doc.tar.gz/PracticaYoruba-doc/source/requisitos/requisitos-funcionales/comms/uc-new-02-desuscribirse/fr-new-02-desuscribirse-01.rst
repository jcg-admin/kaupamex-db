.. meta::
   :artefacto: FR-NEW-02.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-new-02-01:

FR-NEW-02.01: Desactivar suscripcion via token
==============================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NEW-02.01
   * - **Nombre**
     - Desactivar suscripcion via token
   * - **UC Origen**
     - UC-NEW 02 DESUSCRIBIRSE
   * - **Paso UC**
     - Paso 2
   * - **Modulo**
     - MOD-016 NEWSLETTER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE desactivar la suscripcion CUANDO el usuario sigue el enlace del email.

**Descripcion:**

El enlace del email contiene un token HMAC firmado con el email.
``Newsletter.is_active = False``
Si el token es invalido o el email no esta suscrito: respuesta exitosa igualmente (seguridad).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Desuscripcion exitosa
   DADO token valido de desuscripcion
   CUANDO se sigue el enlace
   ENTONCES Newsletter.is_active=False

   Escenario: Token invalido — respuesta exitosa
   DADO token malformado o de otro email
   CUANDO se intenta usar
   ENTONCES respuesta 200 con mensaje de desuscripcion exitosa sin revelar el error


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La respuesta siempre es exitosa para no revelar si el email estaba en la lista.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NEW 02 DESUSCRIBIRSE
   * - **Depende de**
     - Suscripcion existente
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-NEW-02.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-NEW 02 DESUSCRIBIRSE

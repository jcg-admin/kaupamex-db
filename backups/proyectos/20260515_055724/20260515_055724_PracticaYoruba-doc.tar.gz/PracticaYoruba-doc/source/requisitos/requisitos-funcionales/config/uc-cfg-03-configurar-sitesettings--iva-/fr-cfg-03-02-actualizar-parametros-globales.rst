.. meta::
   :artefacto: FR-CFG-03.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cfg-03-02:

=================================================================================
FR-CFG-03.02: Validar y persistir los parámetros globales con efecto inmediato
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-03.02
   * - **Nombre**
     - Validar el rango y formato de cada parámetro global, advertir
       al admin sobre el alcance de cambios críticos como la tasa de
       IVA, y persistir los cambios con efecto inmediato para las
       nuevas solicitudes
   * - **UC Origen**
     - UC-CFG-03: Configurar SiteSettings (IVA y parámetros globales)
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Crítica
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el rango y formato de cada parámetro
   modificado, advertir al admin sobre el alcance real de los cambios
   críticos antes de confirmar y persistir los nuevos valores con
   efecto inmediato para todas las solicitudes posteriores, sin
   afectar las órdenes ya creadas.

**Descripcion:**

SiteSettings es el repositorio de configuración global del que
dependen múltiples módulos. Los parámetros que gestiona este FR son:

- **iva_rate** — la tasa de IVA aplicada en el checkout (BR-002).
  Valor entre 0 y 1; el 16% se expresa como 0.16.
- **min_stock_threshold** — el umbral mínimo de stock que activa
  las alertas del panel de inventario (FR-INV-01.02).
- **payment_timeout_minutes** — los minutos que el sistema espera
  antes de cancelar automáticamente una orden sin pago
  (FR-SYS-01.02).
- **return_period_days** — los días desde la entrega durante los
  cuales el comprador puede solicitar una devolución (FR-RET-01.02).

Cada parámetro tiene su validación propia: la tasa de IVA debe estar
entre 0 y 1, el umbral de stock debe ser un entero positivo, el
timeout de pago debe estar entre 5 y 1440 minutos, y el período de
devolución entre 1 y 365 días. Si un valor está fuera de rango, el
sistema rechaza solo ese campo sin perder los demás cambios (Alt. A).

**Cambio de tasa de IVA con órdenes pendientes (Alt. B).**
La tasa de IVA solo afecta a las órdenes nuevas. Las órdenes que ya
existen tienen el IVA capturado como snapshot inmutable en
``OrderValue.iva_rate`` (BR-005). Sin embargo, si hay órdenes en
estado ``PENDING_PAYMENT`` cuando el admin cambia la tasa, el sistema
lo advierte porque esas órdenes mostrarán al comprador el IVA de
cuando fueron creadas, que podría diferir del nuevo. El admin confirma
entendiendo que es un comportamiento correcto por diseño.

**Efecto inmediato sin reinicio.**
Una vez persistidos, los valores nuevos están disponibles para la
siguiente solicitud que los consulte. No se requiere reiniciar
ningún proceso ni limpiar ningún cache manualmente.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Tasa de IVA actualizada con advertencia de órdenes pendientes
   DADO 5 órdenes en PENDING_PAYMENT y admin que cambia iva_rate de 0.16 a 0.08
   CUANDO el admin guarda el cambio
   ENTONCES el sistema muestra "Hay 5 órdenes pendientes de pago que conservarán
   la tasa del 16%. ¿Confirmas el cambio?"
   Y tras confirmar: SiteSettings.iva_rate = 0.08
   Y el siguiente checkout calcula el total con 0.08

   Escenario 2: Tasa de IVA fuera de rango — rechazada (EX-02)
   DADO admin que ingresa iva_rate = 1.5
   CUANDO el sistema valida
   ENTONCES HTTP 400 con {"errors": {"iva_rate":
   "La tasa de IVA debe ser un valor entre 0 y 1 (donde 0.16 representa el 16%)."}}
   Y los demás parámetros modificados en la misma petición no se pierden

   Escenario 3: Período de devolución reducido — efecto solo en solicitudes nuevas
   DADO admin que reduce return_period_days de 30 a 15
   CUANDO guarda el cambio
   ENTONCES las nuevas solicitudes de devolución solo se aceptan hasta 15 días
   Y las solicitudes que ya estaban abiertas no se ven afectadas por el cambio

   Escenario 4: Timeout de pago actualizado — órdenes existentes no cambian
   DADO admin que cambia payment_timeout_minutes de 30 a 60
   CUANDO guarda el cambio
   ENTONCES las nuevas órdenes que se creen esperan 60 minutos antes de cancelarse
   Y las órdenes PENDING_PAYMENT que ya existen siguen con su tiempo original

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** BR-002 (la tasa de IVA de SiteSettings es la
  que usa el checkout para calcular el total), BR-005 (las órdenes
  existentes conservan el snapshot de iva_rate; el cambio en
  SiteSettings no las modifica)
- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms)
- **Notas:** Los parámetros de SiteSettings no tienen historial de
  versiones nativo. Si el admin necesita saber qué valor tenía un
  parámetro en una fecha específica, debe consultar el log de
  auditoría.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG-03: Configurar SiteSettings
   * - **Requerido por**
     - FR-ORD-01.03 (usa iva_rate para calcular el total),
       FR-INV-01.02 (usa min_stock_threshold para las alertas),
       FR-SYS-01.02 (usa payment_timeout_minutes para cancelar
       órdenes expiradas), FR-RET-01.02 (usa return_period_days
       para validar el plazo de devolución)
   * - **Test**
     - TST-FR-CFG-03.02 (pendiente — verificar que el cambio de
       iva_rate no modifica el OrderValue.iva_rate de las órdenes
       ya creadas; verificar que la validación de rango rechaza
       solo el campo inválido sin perder los demás)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: cuatro parámetros documentados con
       sus rangos, advertencia de IVA con órdenes pendientes,
       efecto inmediato sin reinicio, 4 escenarios BDD

.. meta::
   :artefacto: FR-AUTH-06.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-AUTH-06.03: Validar campos de texto modificados
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-06.03
   * - **Nombre**
     - Validar formato, longitud y caracteres de los campos de texto editados
   * - **UC Origen**
     - UC-AUTH-06: Editar Perfil
   * - **Paso UC**
     - Paso 6 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (ProfileUpdateSerializer)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Validacion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato y las restricciones de cada
   campo de texto modificado CUANDO el usuario solicita guardar
   los cambios del perfil.

**Descripcion:**

Validaciones por campo (segun PARTE 7.1 del UC):

.. list-table::
   :widths: 20 25 55
   :header-rows: 1

   * - Campo
     - Tipo de validacion
     - Regla
   * - ``first_name``
     - Longitud
     - 2-50 caracteres. Si se envia no puede estar vacio.
       Solo letras, espacios y guiones. Trim de espacios al inicio/fin.
   * - ``last_name``
     - Longitud
     - 2-50 caracteres. Mismas reglas que first_name.
   * - ``phone``
     - Formato
     - Acepta formatos internacional (+52 55 1234 5678) o local.
       Puede estar vacio (para "borrar" el telefono).
       Si no vacio: minimo 7 digitos, maximo 20 caracteres.

El endpoint usa PATCH semantics — solo se validan los campos
presentes en el body. Los campos ausentes no se modifican.

Si hay errores de validacion: HTTP 400 con detalles por campo:

.. code-block:: json

   {"codigo_error": "DATOS_INVALIDOS",
    "detalles": {
      "first_name": ["El nombre debe tener entre 2 y 50 caracteres."],
      "phone": ["El formato de telefono no es valido."]
    }}

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Todos los campos validos — procede al guardado
   DADO PATCH con {"first_name": "Maria", "phone": "+52 55 9876 5432"}
   CUANDO se valida
   ENTONCES todos los campos cumplen las reglas
   Y el proceso continua a FR-AUTH-06.01 (persistir los cambios)

   Escenario 2: Nombre demasiado corto
   DADO PATCH con {"first_name": "A"}
   CUANDO se valida
   ENTONCES HTTP 400 con {"detalles": {"first_name":
   ["El nombre debe tener al menos 2 caracteres."]}}

   Escenario 3: Telefono borrado explicitamente
   DADO PATCH con {"phone": ""}
   CUANDO se valida
   ENTONCES el campo phone se acepta (borrar el telefono es valido)
   Y el proceso actualiza phone a null o string vacio en la BD

   Escenario 4: Username no modificable — ignorado
   DADO PATCH con {"username": "nuevouser", "first_name": "Maria"}
   CUANDO se valida
   ENTONCES el campo username es ignorado silenciosamente
   Y solo first_name se actualiza
   Y el username permanece igual

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-USAB-001 (mensajes de error claros por campo)
- **Notas:** El username es inmutable en todo el ciclo de vida de la cuenta.
  El email tiene su propio flujo de cambio (requiere re-verificacion).
  Ni username ni email se pueden cambiar en este UC.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-06: Editar Perfil
   * - **Depende de**
     - FR-AUTH-06.02 (datos precargados — el usuario modifico algo)
   * - **Requerido por**
     - FR-AUTH-06.04 (validar el avatar si fue subido)
   * - **Test**
     - TST-FR-AUTH-06.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 6 de UC-AUTH-06

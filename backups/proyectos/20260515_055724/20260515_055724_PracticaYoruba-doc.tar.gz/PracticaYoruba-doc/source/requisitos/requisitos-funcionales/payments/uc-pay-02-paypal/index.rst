.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-pay-02-paypal
===========================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-pay-02-01-crear-orden-paypal
   fr-pay-02-02-crear-orden-paypal-y-redirigir

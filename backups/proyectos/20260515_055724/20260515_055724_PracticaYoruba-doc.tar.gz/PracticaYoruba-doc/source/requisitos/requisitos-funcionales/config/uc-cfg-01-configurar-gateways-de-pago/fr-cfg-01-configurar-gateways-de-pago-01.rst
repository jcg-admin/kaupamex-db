.. meta::
   :artefacto: FR-CFG-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-cfg-01-01:

FR-CFG-01.01: Guardar y verificar credenciales del gateway
==========================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-01.01
   * - **Nombre**
     - Guardar y verificar credenciales del gateway
   * - **UC Origen**
     - UC-CFG 01 CONFIGURAR GATEWAYS DE PAGO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE cifrar y persistir las credenciales del gateway y verificar la conexion CUANDO el admin las configura.

**Descripcion:**

Para cada gateway (MP / PayPal):

1. Recibe las credenciales en texto plano en el request
2. Las cifra inmediatamente con Fernet antes de guardar en BD
3. Hace una llamada de prueba al gateway para verificar que las credenciales son validas
4. Si la verificacion falla: retorna el error del gateway sin guardar las credenciales
5. Si la verificacion es exitosa: guarda en ``PaymentMethodConfig`` cifrado

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Credenciales validas guardadas
   DADO credenciales de MP correctas
   CUANDO el admin las ingresa
   ENTONCES se cifran y guardan en BD
   Y la verificacion de conexion es exitosa

   Escenario: Credenciales invalidas
   DADO access_token de MP incorrecto
   CUANDO se intenta verificar
   ENTONCES MP retorna 401
   Y el sistema NO guarda las credenciales
   Y se informa el error de verificacion


----

4. Reglas y Restricciones
--------------------------

- **BR-009 (credenciales solo en el servidor)**

- :ref:`RNF-SEC-002 (cifrado con Fernet)`
- **Notas:** Las credenciales nunca se retornan en ninguna respuesta de la API — ni siquiera enmascaradas.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG 01 CONFIGURAR GATEWAYS DE PAGO
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - FR-PAY-01.01 (el gateway usa las credenciales para crear preferencias)
   * - **Test**
     - TST-FR-CFG-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-CFG 01 CONFIGURAR GATEWAYS DE PAGO

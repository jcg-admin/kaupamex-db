.. meta::
   :artefacto: FR-CFG-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/config
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-05

.. _fr-cfg-05-02:

=================================================================================
FR-CFG-05.02: Validar y persistir los datos de contacto con efecto inmediato
=================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-CFG-05.02
   * - **Nombre**
     - Validar el formato de cada campo de contacto, advertir sobre URLs
       de redes sociales inaccesibles, persistir los cambios y reflejarlos
       de forma inmediata en el footer y en los emails transaccionales
   * - **UC Origen**
     - UC-CFG-05: Gestionar Datos de Contacto
   * - **Paso UC**
     - Pasos 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-017 SITE_SETTINGS
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato de cada dato de contacto
   modificado, advertir al admin si alguna URL de red social no
   responde, persistir los cambios y hacerlos visibles de forma
   inmediata en el footer del sitio y en los emails transaccionales
   CUANDO el admin actualiza los datos de contacto del negocio.

**Descripcion:**

Los datos de contacto del negocio aparecen en dos lugares: el footer
de todas las páginas del sitio y las plantillas de emails
transaccionales como la confirmación de orden y la respuesta a
mensajes de contacto. Cualquier cambio en estos datos debe reflejarse
de inmediato en ambos lugares sin necesidad de actualizaciones
manuales en las plantillas.

Los campos que el admin puede actualizar son:

- **Email de soporte** — debe tener formato de email válido. Es el
  que los visitantes ven para contacto directo y el que aparece en
  los emails transaccionales como dirección de respuesta.
- **Teléfono de contacto** — campo de texto libre que acepta números
  con prefijo de país y extensiones.
- **Dirección física** — texto libre para la dirección del negocio.
- **Redes sociales** — el admin puede añadir, editar o eliminar URLs
  de perfiles en redes sociales. El sistema tiene perfiles
  preconfigurados para las plataformas comunes (Instagram, Facebook,
  YouTube, TikTok). El admin puede agregar perfiles en plataformas
  no listadas con un nombre personalizado (Alt. C).

**Validación de URLs de redes sociales (EX-02).**
Cuando el admin guarda una URL nueva, el sistema intenta una petición
de verificación para confirmar que la URL responde. Si no responde,
informa al admin con un aviso —no un error bloqueante— y le permite
guardar de todas formas. La URL puede ser válida aunque no responda
en ese instante por un problema temporal de red.

**Efecto inmediato.**
Una vez persistidos, los datos nuevos están disponibles sin necesidad
de limpiar caches ni reiniciar procesos. El footer y las plantillas
de emails leen los datos directamente del repositorio de
configuración en cada solicitud.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Email de soporte actualizado — aparece en emails futuros
   DADO admin que cambia el email de soporte a "soporte@ojayoruba.com"
   CUANDO guarda
   ENTONCES SiteSettings.support_email = "soporte@ojayoruba.com"
   Y el siguiente email transaccional que se envíe usa la nueva dirección
   Y el footer del sitio muestra el nuevo email en el próximo acceso

   Escenario 2: Formato de email inválido — error específico por campo
   DADO admin que ingresa "no-es-un-email" en el campo de email de soporte
   CUANDO el sistema valida
   ENTONCES HTTP 400 con {"errors": {"support_email":
   "El email de soporte no tiene un formato válido."}}
   Y los demás campos modificados en la misma petición no se pierden

   Escenario 3: URL de red social que no responde — aviso sin bloqueo (EX-02)
   DADO admin que agrega "https://tiktok.com/@ojayoruba" como nueva red social
   CUANDO el sistema intenta verificar la URL y no recibe respuesta
   ENTONCES muestra "La URL no respondió. ¿Confirmas que es correcta?"
   Y si el admin confirma: la URL se guarda y aparece en el footer
   Y si cancela: el campo queda vacío sin guardar

   Escenario 4: Red social de plataforma personalizada añadida (Alt. C)
   DADO admin que agrega "Telegram" con URL "https://t.me/ojayoruba"
   como plataforma personalizada
   CUANDO guarda
   ENTONCES el footer muestra el enlace de Telegram con icono genérico
   Y el admin puede agregar el icono específico de Telegram si lo desea

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 400ms; la verificación
  de URLs de redes sociales tiene un tiempo límite propio que no
  bloquea el guardado)
- **Notas:** Los datos de contacto no tienen historial de versiones.
  Si el admin necesita conocer un valor anterior debe consultar el
  log de auditoría general, que registra los cambios de SiteSettings.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-CFG-05: Gestionar Datos de Contacto
   * - **Requerido por**
     - UC-INC-03 (las plantillas de emails transaccionales incluyen
       el email y teléfono de soporte configurados aquí)
   * - **Test**
     - TST-FR-CFG-05.02 (pendiente — verificar que el email de
       soporte nuevo aparece en el siguiente email transaccional;
       verificar que una URL inaccesible no bloquea el guardado
       si el admin confirma)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-05
     - Reescritura completa: cuatro campos documentados, verificación
       de URLs no bloqueante EX-02, red social personalizada Alt. C,
       efecto inmediato en footer y emails, 4 escenarios BDD

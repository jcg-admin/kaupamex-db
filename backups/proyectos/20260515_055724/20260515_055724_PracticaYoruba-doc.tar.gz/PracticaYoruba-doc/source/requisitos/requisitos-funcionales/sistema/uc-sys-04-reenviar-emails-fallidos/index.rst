.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-sys-04-reenviar-emails-fallidos
=============================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-sys-04-02-reenviar-con-backoff-exponencial
   fr-sys-04-reenviar-emails-fallidos-01

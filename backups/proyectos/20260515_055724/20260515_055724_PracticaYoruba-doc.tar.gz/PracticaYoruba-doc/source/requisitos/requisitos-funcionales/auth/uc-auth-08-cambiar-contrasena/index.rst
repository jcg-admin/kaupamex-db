.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-auth-08-cambiar-contrasena
========================================

**6 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-auth-08-01-verificar-contrasena-actual
   fr-auth-08-02-actualizar-contrasena
   fr-auth-08-03-validar-fortaleza-y-confirmacion
   fr-auth-08-04-verificar-contrasena-diferente
   fr-auth-08-05-registrar-auditoria-y-confirmar
   fr-auth-08-06-exc-y-nfr-cambio-contrasena

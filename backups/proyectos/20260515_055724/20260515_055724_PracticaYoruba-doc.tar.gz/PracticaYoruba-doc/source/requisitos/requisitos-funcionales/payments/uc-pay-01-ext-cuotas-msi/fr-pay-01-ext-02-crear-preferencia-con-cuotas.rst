.. meta::
   :artefacto: FR-PAY-01-EXT.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-01-ext-02:

FR-PAY-01-EXT.02: Crear preferencia con plan de cuotas seleccionado
===================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-01-EXT.02
   * - **Nombre**
     - Crear preferencia con plan de cuotas seleccionado
   * - **UC Origen**
     - UC-PAY-01-EXT: Cuotas MSI Mercado Pago
   * - **Paso UC**
     - Pasos 4-5
   * - **Modulo**
     - MOD-007 PAYMENT + Gateway MP
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Integracion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE crear la preferencia de MP con el plan de cuotas CUANDO el comprador selecciona el numero de cuotas.

**Descripcion:**

Agrega al payload de la preferencia:

- ``payment_methods.default_installments``: el numero de cuotas elegido
- ``payment_methods.max_installments``: el mismo numero (fuerza esa opcion)

MP muestra la pantalla de pago con la opcion de cuotas preseleccionada.
El negocio recibe el pago completo de inmediato — MP asume el financiamiento.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Preferencia con 12 cuotas
   DADO comprador que selecciona 12 meses
   CUANDO se crea la preferencia
   ENTONCES MP muestra la pantalla con 12 cuotas preseleccionadas
   Y el monto por cuota corresponde al calculo de MP

   Escenario: Cuotas no validas para la tarjeta
   DADO comprador con tarjeta que no participa en MSI
   CUANDO intenta pagar con cuotas
   ENTONCES MP rechaza y el sistema informa que la tarjeta no es elegible


----

4. Reglas y Restricciones
--------------------------

- **BR-009**

- **Notas:** El negocio recibe el monto total en un solo deposito. Las cuotas son un acuerdo entre el comprador y MP.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-01-EXT: Cuotas MSI Mercado Pago
   * - **Depende de**
     - FR-PAY-01-EXT.01 (plan de cuotas seleccionado)
   * - **Requerido por**
     - FR-PAY-03.01 (webhook confirma el pago con cuotas igual que sin cuotas)
   * - **Test**
     - TST-FR-PAY-01-EXT.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-01-EXT

.. meta::
   :artefacto: FR-RPT-04.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/reportes
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-rpt-04-01:

FR-RPT-04.01: Generar y retornar URL de exportacion
===================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-RPT-04.01
   * - **Nombre**
     - Generar y retornar URL de exportacion
   * - **UC Origen**
     - UC-RPT 04 EXPORTAR REPORTE
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-013 REPORTS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE generar el archivo de exportacion y retornar una URL firmada CUANDO el admin exporta.

**Descripcion:**

Formatos: CSV (default) o XLSX.
El archivo se genera en memoria y se almacena temporalmente.
La URL firmada tiene una validez de 15 minutos.
Si la generacion tarda mas de 30s: se envia el archivo por email al admin.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Exportacion CSV rapida
   DADO admin que exporta el reporte de ventas a CSV
   CUANDO se genera
   ENTONCES respuesta con url_descarga y expira_en=900 segundos

   Escenario: Exportacion grande — envio por email
   DADO reporte con muchos datos que tarda mas de 30s
   CUANDO se genera
   ENTONCES respuesta 202 Accepted con mensaje de que llegara por email


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- **Notas:** La URL firmada previene que el archivo sea accedido por terceros no autorizados.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-RPT 04 EXPORTAR REPORTE
   * - **Depende de**
     - Ninguno
   * - **Requerido por**
     - Ninguno
   * - **Test**
     - TST-FR-RPT-04.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-RPT 04 EXPORTAR REPORTE

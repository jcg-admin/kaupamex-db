.. meta::
   :artefacto: FR-NOT-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/notifications
   :estado: Derivado
   :version: 1.1.0
   :fecha_creacion: 2026-05-03
   :fecha_actualizacion: 2026-05-04

.. _fr-not-02-02:

=============================================================================
FR-NOT-02.02: Notificar al comprador el cambio de estado de su orden
=============================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-NOT-02.02
   * - **Nombre**
     - Verificar que el nuevo estado genera notificación, seleccionar la
       plantilla correspondiente y encolar el email personalizado al
       comprador de forma asíncrona
   * - **UC Origen**
     - UC-NOT-02: Email de Estado de Orden
   * - **Paso UC**
     - Pasos 2 al 9 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.notifications)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Comunicación

----

2. Especificacion
-----------------

**Declaracion:**

   El Sistema de Notificaciones DEBE verificar que el nuevo estado
   de la orden es uno que genera notificación al comprador, seleccionar
   la plantilla de mensaje correspondiente a ese estado, renderizarla
   con los datos actuales de la orden y encolarla de forma asíncrona
   CUANDO recibe el evento de cambio de estado.

**Descripcion:**

No todo cambio de estado genera un email al comprador. El Sistema de
Notificaciones mantiene una lista de los estados que sí lo generan.
Si el nuevo estado no está en esa lista, el proceso termina sin acción
(Alt. A). Los estados que generan notificación son:

- **PAYMENT_CONFIRMED** — el pedido está siendo procesado.
- **SHIPPED** — el pedido está en camino.
- **DELIVERED** — el pedido fue entregado.
- **CANCELLED** — el pedido fue cancelado.
- **CANCELLED_TIMEOUT** — el pedido fue cancelado por falta de pago.

Si el estado sí genera notificación, el Sistema de Notificaciones
verifica a continuación que el comprador tiene un email válido y que
no ha desactivado este tipo de aviso en sus preferencias. Si alguna
de las dos condiciones falla, el proceso termina y el sistema registra
que la notificación fue omitida con el motivo correspondiente.

Cuando ambas verificaciones pasan, el sistema selecciona la plantilla
de mensaje que corresponde al nuevo estado. Cada estado tiene su propia
plantilla porque el mensaje y el tono son distintos: el email de pedido
en camino incluye el número de rastreo y el enlace de seguimiento si
están disponibles (Alt. C), mientras que el de pedido entregado invita
al comprador a dejar una reseña.

El contenido del email incluye siempre el saludo personalizado, el
número de orden, un resumen de los items comprados, el nuevo estado
explicado en lenguaje orientado al comprador y los próximos pasos que
puede esperar o realizar.

Finalmente el mensaje se encola para envío asíncrono. El cambio de
estado de la orden ya fue persistido y confirmado antes de que este
proceso se inicie; el resultado del email no afecta en ningún caso
al estado de la orden.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Estado SHIPPED con número de rastreo — email enriquecido
   DADO orden ORD-20260504-00087 que pasa a estado SHIPPED
   Y la guía de envío tiene número de rastreo 1234567890DHL
   CUANDO el Sistema de Notificaciones recibe el evento
   ENTONCES el email incluye el número de rastreo de forma prominente
   Y el enlace de seguimiento de DHL con el número incrustado
   Y la fecha estimada de entrega si está disponible en la guía

   Escenario 2: Estado SHIPPED sin número de rastreo — email sin rastreo
   DADO orden que pasa a SHIPPED pero la guía aún no tiene número de rastreo
   CUANDO el Sistema de Notificaciones genera el email (Alt. D)
   ENTONCES el email informa que el pedido fue despachado
   Y explica que el número de rastreo estará disponible próximamente
   Y ofrece los datos de contacto del negocio para consultas

   Escenario 3: Estado IN_PREPARATION — sin notificación al comprador
   DADO orden que pasa de PAYMENT_CONFIRMED a IN_PREPARATION
   CUANDO el Sistema de Notificaciones verifica el estado (Alt. A)
   ENTONCES el estado IN_PREPARATION no genera notificación
   Y el proceso termina sin crear ningún registro de email

   Escenario 4: Comprador con preferencia de notificación desactivada
   DADO comprador que desactivó los avisos de cambio de estado en FR-NOT-06.02
   CUANDO el Sistema de Notificaciones verifica las preferencias (Alt. E)
   ENTONCES no se encola ningún email
   Y el sistema registra "omitida por preferencia del usuario"
   en el log de auditoría

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-002 (P95 <= 30 segundos desde el
  evento hasta el encole), RNF-AVAIL-003 (reintentos con espera
  progresiva gestionados por FR-SYS-04.02)
- **Notas:** El listado de estados que generan notificación es una
  decisión de negocio. Si en el futuro se añade un estado nuevo,
  basta con añadirlo a la lista sin modificar la lógica de este FR.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-NOT-02: Email de Estado de Orden
   * - **Disparado por**
     - FR-ORD-07.02 (transición de estado de la orden)
   * - **Incluye**
     - UC-INC-03 (enviar email con plantilla)
   * - **Relacionado con**
     - FR-NOT-06.02 (preferencias del comprador)
   * - **Relacionado con**
     - FR-SYS-04.02 (gestión de reintentos con espera progresiva)
   * - **Test**
     - TST-FR-NOT-02.02 (pendiente — verificar que IN_PREPARATION
       no genera email; verificar que el email de SHIPPED con rastreo
       incluye la URL completa de seguimiento)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial (batch — contenido mínimo)
   * - 1.1.0
     - 2026-05-04
     - Reescritura completa: lista de estados que generan notificación,
       plantilla por estado, SHIPPED con y sin rastreo, preferencias
       de usuario, 4 escenarios BDD con datos concretos

.. meta::
   :artefacto: FR-AUTH-05.03
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-05-03:

=============================================================
FR-AUTH-05.03: Calcular porcentaje de completitud del perfil
=============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-05.03
   * - **Nombre**
     - Calcular profile_completeness y los campos opcionales pendientes
   * - **UC Origen**
     - UC-AUTH-05: Ver Perfil
   * - **Paso UC**
     - Paso 5 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — ProfileCompletenessCalculator)
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Calculo

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE calcular el porcentaje de completitud del perfil
   y la lista de campos pendientes CUANDO los datos del perfil han
   sido recuperados.

**Descripcion:**

**Descripcion:**

El sistema evalúa cinco campos opcionales del perfil del usuario,
asignando a cada uno un peso del 20%:

- ``User.first_name`` — 20% si contiene un valor no vacío.
- ``User.last_name`` — 20% si contiene un valor no vacío.
- ``User.phone`` — 20% si contiene un valor no vacío.
- ``User.avatar`` — 20% si el usuario tiene un avatar subido
  (``User.avatar`` evaluado como booleano es verdadero).
- Direcciones guardadas — 20% si el usuario tiene al menos una
  ``Address`` asociada a su cuenta (consulta ``EXISTS`` sobre
  las direcciones del usuario).

El sistema suma los pesos de los campos presentes para obtener
``profile_completeness`` (entero entre 0 y 100, en múltiplos
de 20). Los campos ausentes conforman la lista ``pending_fields``
que se retorna junto al porcentaje para orientar al usuario sobre
qué completar a continuación.

El resultado ``profile_completeness = 75`` es imposible dado el
diseño — los valores válidos son 0, 20, 40, 60, 80 y 100. Un
resultado de 80 significa que 4 de los 5 campos opcionales
están completados.

El cálculo no se cachea — se ejecuta en cada llamada para
reflejar el estado actual de la cuenta. El coste es máximo
2 consultas: una para los datos del usuario y una ``EXISTS``
para verificar la existencia de direcciones.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Perfil completamente vacio (solo email y username)
   DADO usuario recien registrado sin datos opcionales
   CUANDO se calcula la completitud
   ENTONCES profile_completeness = 0
   Y pending_fields = ["first_name", "last_name", "phone", "avatar", "addresses"]

   Escenario 2: Perfil parcialmente completo
   DADO usuario con first_name, last_name y avatar pero sin phone ni address
   CUANDO se calcula
   ENTONCES profile_completeness = 60
   Y pending_fields = ["phone", "addresses"]

   Escenario 3: Perfil 100% completo
   DADO usuario con todos los campos opcionales rellenados
   CUANDO se calcula
   ENTONCES profile_completeness = 100
   Y pending_fields = []
   Y no se muestra el bloque de "completa tu perfil"

   Escenario 4: El calculo usa datos frescos de la BD
   DADO usuario que acaba de agregar su primera direccion
   CUANDO consulta su perfil
   ENTONCES profile_completeness aumenta en 20 puntos
   Y "addresses" desaparece de pending_fields

----

4. Reglas y Restricciones
--------------------------

- **BR aplicables:** Ninguna
- **Notas:** El calculo es simple y no costoso (max 2 queries: una
  para el usuario y una EXISTS para las direcciones). No se cachea —
  se calcula en cada llamada para reflejar el estado actual.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-05: Ver Perfil
   * - **Depende de**
     - FR-AUTH-05.02 (datos del perfil recuperados)
   * - **Requerido por**
     - Ninguno — es el ultimo paso del Sistema en UC-AUTH-05
   * - **Test**
     - TST-FR-AUTH-05.03 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block
       Python. Logica del dominio preservada integra. Correccion:
       profile_completeness = 75 era imposible (multiplos de 20).

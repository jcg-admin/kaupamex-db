.. meta::
   :artefacto: FR-COM-01.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/comms
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-com-01-01:

FR-COM-01.01: Guardar mensaje de contacto
=========================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-COM-01.01
   * - **Nombre**
     - Guardar mensaje de contacto
   * - **UC Origen**
     - UC-COM 01 FORMULARIO CONTACTO
   * - **Paso UC**
     - Pasos 2-4
   * - **Modulo**
     - MOD-014 CONTACT
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Proceso/Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE guardar el mensaje de contacto CUANDO el visitante lo envia.

**Descripcion:**

Campos: ``name``, ``email``, ``subject``, ``message``.
Rate limiting: max 3 mensajes por email en 24 horas.
El mensaje queda con ``status=NUEVO`` en la cola del admin.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Mensaje guardado exitosamente
   DADO visitante con datos validos
   CUANDO envia el formulario
   ENTONCES Contact queda en BD con status=NUEVO
   Y el admin lo ve en UC-COM-02

   Escenario: Rate limit de mensajes
   DADO mismo email que ya envio 3 mensajes hoy
   CUANDO intenta enviar un cuarto
   ENTONCES error 429: LIMITE_MENSAJES_DIARIOS


----

4. Reglas y Restricciones
--------------------------

- Ninguna especifica.

- :ref:`RNF-SEC-004`
- **Notas:** El rate limiting previene spam del formulario.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-COM 01 FORMULARIO CONTACTO
   * - **Depende de**
     - Ninguno — punto de entrada
   * - **Requerido por**
     - FR-COM-02.01 (admin ve el mensaje)
   * - **Test**
     - TST-FR-COM-01.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-COM 01 FORMULARIO CONTACTO

.. meta::
   :artefacto: FR-LOG-02.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/logistica
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-LOG-02.02: Actualizar el numero de rastreo en la guia y notificar al comprador
==================================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-LOG-02.02
   * - **Nombre**
     - Validar y persistir el numero de rastreo en ShipmentGuide y encolar notificacion
   * - **UC Origen**
     - UC-LOG-02: Registrar Numero de Rastreo
   * - **Paso UC**
     - Pasos 4, 5 y 6 del flujo principal
   * - **Modulo**
     - MOD-008 LOGISTICS
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Datos

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE validar el formato del numero de rastreo,
   actualizarlo en la guia de envio y notificar al comprador
   si aun no fue notificado CUANDO el admin registra el numero.

**Descripcion:**

El sistema valida que el número de rastreo sea alfanumérico con
guiones, entre 5 y 30 caracteres. Si no cumple → ``NUMERO_RASTREO_INVALIDO``.

En caso válido, almacena el número en mayúsculas en
``ShipmentGuide.tracking_number`` y, si el estado actual es
``'CREATED'``, lo actualiza a ``'IN_TRANSIT'``. Si la guía aún no
había notificado al comprador (``ShipmentGuide.buyer_notified = False``),
encola la notificación de número de rastreo disponible de forma
asíncrona y marca ``ShipmentGuide.buyer_notified = True``.

La URL de seguimiento se construye como
``{courier.tracking_url_template.format(tracking=tracking_number)}``
donde ``tracking_url_template`` es un campo del modelo Courier
configurado por el admin (FR-LOG-06.01).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Numero de rastreo registrado y comprador notificado
   DADO guia sin numero de rastreo aun
   CUANDO el admin ingresa "1234567890DHL"
   ENTONCES ShipmentGuide.tracking_number = "1234567890DHL"
   Y ShipmentGuide.status = IN_TRANSIT
   Y la notificacion al comprador se encola con el URL de seguimiento

   Escenario 2: Formato invalido — error especifico
   DADO numero de rastreo con caracteres especiales "ABC@123"
   CUANDO el admin intenta guardarlo
   ENTONCES HTTP 400 con {"codigo_error": "NUMERO_RASTREO_INVALIDO",
   "mensaje": "El numero de rastreo solo puede contener letras, numeros y guiones."}

   Escenario 3: Actualizacion de numero ya existente — no re-notifica
   DADO guia con numero de rastreo "ABC123" que el admin quiere corregir
   CUANDO actualiza a "ABC124"
   ENTONCES el numero se actualiza correctamente
   Y el comprador NO recibe una segunda notificacion (buyer_notified=True ya)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PROC-002 (la actualizacion queda en el historial
  de la guia via AbstractBaseModel.updated_at)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-LOG-02: Registrar Numero de Rastreo
   * - **Depende de**
     - FR-LOG-01.02 (la guia existe)
   * - **Requerido por**
     - FR-LOG-03.02 (el comprador puede ver el URL de seguimiento)
   * - **Test**
     - TST-FR-LOG-02.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 4-6 de UC-LOG-02
   * - 1.1.0
     - 2026-05-05
     - Descripcion reescrita en prosa. Eliminado bloque code-block Python.

.. meta::
   :artefacto: FR-PAY-01-EXT.01
   :tipo: Requisito Funcional
   :subdominio: funcionales/payments
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

.. _fr-pay-01-ext-01:

FR-PAY-01-EXT.01: Consultar planes de cuotas MSI disponibles
============================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-PAY-01-EXT.01
   * - **Nombre**
     - Consultar planes de cuotas MSI disponibles
   * - **UC Origen**
     - UC-PAY-01-EXT: Cuotas MSI Mercado Pago
   * - **Paso UC**
     - Pasos 2-3
   * - **Modulo**
     - MOD-007 PAYMENT + Gateway MP
   * - **Prioridad**
     - Media
   * - **Tipo**
     - Integracion

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE consultar los planes de cuotas disponibles en MP CUANDO el comprador activa la opcion de pagar a meses.

**Descripcion:**

Consulta a MP:

1. ``GET /v1/payment_methods/installments?amount={total}&payment_type_id=credit_card``
2. MP retorna los planes disponibles por tipo de tarjeta
3. El sistema filtra solo los planes MSI (sin interes: ``installment_rate = 0``)
4. Retorna los planes filtrados: ``{num_cuotas, monto_por_cuota, total}``
5. Si no hay planes MSI disponibles para el monto: retorna el error correspondiente

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario: Planes MSI disponibles
   DADO monto de orden que supera el minimo para MSI
   CUANDO se consultan los planes
   ENTONCES MP retorna opciones de 3, 6 y 12 meses
   Y cada plan muestra el monto exacto por cuota

   Escenario: Monto insuficiente para MSI
   DADO monto de orden por debajo del minimo de MP para MSI
   CUANDO se consultan planes
   ENTONCES no hay planes disponibles
   Y el sistema informa el monto minimo requerido


----

4. Reglas y Restricciones
--------------------------

- **BR-009 (credenciales solo en el servidor)**

- **Notas:** Los planes MSI dependen de la promocion activa de MP y del tipo de tarjeta del comprador.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-PAY-01-EXT: Cuotas MSI Mercado Pago
   * - **Depende de**
     - FR-PAY-01.01 (preferencia de MP en curso)
   * - **Requerido por**
     - FR-PAY-01-EXT.02 (crear preferencia con cuotas)
   * - **Test**
     - TST-FR-PAY-01-EXT.01 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-04-30
     - Version inicial derivada de UC-PAY-01-EXT

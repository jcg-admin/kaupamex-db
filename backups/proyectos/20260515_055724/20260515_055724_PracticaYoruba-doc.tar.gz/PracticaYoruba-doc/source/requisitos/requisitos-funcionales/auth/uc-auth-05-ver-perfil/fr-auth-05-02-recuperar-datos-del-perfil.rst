.. meta::
   :artefacto: FR-AUTH-05.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/auth
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

.. _fr-auth-05-02:

================================================================
FR-AUTH-05.02: Recuperar informacion completa del perfil del usuario
================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-AUTH-05.02
   * - **Nombre**
     - Consultar la BD y retornar los datos actuales del perfil autenticado
   * - **UC Origen**
     - UC-AUTH-05: Ver Perfil
   * - **Paso UC**
     - Paso 3 del flujo principal
   * - **Modulo**
     - MOD-001 ACCOUNTS (apps.users — UserProfileSerializer)
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE recuperar y retornar los datos actuales del perfil
   del usuario autenticado CUANDO la sesion ha sido verificada.

**Descripcion:**

El sistema identifica al usuario por el JWT de la solicitud y
recupera su registro ``User`` del repositorio con sus datos actuales.

Los campos retornados en la respuesta incluyen: ``User.id``,
``User.username``, ``User.email``, ``User.first_name``,
``User.last_name``, ``User.phone``, ``User.avatar`` (como URL
absoluta accesible públicamente), ``User.date_joined``,
``User.last_login``, el estado de verificación del email y el
porcentaje de completitud del perfil calculado en el momento de
la consulta.

Los campos ``User.password``, ``User.is_superuser`` y los campos
internos de administración nunca se incluyen en la respuesta.

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Perfil recuperado correctamente
   DADO comprador autenticado con JWT valido
   CUANDO hace GET /api/v1/auth/profile/
   ENTONCES HTTP 200 con sus datos de perfil actuales
   Y el campo password esta ausente de la respuesta
   Y profile_completeness es un numero entre 0 y 100

   Escenario 2: Datos reflejan el estado actual
   DADO usuario que cambio su nombre hace 2 minutos via UC-AUTH-06
   CUANDO consulta su perfil
   ENTONCES first_name muestra el nombre actualizado
   Y no es un dato cacheado del login

   Escenario 3: Avatar URL absoluta accesible publicamente
   DADO usuario con avatar subido
   CUANDO consulta el perfil
   ENTONCES avatar_url es https://cdn.ojayoruba.com/avatars/{id}.jpg
   Y la URL es accesible sin autenticacion (es un recurso publico)

   Escenario 4: Email no verificado — aviso en la respuesta
   DADO usuario con email_verified = False
   CUANDO consulta el perfil
   ENTONCES email_verified = false en la respuesta
   Y la respuesta incluye la accion de reenviar verificacion

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-SEC-003 (aislamiento — el perfil que se
  retorna es SIEMPRE el del usuario en el JWT, nunca de otro usuario),
  RNF-PERF-001 (P95 <= 300ms)
- **Notas:** ``profile_completeness`` se calcula en el momento de la
  consulta. Los campos que suman a la completitud son: ``first_name``,
  ``last_name``, ``phone``, ``avatar``, y tener al menos una direccion
  guardada. Cada campo vale 20% del total.

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-AUTH-05: Ver Perfil
   * - **Depende de**
     - FR-AUTH-05.01 (sesion activa verificada)
   * - **Requerido por**
     - FR-AUTH-05.03 (presentar completitud del perfil al usuario)
   * - **RNF**
     - RNF-SEC-003, RNF-PERF-001
   * - **Test**
     - TST-FR-AUTH-05.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada del paso 3 de UC-AUTH-05

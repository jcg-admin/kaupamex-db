.. meta::
   :tipo: Indice FR
   :estado: Vigente

FRs de uc-ord-02-ver-detalle-orden
======================================

**2 FRs** escritos uno por uno.

.. toctree::
   :maxdepth: 1

   fr-ord-02-01-verificar-propiedad-retornar-detalle
   fr-ord-02-02-recuperar-detalle-con-aislamiento

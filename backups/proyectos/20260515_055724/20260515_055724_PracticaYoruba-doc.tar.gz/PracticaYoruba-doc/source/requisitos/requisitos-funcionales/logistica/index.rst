.. meta::
   :tipo: Indice FR
   :estado: Vigente

Requisitos Funcionales — LOGISTICA
===================================

**7 FRs** escritos manualmente.

.. list-table::
   :widths: 60 40
   :header-rows: 1

   * - UC origen
     - FRs
   * - uc-log-01-crear-guia-envio
     - 1
   * - uc-log-02-registrar-numero-rastreo
     - 1
   * - uc-log-03-ver-estado-envio
     - 1
   * - uc-log-04-webhook-actualizacion-envio
     - 1
   * - uc-log-05-confirmar-entrega
     - 1
   * - uc-log-06-gestionar-couriers-admin
     - 1
   * - uc-log-07-reportar-problema-envio
     - 1

.. toctree::
   :maxdepth: 1
   :hidden:

   uc-log-01-crear-guia-envio/index
   uc-log-02-registrar-numero-rastreo/index
   uc-log-03-ver-estado-envio/index
   uc-log-04-webhook-actualizacion-envio/index
   uc-log-05-confirmar-entrega/index
   uc-log-06-gestionar-couriers-admin/index
   uc-log-07-reportar-problema-envio/index

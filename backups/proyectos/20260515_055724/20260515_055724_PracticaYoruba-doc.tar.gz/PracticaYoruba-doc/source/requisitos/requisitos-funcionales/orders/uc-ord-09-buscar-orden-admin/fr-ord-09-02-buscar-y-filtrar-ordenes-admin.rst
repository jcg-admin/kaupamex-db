.. meta::
   :artefacto: FR-ORD-09.02
   :tipo: Requisito Funcional
   :subdominio: funcionales/orders
   :estado: Derivado
   :version: 1.0.0
   :fecha_creacion: 2026-05-03

FR-ORD-09.02: Buscar y filtrar ordenes en el panel de administracion
====================================================================

1. Identificacion
-----------------

.. list-table::
   :widths: 25 75

   * - **ID**
     - FR-ORD-09.02
   * - **Nombre**
     - Recuperar ordenes filtradas por numero, estado, email o fecha en el panel admin
   * - **UC Origen**
     - UC-ORD-09: Buscar Orden (Admin)
   * - **Paso UC**
     - Pasos 2, 3, 4 y 5 del flujo principal
   * - **Modulo**
     - MOD-006 ORDER
   * - **Prioridad**
     - Alta
   * - **Tipo**
     - Consulta

----

2. Especificacion
-----------------

**Declaracion:**

   El sistema DEBE permitir al administrador buscar y filtrar ordenes
   por multiples criterios de forma combinada CUANDO accede al panel
   de gestion de ordenes.

**Descripcion:**

Los filtros son acumulativos (AND). El sistema construye la consulta
base sobre todas las ``Order`` con carga anticipada de ``User`` y
``OrderValue``, ordenadas por ``-Order.created_at``, y aplica los
filtros activos:

- ``order_number``: coincidencia parcial insensible a mayúsculas en
  ``Order.order_number``.
- ``status``: coincidencia exacta con ``Order.status``.
- ``email``: coincidencia parcial en ``User.email`` o en
  ``Order.guest_email`` (para órdenes de invitado).
- ``date_from``: ``Order.created_at`` ≥ fecha indicada.
- ``date_to``: ``Order.created_at`` ≤ fecha indicada.

Los resultados se paginan a 20 órdenes por página.

El endpoint es de solo acceso admin (``IsAdminUser`` en DRF).

----

3. Criterio de Aceptacion
--------------------------

::

   Escenario 1: Busqueda por numero de orden parcial
   DADO admin que busca "20260503"
   CUANDO GET /api/v1/admin/orders/?order_number=20260503
   ENTONCES retorna todas las ordenes del dia 2026-05-03

   Escenario 2: Filtro combinado estado + fecha
   DADO admin que busca ordenes SHIPPED del ultimo mes
   CUANDO GET /api/v1/admin/orders/?status=SHIPPED&date_from=2026-04-01
   ENTONCES retorna solo ordenes enviadas desde el 1 de abril
   Y el filtro es AND (ambas condiciones se cumplen)

   Escenario 3: Busqueda de ordenes de invitado por email
   DADO orden creada por un visitante sin cuenta con email "juan@ejemplo.com"
   CUANDO el admin busca por email "juan@ejemplo.com"
   ENTONCES la orden aparece en los resultados (guest_email coincide)

----

4. Reglas y Restricciones
--------------------------

- **RNF aplicables:** RNF-PERF-001 (P95 <= 500ms incluyendo los filtros
  compuestos — los campos email y status deben estar indexados)

----

5. Trazabilidad
---------------

.. list-table::
   :widths: 20 80

   * - **UC**
     - UC-ORD-09: Buscar Orden Admin
   * - **Requerido por**
     - FR-ORD-07.02 (el admin necesita encontrar la orden antes de procesarla)
   * - **Test**
     - TST-FR-ORD-09.02 (pendiente)

----

6. Historial
------------

.. list-table::
   :widths: 15 15 70
   :header-rows: 1

   * - Version
     - Fecha
     - Cambio
   * - 1.0.0
     - 2026-05-03
     - Version inicial derivada de los pasos 2-5 de UC-ORD-09

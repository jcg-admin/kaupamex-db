.. meta::
   :artefacto: BReq-010
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_010:

=========================================================
BReq-010: Auditabilidad completa de datos y transacciones
=========================================================

Categoria
---------

Regulatorio

Enunciado
---------

Todos los modelos del sistema DEBEN tener timestamps de creacion y modificacion (created_at, updated_at). Las transacciones de orden y pago DEBEN ser trazables con registro completo del estado y los cambios.

Justificacion
-------------

Constraint R1 del arc42: datos auditables para deteccion de fraude, investigacion y compliance legal. AbstractBaseModel garantiza que todos los modelos tienen timestamps. Las ordenes son snapshots inmutables por diseno (BR-005).

Criterio de aceptacion
-----------------------

- Todos los modelos heredan de AbstractBaseModel (BR-013).
- created_at y updated_at existen en todas las tablas.
- El historial de estados de una orden es trazable.
- Los pagos tienen registro de la respuesta del gateway.
- No se pueden modificar OrderItem, OrderAddress ni OrderValue post-creacion.

Origen
------

- **Fuente arc42:** Constraint R1 AUDITABILITY, Quality Goal CONSISTENCY
- **Stakeholders:** CTO, DevOps
- **UCs que lo realizan:** UC-ORD-04, UC-ORD-05, UC-ORD-06

Reglas de negocio asociadas
-----------------------------

BR-005, BR-013

.. meta::
   :artefacto: BReq-011
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_011:

=======================================================
BReq-011: Sistema operable por equipo de 1 a 2 personas
=======================================================

Categoria
---------

Operacion

Enunciado
---------

El sistema DEBE poder ser operado, mantenido y desplegado por un equipo de 1 a 2 personas sin conocimiento especializado de infraestructura cloud. Los despliegues deben ser simples y reproducibles.

Justificacion
-------------

El stack (el servidor web + ORM + cache en BD, sin contenedores ni cache externo) fue elegido precisamente por su simplicidad operativa. El bootstrap.sh automatiza el setup. El despliegue es git pull + systemctl restart apache2.

Criterio de aceptacion
-----------------------

- El entorno se configura con un solo script: bash scripts/bootstrap.sh.
- El despliegue de una nueva version toma menos de 5 minutos.
- Los crons (clearsessions, flushexpiredtokens) son configurables sin codigo.
- Los logs de Django y Apache estan en rutas conocidas y rotados.
- Un nuevo desarrollador puede tener el entorno local en menos de 30 min.

Origen
------

- **Fuente arc42:** Goal #6 OPERATIONS, Stakeholder DevOps, Stack v2.0.0
- **Stakeholders:** CEO, DevOps, Backend
- **UCs que lo realizan:** N/A (operacion)

Reglas de negocio asociadas
-----------------------------

BR-014

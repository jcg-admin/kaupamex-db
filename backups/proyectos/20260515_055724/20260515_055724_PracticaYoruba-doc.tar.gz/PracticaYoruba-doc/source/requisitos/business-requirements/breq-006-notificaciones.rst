.. meta::
   :artefacto: BReq-006
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_006:

=================================================
BReq-006: Notificaciones de confirmacion de orden
=================================================

Categoria
---------

Comunicacion

Enunciado
---------

El sistema DEBE enviar una notificacion de confirmacion al cliente cuando una orden es creada y cuando el pago es confirmado por el gateway. El canal de notificacion en MVP es email.

Justificacion
-------------

La confirmacion de orden es parte minima de la experiencia de compra. Un cliente que no recibe confirmacion desconfia de la transaccion y puede generar una disputa de cargo. El email es el canal mas barato y confiable sin necesidad de servicios adicionales.

Criterio de aceptacion
-----------------------

- El cliente recibe email al crear la orden (estado: pendiente_pago).
- El cliente recibe email cuando el pago es confirmado por webhook.
- El email incluye numero de orden, items comprados y total.
- El envio no bloquea la respuesta del API (asincrono via cron).

Origen
------

- **Fuente arc42:** Plan 97 UC DOD, Modulo NEWSLETTER
- **Stakeholders:** CEO, Backend
- **UCs que lo realizan:** UC-ORD-04, UC-PAY-03

Reglas de negocio asociadas
-----------------------------

BR-013

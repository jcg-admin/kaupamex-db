.. meta::
   :artefacto: BReq-002
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_002:

======================================================
BReq-002: Procesamiento de pagos reales desde Sprint 0
======================================================

Categoria
---------

Negocio / Financiero

Enunciado
---------

El sistema DEBE procesar pagos reales con Mercado Pago (primario) y PayPal (secundario) desde el primer sprint de produccion. No se permite lanzar con pagos simulados o en modo sandbox.

Justificacion
-------------

El negocio necesita generar ingresos desde el lanzamiento. Un MVP con pagos en sandbox no valida el modelo de negocio. Mercado Pago domina en Mexico con mas de 101 metodos de pago (tarjeta, OXXO, SPEI, MSI). PayPal es requerido porque la cuenta de ojayoruba.com ya tiene PayPal activo en modo produccion.

Criterio de aceptacion
-----------------------

- POST /api/v1/payments/ con provider=mercado_pago procesa un pago real.
- POST /api/v1/payments/ con provider=paypal procesa un pago real.
- El webhook actualiza el estado de la orden al recibir confirmacion.
- Ningun numero de tarjeta toca el servidor de PracticaYoruba.

Origen
------

- **Fuente arc42:** Goal #1 REVENUE, Constraint O3 Payment Gateway, ADR-004
- **Stakeholders:** CEO, Backend Senior
- **UCs que lo realizan:** UC-PAY-01, UC-PAY-02, UC-PAY-03

Reglas de negocio asociadas
-----------------------------

BR-006, BR-007, BR-008, BR-009

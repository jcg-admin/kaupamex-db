.. meta::
   :artefacto: BReq-004
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_004:

==========================================================
BReq-004: Flujo de checkout completo en menos de 2 minutos
==========================================================

Categoria
---------

Experiencia de usuario

Enunciado
---------

El sistema DEBE permitir al usuario completar el proceso completo de checkout (desde ver el carrito hasta recibir confirmacion de orden) en menos de 2 minutos en condiciones normales de red.

Justificacion
-------------

Un checkout largo aumenta la tasa de abandono. Segun el arc42 de referencia, el objetivo de eficiencia (Goal #4) es checkout menor a 2 minutos. La friction en pagos es la causa principal de abandono en ecommerce en Mexico.

Criterio de aceptacion
-----------------------

- El flujo carrito -> direccion -> pago -> confirmacion tiene menos de 5 pasos.
- La API de checkout responde en menos de 500ms (p95).
- El token de pago se genera en menos de 1 segundo.
- La pagina de confirmacion carga en menos de 800ms.

Origen
------

- **Fuente arc42:** Goal #4 EFFICIENCY, Quality Goal PERFORMANCE
- **Stakeholders:** CEO, Frontend, Backend
- **UCs que lo realizan:** UC-CART-02, UC-ORD-01, UC-ORD-04, UC-PAY-01

Reglas de negocio asociadas
-----------------------------

BR-001, BR-002, BR-005

.. meta::
   :artefacto: BReq-013
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_013:

==============================================================
BReq-013: Canales de comunicacion accesibles sin autenticacion
==============================================================

Categoria
---------

Negocio

Enunciado
---------

El sistema DEBE proveer canales para que un visitante anonimo pueda hacer preguntas sobre productos, enviar mensajes de contacto general y suscribirse al newsletter, sin necesidad de crear una cuenta.

Justificacion
-------------

Un cliente potencial que tiene dudas sobre un producto Yoruba antes de comprar necesita poder preguntar sin friction. La religion Yoruba tiene terminologia especializada que el cliente puede no conocer. Facilitar la comunicacion pre-compra aumenta la conversion.

Criterio de aceptacion
-----------------------

- POST /api/v1/contact/ acepta peticiones sin JWT.
- POST /api/v1/questions/ acepta peticiones sin JWT.
- POST /api/v1/newsletter/ acepta peticiones sin JWT.
- Ninguno de los tres modelos tiene user_id como campo obligatorio.

Origen
------

- **Fuente arc42:** Modulo CONTACT, Modulo QUESTION, Modulo NEWSLETTER
- **Stakeholders:** CEO
- **UCs que lo realizan:** UC-COM-01, UC-COM-02, UC-COM-03

Reglas de negocio asociadas
-----------------------------

BR-010

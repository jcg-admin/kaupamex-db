.. meta::
   :artefacto: BReq-005
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_005:

=======================================
BReq-005: Compra sin registro de cuenta
=======================================

Categoria
---------

Negocio

Enunciado
---------

El sistema DEBE permitir que un visitante anonimo (guest) complete una compra sin necesidad de crear una cuenta. El registro de cuenta es opcional y se puede ofrecer despues de la compra.

Justificacion
-------------

Obligar al registro antes de comprar reduce la conversion. Un cliente nuevo que solo quiere comprar un producto puntual no debe tener friction adicional. El registro se puede ofrecer como beneficio post-compra (para rastrear ordenes, repetir compras).

Criterio de aceptacion
-----------------------

- Un visitante sin cuenta puede agregar al carrito.
- Un visitante sin cuenta puede completar el checkout.
- Order.user_id es null para ordenes de guest.
- El sistema no solicita login en ningun paso del checkout.

Origen
------

- **Fuente arc42:** Goal #1 REVENUE (conversion), BR-004 del proyecto
- **Stakeholders:** CEO
- **UCs que lo realizan:** UC-CART-01, UC-ORD-01, UC-ORD-04

Reglas de negocio asociadas
-----------------------------

BR-004, BR-011, BR-013

.. meta::
   :artefacto: BReq-008
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_008:

============================================
BReq-008: Rendimiento: API p95 menor a 500ms
============================================

Categoria
---------

Calidad

Enunciado
---------

El 95% de las peticiones a la API DEBEN responderse en menos de 500ms en condiciones de carga normal (hasta 100 usuarios concurrentes en MVP). Las paginas del catalogo con cache deben responder en menos de 100ms.

Justificacion
-------------

Criterio de performance del arc42 de referencia: p95 < 500ms, p50 < 150ms. El rendimiento afecta directamente la conversion: un checkout rapido reduce el abandono. Con DatabaseCache y F() expressions los endpoints criticos alcanzan este objetivo.

Criterio de aceptacion
-----------------------

- GET /api/v1/products/ (cache hit): < 100ms.
- POST /api/v1/auth/login/: < 300ms.
- POST /api/v1/orders/: < 800ms (incluye validacion de stock).
- p95 global de todos los endpoints: < 500ms.

Origen
------

- **Fuente arc42:** Quality Goal PERFORMANCE, Plan 97 UC DOD
- **Stakeholders:** CTO, Backend
- **UCs que lo realizan:** Todos los endpoints

Reglas de negocio asociadas
-----------------------------

BR-014

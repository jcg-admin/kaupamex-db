.. meta::
   :artefacto: BReq-007
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_007:

===========================================
BReq-007: Disponibilidad del servicio 99.5%
===========================================

Categoria
---------

Calidad

Enunciado
---------

El sistema DEBE estar disponible el 99.5% del tiempo medido mensualmente. Eso equivale a un maximo de 3.6 horas de inactividad no planificada por mes.

Justificacion
-------------

Disponibilidad del arc42 de referencia: SLO 99.5%. En MVP con un solo VPS, un reinicio manual ante falla tiene RTO de 15-30 minutos. Un incidente de 30 minutos por mes mantiene el SLO. En Phase 2 (3 VPS + DNS round-robin) la disponibilidad mejora a 99%+ sin LB adicional.

Criterio de aceptacion
-----------------------

- El endpoint /api/health/ responde 200 en condiciones normales.
- El sistema tiene monitoreo de uptime con alertas.
- El tiempo de recuperacion ante falla (RTO) es menor a 30 minutos.
- La disponibilidad mensual medida es mayor o igual a 99.5%.

Origen
------

- **Fuente arc42:** Goal #6 OPERATIONS, Quality Goal AVAILABILITY
- **Stakeholders:** CEO, DevOps
- **UCs que lo realizan:** Todos

Reglas de negocio asociadas
-----------------------------

BR-014, BR-015

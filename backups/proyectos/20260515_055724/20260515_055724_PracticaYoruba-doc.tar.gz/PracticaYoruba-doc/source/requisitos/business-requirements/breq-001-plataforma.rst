.. meta::
   :artefacto: BReq-001
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_001:

==========================================================
BReq-001: Plataforma de venta en linea de productos Yoruba
==========================================================

Categoria
---------

Negocio

Enunciado
---------

El sistema DEBE proveer una plataforma de comercio electronico especializada en productos de la practica de la religion y tradicion Yoruba, accesible desde el dominio ojayoruba.com.

Justificacion
-------------

PracticaYoruba es el canal digital principal del negocio. Sin una plataforma de venta en linea funcional no hay negocio. El nicho (productos Yoruba en Mexico) no tiene competencia directa digital consolidada, lo que representa una ventana de oportunidad.

Criterio de aceptacion
-----------------------

- El sitio esta accesible en ojayoruba.com con HTTPS.
- Un visitante puede navegar el catalogo sin autenticacion.
- Un visitante puede completar una compra desde el catalogo.

Origen
------

- **Fuente arc42:** Goal #1 REVENUE, Goal #3 ARCHITECTURE
- **Stakeholders:** CEO, Equipo de desarrollo
- **UCs que lo realizan:** UC-CAT-01, UC-CAT-02, UC-CART-01, UC-ORD-01

Reglas de negocio asociadas
-----------------------------

BR-003, BR-004, BR-013

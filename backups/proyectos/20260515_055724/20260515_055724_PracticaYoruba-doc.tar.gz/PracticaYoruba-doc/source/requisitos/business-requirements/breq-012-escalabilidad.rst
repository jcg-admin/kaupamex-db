.. meta::
   :artefacto: BReq-012
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_012:

=============================================================
BReq-012: Escalabilidad horizontal sin cambio de arquitectura
=============================================================

Categoria
---------

Calidad

Enunciado
---------

El sistema DEBE poder escalar horizontalmente agregando instancias VPS adicionales con DNS round-robin, sin cambios en el codigo de aplicacion ni en la arquitectura central.

Justificacion
-------------

Goal #5 STRATEGIC del arc42: arquitectura preparada para crecimiento. En Phase 2, se agregan 2 VPS adicionales con la misma configuracion Apache + mod_wsgi. DatabaseCache es compartido porque todos los workers usan el repositorio. No se necesita un load balancer externo.

Criterio de aceptacion
-----------------------

- Agregar un segundo VPS requiere solo replicar la configuracion.
- El DNS round-robin distribuye trafico sin load balancer adicional.
- DatabaseCache funciona correctamente con multiples VPS (BD compartida).
- La sesion de usuario es portable entre instancias (SESSION_ENGINE=db).

Origen
------

- **Fuente arc42:** Goal #5 STRATEGIC, Goal #2 USERS, Quality Goal SCALABILITY
- **Stakeholders:** CTO, DevOps
- **UCs que lo realizan:** N/A (infraestructura)

Reglas de negocio asociadas
-----------------------------

BR-014

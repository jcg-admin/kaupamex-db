.. meta::
   :artefacto: BReq-009
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_009:

========================================================
BReq-009: Seguridad de transacciones y datos de usuarios
========================================================

Categoria
---------

Seguridad

Enunciado
---------

El sistema DEBE proteger los datos de los usuarios y las transacciones financieras. Ningun numero de tarjeta o dato de pago sensible debe almacenarse en los servidores de PracticaYoruba. La autenticacion usa JWT con blacklist.

Justificacion
-------------

Constraint R1 del arc42: datos deben ser auditables. La tokenizacion de tarjetas es responsabilidad del gateway (Mercado Pago, PayPal). PCI-DSS compliance se delega completamente al gateway. JWT con blacklist garantiza que el logout invalida el token real.

Criterio de aceptacion
-----------------------

- HTTPS obligatorio en todos los endpoints.
- Ningun dato de tarjeta se recibe ni almacena en el backend.
- Los tokens JWT expirados o revocados son rechazados (401).
- Las credenciales secretas estan en .env, no en el codigo.
- Rate limiting activo en el endpoint de login (BR-015).
- Django ORM previene SQL injection (sin raw SQL).

Origen
------

- **Fuente arc42:** Quality Goal SECURITY, Constraint R1 AUDITABILITY, Constraint O3
- **Stakeholders:** CTO, Backend, DevOps
- **UCs que lo realizan:** UC-AUTH-02, UC-AUTH-03, UC-PAY-01, UC-PAY-02

Reglas de negocio asociadas
-----------------------------

BR-009, BR-015

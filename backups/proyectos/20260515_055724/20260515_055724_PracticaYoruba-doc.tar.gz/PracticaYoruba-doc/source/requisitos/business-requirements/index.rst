.. meta::
   :artefacto: INDEX-BREQ
   :tipo: Indice
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30

========================
Business Requirements
========================

Requisitos de negocio de alto nivel de PracticaYoruba.
Los BReqs definen **que** necesita el negocio, sin prescribir
**como** se implementa. Cada BReq se realiza a traves de uno o
mas Casos de Uso.

Fuentes de este catalogo: arc42 de referencia TiendaMax (Business Goals,
Quality Goals, Constraints), modelo de negocio PracticaYoruba v0.4.0,
plan de desarrollo 97 UC y stack definitivo del proyecto.

.. list-table:: Catalogo de Business Requirements
   :widths: 12 25 15 48
   :header-rows: 1

   * - ID
     - Titulo
     - Categoria
     - Enunciado resumido
   * - BReq-001
     - Plataforma de venta en linea
     - Negocio
     - El sistema debe proveer una plataforma de ecommerce en ojayoruba.com
   * - BReq-002
     - Pagos reales desde Sprint 0
     - Financiero
     - Mercado Pago + PayPal operativos desde el primer sprint de produccion
   * - BReq-003
     - Catalogo con variantes Yoruba
     - Producto
     - Catalogo con ProductSize, categorias jerarquicas y soporte utf8mb4
   * - BReq-004
     - Checkout en menos de 2 minutos
     - Experiencia
     - Flujo completo de compra en menos de 2 minutos
   * - BReq-005
     - Compra sin registro
     - Negocio
     - Guest checkout sin obligar a crear cuenta
   * - BReq-006
     - Notificaciones de orden
     - Comunicacion
     - Email de confirmacion al crear orden y al confirmar pago
   * - BReq-007
     - Disponibilidad 99.5%
     - Calidad
     - Maximo 3.6 horas de inactividad no planificada por mes
   * - BReq-008
     - Rendimiento p95 < 500ms
     - Calidad
     - 95% de peticiones respondidas en menos de 500ms
   * - BReq-009
     - Seguridad de transacciones
     - Seguridad
     - Ningun dato de tarjeta en servidores, JWT con blacklist, HTTPS
   * - BReq-010
     - Auditabilidad completa
     - Regulatorio
     - Todos los modelos con timestamps, ordenes trazables e inmutables
   * - BReq-011
     - Operable por equipo pequeno
     - Operacion
     - Setup y despliegue por 1-2 personas sin expertise cloud
   * - BReq-012
     - Escalabilidad horizontal
     - Calidad
     - Agregar VPS con DNS round-robin sin cambios de codigo
   * - BReq-013
     - Comunicacion guest-friendly
     - Negocio
     - Contact, Question y Newsletter accesibles sin autenticacion
   * - BReq-014
     - Interfaz de administracion
     - Operacion
     - Admin Django para gestion de catalogo, ordenes y configuracion
   * - BReq-015
     - Mexico, MXN, 1 zona de envio
     - Negocio
     - MVP exclusivamente en Mexico con moneda MXN e IVA 16%

.. toctree::
   :maxdepth: 1
   :hidden:

   breq-001-plataforma
   breq-002-pagos
   breq-003-catalogo
   breq-004-checkout
   breq-005-guest
   breq-006-notificaciones
   breq-007-disponibilidad
   breq-008-rendimiento
   breq-009-seguridad
   breq-010-auditoria
   breq-011-operacion
   breq-012-escalabilidad
   breq-013-comunicacion
   breq-014-administracion
   breq-015-mercado

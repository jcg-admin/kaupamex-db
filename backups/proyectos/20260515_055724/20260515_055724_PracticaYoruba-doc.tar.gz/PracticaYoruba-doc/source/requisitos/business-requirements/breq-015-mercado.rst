.. meta::
   :artefacto: BReq-015
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_015:

================================================================
BReq-015: Mercado objetivo: Mexico, MXN, una zona de envio (MVP)
================================================================

Categoria
---------

Negocio

Enunciado
---------

El MVP del sistema opera exclusivamente en Mexico, con moneda MXN, una sola zona de envio, y con capacidad para hasta 1,000 usuarios. La expansion geografica es posterior al MVP.

Justificacion
-------------

Restringir el alcance del MVP a un mercado y moneda simplifica radicalmente el sistema: un solo tax_rate (IVA 16%), un solo metodo de envio, un solo idioma. El negocio ojayoruba.com opera en Mexico. La arquitectura del arc42 es LATAM-ready para expansion futura.

Criterio de aceptacion
-----------------------

- SiteSettings.tax_rate = 0.16 (IVA Mexico).
- SiteSettings.currency = MXN.
- Solo existe un ShippingMethod activo en MVP.
- El catalogo, el admin y todos los textos del sistema estan en espanol.
- La BD usa utf8mb4 para soportar caracteres Yoruba en nombres de productos.

Origen
------

- **Fuente arc42:** Goal #5 STRATEGIC (LATAM-ready), Constraint BUSINESS_REVENUE
- **Stakeholders:** CEO
- **UCs que lo realizan:** UC-ORD-01, UC-ORD-02

Reglas de negocio asociadas
-----------------------------

BR-001, BR-002

.. meta::
   :artefacto: BReq-014
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_014:

=============================================================
BReq-014: Interfaz de administracion para gestion del negocio
=============================================================

Categoria
---------

Operacion

Enunciado
---------

El sistema DEBE proveer una interfaz de administracion para gestionar el catalogo de productos, variantes, descuentos, ordenes y configuracion del sitio sin necesidad de acceso directo a la base de datos.

Justificacion
-------------

La interfaz de administracion (con personalizaciones) permite al equipo no tecnico gestionar el catalogo y las ordenes. La alternativa (acceso directo a el repositorio) es riesgosa e impracticable para operacion diaria del negocio.

Criterio de aceptacion
-----------------------

- /admin/ esta disponible y protegido (solo is_staff=True).
- Desde /admin/ se pueden crear, editar y eliminar productos.
- Desde /admin/ se pueden ver y actualizar ordenes.
- Desde /admin/ se puede gestionar SiteSettings (IVA, gateways, envio).
- El acceso a /admin/ requiere HTTPS.

Origen
------

- **Fuente arc42:** Goal #6 OPERATIONS, Modulo SITE_SETTINGS, Modulo DASHBOARD
- **Stakeholders:** CEO
- **UCs que lo realizan:** N/A (admin)

Reglas de negocio asociadas
-----------------------------

BR-012, BR-013

.. meta::
   :artefacto: BReq-003
   :tipo: Business Requirement
   :estado: Vigente
   :version: 1.0.0
   :fecha_creacion: 2026-04-30
   :fuente: arc42 TiendaMax + Modelo de Negocio PracticaYoruba

.. _breq_003:

============================================================================
BReq-003: Catalogo de productos con variantes especificas del dominio Yoruba
============================================================================

Categoria
---------

Producto

Enunciado
---------

El sistema DEBE gestionar un catalogo de productos con soporte para variantes de tamano y presentacion (ProductSize), categorias jerarquicas, marcas, imagenes multiples por producto y nombres en lengua Yoruba (caracteres especiales incluidos).

Justificacion
-------------

Los productos del dominio Yoruba tienen nombres en lengua Yoruba con caracteres especiales (tildes, diacriticos). La BD usa utf8mb4 para soportarlos. Las variantes son necesarias porque un mismo producto puede venir en diferentes tamanos o presentaciones con diferente precio.

Criterio de aceptacion
-----------------------

- Un producto con nombre en Yoruba se guarda y muestra correctamente.
- Un producto puede tener 1 a N imagenes asociadas.
- Un producto puede tener variantes (ProductSize) con precio propio.
- Las categorias pueden ser jerarquicas (padre-hijo).
- El catalogo es navegable sin autenticacion.

Origen
------

- **Fuente arc42:** Goal #3 ARCHITECTURE, Modulo CATALOGUE, Modulo CHARTSIZE
- **Stakeholders:** CEO, Backend
- **UCs que lo realizan:** UC-CAT-01, UC-CAT-02, UC-CAT-03

Reglas de negocio asociadas
-----------------------------

BR-001, BR-002, BR-014
